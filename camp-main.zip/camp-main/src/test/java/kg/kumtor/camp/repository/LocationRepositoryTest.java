//package kg.kumtor.camp.repository;
//
//import kg.kumtor.camp.dto.reference.LocationDto;
//import kg.kumtor.camp.model.Location;
//import lombok.AllArgsConstructor;
//import org.junit.jupiter.api.Disabled;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
//
//import java.time.LocalDateTime;
//import java.util.*;
//
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.jupiter.api.Assertions.*;
//
//@DataJpaTest
//class LocationRepositoryTest {
//
//    @Autowired
//    private LocationRepository repositoryTest;
//
//    @Test
//    void findAllByIsSiteLocation() {
//
//        //given
//        Location location = new Location(
//                "TestUser",
//                LocalDateTime.now(),
//                1,
//                "City",
//                "Город",
//                (short) 0,
//                "A");
//        repositoryTest.save(location);
//
//        //when
//        List<LocationDto> allByIsSiteLocation = repositoryTest.findAllByIsSiteLocation((short) 0);
//        LocationDto locationDto = new LocationDto(location);
//
//        //then
//        assertThat(allByIsSiteLocation).contains(locationDto);
//    }
//
//    @Test
//    @Disabled
//    void findAllByIdIn() {
//
//        // given
//        Location location1 = new Location(
//                "TestUser1",
//                LocalDateTime.now(),
//                1,
//                "City1",
//                "Город1",
//                (short) 0,
//                "C");
//        Location location2 = new Location(
//                "TestUser2",
//                LocalDateTime.now(),
//                2,
//                "City2",
//                "Город2",
//                (short) 1,
//                "A");
//        Location location3 = new Location(
//                "TestUser3",
//                LocalDateTime.now(),
//                3,
//                "City3",
//                "Город3",
//                (short) 0,
//                "C");
//        repositoryTest.saveAll(List.of(location1, location2, location3));
//
//        // when
//        List<LocationDto> allByIdIn = repositoryTest.findAllByIdIn(List.of(1, 3));
//
//        LocationDto locationDto1 = new LocationDto(location1);
//        LocationDto locationDto2 = new LocationDto(location2);
//        LocationDto locationDto3 = new LocationDto(location3);
//        List<LocationDto> locationDtoList = List.of(locationDto1, locationDto3);
//
//        //then
//        assertThat(allByIdIn).isEqualTo(locationDtoList);
//    }
//
//    @Test
//    @Disabled
//    void getLocationById() {
//    }
//}