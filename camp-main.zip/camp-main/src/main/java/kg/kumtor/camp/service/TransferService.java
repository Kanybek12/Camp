package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.transfer.*;
import kg.kumtor.camp.dto.transfer.TransferApplicationDto;
import kg.kumtor.camp.dto.transfer.update.UpdateDescentApplicationDTO;
import kg.kumtor.camp.dto.transfer.vahta.BusVahtaApplicationsDTO;
import kg.kumtor.camp.dto.transfer.vahta.VahtaApplicationStatisticsDto;
import kg.kumtor.camp.dto.transfer.vahta.VahtaApplicationStatusStatisticsDto;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface TransferService {
    ResponseDTO checkInTransfer(TransferCheckInDto transferCheckInDto) throws ApiException;
    List<Map<String, Object>> saveTransfer(TransferApplicationDto transferApplicationDto)throws ApiException;
    List<Map<String, Object>> getDepartmentsForTransfer() throws ApiException;
    List<TransferTypeDto> getTransferType();
    List<TransferInfoForDriverDto> getTransferInfoForDriver(LocalDate transferDate, Integer transferType, Integer location)throws ApiException;
    PersonalInfoDTO getPersonalInfo(int empCode) throws ApiException;
    PersonalTransferDTO getPersonalTransferAscent(int empCode) throws ApiException;
    PersonalTransferDTO getPersonalTransferDescent(int empCode) throws ApiException;
    ResponseDTO updatePersonalTransferAscent(PersonalTransferDTO info) throws ApiException;
    ResponseDTO updatePersonalTransferDescent(PersonalTransferDTO info) throws ApiException;
    boolean approveTransfer(List<TransferApproveDto> transferApproveDtos)throws ApiException;
    ResponseDTO approveTransferRequest(List<TransferApproveDto> transferApproveDtos)throws ApiException;
    Map<String, Object> getTransferApplicationsForApprove(Integer empCode)throws ApiException;
    VahtaApplicationStatisticsDto getVahtaApplicationStatistics(LocalDate date)throws ApiException;
    VahtaApplicationStatusStatisticsDto getVahtaApplicationStatusStatistics(LocalDate date)throws ApiException;
    PageableResponseDTO getVahtaApplicationList(Pageable pageable, LocalDate date, Integer empCode,
                                                Integer applicationType, Integer visitorType) throws ApiException;
    PageableResponseDTO getReceivedVahtaApplicationList(Pageable pageable, LocalDate date, Integer empCode,
                                                Integer applicationType, Integer visitorType) throws ApiException;
    ResponseDTO approveVahtaApplication(long id) throws ApiException;
    ResponseDTO rejectVahtaApplication(long id) throws ApiException;
    ResponseDTO undoVahtaApplication(long id) throws ApiException;
    PageableResponseDTO getBusApplicationList(Pageable pageable, LocalDate date, Integer empCode,
                                              Integer applicationType, Integer visitorType) throws ApiException;
    PageableResponseDTO getReceivedBusApplicationList(Pageable pageable, LocalDate date, Integer empCode,
                                              Integer applicationType, Integer visitorType) throws ApiException;
    ResponseDTO approveBusApplication(long id) throws ApiException;
    ResponseDTO rejectBusApplication(long id) throws ApiException;
    ResponseDTO undoBusApplication(long id) throws ApiException;
    PageableResponseDTO getMyApplications(Pageable pageable, int empCode, String dateCreated, String plannedDate,
                                          String applicationType) throws ApiException;
    PageableResponseDTO getApplicationsForOthers(Pageable pageable, int empCode, String dateCreated, String plannedDate,
                                                 String applicationType) throws ApiException;
    ResponseDTO cancelMyApplications(List<CancelMyApplicationDTO> applications) throws ApiException;

    List<TransferInfoDto> getTransferInfoList(LocalDate transferDate, Integer transferType, Integer location,Integer empCode, String fio) throws ApiException;
    ResponseDTO updateDescentApplication(long id, UpdateDescentApplicationDTO application) throws ApiException;

    PageableResponseDTO getAllTransferList(Pageable pageable, LocalDate date, Integer empCode,
                                           Integer applicationType, Integer visitorType, Integer status) throws ApiException;
}
