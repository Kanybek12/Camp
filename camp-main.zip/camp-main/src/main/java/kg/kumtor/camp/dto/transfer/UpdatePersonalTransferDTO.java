package kg.kumtor.camp.dto.transfer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdatePersonalTransferDTO {

    private int empCode;
    private Boolean busTransfer;
    private Integer busFrom = null;
    private Integer busTo = null;
    private Integer vahtaFrom = null;
    private Integer vahtaTo = null;
    private Integer carFrom = null;
    private Integer carTo = null;
    private String carNumber;
    private String carModel;
    private String driver;
    private Integer carTypeId = null;
}
