package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.CostCenterDTO;
import kg.kumtor.camp.dto.EmployeeGuestDto;
import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.reference.*;
import kg.kumtor.camp.dto.reference.crud.*;
import kg.kumtor.camp.dto.transfer.MyApplicationTypeDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.BlockRepository;
import kg.kumtor.camp.service.EmployeeService;
import kg.kumtor.camp.service.UtilityService;
import lombok.AllArgsConstructor;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.*;


@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@AllArgsConstructor
@RequestMapping("/utility")
@RestController
public class UtilityController {
    private final UtilityService utilityService;
    private final BlockRepository blockRepository;
    private final EmployeeService employeeService;
    @GetMapping(value = "/get-location")
    public ResponseEntity<List<CampDto>> getLocation() {
        return ResponseEntity.ok(utilityService.getLocation());
    }

    @GetMapping(value = "/get-block")
    public ResponseEntity<List<BlockDto>> getBlock(@RequestParam(value = "location", required = false) Integer locationId) {
        if (locationId != null){
            return ResponseEntity.ok(utilityService.getBlockByLocationId(locationId));
        } else {
            return ResponseEntity.ok(blockRepository.findAllBlocks());
        }
    }
    @GetMapping(value = "/get-gender")
    public ResponseEntity<List<GenderDto>> getGender() {
        return ResponseEntity.ok(utilityService.getGender());
    }

    @GetMapping(value = "/get-schedule")
    public ResponseEntity<List<ScheduleDTO>> getSchedule() {
        List<ScheduleDTO> scheduleDTOList = List.of(
                ScheduleDTO.builder().id(0).title("Не по графику").build(),
                ScheduleDTO.builder().id(1).title("По графику").build()
        );
        return ResponseEntity.ok(scheduleDTOList);
    }

    @GetMapping(value = "/get-departments")
    public ResponseEntity<List<DepartmentDTO>> getDepartments() throws ApiException {
        List<DepartmentDTO> departments = utilityService.getDepartments();
        return ResponseEntity.ok(departments);
    }

    @GetMapping(value = "/get-room/quantity")
    public ResponseEntity<List<Map<String,Object>>> getRoomQuantity() {
        return ResponseEntity.ok(utilityService.getQuantityOfBedInRoom());
    }

    @GetMapping("/get-visitor-types")
    public ResponseEntity<List<VisitorTypeDTO>> getVisitorTypes() throws ApiException {
        return ResponseEntity.ok(utilityService.getVisitorTypes());
    }

    @GetMapping("/get-job-titles")
    public ResponseEntity<List<JobTitleDTO>> getJobTitles() throws ApiException {
        return ResponseEntity.ok(utilityService.getJobTitles());
    }

    @GetMapping("/get-employees")
    public ResponseEntity<List<EmployeeDTO>> getEmployees() throws ApiException {
        return ResponseEntity.ok(utilityService.getEmployees());
    }

    @GetMapping("/get-beds")
    public ResponseEntity<List<BedReferenceDTO>> getBeds(
            @RequestParam(value = "camp-id", required = false, defaultValue = "%%") String campId,
            @RequestParam(value = "block-id", required = false, defaultValue = "%%") String blockId,
            @RequestParam(value = "room-id", required = false, defaultValue = "%%") String roomId,
            @RequestParam(value = "type-id", required = false, defaultValue = "%%") String bedTypeId,
            @RequestParam(value = "status", required = false, defaultValue = "%%") String status
            ) throws ApiException {
        return ResponseEntity.ok(utilityService.getBedReference(campId, blockId, roomId, bedTypeId, status));
    }

    @GetMapping("/get-bed-types")
    public ResponseEntity<List<BedTypeDTO>> getBedType() throws ApiException {
        return ResponseEntity.ok(utilityService.getBedTypes());
    }

    @PostMapping("/add-bed")
    public ResponseDTO addNewBed(@RequestBody int bedTypeId) throws ApiException {
        return utilityService.addBed(bedTypeId);
    }

    @GetMapping("/get-stock-beds")
    public ResponseEntity<List<Map<String,Object>>> getBedListInStock() throws ApiException {
        return ResponseEntity.ok(utilityService.getBedsInStock());
    }
    @GetMapping(value = "/application-type")
    public ResponseEntity<List<ApplicationTypeDto>> getApplicationTypeList() {
        return ResponseEntity.ok(utilityService.getApplicationTypeList());
    }

    @GetMapping("/my-application-type")
    public ResponseEntity<List<MyApplicationTypeDTO>> getMyApplicationTypeList() {
        return ResponseEntity.ok(utilityService.getMyApplicationTypeList());
    }


    @GetMapping(value = "/car-type")
    public ResponseEntity<List<CarTypeDto>> getCarTypeList() {
        return ResponseEntity.ok(utilityService.getCarTypeList());
    }
    @PostMapping("/add-location")
    public ResponseEntity<ResponseDTO> createLocation(@RequestBody LocationCRUDDto locationCRUDDto) throws ApiException {
        return ResponseEntity.ok(utilityService.createLocation(locationCRUDDto));
    }
    @PutMapping("/edit-location")
    public ResponseEntity<ResponseDTO> editLocation(@RequestBody LocationCRUDDto locationCRUDDto) throws ApiException {
        return ResponseEntity.ok(utilityService.editLocation(locationCRUDDto));
    }
    @GetMapping ("/location-list")
    ResponseEntity<List<LocationCRUDDto>> getLocationList() throws ApiException {
        return ResponseEntity.ok(utilityService.getLocationList());
    }

    @PostMapping("/add-camp")
    public ResponseEntity<ResponseDTO> createCamp(@RequestBody CampCRUDDto campCRUDDto)throws ApiException{
        return ResponseEntity.ok(utilityService.createCamp(campCRUDDto));
    }

    @PutMapping("/edit-camp")
    public ResponseEntity<ResponseDTO> editCamp(@RequestBody CampCRUDDto campCRUDDto)throws ApiException{
        return ResponseEntity.ok(utilityService.editCamp(campCRUDDto));
    }
    @GetMapping ("/camp-list")
    public ResponseEntity<List<CampCRUDDto>> getCampList() throws ApiException {
        return ResponseEntity.ok(utilityService.getCampList());
    }
    @PostMapping("/add-block")
    public ResponseEntity<ResponseDTO> createBlock(@RequestBody BlockCRUDDto blockCRUDDto)throws ApiException{
        return ResponseEntity.ok(utilityService.createBlock(blockCRUDDto));
    }

    @PutMapping("/edit-block")
    public ResponseEntity<ResponseDTO> editBlock(@RequestBody BlockCRUDDto blockCRUDDto)throws ApiException{
        return ResponseEntity.ok(utilityService.editBlock(blockCRUDDto));
    }
    @GetMapping ("/block-list")
    public ResponseEntity<List<BlockCRUDDto>> getBlockList() throws ApiException {
        return ResponseEntity.ok(utilityService.getBlockList());
    }
    @PostMapping("/add-room")
    public ResponseEntity<ResponseDTO> createRoom(@RequestBody RoomCRUDDto roomCRUDDto)throws ApiException{
        return ResponseEntity.ok(utilityService.createRoom(roomCRUDDto));
    }
    @PutMapping("/edit-room")
    public ResponseEntity<ResponseDTO> editRoom(@RequestBody RoomCRUDDto roomCRUDDto)throws ApiException{
        return ResponseEntity.ok(utilityService.editRoom(roomCRUDDto));
    }
    @GetMapping ("/room-list")
    public ResponseEntity<Map<String,Object>> getRoomList(
            @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
            @RequestParam(value = "size", required = false, defaultValue = "10") Integer size
    ) throws ApiException {
        return ResponseEntity.ok(utilityService.getRoomList(page-1,size));
    }

    @GetMapping("/room-capacity")
    public ResponseEntity<List<RoomCapacityUtilityDTO>> getRoomCapacityList() throws ApiException {
        return ResponseEntity.ok(utilityService.getRoomCapacityList());
    }

    @PostMapping("/room-capacity")
    public ResponseDTO addRoomCapacity(@RequestBody RoomCapacityUtilityDTO roomCapacityUtilityDTO) throws ApiException {
        return utilityService.addRoomCapacity(roomCapacityUtilityDTO);
    }

    @PutMapping("/room-capacity")
    public ResponseDTO updateRoomCapacity(@RequestBody RoomCapacityUtilityDTO roomCapacityUtilityDTO) throws ApiException {
        return utilityService.updateRoomCapacity(roomCapacityUtilityDTO);
    }

    @GetMapping("/room-category")
    public ResponseEntity<List<RoomCategoryUtilityDTO>> getRoomCategoryList() throws ApiException {
        return ResponseEntity.ok(utilityService.getRoomCategoryList());
    }

    @PostMapping("/room-category")
    public ResponseDTO addRoomCategory(@RequestBody RoomCategoryUtilityDTO roomCategoryDTO) throws ApiException {
        return utilityService.addRoomCategory(roomCategoryDTO);
    }

    @PutMapping("/room-category")
    public ResponseDTO updateRoomCategory(@RequestBody RoomCategoryUtilityDTO roomCategoryDTO) throws ApiException{
        return utilityService.updateRoomCategory(roomCategoryDTO);
    }

    @GetMapping("/beds")
    public PageableResponseDTO getBedList(@RequestParam(value = "page", required = true) int page) throws ApiException {
        return utilityService.getBedList(PageRequest.of(page - 1, 10));
    }

    @PostMapping("/bed")
    public ResponseDTO addBed(@RequestBody BedUtilityDTO bedUtilityDTO) throws ApiException {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        Principal principal = (Principal) authentication.getPrincipal();
        KeycloakPrincipal<KeycloakSecurityContext> keycloakPrincipal =
                (KeycloakPrincipal<KeycloakSecurityContext>) principal;

        String emp_code = keycloakPrincipal.getKeycloakSecurityContext().getToken().getOtherClaims().get("emp_code").toString();
        String given_name = keycloakPrincipal.getKeycloakSecurityContext().getToken().getGivenName();

        String val = given_name != null && !given_name.equals("") ? given_name
                : (emp_code != null && !emp_code.equals("") ? emp_code : "Undefined");
        bedUtilityDTO.setChangedBy(val);

        return utilityService.addBed(bedUtilityDTO);
    }

    @PutMapping("/bed")
    public ResponseDTO updateBed(@RequestBody BedUtilityDTO bedDTO) throws ApiException {
        return utilityService.updateBed(bedDTO);
    }

    @DeleteMapping("/bed/{ids}")
    public ResponseDTO deleteBed(@PathVariable List<Integer> ids) throws ApiException {
        return utilityService.deleteBed(ids);
    }

    @GetMapping("/employees")
    public List<EmployeeUtilityDTO> getEmployeeList() throws ApiException {
        return utilityService.getEmployeeList();
    }

    @PostMapping("/employee")
    public ResponseDTO addEmployee(@RequestBody EmployeeUtilityDTO employeeDTO) throws ApiException {
        return utilityService.addEmployee(employeeDTO);
    }

    @PutMapping("/employee")
    public ResponseDTO updateEmployee(@RequestBody EmployeeUtilityDTO employeeDTO) throws ApiException {
        return utilityService.updateEmployee(employeeDTO);
    }

    @DeleteMapping("/employee/{empCode}")
    public ResponseDTO deleteEmployee(@PathVariable int empCode) throws ApiException {
        return utilityService.deleteEmployee(empCode);
    }

    @GetMapping("/approvers")
    public PageableResponseDTO getApproverList(@RequestParam(value = "page", required = true) int page) throws ApiException {
        return utilityService.getApproverList(PageRequest.of(page - 1, 10));
    }

    @PostMapping("/approver")
    public ResponseDTO addApprover(@RequestBody ApproverUtilityDTO approverDTO) throws ApiException {
        return utilityService.addApprover(approverDTO);
    }

    @PutMapping("/approver")
    public ResponseDTO updateApprover(@RequestBody ApproverUtilityDTO approverDTO) throws ApiException {
        return utilityService.updateApprover(approverDTO);
    }

    @DeleteMapping("/approver/{id}")
    public ResponseDTO deleteApprover(@PathVariable int id) throws ApiException {
        return utilityService.deleteApprover(id);
    }
    @PostMapping("/create-guest")
    public ResponseEntity<Integer> createGuest(@RequestBody EmployeeGuestDto employeeGuestDto) throws ApiException{
        return ResponseEntity.ok(employeeService.createGuest(employeeGuestDto));
    }
    @GetMapping("/get-cost-center")
    public ResponseEntity<List<CostCenterDTO>> getCostCenter() throws ApiException {
        return ResponseEntity.ok(utilityService.getCostCenter());
    }
}
