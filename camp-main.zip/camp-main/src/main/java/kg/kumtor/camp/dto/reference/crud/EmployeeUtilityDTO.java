package kg.kumtor.camp.dto.reference.crud;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeUtilityDTO {

    private Integer empCode = null;
    private String email;
    private String firstName;
    private String firstNameRu;
    private String lastName;
    private String lastNameRu;
    private String middleName;
    private String middleNameRu;
    private String phoneNum1;
    private String phoneNum2;
    private String sin;
    private int genderId;
    private Date dateBirth;
    private String changedBy;
}
