package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.entity.Employee;
import kg.kumtor.camp.entity.RequestLog;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.repository.RequestLogRepository;
import kg.kumtor.camp.service.RequestLogService;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.Map;

@Service
@Slf4j
public class RequestLogServiceImpl implements RequestLogService {

    private static final String PARAM_DELIMITER = ";";

    private static final int VARCHAR_MAX_LENGTH = 4000;


    private final EmployeeRepository employeeRepository;

    private final RequestLogRepository logRepository;


    public RequestLogServiceImpl(EmployeeRepository employeeRepository, RequestLogRepository logRepository) {
        this.employeeRepository = employeeRepository;
        this.logRepository = logRepository;
    }

    @Override
    public RequestLog createLog(HttpServletRequest request) {

        log.info("start createLog");

        String ip = request.getHeader("X-FORWARDED-FOR");
        String ipAddress = (ip == null) ? request.getRemoteAddr() : ip;

        Map<String, String[]> params = request.getParameterMap();
        String inParams = "";
        for (Map.Entry<String, String[]> entry : params.entrySet()) {
            inParams += entry.getKey() + ":";// param key
            for (String val : entry.getValue()) {
                inParams += val;
            }
            inParams += PARAM_DELIMITER;
        }

        log.info("in Params: {} ", inParams);

        RequestLog requestLog = new RequestLog(ipAddress, request.getRequestURI(), request.getMethod());

        if (inParams.length() < VARCHAR_MAX_LENGTH)
            requestLog.setInParams(inParams);
        else
            requestLog.setInParams(inParams.substring(0, VARCHAR_MAX_LENGTH));

        KeycloakAuthenticationToken principal = (KeycloakAuthenticationToken) request.getUserPrincipal();
        Employee user = null;

        if (principal != null) {
            String email = principal.getAccount().getKeycloakSecurityContext().getToken().getEmail();
            log.info("in email: {} ", email);
            user = employeeRepository.getEmployeeByEmailIgnoreCase(email);
            requestLog.setEmployee(user);
            requestLog.setSessionId(principal.getAccount().getKeycloakSecurityContext().getToken().getSessionId());
        }


        logRepository.save(requestLog);

        log.info("createLog : {}", requestLog);

        return requestLog;
    }

    @Override
    public void addOrUpdateLog(HttpServletRequest request, HttpServletResponse response, ModelAndView modelAndView) {

        log.info("start addOrUpdateLog");

        RequestLog requestLog = (RequestLog) request.getAttribute("log");

        requestLog.setHttpStatus(String.valueOf(response.getStatus()));

        StringBuilder outParams = new StringBuilder();

        if (modelAndView != null) {
            ModelMap map = modelAndView.getModelMap();

            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (entry.getValue() instanceof Collection) {
                    Collection value = (Collection) entry.getValue();
                    outParams.append(entry.getKey()).append(":").append(value.size()).append(";");
                } else {
                    outParams.append(entry.getKey()).append(":").append(entry.getValue()).append(";");
                }
            }
        } else {
            for (String headerName : response.getHeaderNames()) {
                outParams.append(headerName).append(": ").append(response.getHeader(headerName));
            }
        }

        log.info("in Params: {} ", outParams);

        if (outParams.length() < VARCHAR_MAX_LENGTH)
            requestLog.setOutParams(outParams.toString());
        else
            requestLog.setOutParams(outParams.substring(0, VARCHAR_MAX_LENGTH));

        logRepository.save(requestLog);
        log.info("addOrUpdateLog : {}", requestLog);
    }
}
