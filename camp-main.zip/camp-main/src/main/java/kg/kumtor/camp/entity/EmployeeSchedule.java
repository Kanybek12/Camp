package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "employee_schedule")
public class EmployeeSchedule {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @ManyToOne
    @JoinColumn(name = "emp_code", foreignKey = @ForeignKey(name = "fk_emp_code"))
    private Employee empCode;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date_from")
    private LocalDate dateFrom;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date_to")
    private LocalDate dateTo;

}
