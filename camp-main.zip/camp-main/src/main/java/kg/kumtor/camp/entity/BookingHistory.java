package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "booking_history")
public class BookingHistory implements Serializable {

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @ManyToOne
    @JoinColumn(name = "booking_id", nullable = false, foreignKey = @ForeignKey(name = "fk_booking_id"))
    private Booking bookingId;

    @OneToOne
    @JoinColumn(name = "emp_code", foreignKey = @ForeignKey(name = "fk_emp_code"))
    private Employee empCode;

    @OneToOne
    @JoinColumn(name = "bed_id", foreignKey = @ForeignKey(name = "fk_bed_id"))
    private Bed bedId;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "old_date_in", nullable = false)
    private LocalDate oldDateIn;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "old_date_out", nullable = false)
    private LocalDate oldDateOut;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "new_date_in", nullable = false)
    private LocalDate newDateIn;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "new_date_out", nullable = false)
    private LocalDate newDateOut;

    public BookingHistory(LocalDateTime dateChanged, Booking bookingId, Employee empCode, Bed bedId, LocalDate oldDateIn, LocalDate oldDateOut, LocalDate newDateIn, LocalDate newDateOut) {
        this.dateChanged = dateChanged;
        this.bookingId = bookingId;
        this.empCode = empCode;
        this.bedId = bedId;
        this.oldDateIn = oldDateIn;
        this.oldDateOut = oldDateOut;
        this.newDateIn = newDateIn;
        this.newDateOut = newDateOut;
    }
}
