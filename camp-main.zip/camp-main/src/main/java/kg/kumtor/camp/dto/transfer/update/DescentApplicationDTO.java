package kg.kumtor.camp.dto.transfer.update;

import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DescentApplicationDTO {
    private long id;
    private int empCode;
    private boolean busTransferDown;
    private boolean vahtaTransferDown;
    private boolean onCarDown;
}
