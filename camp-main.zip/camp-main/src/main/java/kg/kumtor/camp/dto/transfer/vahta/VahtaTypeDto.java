package kg.kumtor.camp.dto.transfer.vahta;

public class VahtaTypeDto {
    private Long transferUp;
    private Long transferDown;

    public VahtaTypeDto() {
    }

    public VahtaTypeDto(Long transferUp, Long transferDown) {
        this.transferUp = transferUp;
        this.transferDown = transferDown;
    }

    public Long getTransferUp() {
        return transferUp;
    }

    public void setTransferUp(Long transferUp) {
        this.transferUp = transferUp;
    }

    public Long getTransferDown() {
        return transferDown;
    }

    public void setTransferDown(Long transferDown) {
        this.transferDown = transferDown;
    }
}
