package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.guardpoint.GuardPointDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.GuardPointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

import static kg.kumtor.camp.exception.ExceptionsEnum.GUARDPOINT_RECORDS_NOT_FOUND;

@Slf4j
@Service
public class GuardPointServiceImpl implements GuardPointService {

    private final JdbcTemplate jdbcTemplate;

    public GuardPointServiceImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public PageableResponseDTO getGuardPointList(Pageable pageable, String enterDate, String exitDate,
                                                 String checkInDate, String checkOutDate, String empCode) throws ApiException {
        String countQuery = "SELECT COUNT(1) " +
                "FROM camp.vw_get_guardpoint_list " +
                "WHERE entrance_date::text LIKE CONCAT(?::text, '%') " +
                " AND exit_date::text LIKE CONCAT(?::text, '%') " +
                " AND check_in::text LIKE CONCAT(?::text, '%') OR check_in ISNULL " +
                " AND check_out::text LIKE CONCAT(?::text, '%') OR check_out ISNULL " +
                " AND emp_code LIKE ?";
        String resultQuery = "SELECT * " +
                "FROM camp.vw_get_guardpoint_list " +
                "WHERE entrance_date::text LIKE CONCAT(?::text, '%') " +
                " AND COALESCE(exit_date::text, '') LIKE CONCAT(?::text, '%') " +
                " AND COALESCE(check_in::text, '') LIKE CONCAT(?::text, '%') " +
                " AND COALESCE(check_out::text, '') LIKE CONCAT(?::text, '%') " +
                " AND emp_code LIKE ?" +
                "ORDER BY entrance_date DESC " +
                "LIMIT ? OFFSET ?";
        try {
            log.info("Getting total number of GuardPoint records...");
            int count = jdbcTemplate.queryForObject(countQuery, new Object[]{enterDate, exitDate, checkInDate,
                    checkOutDate, empCode}, Integer.class);
            log.info("Got the total number of GuardPoint records: {}", count);
            log.info("Retrieving all GuardPoint records with filters: enterDate = {}, exitDate = {}, checkInDate = {}," +
                    "checkOutDate = {}, empCode = {} ...", enterDate, exitDate, checkInDate, checkOutDate, empCode);
            List<GuardPointDTO> guardPointList = jdbcTemplate.query(resultQuery,
                    new Object[]{enterDate, exitDate, checkInDate, checkOutDate, empCode, pageable.getPageSize(),
                            pageable.getOffset()},
                    new BeanPropertyRowMapper<>(GuardPointDTO.class));
            log.info("Received all GuardPoint records: {}", guardPointList);
            PageImpl<GuardPointDTO> guardPointPages = new PageImpl<>(guardPointList, pageable, count);
            return PageableResponseDTO.builder()
                    .pageNumber(guardPointPages.getNumber() + 1)
                    .totalPages(guardPointPages.getTotalPages())
                    .content(guardPointPages.getContent())
                    .build();
        } catch (Exception ex) {
            log.error("Error in receiving a list of GuardPoint records: {}", ex.getMessage());
            throw new ApiException(GUARDPOINT_RECORDS_NOT_FOUND.getCode(), GUARDPOINT_RECORDS_NOT_FOUND.getMessage());
        }
    }
}
