package kg.kumtor.camp.service;

public interface RoomService {
}
