package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.LocationDto;
import kg.kumtor.camp.dto.reference.crud.LocationCRUDDto;
import kg.kumtor.camp.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocationRepository extends JpaRepository<Location, Integer> {
    @Query("SELECT new kg.kumtor.camp.dto.reference.LocationDto(u.id,u.title,u.titleRu,u.approverTypeId) FROM Location u ORDER BY u.id")
    List<LocationDto> find();
    List<LocationDto> findAllByIsSiteLocation(short isSite);

    List<LocationDto> findAllByIdIn(List<Integer> locationIdList);

    LocationDto getLocationById(int id);

    Location findLocationById(Integer id);

    @Query("SELECT new kg.kumtor.camp.dto.reference.crud.LocationCRUDDto(u.id, u.isSiteLocation, u.statusCode,u.title,u.titleRu, u.changedBy) FROM Location u WHERE u.statusCode='A' ORDER BY u.titleRu")
    List<LocationCRUDDto> findAllLocations();
   }
