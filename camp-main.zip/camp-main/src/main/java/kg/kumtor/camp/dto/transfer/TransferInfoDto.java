package kg.kumtor.camp.dto.transfer;

import java.util.Date;

public class TransferInfoDto {
    private Long transferId;
    private String fio;
    private String department;
    private String fromLocation;
    private String toLocation;
    private String transportType;
    private String transferType;
    private Date transferDate;
    private String transferStatus;
    private String applicationStatus;

    public TransferInfoDto() {
    }

    public TransferInfoDto(Long transferId, String fio, String department, String fromLocation, String toLocation, String transportType, String transferType, Date transferDate, String transferStatus, String applicationStatus) {
        this.transferId = transferId;
        this.fio = fio;
        this.department = department;
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
        this.transportType = transportType;
        this.transferType = transferType;
        this.transferDate = transferDate;
        this.transferStatus = transferStatus;
        this.applicationStatus = applicationStatus;
    }

    public Long getTransferId() {
        return transferId;
    }

    public void setTransferId(Long transferId) {
        this.transferId = transferId;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public String getTransferType() {
        return transferType;
    }

    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }

    public Date getTransferDate() {
        return transferDate;
    }

    public void setTransferDate(Date transferDate) {
        this.transferDate = transferDate;
    }

    public String getTransferStatus() {
        return transferStatus;
    }

    public void setTransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }
}
