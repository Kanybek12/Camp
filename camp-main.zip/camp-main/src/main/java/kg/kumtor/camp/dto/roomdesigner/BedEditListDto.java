package kg.kumtor.camp.dto.roomdesigner;

public class BedEditListDto {
    private Integer bedId;
    private Integer roomId;

    public BedEditListDto() {
    }

    public BedEditListDto(Integer bedId, Integer roomId) {
        this.bedId = bedId;
        this.roomId = roomId;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }
}
