package kg.kumtor.camp.repository;

import kg.kumtor.camp.entity.Gender;
import kg.kumtor.camp.dto.reference.GenderDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GenderRepository extends JpaRepository<Gender, Integer> {

    @Query("SELECT new kg.kumtor.camp.dto.reference.GenderDto(g.id,g.name) FROM Gender g")
    List<GenderDto> findGenderBy();
}
