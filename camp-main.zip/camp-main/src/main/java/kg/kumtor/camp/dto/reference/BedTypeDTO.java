package kg.kumtor.camp.dto.reference;

import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BedTypeDTO {

    private int id;
    private String title;
}
