package kg.kumtor.camp.dto.roomdesigner;

public class RoomDesignerDto {
    private String room;
    private Integer roomCapacity;
    private String gender;
    private String roomCategory;
    private Integer roomCategoryId;
    private String statusText;
    private Integer status;
    private Long roomId;

    public RoomDesignerDto() {
    }

    public RoomDesignerDto(String room, Integer roomCapacity, String gender, String roomCategory, Integer roomCategoryId, String statusText, Integer status, Long roomId) {
        this.room = room;
        this.roomCapacity = roomCapacity;
        this.gender = gender;
        this.roomCategory = roomCategory;
        this.roomCategoryId = roomCategoryId;
        this.statusText = statusText;
        this.status = status;
        this.roomId = roomId;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public Integer getRoomCapacity() {
        return roomCapacity;
    }

    public void setRoomCapacity(Integer roomCapacity) {
        this.roomCapacity = roomCapacity;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRoomCategory() {
        return roomCategory;
    }

    public void setRoomCategory(String roomCategory) {
        this.roomCategory = roomCategory;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public Integer getRoomCategoryId() {
        return roomCategoryId;
    }

    public void setRoomCategoryId(Integer roomCategoryId) {
        this.roomCategoryId = roomCategoryId;
    }
}
