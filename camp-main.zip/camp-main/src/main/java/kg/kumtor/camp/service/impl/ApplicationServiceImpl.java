package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.RejectApplicationDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.statistics.ApplicationForSettlementDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.BookingRepository;
import kg.kumtor.camp.repository.StatusRepository;
import kg.kumtor.camp.service.ApplicationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static kg.kumtor.camp.exception.ExceptionsEnum.APPLICATIONS_FOR_SETTLEMENT_NOT_FOUND;
import static kg.kumtor.camp.exception.ExceptionsEnum.APPLICATIONS_FOR_SETTLEMENT_NOT_REJECTED;
import static kg.kumtor.camp.utility.ResponseEnum.APPLICATION_FOR_SETTLEMENT_CANCELED;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {

    private final JdbcTemplate jdbcTemplate;
    private final BookingRepository bookingRepository;
    private final StatusRepository statusRepository;

    @Override
    public PageableResponseDTO getApplicationsForSettlement(Pageable pageable, String empCode, String dateIn,
                                                            String dateOut, String visitorTypeId,
                                                            String departmentId, String jobTitleId,
                                                            String onSchedule) throws ApiException {
        String countQuery = "SELECT count(1) " +
                "FROM camp.booking AS book " +
                "  LEFT JOIN camp.employee AS emp on emp.emp_code = book.emp_code " +
                "  LEFT JOIN camp.employee_rm_department AS edep ON book.emp_code = edep.emp_code " +
                "  LEFT JOIN camp.department_rm AS deprm ON edep.department_rm_id = deprm.id " +
                "  LEFT JOIN camp.job_title AS jt on emp.job_title_id = jt.id " +
                "  LEFT JOIN camp.visitor_type vt on emp.employee_type_id = vt.id " +
                "WHERE book.status_id = 1 " +
                "  AND CAST(date_in AS VARCHAR) LIKE ? " +
                "  AND CAST(date_out AS VARCHAR) LIKE ? " +
                "  AND CAST(vt.id AS VARCHAR) LIKE ? " +
                "  AND COALESCE(CAST(deprm.id AS VARCHAR), '') LIKE ? " +
                "  AND (CAST(jt.id AS VARCHAR) LIKE ? OR jt.id IS NULL) " +
                "  AND COALESCE(CAST(on_schedule AS VARCHAR), '') LIKE ? " +
                "  AND CAST(book.emp_code AS VARCHAR) LIKE ?";
        String resultQuery = "SELECT book.id, " +
                "       emp.emp_code, " +
                "       coalesce(emp.last_name_ru || ' ' || emp.first_name_ru, " +
                "       emp.last_name || ' ' || emp.first_name) AS name, " +
                "       coalesce (coalesce(jt.title_ru, jt.title), gdi.job_title ) AS job_title, " +
                "       coalesce(coalesce (deprm.title_ru, deprm.title), coalesce (dep.title_ru, dep.title), gdi.department)  AS department, " +
                "       book.date_in, " +
                "       book.date_out, " +
                // tkabirov: Стажер КГК
                "       CASE " +
                "           WHEN CAST(emp.emp_code AS VARCHAR) LIKE '2%' THEN 'Стажер КГК' " +
                "           ELSE vt.name " +
                "           END AS visitor_type, " +
                // "       vt.name AS visitor_type, " +
                "       CASE " +
                "           WHEN on_schedule = 0 THEN 'Не по графику' " +
                "           WHEN on_schedule = 1 THEN 'По графику' " +
                "           END AS on_schedule, " +
                "       book.note " +
                "FROM camp.booking AS book " +
                "         LEFT JOIN camp.employee AS emp on emp.emp_code = book.emp_code " +
                "	  LEFT JOIN camp.employee_rm_department AS edep ON emp.emp_code = edep.emp_code" +
                "	  LEFT JOIN camp.department_rm AS deprm ON edep.department_rm_id = deprm.id" +
                "         LEFT JOIN camp.department AS dep on emp.department_id = dep.id " +
                "         LEFT JOIN camp.job_title AS jt on emp.job_title_id = jt.id " +
                "         LEFT JOIN camp.visitor_type vt on emp.employee_type_id = vt.id " +
                "         LEFT JOIN camp.guest_detail_info gdi on emp.emp_code = gdi.emp_code " +
                "WHERE book.status_id = 1 " +
                "  AND CAST(date_in AS VARCHAR) LIKE ? " +
                "  AND CAST(date_out AS VARCHAR) LIKE ? " +
                "  AND CAST(vt.id AS VARCHAR) LIKE ? " +
                "  AND COALESCE(CAST(deprm.id AS VARCHAR), '') LIKE ? " +
                "  AND (CAST(jt.id AS VARCHAR) LIKE ? OR jt.id IS NULL) " +
                "  AND COALESCE(CAST(on_schedule AS VARCHAR), '') LIKE ? " +
                "  AND CAST(emp.emp_code AS VARCHAR) LIKE ? " +
                "LIMIT ? OFFSET ?";

        try {
            log.info("Getting number of applications for settlement with filters: dateIn = {}, dateOut = {}, visitorType " +
                            "= {}, departmentId = {}, jobTitleId = {}, onSchedule = {}",
                    dateIn, dateOut, visitorTypeId, departmentId, jobTitleId, onSchedule);
            int count = jdbcTemplate.queryForObject(countQuery,
                    new Object[]{dateIn, dateOut, visitorTypeId, departmentId, jobTitleId, onSchedule, empCode},
                    Integer.class);
            log.info("Number of applications for settlement: {}", count);

            log.info("Getting list of applications for settlement with filters: dateIn = {}, dateOut = {}, visitorType " +
                            "= {}, departmentId = {}, jobTitleId = {}, onSchedule = {}",
                    dateIn, dateOut, visitorTypeId, departmentId, jobTitleId, onSchedule);
            List<ApplicationForSettlementDTO> applications = jdbcTemplate.query(resultQuery,
                    new Object[]{dateIn, dateOut, visitorTypeId, departmentId, jobTitleId, onSchedule, empCode,
                            pageable.getPageSize(), pageable.getOffset()},
                    (rs, rowNum) ->
                            ApplicationForSettlementDTO.builder()
                                    .id(rs.getInt("id"))
                                    .empCode(rs.getInt("emp_code"))
                                    .name(rs.getString("name"))
                                    .jobTitle(rs.getString("job_title"))
                                    .department(rs.getString("department"))
                                    .dateIn(rs.getDate("date_in"))
                                    .dateOut(rs.getDate("date_out"))
                                    .visitorType(rs.getString("visitor_type"))
                                    .schedule(rs.getString("on_schedule"))
                                    .note(rs.getString("note"))
                                    .build());
            log.info("Applications for settlement received: {}", applications);
            PageImpl<ApplicationForSettlementDTO> applicationPages = new PageImpl<>(applications, pageable, count);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationPages.getNumber() + 1)
                    .totalPages(applicationPages.getTotalPages())
                    .content(applicationPages.getContent())
                    .build();
        } catch (Exception ex) {
            log.error("Error when receiving a list of applications for settlement: {}", ex.getMessage());
            throw new ApiException(APPLICATIONS_FOR_SETTLEMENT_NOT_FOUND.getCode(),
                    APPLICATIONS_FOR_SETTLEMENT_NOT_FOUND.getMessage());
        }
    }

    @Transactional
    @Override
    public ResponseDTO rejectApplicationForSettlement(int empCode, List<RejectApplicationDTO> rejectApplications) throws ApiException {
        try {
            for (RejectApplicationDTO rejectApplicationDTO : rejectApplications) {
                long id = rejectApplicationDTO.getId();
                String note = rejectApplicationDTO.getNote();
                jdbcTemplate.update("UPDATE camp.booking SET changed_by = ?, date_changed = now()::timestamp(0), " +
                        "status_id=3, note=? WHERE id = ?", empCode, note, id);
                log.info("Status of booking with id = {} updated to 3(Reject)", id);

                jdbcTemplate.update("UPDATE camp.transfer_application SET changed_by = ?, date_changed = now()::timestamp(0), " +
                        "status_id = 3 WHERE booking_id = ?", empCode, id);
                log.info("Status of transfer_application with id = {} updated to 3(Reject)", id);
            }
            return ResponseDTO.builder()
                    .code(APPLICATION_FOR_SETTLEMENT_CANCELED.getCode())
                    .message(APPLICATION_FOR_SETTLEMENT_CANCELED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error in cancelling a application for settlement: {}", ex.getMessage());
            throw new ApiException(APPLICATIONS_FOR_SETTLEMENT_NOT_REJECTED.getCode(),
                    APPLICATIONS_FOR_SETTLEMENT_NOT_REJECTED.getMessage());
        }
    }
}
