package kg.kumtor.camp.dto.reference;

public class CampDto {
    private Integer id;
    private String titleRu;

    public CampDto() {
    }

    public CampDto(Integer id, String titleRu) {
        this.id = id;
        this.titleRu = titleRu;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitleRu() {
        return titleRu;
    }

    public void setTitleRu(String titleRu) {
        this.titleRu = titleRu;
    }
}
