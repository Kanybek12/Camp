package kg.kumtor.camp.dto;

import java.time.LocalDate;

public class ChangeBookingDto {
    private Long id;
    private Integer empCode;
    private String lastName;
    private String firstName;
    private Integer gender;
    private String department;
    private String jobTitle;
    private LocalDate dateIn;
    private LocalDate dateOut;
    private Integer locationId;
    private Integer blockId;
    private Integer roomCapacity;
    private Integer roomId;
    private Integer roomCategory;
    private Integer bedId;
    private Integer roomGender;
    public ChangeBookingDto() {
    }

    public ChangeBookingDto(Long id, Integer empCode, String lastName, String firstName, Integer gender, String department, String jobTitle, LocalDate dateIn, LocalDate dateOut, Integer locationId, Integer blockId, Integer roomCapacity, Integer roomId, Integer roomCategory, Integer bedId, Integer roomGender) {
        this.id = id;
        this.empCode = empCode;
        this.lastName = lastName;
        this.firstName = firstName;
        this.gender = gender;
        this.department = department;
        this.jobTitle = jobTitle;
        this.dateIn = dateIn;
        this.dateOut = dateOut;
        this.locationId = locationId;
        this.blockId = blockId;
        this.roomCapacity = roomCapacity;
        this.roomId = roomId;
        this.roomCategory = roomCategory;
        this.bedId = bedId;
        this.roomGender = roomGender;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public LocalDate getDateIn() {
        return dateIn;
    }

    public void setDateIn(LocalDate dateIn) {
        this.dateIn = dateIn;
    }

    public LocalDate getDateOut() {
        return dateOut;
    }

    public void setDateOut(LocalDate dateOut) {
        this.dateOut = dateOut;
    }

    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    public Integer getBlockId() {
        return blockId;
    }

    public void setBlockId(Integer blockId) {
        this.blockId = blockId;
    }

    public Integer getRoomCapacity() {
        return roomCapacity;
    }

    public void setRoomCapacity(Integer roomCapacity) {
        this.roomCapacity = roomCapacity;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Integer getRoomCategory() {
        return roomCategory;
    }

    public void setRoomCategory(Integer roomCategory) {
        this.roomCategory = roomCategory;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }

    public Integer getRoomGender() {
        return roomGender;
    }

    public void setRoomGender(Integer roomGender) {
        this.roomGender = roomGender;
    }
}
