package kg.kumtor.camp.dto.transfer;

public class TransferApproveDto {
    private Long transferApplicationId;
    private Integer approverEmpCode;
    private int approverType;
    private String changedBy;
    private boolean approve;

    public TransferApproveDto() {
    }

    public TransferApproveDto(Long transferApplicationId, Integer approverEmpCode, int approverType, String changedBy, boolean approve) {
        this.transferApplicationId = transferApplicationId;
        this.approverEmpCode = approverEmpCode;
        this.approverType = approverType;
        this.changedBy = changedBy;
        this.approve = approve;
    }

    public boolean isApprove() {
        return approve;
    }

    public void setApprove(boolean approve) {
        this.approve = approve;
    }

    public Long getTransferApplicationId() {
        return transferApplicationId;
    }

    public void setTransferApplicationId(Long transferApplicationId) {
        this.transferApplicationId = transferApplicationId;
    }

    public Integer getApproverEmpCode() {
        return approverEmpCode;
    }

    public void setApproverEmpCode(Integer approverEmpCode) {
        this.approverEmpCode = approverEmpCode;
    }

    public int getApproverType() {
        return approverType;
    }

    public void setApproverType(int approverType) {
        this.approverType = approverType;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }
}
