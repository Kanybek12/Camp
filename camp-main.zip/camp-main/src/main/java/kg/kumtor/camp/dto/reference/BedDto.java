package kg.kumtor.camp.dto.reference;

public class BedDto {
    private Integer id;
    private Integer bed_numder;
    private Integer roomId;

    public BedDto() {
    }

    public BedDto(Integer id, Integer bed_numder, Integer roomId) {
        this.id = id;
        this.bed_numder = bed_numder;
        this.roomId = roomId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBed_numder() {
        return bed_numder;
    }

    public void setBed_numder(Integer bed_numder) {
        this.bed_numder = bed_numder;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }
}
