package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.BlockDto;
import kg.kumtor.camp.dto.reference.crud.BlockCRUDDto;
import kg.kumtor.camp.entity.Block;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BlockRepository extends JpaRepository<Block, Integer> {
    @Query("SELECT NEW kg.kumtor.camp.dto.reference.BlockDto(b.id, b.name) FROM Block b LEFT JOIN Camp c ON b" +
            ".campId=c.id WHERE c.locationId.id= :id ORDER BY b.id")
    List<BlockDto> findBlockLocationId(@Param("id") Integer id);

    @Query("SELECT NEW kg.kumtor.camp.dto.reference.BlockDto(b.id, b.name) FROM Block b ORDER BY b.id")
    List<BlockDto> findAllBlocks();

    @Query("SELECT NEW kg.kumtor.camp.dto.reference.crud.BlockCRUDDto(b.id, b.name, b.changedBy, c.id,c.nameRu,b.statusCode) FROM Block b INNER JOIN Camp c on c.id=b.campId.id WHERE b.statusCode='A'")
    List<BlockCRUDDto> findBlockList();
}
