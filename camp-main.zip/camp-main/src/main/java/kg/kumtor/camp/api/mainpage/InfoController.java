package kg.kumtor.camp.api.mainpage;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.BookingInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@Slf4j
@RequestMapping("/statistics")
public class InfoController {
    private final BookingInfoService bookingInfoService;

    public InfoController(BookingInfoService bookingInfoService) {
        this.bookingInfoService = bookingInfoService;
    }

    @RolesAllowed("coordinator")
    @GetMapping("/applications/booking")
    public PageableResponseDTO getBookingApplications(@RequestParam(value = "page", required = true) int page,
                                                      @RequestParam(value = "check-in", required = false, defaultValue = "%%") String checkIn,
                                                      @RequestParam(value = "visitor-type-id", required = false, defaultValue = "%%") String visitorTypeId,
                                                      @RequestParam(value = "date-in", required = false, defaultValue = "%%") String dateIn,
                                                      @RequestParam(value = "department-id", required = false, defaultValue = "%%") String departmentId,
                                                      @RequestParam(value = "transit-status", required = false, defaultValue = "%%") String transitStatus,
                                                      @RequestParam(value = "date-out", required = false, defaultValue = "%%") String dateOut,
                                                      @RequestParam(value = "empCode", required = false, defaultValue = "%%") String empCode) throws ApiException {
        return bookingInfoService.getBookingApplications(PageRequest.of(page - 1, 10), dateIn, departmentId, checkIn, transitStatus, visitorTypeId, dateOut, empCode);
    }
}
