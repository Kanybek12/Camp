package kg.kumtor.camp.repository;

import kg.kumtor.camp.entity.TransferApplication;
import kg.kumtor.camp.entity.TransferApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TransferApprovalRepository extends JpaRepository<TransferApproval, Long> {

    TransferApproval findByTransferApplicationId(TransferApplication transferApplication);
}
