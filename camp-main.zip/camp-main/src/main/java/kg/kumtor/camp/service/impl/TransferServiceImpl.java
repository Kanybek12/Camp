package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.BookingDto;
import kg.kumtor.camp.dto.BookingListDTO;
import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.transfer.*;
import kg.kumtor.camp.dto.transfer.update.DescentApplicationDTO;
import kg.kumtor.camp.dto.transfer.update.UpdateDescentApplicationDTO;
import kg.kumtor.camp.dto.transfer.vahta.BusVahtaApplicationsDTO;
import kg.kumtor.camp.dto.transfer.vahta.VahtaApplicationStatisticsDto;
import kg.kumtor.camp.dto.transfer.vahta.VahtaApplicationStatusStatisticsDto;
import kg.kumtor.camp.dto.transfer.vahta.VahtaTypeDto;
import kg.kumtor.camp.entity.*;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.*;
import kg.kumtor.camp.service.BookingInfoService;
import kg.kumtor.camp.service.EmailService;
import kg.kumtor.camp.service.TransferService;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;
import static kg.kumtor.camp.utility.ApplicationTypeEnum.*;
import static kg.kumtor.camp.utility.ResponseEnum.*;

@Service
public class TransferServiceImpl implements TransferService {
    @Autowired
    private ModelMapper modelMapper;
    private final BusVisitRepository busVisitRepository;
    private final CarVisitRepository carVisitRepository;
    private final BookingServiceImpl bookingService;
    private final JdbcTemplate jdbcTemplate;
    private final EmployeeRepository employeeRepository;
    private final LocationRepository locationRepository;
    private final UtilityServiceImpl utilityService;
    private final TransferTypeRepository transferTypeRepository;
    private final TransferApprovalRepository transferApprovalRepository;
    private final TransferApprovalHistoryRepository transferApprovalHistoryRepository;
    private final TransferApplicationRepository transferApplicationRepository;
    private final BookingRepository bookingRepository;
    Logger logger = LoggerFactory.getLogger(TransferServiceImpl.class);
    private final MineApplicationRepository mineApplicationRepository;

    private final BookingInfoService bookingInfoService;

    private final EmailService emailService;

    public TransferServiceImpl(BusVisitRepository busVisitRepository, CarVisitRepository carVisitRepository, BookingServiceImpl bookingService, JdbcTemplate jdbcTemplate, EmployeeRepository employeeRepository, LocationRepository locationRepository, UtilityServiceImpl utilityService, TransferTypeRepository transferTypeRepository, TransferApprovalRepository transferApprovalRepository, TransferApprovalHistoryRepository transferApprovalHistoryRepository, TransferApplicationRepository transferApplicationRepository, BookingRepository bookingRepository, MineApplicationRepository mineApplicationRepository, BookingInfoService bookingInfoService, EmailService emailService) {
        this.busVisitRepository = busVisitRepository;
        this.carVisitRepository = carVisitRepository;
        this.bookingService = bookingService;
        this.jdbcTemplate = jdbcTemplate;
        this.employeeRepository = employeeRepository;
        this.locationRepository = locationRepository;
        this.utilityService = utilityService;
        this.transferTypeRepository = transferTypeRepository;
        this.transferApprovalRepository = transferApprovalRepository;
        this.transferApprovalHistoryRepository = transferApprovalHistoryRepository;
        this.transferApplicationRepository = transferApplicationRepository;
        this.bookingRepository = bookingRepository;
        this.mineApplicationRepository = mineApplicationRepository;
        this.bookingInfoService = bookingInfoService;
        this.emailService = emailService;
    }

    @Override
    public ResponseDTO checkInTransfer(TransferCheckInDto transferCheckInDto) throws ApiException {
        try {
            logger.info("Editing transfer with id = {}", transferCheckInDto.getTransferId());

            // дата отъезда не должна быть больше даты приезда
            String check_sql = "select bus.application_type_id as application_type_id,\n"
                    + "  to_char(trans.transfer_date_from, 'yyyy-mm-dd') as transfer_date_from,\n"
                    + "  to_char(trans.transfer_date_to, 'yyyy-mm-dd') as transfer_date_to\n"
                    + "from camp.bus_transfer bus,\n"
                    + "  camp.transfer_application trans\n"
                    + "where bus.id = ?\n"
                    + "  and bus.mine_application_id = trans.id";
            Map<String, Object> check_res =  jdbcTemplate.queryForMap(check_sql, new Object[]{transferCheckInDto.getTransferId()});

            if (((Integer)check_res.get("application_type_id") == 2)
                 && (transferCheckInDto.getTransferDate().compareTo((String)check_res.get("transfer_date_to")) > 0)) {
                logger.error("Error while editing transfer with id = {}: from date: {} can not be greater than to date: {}",
                        transferCheckInDto.getTransferId(), transferCheckInDto.getTransferDate(), check_res.get("transfer_date_to"));
                throw new ApiException(500, "Передана неверная дата Подъема: " + transferCheckInDto.getTransferDate()
                    + ". Она больше даты Спуска: " + check_res.get("transfer_date_to"));
            }
            if (((Integer)check_res.get("application_type_id") < 2)
                 && (transferCheckInDto.getTransferDate().compareTo((String)check_res.get("transfer_date_from")) < 0)) {
                logger.error("Error while editing transfer with id = {}: to date: {} can not be less than from date: {}",
                        transferCheckInDto.getTransferId(), transferCheckInDto.getTransferDate(), check_res.get("transfer_date_from"));
                throw new ApiException(500, "Передана неверная дата Спуска: " + transferCheckInDto.getTransferDate()
                        + ". Она меньше даты Подъема: " + check_res.get("transfer_date_to"));
            }

            jdbcTemplate.update("with inner_update as\n" +
                            "  (update camp.bus_transfer\n" +
                            "   set location_from = ?\n" +
                            "   where id = ?)\n" +
                            "update camp.transfer_application\n" +
                            "set transfer_date_from = case\n" +
                            "                           when (select application_type_id\n" +
                            "                                 from camp.bus_transfer\n" +
                            "                                 where id = ?) = 2 then to_date(?, 'yyyy-mm-dd')\n" +
                            "                           else transfer_date_from\n" +
                            "                         end,\n" +
                            "    transfer_date_to = case\n" +
                            "                         when (select application_type_id\n" +
                            "                               from camp.bus_transfer\n" +
                            "                               where id = ?) = 1 then to_date(?, 'yyyy-mm-dd')\n" +
                            "                         else transfer_date_to\n" +
                            "                       end\n" +
                            "where id = (select mine_application_id\n" +
                            "            from camp.bus_transfer bt_inner\n" +
                            "            where bt_inner.id = ?)",
                    transferCheckInDto.getLocationId(), transferCheckInDto.getTransferId(),
                    transferCheckInDto.getTransferId(), transferCheckInDto.getTransferDate(),
                    transferCheckInDto.getTransferId(), transferCheckInDto.getTransferDate(),
                    transferCheckInDto.getTransferId());
            logger.info("Successfully setting transfer date to {} and location to {}", transferCheckInDto.getTransferDate(), transferCheckInDto.getLocationId());
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно отредактирована")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while editing transfer with id = {}: {}", transferCheckInDto.getTransferId(), ex.getMessage());
            if (ex.getMessage().startsWith("Передана неверная дата")) {
                throw new ApiException(500, ex.getMessage());
            } else {
                throw new ApiException(500, "Не удалось изменить заявку");
            }
        }
    }

    @Transactional(rollbackOn = ApiException.class)
    public List<Map<String, Object>> saveTransfer(TransferApplicationDto transferApplicationDto) throws ApiException {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        if (!transferApplicationDto.isAgreement()) {
            throw new ApiException(500, "Пожалуйста нажмите на галочку согласия");
        }
        if (transferApplicationDto.isBusTransferUp() && transferApplicationDto.isVahtaTransferUp() && transferApplicationDto.isCarTransfer()) {
            throw new ApiException(500, "Вы выбрали все виды транспортов для подьема, пожалуйста выберите валидные виды транспортов!");
        }
        if (transferApplicationDto.isBusTransferDown() && transferApplicationDto.isVahtaTransferDown() && transferApplicationDto.isCarTransferDown()) {
            throw new ApiException(500, "Вы выбрали все виды транспортов для спуска, пожалуйста выберите валидные виды транспортов!");
        }
        if ((transferApplicationDto.getVisitorTypeId().equals(3) || transferApplicationDto.getVisitorTypeId().equals(4)) && String.valueOf(transferApplicationDto.getReceivingPerson()).equals("null")) {
            throw new ApiException(500, "Пожалуйста укажите принимающего сотрудника!");
        }
        if (transferApplicationDto.getTransferDateFrom().isAfter(transferApplicationDto.getTransferDateTo())) {
            throw new ApiException(500, "Дата спуска больше чем дата подьема! Пожалуйста укажите валидный период даты!");
        }
        List<Map<String, Object>> resultOfTransfer = new ArrayList<>();
        Map<String, Object> resultElement = new LinkedHashMap<>();
        TransferApplication transferApplication = modelMapper.map(transferApplicationDto, TransferApplication.class);
        BusTransfer busTransfer = new BusTransfer();
        try {
            transferApplication.setId(null);
            transferApplication.setDateCreated(LocalDateTime.now());
            transferApplication.setDateChanged(LocalDateTime.now());
            transferApplication.setStatusId(Status.builder().id(1).build());
            if (!transferApplicationDto.isMyApplication()) {
                transferApplication.setCreatedBy(utilityService.getEmpCodeByAuthToken(authentication));
            }
            logger.info("Insert into transfer: " + transferApplicationDto);
            TransferApplication response = mineApplicationRepository.save(transferApplication);
            logger.info("Insert was successfully!");
            if (!response.getId().equals(null)) {
                if (transferApplicationDto.isBusTransferUp()) {
                    Integer res = saveBusVisit(transferApplicationDto.getBusTransferUpDto(), transferApplicationDto.getChangedBy(), response.getId(), 1, 1);
                    Location toLocation = locationRepository.findLocationById(transferApplicationDto.getBusTransferUpDto().getToLocationId());
                    Location fromLocation = locationRepository.findLocationById(transferApplicationDto.getBusTransferUpDto().getFromLocationId());
                    resultElement.put("message", "Заявка на " + busVisitRepository.getTransferTypeById(Long.valueOf(res)) + " с : " + fromLocation.getTitleRu() + " до: " + toLocation.getTitleRu() + " на подьем была успешно создана");
                    resultOfTransfer.add(resultElement);
                }
                if (transferApplicationDto.isVahtaTransferUp()) {
                    Integer res = saveBusVisit(transferApplicationDto.getVahtaTransferUpDto(), transferApplicationDto.getChangedBy(), response.getId(), 1, 2);
                    Location toLocation = locationRepository.findLocationById(transferApplicationDto.getVahtaTransferUpDto().getToLocationId());
                    Location fromLocation = locationRepository.findLocationById(transferApplicationDto.getVahtaTransferUpDto().getFromLocationId());
                    resultElement = new HashMap<>();
                    resultElement.put("message", "Заявка на " + busVisitRepository.getTransferTypeById(Long.valueOf(res)) + " с : " + fromLocation.getTitleRu() + " до: " + toLocation.getTitleRu() + " на подьем была успешно создана");
                    resultOfTransfer.add(resultElement);
                }
                if (transferApplicationDto.isBusTransferDown()) {
                    Integer res = saveBusVisit(transferApplicationDto.getBusTransferDownDto(), transferApplicationDto.getChangedBy(), response.getId(), 2, 1);
                    Location toLocation = locationRepository.findLocationById(transferApplicationDto.getBusTransferDownDto().getToLocationId());
                    Location fromLocation = locationRepository.findLocationById(transferApplicationDto.getBusTransferDownDto().getFromLocationId());
                    resultElement = new HashMap<>();
                    resultElement.put("message", "Заявка на " + busVisitRepository.getTransferTypeById(Long.valueOf(res)) + " с : " + fromLocation.getTitleRu() + " до: " + toLocation.getTitleRu() + " на спуск была успешно создана");
                    resultOfTransfer.add(resultElement);
                }
                if (transferApplicationDto.isVahtaTransferDown()) {
                    Integer res = saveBusVisit(transferApplicationDto.getVahtaTransferDownDto(), transferApplicationDto.getChangedBy(), response.getId(), 2, 2);
                    Location toLocation = locationRepository.findLocationById(transferApplicationDto.getVahtaTransferDownDto().getToLocationId());
                    Location fromLocation = locationRepository.findLocationById(transferApplicationDto.getVahtaTransferDownDto().getFromLocationId());
                    resultElement = new HashMap<>();
                    resultElement.put("message", "Заявка на " + busVisitRepository.getTransferTypeById(Long.valueOf(res)) + " с : " + fromLocation.getTitleRu() + " до: " + toLocation.getTitleRu() + " была успешно создана");
                    resultOfTransfer.add(resultElement);
                }
                if (transferApplicationDto.isCarTransfer()) {
                    Integer res = saveCarVisit(transferApplicationDto.getCarTransferDto(), transferApplicationDto.getChangedBy(), response.getId(), 1);
                    Location toLocation = locationRepository.findLocationById(transferApplicationDto.getCarTransferDto().getToLocationId());
                    Location fromLocation = locationRepository.findLocationById(transferApplicationDto.getCarTransferDto().getFromLocationId());
                    resultElement = new HashMap<>();
                    resultElement.put("message", "Заявка на транспортировку с : " + fromLocation.getTitleRu() + " до: " + toLocation.getTitleRu() + " была успешно создана");
                    resultOfTransfer.add(resultElement);
                }
                if (transferApplicationDto.isCarTransferDown()) {
                    Integer res = saveCarVisit(transferApplicationDto.getCarTransferDownDto(), transferApplicationDto.getChangedBy(), response.getId(), 2);
                    Location toLocation = locationRepository.findLocationById(transferApplicationDto.getCarTransferDownDto().getToLocationId());
                    Location fromLocation = locationRepository.findLocationById(transferApplicationDto.getCarTransferDownDto().getFromLocationId());
                    resultElement = new HashMap<>();
                    resultElement.put("message", "Заявка на транспортировку с : " + fromLocation.getTitleRu() + " до: " + toLocation.getTitleRu() + " была успешно создана");
                    resultOfTransfer.add(resultElement);
                }
                if (transferApplicationDto.isCampLiveNeed()) {
                    Long res = setBooking(transferApplicationDto);
                    transferApplication.setBooking(Booking.builder().id(res).build());
                    logger.info("Update transfer with id: " + res + " add booking id");
                    response = mineApplicationRepository.save(transferApplication);
                    logger.info("Update was successfully!");
                }
                sendTransferToApprove(transferApplication);
            }
        } catch (Exception ex) {
            throw new ApiException(500, ex.getMessage());
        }

        return resultOfTransfer;
    }

    private Integer saveCarVisit(CarTransferDto carTransferDto, String changedBy, Long mineApplicationId, Integer applicationType) {
        CarTransfer carTransfer = new CarTransfer();
        carTransfer.setId(null);
        carTransfer.setDateChanged(LocalDateTime.now());
        carTransfer.setChangedBy(changedBy);
        carTransfer.setTransferApplicationId(TransferApplication.builder().id(mineApplicationId).build());
        carTransfer.setCarTypeId(CarType.builder().id(carTransferDto.getCarTypeId()).build());
        carTransfer.setFromLocationId(Location.builder().id(carTransferDto.getFromLocationId()).build());
        carTransfer.setToLocationId(Location.builder().id(carTransferDto.getToLocationId()).build());
        carTransfer.setCarModel(carTransferDto.getCarModel());
        carTransfer.setCarNumber(carTransferDto.getCarNumber());
        carTransfer.setDriver(carTransferDto.getDriverName());
        carTransfer.setApplicationTypeId(ApplicationType.builder().id(applicationType).build());
        carTransfer.setTransferStatusId(TransferStatus.builder().id(1).build());
        CarTransfer response = carVisitRepository.save(carTransfer);
        return Math.toIntExact(response.getId());
    }

    private Integer saveBusVisit(BusTransferDto busTransferDto, String changedBy, Long mineApplicationId, Integer applicationType, Integer transferType) {
        BusTransfer busTransfer = new BusTransfer();
        busTransfer.setDateChanged(LocalDateTime.now());
        busTransfer.setChangedBy(changedBy);
        busTransfer.setToLocation(Location.builder().id(busTransferDto.getToLocationId()).build());
        busTransfer.setFromLocation(Location.builder().id(busTransferDto.getFromLocationId()).build());
        busTransfer.setTransferApplicationId(TransferApplication.builder().id(mineApplicationId).build());
        busTransfer.setApplicationTypeId(ApplicationType.builder().id(applicationType).build());
        busTransfer.setTransferTypeId(TransferType.builder().id(transferType).build());
        busTransfer.setTransferStatusId(TransferStatus.builder().id(1).build());
        BusTransfer response = busVisitRepository.save(busTransfer);
        return Math.toIntExact(response.getId());
    }

    private Long setBooking(TransferApplicationDto transfer) throws ApiException {
        Integer bedId = bookingInfoService.getFreeBedId(transfer.getEmpCode(), transfer.getTransferDateTo(), transfer.getTransferDateFrom());
        BookingDto bookingDto = new BookingDto();
        bookingDto.setBedId(bedId);
        bookingDto.setEmpCode(transfer.getEmpCode());
        bookingDto.setFirstName(transfer.getFirstName());
        bookingDto.setLastName(transfer.getLastName());
        bookingDto.setDepartment(transfer.getDepartment());
        bookingDto.setJobTitle(transfer.getJobTitle());
        bookingDto.setDateIn(transfer.getTransferDateFrom());
        bookingDto.setDateOut(transfer.getTransferDateTo());
        bookingDto.setGenderId(transfer.getGenderId());
        bookingDto.setStatusId(1);
        bookingDto.setChangedBy(transfer.getChangedBy());
        try {
            Employee employee = employeeRepository.findByEmpCode(transfer.getEmpCode());
            bookingDto.setPayAccount(employee.getPayAccount());
        } catch (Exception ex) {

        }
        if (transfer.getReceivingPerson() != null && bookingDto.getPayAccount() == null) {
            Employee employee = employeeRepository.findByEmpCode(transfer.getReceivingPerson());
            bookingDto.setPayAccount(employee.getPayAccount());
        }
        bookingDto.setNote("Бронь создана из заявки на транспортировку");
        bookingDto = bookingService.saveBooking(bookingDto);
        return bookingDto.getId();
    }

    public List<Map<String, Object>> getDepartmentsForTransfer() throws ApiException {
        String query = "select title_ru from camp.department group by title_ru";
        List<Map<String, Object>> res = new ArrayList<>();
        try {
            List<Map<String, Object>> queryResponse = jdbcTemplate.queryForList(query);
            for (Map<String, Object> iterator : queryResponse) {
                Map<String, Object> elementOfQueryResult = new HashMap<>();
                elementOfQueryResult.put("department", String.valueOf(iterator.get("title_ru")));
                res.add(elementOfQueryResult);
            }
        } catch (Exception ex) {
            throw new ApiException(500, "При выполнении запроса произошла ошибка");
        }
        return res;
    }

    public List<TransferTypeDto> getTransferType() {
        return transferTypeRepository.findAllTransfer();
    }

    @Override
    public List<TransferInfoForDriverDto> getTransferInfoForDriver(LocalDate transferDate, Integer transferType, Integer location) throws ApiException {
        String query = "select *from camp.func_get_bus_transfer_requests(?,?,?)";
        List<TransferInfoForDriverDto> transferInfoForDriverDtos = new ArrayList<>();
        Object arg[] = new Object[]{transferDate, transferType, location};
        try {
            List<Map<String, Object>> resultQuery = jdbcTemplate.queryForList(query, arg);
            for (Map<String, Object> iterator : resultQuery) {
                TransferInfoForDriverDto transferInfoForDriverDto = new TransferInfoForDriverDto();
                transferInfoForDriverDto.setBusTransferId(Long.valueOf(String.valueOf(iterator.get("bus_transfer_id"))));
                transferInfoForDriverDto.setFirstName(String.valueOf(iterator.get("first_name")));
                transferInfoForDriverDto.setLastName(String.valueOf(iterator.get("last_name")));
                transferInfoForDriverDto.setDepartment(String.valueOf(iterator.get("department")));
                transferInfoForDriverDto.setFromLocation(String.valueOf(iterator.get("from_location")));
                transferInfoForDriverDto.setToLocation(String.valueOf(iterator.get("to_location")));
                transferInfoForDriverDto.setTransportType(String.valueOf(iterator.get("transport_type")));
                transferInfoForDriverDto.setTransferType(String.valueOf(iterator.get("transfer_type")));
                transferInfoForDriverDto.setTransferDate((Date) iterator.get("transfer_date"));
                transferInfoForDriverDto.setTransferStatus(String.valueOf(iterator.get("transfer_status")));
                transferInfoForDriverDto.setApplicationStatus(String.valueOf(iterator.get("application_status")));
                transferInfoForDriverDtos.add(transferInfoForDriverDto);
            }
        } catch (Exception ex) {
            throw new ApiException(500, "Произошла ошибка!");
        }
        return transferInfoForDriverDtos;
    }

    @Override
    public List<TransferInfoDto> getTransferInfoList(LocalDate transferDate, Integer transferType, Integer location, Integer empCode, String fio) throws ApiException {
        String query = "select * from camp.func_transfer_application_list(?,?,?,?,?,?)";
        LocalDate dateFrom = LocalDate.parse("1900-01-01");
        LocalDate dateTo = LocalDate.parse("2300-01-01");
        if (transferDate != null) {
            dateFrom = transferDate;
            dateTo = transferDate;
        }
        List<TransferInfoDto> transferInfoDtos = new ArrayList<>();
        Object arg[] = new Object[]{dateFrom, dateTo, fio, transferType, location, empCode};
        try {
            List<Map<String, Object>> resultQuery = jdbcTemplate.queryForList(query, arg);
            for (Map<String, Object> iterator : resultQuery) {
                TransferInfoDto transferInfoForDriverDto = new TransferInfoDto();
                transferInfoForDriverDto.setTransferId(Long.valueOf(String.valueOf(iterator.get("bus_transfer_id"))));
                transferInfoForDriverDto.setFio(String.valueOf(iterator.get("fio")));
                transferInfoForDriverDto.setDepartment(String.valueOf(iterator.get("department")));
                transferInfoForDriverDto.setFromLocation(String.valueOf(iterator.get("from_location")));
                transferInfoForDriverDto.setToLocation(String.valueOf(iterator.get("to_location")));
                transferInfoForDriverDto.setTransportType(String.valueOf(iterator.get("transport_type")));
                transferInfoForDriverDto.setTransferType(String.valueOf(iterator.get("transfer_type")));
                transferInfoForDriverDto.setTransferDate((Date) iterator.get("transfer_date"));
                transferInfoForDriverDto.setTransferStatus(String.valueOf(iterator.get("transfer_status")));
                transferInfoForDriverDto.setApplicationStatus(String.valueOf(iterator.get("application_status")));
                transferInfoDtos.add(transferInfoForDriverDto);
            }
        } catch (Exception ex) {
            throw new ApiException(500, "Произошла ошибка!");
        }
        return transferInfoDtos;
    }

    @Override
    public PersonalInfoDTO getPersonalInfo(int empCode) throws ApiException {
        try {
            logger.info("Getting personal info by empCode: {}", empCode);
            PersonalInfoDTO personalInfo = jdbcTemplate.queryForObject("SELECT * FROM camp.get_personal_info(?)",
                    new Object[]{empCode}, new BeanPropertyRowMapper<>(PersonalInfoDTO.class));
            logger.info("Personal info by empCode {} received: {}", empCode, personalInfo);
            return personalInfo;
        } catch (Exception ex) {
            logger.error("Error in getting personal info by empCode: {}", ex.getMessage());
            throw new ApiException(PERSONAL_INFO_ERROR.getCode(), PERSONAL_INFO_ERROR.getMessage() + empCode);
        }
    }

    @Override
    public PersonalTransferDTO getPersonalTransferAscent(int empCode) throws ApiException {
        try {
            logger.info("Getting personal ascent transfer info for empCode: {}", empCode);

            PersonalTransferDTO personalTransfer = jdbcTemplate.queryForObject(
                    "SELECT * FROM camp.get_personal_transfer_ascent(?)", new Object[]{empCode},
                    new BeanPropertyRowMapper<>(PersonalTransferDTO.class));

            logger.info("Personal ascent transfer info received: {}", personalTransfer);

            return personalTransfer;
        } catch (EmptyResultDataAccessException ex) {
            logger.error("Received empty personal ascent transfer info: {}", ex.getMessage());
            PersonalTransferDTO personalTransfer = PersonalTransferDTO.builder()
                    .empCode(empCode)
                    .vahtaFrom(5)
                    .vahtaTo(1)
                    .build();
            logger.info("Sending default info: {}", personalTransfer);
            return personalTransfer;
        } catch (Exception ex) {
            logger.error("Error in getting personal ascent transfer info: {}", ex.getMessage());
            throw new ApiException(PERSONAL_TRANSFER_ASCENT_ERROR.getCode(), PERSONAL_TRANSFER_ASCENT_ERROR.getMessage());
        }
    }

    @Override
    public PersonalTransferDTO getPersonalTransferDescent(int empCode) throws ApiException {
        try {
            logger.info("Getting personal descent transfer info for empCode: {}", empCode);
            PersonalTransferDTO personalTransfer = jdbcTemplate.queryForObject(
                    "SELECT * FROM camp.get_personal_transfer_descent(?)", new Object[]{empCode},
                    new BeanPropertyRowMapper<>(PersonalTransferDTO.class));
            logger.info("Personal descent transfer info received: {}", personalTransfer);
            return personalTransfer;
        } catch (EmptyResultDataAccessException ex) {
            logger.error("Received empty personal descent transfer info: {}", ex.getMessage());
            PersonalTransferDTO personalTransfer = PersonalTransferDTO.builder()
                    .empCode(empCode)
                    .vahtaFrom(1)
                    .vahtaTo(5)
                    .build();
            logger.info("Sending default info: {}", personalTransfer);
            return personalTransfer;
        } catch (Exception ex) {
            logger.error("Error in getting personal descent transfer info: {}", ex.getMessage());
            throw new ApiException(PERSONAL_TRANSFER_DESCENT_ERROR.getCode(), PERSONAL_TRANSFER_DESCENT_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO updatePersonalTransferAscent(PersonalTransferDTO info) throws ApiException {
        String updateQuery = "UPDATE camp.personal_transfer_information " +
                "SET changed_by = ?, date_changed = now()::timestamp, " +
                "    bus_transfer = ?, bus_location_from = ?, bus_location_to = ?, " +
                "    vahta_transfer = ?, vahta_location_from = ?, vahta_location_to = ?, " +
                "    car_transfer = ?, car_location_from = ?, car_location_to = ?, " +
                "    car_type_id = ?, car_model = ?, car_number = ?, driver = ?, " +
                "    medical_examination_id = ? " +
                "WHERE emp_code = ? AND transfer_type_id = 1";

        String insertQuery = "INSERT INTO camp.personal_transfer_information (" +
                "emp_code, changed_by, date_changed, transfer_type_id, " +
                "bus_transfer, bus_location_from, bus_location_to, " +
                "vahta_transfer, vahta_location_from, vahta_location_to, " +
                "car_transfer, car_location_from, car_location_to, " +
                "car_type_id, car_model, car_number, driver, " +
                "medical_examination_id) " +
                "VALUES (?, ?, now()::timestamp, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            logger.info("Getting transferId of ascent transfer");
            long transferId = jdbcTemplate.queryForObject(
                    "SELECT id FROM camp.personal_transfer_information WHERE emp_code = ? AND transfer_type_id = 1",
                    new Object[]{info.getEmpCode()}, Long.class);
            jdbcTemplate.update(updateQuery, info.getEmpCode(),
                    info.getBusTransfer(), info.getBusFrom(), info.getBusTo(),
                    info.getVahtaTransfer(), info.getVahtaFrom(), info.getVahtaTo(),
                    info.getCarTransfer(), info.getCarFrom(), info.getCarTo(),
                    info.getCarTypeId(), info.getCarModel(), info.getCarNumber(), info.getDriver(),
                    info.getMedicalExaminationId(), info.getEmpCode());
            logger.info("Ascent transfer info updated for empCode: {}", info.getEmpCode());
            return ResponseDTO.builder()
                    .code(PERSONAL_TRANSFER_ASCENT_UPDATED.getCode())
                    .message(PERSONAL_TRANSFER_ASCENT_UPDATED.getMessage())
                    .build();
        } catch (EmptyResultDataAccessException ex) {
            logger.error("TransferId not exists, inserting new record");
            jdbcTemplate.update(insertQuery, info.getEmpCode(), info.getEmpCode(),
                    info.getBusTransfer(), info.getBusFrom(), info.getBusTo(),
                    info.getVahtaTransfer(), info.getVahtaFrom(), info.getVahtaTo(),
                    info.getCarTransfer(), info.getCarFrom(), info.getCarTo(),
                    info.getCarTypeId(), info.getCarModel(), info.getCarNumber(), info.getDriver(), info.getMedicalExaminationId());
            logger.info("Ascent transfer info inserted");
            return ResponseDTO.builder()
                    .code(PERSONAL_TRANSFER_ASCENT_SAVED.getCode())
                    .message(PERSONAL_TRANSFER_ASCENT_SAVED.getMessage())
                    .build();
        } catch (Exception ex) {
            logger.info("Error in Inserting/Updating ascent transfer info: {}", ex.getMessage());
            throw new ApiException(PERSONAL_TRANSFER_ASCENT_SAVE_ERROR.getCode(), PERSONAL_TRANSFER_ASCENT_SAVE_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO updatePersonalTransferDescent(PersonalTransferDTO info) throws ApiException {
        String updateQuery = "UPDATE camp.personal_transfer_information " +
                "SET changed_by = ?, date_changed = now()::timestamp, " +
                "    bus_transfer = ?, bus_location_from = ?, bus_location_to = ?, " +
                "    vahta_transfer = ?, vahta_location_from = ?, vahta_location_to = ?, " +
                "    car_transfer = ?, car_location_from = ?, car_location_to = ?, " +
                "    car_type_id = ?, car_model = ?, car_number = ?, driver = ?, " +
                "    medical_examination_id = ? " +
                "WHERE emp_code = ? AND transfer_type_id = 2";

        String insertQuery = "INSERT INTO camp.personal_transfer_information (" +
                "emp_code, changed_by, date_changed, transfer_type_id, " +
                "bus_transfer, bus_location_from, bus_location_to, " +
                "vahta_transfer, vahta_location_from, vahta_location_to, " +
                "car_transfer, car_location_from, car_location_to, " +
                "car_type_id, car_model, car_number, driver, " +
                "medical_examination_id) " +
                "VALUES (?, ?, now()::timestamp, 2, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            logger.info("Getting transferId of descent transfer");
            long transferId = jdbcTemplate.queryForObject(
                    "SELECT id FROM camp.personal_transfer_information WHERE emp_code = ? AND transfer_type_id = 2",
                    new Object[]{info.getEmpCode()}, Long.class);
            jdbcTemplate.update(updateQuery, info.getEmpCode(),
                    info.getBusTransfer(), info.getBusFrom(), info.getBusTo(),
                    info.getVahtaTransfer(), info.getVahtaFrom(), info.getVahtaTo(),
                    info.getCarTransfer(), info.getCarFrom(), info.getCarTo(),
                    info.getCarTypeId(), info.getCarModel(), info.getCarNumber(), info.getDriver(),
                    info.getMedicalExaminationId(), info.getEmpCode());
            logger.info("Descent transfer info updated for empCode: {}", info.getEmpCode());
            return ResponseDTO.builder()
                    .code(PERSONAL_TRANSFER_DESCENT_UPDATED.getCode())
                    .message(PERSONAL_TRANSFER_DESCENT_UPDATED.getMessage())
                    .build();
        } catch (EmptyResultDataAccessException ex) {
            logger.error("TransferId not exists, inserting new record");
            jdbcTemplate.update(insertQuery, info.getEmpCode(), info.getEmpCode(),
                    info.getBusTransfer(), info.getBusFrom(), info.getBusTo(),
                    info.getVahtaTransfer(), info.getVahtaFrom(), info.getVahtaTo(),
                    info.getCarTransfer(), info.getCarFrom(), info.getCarTo(),
                    info.getCarTypeId(), info.getCarModel(), info.getCarNumber(), info.getDriver(), info.getMedicalExaminationId());
            logger.info("Descent transfer info inserted");
            return ResponseDTO.builder()
                    .code(PERSONAL_TRANSFER_DESCENT_SAVED.getCode())
                    .message(PERSONAL_TRANSFER_DESCENT_SAVED.getMessage())
                    .build();
        } catch (Exception ex) {
            logger.info("Error in Inserting/Updating descent transfer info: {}", ex.getMessage());
            throw new ApiException(PERSONAL_TRANSFER_DESCENT_SAVE_ERROR.getCode(),
                    PERSONAL_TRANSFER_DESCENT_SAVE_ERROR.getMessage());
        }
    }

    public void sendTransferToApprove(TransferApplication transferApplication) throws ApiException {
        TransferApproval transferApproval = new TransferApproval();
        try {
            transferApproval.setTransferApplicationId(TransferApplication.builder().id(transferApplication.getId()).build());
            transferApproval.setChangedBy(transferApplication.getChangedBy());
            transferApproval.setDateChanged(LocalDateTime.now());
            if (transferApplication.isCampLiveNeed()) {
                if (transferApplication.getVisitorType().getId().equals(1)) {
                    transferApproval.setSupervisor(Status.builder().id(1).build());
                    transferApproval.setMineSiteAdministration(Status.builder().id(1).build());
                } else if (transferApplication.getVisitorType().getId().equals(2)) {
                    transferApproval.setSupervisor(Status.builder().id(1).build());
                    transferApproval.setMineSiteAdministration(Status.builder().id(1).build());
                    transferApproval.setHr(Status.builder().id(1).build());
                } else if (transferApplication.getVisitorType().getId().equals(3)) {
                    transferApproval.setMineSiteAdministration(Status.builder().id(1).build());
                } else {
                    transferApproval.setMineSiteDirectors(Status.builder().id(1).build());
                    transferApproval.setMedical(Status.builder().id(1).build());
                }
            }
            logger.info("Insert into the table transfer_approval: " + transferApproval);
            transferApprovalRepository.save(transferApproval);
            logger.info("Insert into the table transfer_approval was successfully!");
        } catch (Exception ex) {
            logger.error("Error: insert into the table transfer_approval was failed!");
            throw new ApiException(SAVE_ERROR.getCode(), SAVE_ERROR.getMessage());
        }
    }

    @Override
    @Transactional(rollbackOn = ApiException.class)
    public boolean approveTransfer(List<TransferApproveDto> transferApproveDtos) throws ApiException {
        TransferApprovalHistory transferApprovalHistory = new TransferApprovalHistory();
        boolean isApprove = false;
        try {
            for (TransferApproveDto iterator : transferApproveDtos) {
                if (iterator.isApprove()) {
                    TransferApproval transferApproval = transferApprovalRepository.findByTransferApplicationId(TransferApplication.builder().id(iterator.getTransferApplicationId()).build());
                    transferApproval.setDateChanged(LocalDateTime.now());
                    transferApproval.setChangedBy(iterator.getChangedBy());
                    switch (iterator.getApproverType()) {
                        case 1:
                            transferApproval.setHr(Status.builder().id(1).build());
                            break;
                        case 2:
                            transferApproval.setMedical(Status.builder().id(1).build());
                            break;
                        case 3:
                            transferApproval.setMineSiteAdministration(Status.builder().id(1).build());
                            break;
                        case 4:
                            transferApproval.setMineSiteDirectors(Status.builder().id(1).build());
                            break;
                        case 5:
                            transferApproval.setSupervisor(Status.builder().id(1).build());
                            break;
                        case 6:
                            transferApproval.setCuratorOfContractors(Status.builder().id(1).build());
                            break;
                    }
                    logger.info("Update status of Transfer status: " + transferApproval);
                    transferApprovalRepository.save(transferApproval);
                    logger.info("Update status of Transfer status was successfully!");
                    transferApprovalHistory.setStatus(1);
                } else {
                    TransferApproval transferApproval = transferApprovalRepository.findByTransferApplicationId(TransferApplication.builder().id(iterator.getTransferApplicationId()).build());
                    transferApproval.setDateChanged(LocalDateTime.now());
                    transferApproval.setChangedBy(iterator.getChangedBy());
                    switch (iterator.getApproverType()) {
                        case 1:
                            transferApproval.setHr(Status.builder().id(3).build());
                            break;
                        case 2:
                            transferApproval.setMedical(Status.builder().id(3).build());
                            break;
                        case 3:
                            transferApproval.setMineSiteAdministration(Status.builder().id(3).build());
                            break;
                        case 4:
                            transferApproval.setMineSiteDirectors(Status.builder().id(3).build());
                            break;
                        case 5:
                            transferApproval.setSupervisor(Status.builder().id(3).build());
                            break;
                        case 6:
                            transferApproval.setCuratorOfContractors(Status.builder().id(3).build());
                            break;
                    }
                    logger.info("Update status of Transfer status: " + transferApproval);
                    transferApprovalRepository.save(transferApproval);
                    logger.info("Update status of Transfer status was successfully!");
                    transferApprovalHistory.setStatus(3);
                    TransferApplication transferApplication = transferApplicationRepository.getById(iterator.getTransferApplicationId());
                    if (transferApplication.getBooking() != null) {
                        Booking booking = bookingRepository.getById(transferApplication.getBooking().getId());
                        booking.setStatusId(Status.builder().id(3).build());
                        bookingRepository.save(booking);
                        logger.info("Booking status updated: " + booking.getId());
                    }
                }
                transferApprovalHistory.setChangedBy(iterator.getChangedBy());
                transferApprovalHistory.setDateChanged(LocalDateTime.now());
                transferApprovalHistory.setApproverEmpCode(iterator.getApproverEmpCode());
                transferApprovalHistory.setAppoverType(iterator.getApproverType());
                transferApprovalHistory.setTransferApplicationId(iterator.getTransferApplicationId());
                logger.info("Insert into the table transfer_approval_history status: " + transferApprovalHistory);
                transferApprovalHistoryRepository.save(transferApprovalHistory);
                logger.info("Insert into the table transfer_approval_history was successfully!");
                if (iterator.isApprove()) {
                    isApprove = true;
                } else {
                    isApprove = false;
                }
            }
        } catch (Exception ex) {
            throw new ApiException(SAVE_ERROR.getCode(), SAVE_ERROR.getMessage());
        }
        return isApprove;
    }

    @Override
    public ResponseDTO approveTransferRequest(List<TransferApproveDto> transferApproveDtos) throws ApiException {
        boolean isApprove = approveTransfer(transferApproveDtos);
        try {
            emailService.sendEmailApprovedTransfers(transferApproveDtos);
        } catch (Exception e) {
           logger.error("sendEmailApprovedTransfers {}", e.getCause());
        }

        if (isApprove) {
            return new ResponseDTO(200, "Заявка утверждена");
        } else {
            return new ResponseDTO(200, "Заявка отклонена");
        }
    }

    public Map<String, Object> getTransferApplicationsForApprove(Integer empCode) throws ApiException {
        List<TransferApporvalListDto> transferApporvalListDtos = new ArrayList<>();
        String query = "select * from camp.func_get_request_for_approve_ext(?, 1)  where status = 1 ";
        Object[] args = new Object[]{empCode};
        try {
            List<Map<String, Object>> resultOfQuery = jdbcTemplate.queryForList(query, args);
            if (resultOfQuery.size() == 0) {
                throw new ApiException();
            }
            for (Map<String, Object> iterator : resultOfQuery) {
                TransferApporvalListDto transferApporvalListDto = new TransferApporvalListDto();
                transferApporvalListDto.setTransferId((Long) iterator.get("id"));
                transferApporvalListDto.setFullName(String.valueOf(iterator.get("full_name")));
                transferApporvalListDto.setEmpCode(String.valueOf(iterator.get("emp_code")).equals("null") ? null : (Integer) iterator.get("emp_code"));
                transferApporvalListDto.setDepartment(String.valueOf(iterator.get("department")));
                transferApporvalListDto.setJobTitle(String.valueOf(iterator.get("job_title")));
                transferApporvalListDto.setVisitorTypeId(String.valueOf(iterator.get("visitor_type_id")).equals("null") ? null : (Integer) iterator.get("visitor_type_id"));
                transferApporvalListDto.setVisitorName(String.valueOf(iterator.get("visitor_name")));
                transferApporvalListDto.setCampLiveNeed((boolean) iterator.get("camp_live"));
                transferApporvalListDto.setStatusId(String.valueOf(iterator.get("status_id")).equals("null") ? null : (Integer) iterator.get("status_id"));
                transferApporvalListDto.setStatusName(String.valueOf(iterator.get("status_name")));
                transferApporvalListDto.setTransferTypes(String.valueOf(iterator.get("transfer_types")));
                transferApporvalListDto.setDateFrom((Date) iterator.get("date_from"));
                transferApporvalListDto.setDateTo((Date) iterator.get("date_to"));
                transferApporvalListDto.setDateCreated((Date) iterator.get("date_created"));
                transferApporvalListDto.setReceivingPerson(String.valueOf(iterator.get("receiving_person")).equals("null") ? null : (Integer) iterator.get("receiving_person"));
                transferApporvalListDto.setReceivingPersonName(String.valueOf(iterator.get("receiving_person_name")));
                transferApporvalListDto.setTransfer(String.valueOf(iterator.get("transfer")));
                transferApporvalListDto.setApproverEmpCode(String.valueOf(iterator.get("appr_emp_code")).equals("null") ? null : (Integer) iterator.get("appr_emp_code"));
                transferApporvalListDto.setApproverType(String.valueOf(iterator.get("appr_type")).equals("null") ? null : (Integer) iterator.get("appr_type"));
                transferApporvalListDto.setApproverName(String.valueOf(iterator.get("approver_name")));
                transferApporvalListDto.setCreator(String.valueOf(iterator.get("created_by")));

                transferApporvalListDtos.add(transferApporvalListDto);
            }
        } catch (Exception ex) {
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
        Map<String, Object> res = new HashMap<>();
        res.put("content", transferApporvalListDtos);
        return res;
    }

    public VahtaApplicationStatisticsDto getVahtaApplicationStatistics(LocalDate date) throws ApiException {
        String query = "select \n" +
                "count(case when bt.application_type_id=2 and ta.visitor_type_id=1 then 1 else null end) as down_site_employee ,\n" +
                "count(case when bt.application_type_id=2 and ta.visitor_type_id=2 then 1 else null end) as down_kumtor_employee,\n" +
                "count(case when bt.application_type_id=2 and ta.visitor_type_id=3 then 1 else null end) as down_contractor,\n" +
                "count(case when bt.application_type_id=1 and ta.visitor_type_id=1 then 2 else null end) as up_site_employee,\n" +
                "count(case when bt.application_type_id=1 and ta.visitor_type_id=2 then 2 else null end) as up_kumtor_employee,\n" +
                "count(case when bt.application_type_id=1 and ta.visitor_type_id=3 then 2 else null end) as up_contractor\n" +
                "from camp.transfer_application ta \n" +
                "inner join camp.bus_transfer bt on bt.mine_application_id =ta.id \n" +
                "where bt.transfer_type_id =2 and ((ta.transfer_date_from between ? and ?) \n" +
                "or (ta.transfer_date_to between ? and ?))";
        LocalDate dateFrom = LocalDate.parse("1900-01-01");
        LocalDate dateTo = LocalDate.parse("2300-01-01");
        VahtaApplicationStatisticsDto vahtaApplicationStatisticsDto = new VahtaApplicationStatisticsDto();
        if (date != null) {
            dateFrom = date;
            dateTo = date;
        }
        Object args[] = new Object[]{dateFrom, dateTo, dateFrom, dateTo};
        try {
            List<Map<String, Object>> resultOfQuery = jdbcTemplate.queryForList(query, args);
            if (resultOfQuery.size() == 0) {
                throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
            }
            VahtaTypeDto empVahtaTypeDto = new VahtaTypeDto();
            VahtaTypeDto mineSiteEmpVahtaTypeDto = new VahtaTypeDto();
            VahtaTypeDto contarctorVahtaTypeDto = new VahtaTypeDto();
            mineSiteEmpVahtaTypeDto.setTransferUp((Long) resultOfQuery.get(0).get("up_site_employee"));
            mineSiteEmpVahtaTypeDto.setTransferDown((Long) resultOfQuery.get(0).get("down_site_employee"));
            vahtaApplicationStatisticsDto.setMineSiteEmployees(mineSiteEmpVahtaTypeDto);
            empVahtaTypeDto.setTransferUp((Long) resultOfQuery.get(0).get("up_kumtor_employee"));
            empVahtaTypeDto.setTransferDown((Long) resultOfQuery.get(0).get("down_kumtor_employee"));
            vahtaApplicationStatisticsDto.setKumtorEmployees(empVahtaTypeDto);
            contarctorVahtaTypeDto.setTransferUp((Long) resultOfQuery.get(0).get("up_contractor"));
            contarctorVahtaTypeDto.setTransferDown((Long) resultOfQuery.get(0).get("down_contractor"));
            vahtaApplicationStatisticsDto.setContractors(contarctorVahtaTypeDto);
        } catch (Exception ex) {
            throw new ApiException(500, ex.getMessage());
        }
        return vahtaApplicationStatisticsDto;
    }

    public VahtaApplicationStatusStatisticsDto getVahtaApplicationStatusStatistics(LocalDate date) throws ApiException {
        String query = "select \n" +
                "count(case when bt.application_type_id=2 and ta.status_id =0 then 1 else null end) as down_in_progress,\n" +
                "count(case when bt.application_type_id=2 and ta.status_id =1 then 1 else null end) as down_approved,\n" +
                "count(case when bt.application_type_id=2 and ta.status_id =3 then 1 else null end) as down_rejected,\n" +
                "count(case when bt.application_type_id=1 and ta.status_id =0 then 1 else null end) as up_in_progress,\n" +
                "count(case when bt.application_type_id=1 and ta.status_id =1 then 1 else null end) as up_approved,\n" +
                "count(case when bt.application_type_id=1 and ta.status_id =3 then 1 else null end) as up_rejected\n" +
                "from camp.transfer_application ta \n" +
                "inner join camp.bus_transfer bt on bt.mine_application_id =ta.id \n" +
                "where bt.transfer_type_id =2 and ((ta.transfer_date_from between ? and ?)\n" +
                "or (ta.transfer_date_to between ? and ?))";
        LocalDate dateFrom = LocalDate.parse("1900-01-01");
        LocalDate dateTo = LocalDate.parse("2300-01-01");
        VahtaApplicationStatusStatisticsDto vahtaApplicationStatisticsDto = new VahtaApplicationStatusStatisticsDto();
        if (date != null) {
            dateFrom = date;
            dateTo = date;
        }
        Object args[] = new Object[]{dateFrom, dateTo, dateFrom, dateTo};
        try {
            List<Map<String, Object>> resultOfQuery = jdbcTemplate.queryForList(query, args);
            if (resultOfQuery.size() == 0) {
                throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
            }
            VahtaTypeDto inProgress = new VahtaTypeDto();
            VahtaTypeDto approved = new VahtaTypeDto();
            VahtaTypeDto rejected = new VahtaTypeDto();
            inProgress.setTransferUp((Long) resultOfQuery.get(0).get("up_in_progress"));
            inProgress.setTransferDown((Long) resultOfQuery.get(0).get("down_in_progress"));
            vahtaApplicationStatisticsDto.setInProgress(inProgress);
            approved.setTransferUp((Long) resultOfQuery.get(0).get("up_approved"));
            approved.setTransferDown((Long) resultOfQuery.get(0).get("down_approved"));
            vahtaApplicationStatisticsDto.setApproved(approved);
            rejected.setTransferUp((Long) resultOfQuery.get(0).get("up_rejected"));
            rejected.setTransferDown((Long) resultOfQuery.get(0).get("down_rejected"));
            vahtaApplicationStatisticsDto.setRejected(rejected);
        } catch (Exception ex) {
            throw new ApiException(500, ex.getMessage());
        }
        return vahtaApplicationStatisticsDto;
    }

    @Override
    public PageableResponseDTO getMyApplications(Pageable pageable, int empCode, String dateCreated,
                                                 String plannedDate, String applicationType) throws ApiException {
        try {
            if (applicationType.equals(ASCENT.getName().toLowerCase())) {
                applicationType = ASCENT.getNameRu();
            } else if (applicationType.equals(DESCENT.getName().toLowerCase())) {
                applicationType = DESCENT.getNameRu();
            } else if (applicationType.equals(SETTLEMENT.getName().toLowerCase())) {
                applicationType = SETTLEMENT.getNameRu();
            }
            logger.info("Getting list of my applications for employee: {}", empCode);
            int applicationsCount = jdbcTemplate.queryForObject(
                    "SELECT count(1) FROM camp.get_my_applications(?, ?, ?, ?, null, 0)",
                    new Object[]{empCode, dateCreated, plannedDate, applicationType},
                    Integer.class);
            List<MyApplicationsDTO> applications = jdbcTemplate.query(
                    "SELECT * FROM camp.get_my_applications(?, ?, ?, ?, ?, ?)",
                    new Object[]{empCode, dateCreated, plannedDate, applicationType,
                            pageable.getPageSize(), pageable.getOffset()},
                    (rs, rowNum) ->
                            MyApplicationsDTO.builder()
                                    .id(rs.getLong("id"))
                                    .dateCreated(rs.getDate("date_created"))
                                    .employee(TransferEmployeeDTO.builder()
                                            .empCode(rs.getInt("emp_code"))
                                            .name(rs.getString("name"))
                                            .visitorType(rs.getString("visitor_type"))
                                            .build())
                                    .applicationType(rs.getString("application_type"))
                                    .plannedDate(rs.getDate("planned_date"))
                                    .info(rs.getString("info"))
                                    .status(rs.getString("status"))
                                    .build()
            );
            logger.info("List of transfer applications for employee: {} received", empCode);
            PageImpl<MyApplicationsDTO> applicationPages = new PageImpl<>(applications, pageable, applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationPages.getNumber() + 1)
                    .totalPages(applicationPages.getTotalPages())
                    .content(applicationPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of my applications: {}", ex.getMessage());
            throw new ApiException(500, "Не удалось получить список всех заявок");
        }

    }

    @Override
    public PageableResponseDTO getApplicationsForOthers(Pageable pageable, int empCode, String dateCreated,
                                                        String plannedDate, String applicationType) throws ApiException {
        try {
            if (applicationType.equals(ASCENT.getName().toLowerCase())) {
                applicationType = ASCENT.getNameRu();
            } else if (applicationType.equals(DESCENT.getName().toLowerCase())) {
                applicationType = DESCENT.getNameRu();
            } else if (applicationType.equals(SETTLEMENT.getName().toLowerCase())) {
                applicationType = SETTLEMENT.getNameRu();
            }
            logger.info("Getting list of applications for others: {}", empCode);
            int applicationsCount = jdbcTemplate.queryForObject(
                    "SELECT count(1) FROM camp.get_applications_for_others(?, ?, ?, ?, null, 0)",
                    new Object[]{empCode, dateCreated, plannedDate, applicationType},
                    Integer.class);
            List<MyApplicationsDTO> applications = jdbcTemplate.query(
                    "SELECT * FROM camp.get_applications_for_others(?, ?, ?, ?, ?, ?)",
                    new Object[]{empCode, dateCreated, plannedDate, applicationType,
                            pageable.getPageSize(), pageable.getOffset()},
                    (rs, rowNum) ->
                            MyApplicationsDTO.builder()
                                    .id(rs.getLong("id"))
                                    .dateCreated(rs.getDate("date_created"))
                                    .employee(TransferEmployeeDTO.builder()
                                            .empCode(rs.getInt("emp_code"))
                                            .name(rs.getString("name"))
                                            .visitorType(rs.getString("visitor_type"))
                                            .build())
                                    .applicationType(rs.getString("application_type"))
                                    .plannedDate(rs.getDate("planned_date"))
                                    .info(rs.getString("info"))
                                    .status(rs.getString("status"))
                                    .build()
            );
            logger.info("List of transfer applications for others: {} received", empCode);
            PageImpl<MyApplicationsDTO> applicationPages = new PageImpl<>(applications, pageable, applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationPages.getNumber() + 1)
                    .totalPages(applicationPages.getTotalPages())
                    .content(applicationPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of applications for others: {}", ex.getMessage());
            throw new ApiException(500, "Не удалось получить список заявок для других");
        }
    }

    @Override
    @Transactional
    public ResponseDTO cancelMyApplications(List<CancelMyApplicationDTO> applications) throws ApiException {
        try {
            for (CancelMyApplicationDTO application : applications) {
                if (application.getApplicationType().equalsIgnoreCase("заселение")) {
                    try {
                        logger.info("Canceling application with id = {} and type = {}", application.getId(), application.getApplicationType());
                        logger.info("Canceling booking with id = {}", application.getId());
                        jdbcTemplate.update("UPDATE camp.booking SET date_changed = ?, status_id = 6, note = 'Cancelled by user' WHERE" +
                                        " id = ?",
                                LocalDateTime.now(), application.getId());
                        logger.info("Booking with id = {} cancelled", application.getId());

                    } catch (EmptyResultDataAccessException ex) {
                        logger.error("Error while getting transferId: {}", ex.getMessage());
                        return ResponseDTO.builder()
                                .code(500)
                                .message("Заявки на транспортировку, связанные с заселением, не найдены")
                                .build();
                    }
                } else {
                    try {
                        logger.info("Canceling application with id = {} and type = {}", application.getId(), application.getApplicationType());

                        logger.info("Cancelling transfer with id = {}", application.getId());
                        jdbcTemplate.update("UPDATE camp.transfer_application SET date_changed = ?, status_id = 4, " +
                                "note = 'Cancelled by user' WHERE id = ?", LocalDateTime.now(), application.getId());
                        logger.info("Transfer with id = {} cancelled", application.getId());

                        logger.info("Cancelling bus transfer with mine_application_id = {}", application.getId());
                        jdbcTemplate.update("UPDATE camp.bus_transfer SET date_changed = ?, transfer_status_id = 4 " +
                                "WHERE mine_application_id = ?", LocalDateTime.now(), application.getId());
                        logger.info("Bus transfer with with mine_application_id = {} cancelled", application.getId());

                        logger.info("Cancelling car transfer with mine_application_id = {}", application.getId());
                        jdbcTemplate.update("UPDATE camp.car_transfer SET date_changed = ?, transfer_status_id = 4 " +
                                "WHERE mine_application_id = ?", LocalDateTime.now(), application.getId());
                        logger.info("Car transfer with with mine_application_id = {} cancelled", application.getId());

                    } catch (EmptyResultDataAccessException ex) {
                        logger.error("Error while getting bookingId: {}", ex.getMessage());
                        return ResponseDTO.builder()
                                .code(500)
                                .message("Заявка на заселение, связанная с транспортировкой, не найдена")
                                .build();
                    }
                }
            }
            try {
                emailService.sendEmailCancelMyApplications(applications);
            } catch (Exception e) {
                return ResponseDTO.builder()
                        .code(200)
                        .message("Заявки успешно отменены")
                        .build();
            }
        } catch (Exception ex) {
            logger.error("Error while cancelling applications: {}", ex.getMessage());
            throw new ApiException(500, "Не удалось отменить заявки");
        }

        return ResponseDTO.builder()
                .code(200)
                .message("Заявки успешно отменены")
                .build();
    }

    @Override
    public ResponseDTO updateDescentApplication(long id, UpdateDescentApplicationDTO updateApplication) throws ApiException {
        try {
            DescentApplicationDTO descentApplication = (DescentApplicationDTO) jdbcTemplate.query(
                    "SELECT id, emp_code, bus_transfer_down, vahta_transfer_down, on_car_down " +
                            "FROM camp.transfer_application " +
                            "WHERE id = ?",
                    new Object[]{id},
                    new BeanPropertyRowMapper(DescentApplicationDTO.class)).get(0);
            logger.info("Received info of application: {}", descentApplication);

            if (descentApplication.isBusTransferDown()) {
                jdbcTemplate.update("UPDATE camp.bus_transfer SET date_changed = ?, changed_by = ?, " +
                                "transfer_status_id = 4 " +
                                "WHERE mine_application_id = ? AND transfer_type_id = 1",
                        LocalDateTime.now(), descentApplication.getEmpCode(), id);
                logger.info("Status of application changed to 4");
            }

            if (updateApplication.isPersonalCarTransferDown()) {
                jdbcTemplate.update("INSERT INTO camp.car_transfer " +
                                "(car_model, car_number, changed_by, date_changed, driver, car_type_id, mine_application_id, " +
                                "location_from, location_to, application_type_id, transfer_status_id) SELECT " +
                                "?, ?, ?, ?, null, 1, ?, ?, ?, 2, 2",
                        updateApplication.getCarModel(), updateApplication.getCarNumber(),
                        descentApplication.getEmpCode(), LocalDateTime.now(), id,
                        updateApplication.getFromLocationId(), updateApplication.getToLocationId());
                logger.info("New record added");
            }
        } catch (Exception ex) {
            logger.error("Error: {}", ex.getMessage());
            throw new ApiException(500, "Error");
        }
        return ResponseDTO.builder()
                .code(201)
                .message("Updated")
                .build();
    }

    public PageableResponseDTO getVahtaApplicationList(Pageable pageable, LocalDate date, Integer empCode,
                                                       Integer applicationType, Integer visitorType) throws ApiException {
        Integer applicationsCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM camp.vw_vahta_without_settlement_applications\n" +
                        "WHERE ((transfer_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 DAY')::DATE AND visitor_type_id = 1)\n" +
                        "        OR (visitor_type_id <> 1))\n" +
                        "  AND status_id = 1\n" +
                        "  AND (?::DATE IS NULL OR transfer_date = ?)\n" +
                        "  AND (?::INTEGER IS NULL OR emp_code = ?)\n" +
                        "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n" +
                        "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)",
                new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType},
                Integer.class);
        if (applicationsCount == null) {
            applicationsCount = 0;
        }

        String query = "SELECT * FROM camp.vw_vahta_without_settlement_applications\n" +
                        "WHERE ((transfer_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 DAY')::DATE AND visitor_type_id = 1)\n" +
                        "        OR (visitor_type_id <> 1))\n" +
                        "  AND status_id = 1\n" +
                        "  AND (?::DATE IS NULL OR transfer_date = ?)\n" +
                        "  AND (?::INTEGER IS NULL OR emp_code = ?)\n" +
                        "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n" +
                        "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)" +
                        "LIMIT ? OFFSET ?";
        try {
            logger.info("Getting list of Vahta applications with status = 1");

            List<BusVahtaApplicationsDTO> applications = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType,
                            pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BusVahtaApplicationsDTO.class));

            logger.info("List of Vahta applications with status = 1 received");

            PageImpl<BusVahtaApplicationsDTO> applicationsPages = new PageImpl<>(applications, pageable,
                    applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of Vahta applications with status = 1: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    @Override
    public ResponseDTO approveVahtaApplication(long id) throws ApiException {
        try {
            logger.info("Approving vahta application with id = {}", id);
            jdbcTemplate.update("UPDATE camp.bus_transfer SET transfer_status_id = 2 WHERE id = ?", id);
            logger.info("Status of vahta application with id = {} updated to 2", id);

            try {
                emailService.sendEmailVahtaAndBusApproved(id);
            } catch (Exception e) {
                logger.error("Error sendEmailVahtaAndBusApproved {}", e.getMessage());
            }
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно одобрена")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while updating status of application with = {}: {}", id, ex.getMessage());
            throw new ApiException(500, "Не удалось одобрить заявку");
        }
    }

    @Override
    public ResponseDTO rejectVahtaApplication(long id) throws ApiException {
        try {
            logger.info("Rejecting vahta application with id = {}", id);
            jdbcTemplate.update("UPDATE camp.bus_transfer SET transfer_status_id = 4 WHERE id = ?", id);
            logger.info("Status of vahta application with id = {} updated to 4", id);
            try {
                emailService.sendEmailVahtaAndBusCanceled(id);
            } catch (Exception e) {
                logger.error("Error sendEmailVahtaAndBusApproved {}", e.getMessage());
            }
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно отклонена")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while rejecting status of application with = {}: {}", id, ex.getMessage());
            throw new ApiException(500, "Не удалось отклонить заявку");
        }
    }

    @Override
    public ResponseDTO undoVahtaApplication(long id) throws ApiException {
        try {
            logger.info("Undoing vahta and bus application with id = {}", id);
            jdbcTemplate.update("update camp.bus_transfer\n"
                    + "set transfer_status_id = 1\n"
                    + "where id = ?", id);
            logger.info("Status of vahta application with id = {} updated to 1", id);
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно отменена")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while undoing status of application with = {}: {}", id, ex.getMessage());
            throw new ApiException(500, "Не удалось отменить заявку");
        }
    }

    @Override
    public PageableResponseDTO getReceivedVahtaApplicationList(Pageable pageable, LocalDate date, Integer empCode, Integer applicationType, Integer visitorType) throws ApiException {
        Integer applicationsCount = jdbcTemplate.queryForObject(
                "SELECT count(1)\n"
                        + "FROM camp.vw_vahta_without_settlement_applications\n"
                        + "WHERE status_id > 1\n"
                        + "  AND (?::DATE IS NULL OR transfer_date = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)",
                new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType},
                Integer.class);
        if (applicationsCount == null) {
            applicationsCount = 0;
        }

        String query = "SELECT *\n"
                + "FROM camp.vw_vahta_without_settlement_applications\n"
                + "WHERE status_id > 1\n"
                + "  AND (?::DATE IS NULL OR transfer_date = ?)\n"
                + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)\n"
                + "LIMIT ? OFFSET ?";
        try {
            logger.info("Getting list of Vahta applications with status != 1");

            List<BusVahtaApplicationsDTO> applications = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType,
                            pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BusVahtaApplicationsDTO.class));

            logger.info("List of Vahta applications with status != 1 received");

            PageImpl<BusVahtaApplicationsDTO> applicationsPages = new PageImpl<>(applications, pageable,
                    applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of Vahta applications with status != 1: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    @Override
    public PageableResponseDTO getBusApplicationList(Pageable pageable, LocalDate date, Integer empCode, Integer applicationType, Integer visitorType) throws ApiException {
        Integer applicationsCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(1)\n" +
                        "FROM camp.vw_bus_without_settlement_applications\n"
                        + "WHERE status_id = 1\n"
                        + "  AND (visitor_type_id <> 1 OR transfer_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 DAY')::DATE)\n"
                        + "  AND (?::DATE IS NULL OR transfer_date = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)",
                new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType}, Integer.class);
        if (applicationsCount == null) {
            applicationsCount = 0;
        }

        String query = "SELECT *\n"
                + "FROM camp.vw_bus_without_settlement_applications\n"
                + "WHERE status_id = 1\n"
                + "  AND (visitor_type_id <> 1 OR transfer_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 DAY')::DATE)\n"
                + "  AND (?::DATE IS NULL OR transfer_date = ?)\n"
                + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)\n"
                + "LIMIT ? OFFSET ?";

        try {
            logger.info("Getting list of Bus applications with status = 1");

            List<BusVahtaApplicationsDTO> applications = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType,
                            pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BusVahtaApplicationsDTO.class));

            logger.info("List of Bus applications with status = 1 received");

            PageImpl<BusVahtaApplicationsDTO> applicationsPages = new PageImpl<>(
                    applications, pageable, applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of Bus applications with status = 1: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    @Override
    public PageableResponseDTO getReceivedBusApplicationList(Pageable pageable, LocalDate date, Integer empCode, Integer applicationType, Integer visitorType) throws ApiException {
        Integer applicationsCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM camp.vw_bus_without_settlement_applications\n"
                        + "WHERE status_id > 1\n"
                        + "  AND (?::DATE IS NULL OR transfer_date = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)",
                new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType}, Integer.class);
        if (applicationsCount == null) {
            applicationsCount = 0;
        }

        String query = "SELECT * FROM camp.vw_bus_without_settlement_applications\n"
                + "WHERE status_id > 1\n"
                + "  AND (?::DATE IS NULL OR transfer_date = ?)\n"
                + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)\n"
                + "LIMIT ? OFFSET ?";

        try {
            logger.info("Getting list of Bus applications with status > 1");

            List<BusVahtaApplicationsDTO> applications = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType,
                            pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BusVahtaApplicationsDTO.class));

            logger.info("List of Bus applications with status > 1 received");

            PageImpl<BusVahtaApplicationsDTO> applicationsPages
                    = new PageImpl<>(applications, pageable, applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of Bus applications with status > 1: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    @Override
    public ResponseDTO approveBusApplication(long id) throws ApiException {
        try {
            logger.info("Approving bus application with id = {}", id);
            jdbcTemplate.update("UPDATE camp.bus_transfer SET transfer_status_id = 2 WHERE id = ?", id);
            logger.info("Status of bus application with id = {} updated to 2", id);
            try {
                emailService.sendEmailVahtaAndBusApproved(id);
            } catch (Exception e) {
                logger.error("Error sendEmailVahtaAndBusApproved {}", e.getMessage());
            }
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно одобрена")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while updating status of application with = {}: {}", id, ex.getMessage());
            throw new ApiException(500, "Не удалось одобрить заявку");
        }
    }

    @Override
    public ResponseDTO rejectBusApplication(long id) throws ApiException {
        try {
            logger.info("Rejecting bus application with id = {}", id);
            jdbcTemplate.update("UPDATE camp.bus_transfer SET transfer_status_id = 4 WHERE id = ?", id);
            logger.info("Status of bus application with id = {} updated to 4", id);
            try {
                emailService.sendEmailVahtaAndBusCanceled(id);
            } catch (Exception e) {
                logger.error("Error sendEmailVahtaAndBusApproved {}", e.getMessage());
            }
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно отклонена")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while rejecting status of application with = {}: {}", id, ex.getMessage());
            throw new ApiException(500, "Не удалось отклонить заявку");
        }
    }

    @Override
    public ResponseDTO undoBusApplication(long id) throws ApiException {
        try {
            logger.info("Undoing bus application with id = {}", id);
            jdbcTemplate.update("update camp.bus_transfer\n"
                    + "set transfer_status_id = 1\n"
                    + "where id = ?", id);
            logger.info("Status of bus application with id = {} updated to 1", id);
            return ResponseDTO.builder()
                    .code(201)
                    .message("Заявка успешно отменена")
                    .build();
        } catch (Exception ex) {
            logger.error("Error while undoing status of application with = {}: {}", id, ex.getMessage());
            throw new ApiException(500, "Не удалось отменить заявку");
        }
    }

    public PageableResponseDTO getAllTransferList(Pageable pageable, LocalDate date, Integer empCode,
                                                  Integer applicationType, Integer visitorType, Integer status) throws ApiException {
        Integer applicationsCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM camp.vw_vahta_without_settlement_applications" +
                        " WHERE (?::DATE IS NULL OR transfer_date = ?)\n"
                        + " AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                        + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)"
                        + "  AND (?::INTEGER IS NULL OR status_id = ?)",
                new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType, status, status},
                Integer.class);
        if (applicationsCount == null) {
            applicationsCount = 0;
        }

        String query = "SELECT * FROM camp.vw_vahta_without_settlement_applications" +
                 "  WHERE (?::DATE IS NULL OR transfer_date = ?)\n"
                + "  AND (?::INTEGER IS NULL OR emp_code = ?)\n"
                + "  AND (?::INTEGER IS NULL OR application_type_id = ?)\n"
                + "  AND (?::INTEGER IS NULL OR visitor_type_id = ?)\n"
                + "  AND (?::INTEGER IS NULL OR status_id = ?)\n"
                + "LIMIT ? OFFSET ?";
        try {
            logger.info("Getting list of Transfer applications");

            List<BusVahtaApplicationsDTO> applications = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType, status, status, pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BusVahtaApplicationsDTO.class));

            logger.info("List of Transfer applications received");

            PageImpl<BusVahtaApplicationsDTO> applicationsPages = new PageImpl<>(applications, pageable,
                    applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of Transfer applications {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }
}
