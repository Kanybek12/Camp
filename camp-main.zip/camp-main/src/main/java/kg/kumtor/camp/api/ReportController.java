package kg.kumtor.camp.api;

import kg.kumtor.camp.service.ReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@Controller
@RequestMapping("api/report")
@Slf4j
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/vahta/xls")
    public void getApprovedVahtaXls(@RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern= "yyyy-MM-dd") LocalDate transferDate,
                                    @RequestParam(value = "emp-code", required = false) Integer empCode,
                                    @RequestParam(value = "application-type", required = false)Integer applicationType,
                                    @RequestParam(value = "visitor-type", required = false)Integer visitorType, HttpServletResponse response) throws Exception{
        log.info("call vahta xls");
        reportService.getApprovedVahtaXls(transferDate, empCode,
                applicationType, visitorType, response);
    }

    @GetMapping("/bus/xls")
    public void getApprovedBusXls(@RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern= "yyyy-MM-dd") LocalDate transferDate,
                                  @RequestParam(value = "emp-code", required = false) Integer empCode,
                                  @RequestParam(value = "application-type", required = false)Integer applicationType,
                                  @RequestParam(value = "visitor-type", required = false)Integer visitorType, HttpServletResponse response) throws Exception{
        log.info("call bus xls");
        reportService.getApprovedBusXls(transferDate, empCode,
                applicationType, visitorType, response);
    }
}
