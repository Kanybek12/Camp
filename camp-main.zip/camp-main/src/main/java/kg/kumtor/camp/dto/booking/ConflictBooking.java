package kg.kumtor.camp.dto.booking;

import java.util.Objects;

public class ConflictBooking {

    private String confId;
    private String confEmpCode;
    private String confFirstName;
    private String confLastName;
    private String confFullName;
    private String confDateIn;
    private String confDateOut;

    private String confStatusId;
    private String roomInfo;

    private String id;
    private String empCode;
    private String firstName;
    private String lastName;
    private String fullName;
    private String dateIn;
    private String dateOut;

    private String statusId;


    public ConflictBooking() {
    }

    public String getConfId() {
        return confId;
    }

    public void setConfId(String confId) {
        this.confId = confId;
    }

    public String getConfEmpCode() {
        return confEmpCode;
    }

    public void setConfEmpCode(String confEmpCode) {
        this.confEmpCode = confEmpCode;
    }

    public String getConfFirstName() {
        return confFirstName;
    }

    public void setConfFirstName(String confFirstName) {
        this.confFirstName = confFirstName;
    }

    public String getConfLastName() {
        return confLastName;
    }

    public void setConfLastName(String confLastName) {
        this.confLastName = confLastName;
    }

    public String getConfFullName() {
        return confFullName;
    }

    public void setConfFullName(String confFullName) {
        this.confFullName = confFullName;
    }

    public String getConfDateIn() {
        return confDateIn;
    }

    public void setConfDateIn(String confDateIn) {
        this.confDateIn = confDateIn;
    }

    public String getConfDateOut() {
        return confDateOut;
    }

    public void setConfDateOut(String confDateOut) {
        this.confDateOut = confDateOut;
    }

    public String getConfStatusId() {
        return confStatusId;
    }

    public void setConfStatusId(String confStatusId) {
        this.confStatusId = confStatusId;
    }

    public String getRoomInfo() {
        return roomInfo;
    }

    public void setRoomInfo(String roomInfo) {
        this.roomInfo = roomInfo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDateIn() {
        return dateIn;
    }

    public void setDateIn(String dateIn) {
        this.dateIn = dateIn;
    }

    public String getDateOut() {
        return dateOut;
    }

    public void setDateOut(String dateOut) {
        this.dateOut = dateOut;
    }

    public String getStatusId() {
        return statusId;
    }

    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConflictBooking that = (ConflictBooking) o;
        return Objects.equals(confId, that.confId) && Objects.equals(confEmpCode, that.confEmpCode) && Objects.equals(confFirstName, that.confFirstName) && Objects.equals(confLastName, that.confLastName) && Objects.equals(confFullName, that.confFullName) && Objects.equals(confDateIn, that.confDateIn) && Objects.equals(confDateOut, that.confDateOut) && Objects.equals(confStatusId, that.confStatusId) && Objects.equals(roomInfo, that.roomInfo) && Objects.equals(id, that.id) && Objects.equals(empCode, that.empCode) && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(fullName, that.fullName) && Objects.equals(dateIn, that.dateIn) && Objects.equals(dateOut, that.dateOut) && Objects.equals(statusId, that.statusId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(confId, confEmpCode, confFirstName, confLastName, confFullName, confDateIn, confDateOut, confStatusId, roomInfo, id, empCode, firstName, lastName, fullName, dateIn, dateOut, statusId);
    }

    @Override
    public String toString() {
        return "ConflictBooking{" +
                "confId='" + confId + '\'' +
                ", confEmpCode='" + confEmpCode + '\'' +
                ", confFirstName='" + confFirstName + '\'' +
                ", confLastName='" + confLastName + '\'' +
                ", confFullName='" + confFullName + '\'' +
                ", confDateIn='" + confDateIn + '\'' +
                ", confDateOut='" + confDateOut + '\'' +
                ", confStatusId='" + confStatusId + '\'' +
                ", roomInfo='" + roomInfo + '\'' +
                ", id='" + id + '\'' +
                ", empCode='" + empCode + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", fullName='" + fullName + '\'' +
                ", dateIn='" + dateIn + '\'' +
                ", dateOut='" + dateOut + '\'' +
                ", statusId='" + statusId + '\'' +
                '}';
    }
}
