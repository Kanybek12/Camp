package kg.kumtor.camp.dto.email;

import java.util.Objects;

public class TransferAppInfoDetail extends TransferApplicationInfo{
    private String locationFrom;
    private String locationTo;

    public String getLocationFrom() {
        return locationFrom;
    }

    public void setLocationFrom(String locationFrom) {
        this.locationFrom = locationFrom;
    }

    public String getLocationTo() {
        return locationTo;
    }

    public void setLocationTo(String locationTo) {
        this.locationTo = locationTo;
    }
}
