package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.EmployeeDao;
import kg.kumtor.camp.dto.EmployeeGuestDto;
import kg.kumtor.camp.entity.*;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.repository.GuestDetailInfoRepository;
import kg.kumtor.camp.service.EmployeeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final EmployeeDao employeeDao;

    private final GuestDetailInfoRepository guestDetailInfoRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository,
                               EmployeeDao employeeDao,
                               GuestDetailInfoRepository guestDetailInfoRepository) {
        this.employeeRepository = employeeRepository;
        this.employeeDao = employeeDao;
        this.guestDetailInfoRepository = guestDetailInfoRepository;
    }

    @Override
    @Transactional
    public Integer createGuest(EmployeeGuestDto employeeGuestDto) throws ApiException {

        Employee employee = new Employee();
        try {
            employee.setChangedBy(employeeDao.getAccessToken().getOtherClaims().get("emp_code").toString());
            employee.setDateChanged(LocalDateTime.now());
            employee.setFirstNameRu(employeeGuestDto.getFirstName());
            employee.setLastNameRu(employeeGuestDto.getLastName());
            employee.setDateBirth(employeeGuestDto.getDateBirth());
            employee.setSin(employeeGuestDto.getPin());
            employee.setGenderId(Gender.builder().id(employeeGuestDto.getGenderId()).build());
            employee.setEmployeeTypeId(VisitorType.builder().id(4).build());
            employee.setStatusCode("A");
            employee.setPayAccount(employeeGuestDto.getPayAccount());
            employee = employeeRepository.save(employee);

            GuestDetailInfo guestDetailInfo = new GuestDetailInfo();
            guestDetailInfo.setEmpCode(employee.getEmpCode());
            guestDetailInfo.setDateChanged(employee.getDateChanged());
            guestDetailInfo.setChangedBy(employee.getChangedBy());
            guestDetailInfo.setDepartment(employeeGuestDto.getDepartment());
            guestDetailInfo.setJobTitle(employeeGuestDto.getJobTitle());
            guestDetailInfoRepository.save(guestDetailInfo);
        } catch (Exception ex) {
            throw new ApiException(500, "Не удалось создать посетителя с именем: " + employeeGuestDto.getFirstName() + " " + employeeGuestDto.getLastName());
        }
        return employee.getEmpCode();
    }

}
