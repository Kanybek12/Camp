package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.auth.RegisterDto;
import kg.kumtor.camp.entity.Employee;
import kg.kumtor.camp.entity.Role;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Map;

public interface AuthContractService extends UserDetailsService {

    UserDetails loadUserByUsername(String empCode) throws UsernameNotFoundException;

    Employee getEmployee(String empCode);

    boolean checkIsRegistered(Map<String, Integer> empCode) throws ApiException;

    boolean checkEmpCodeAndSin(int empCode, String sin) throws ApiException;

    ResponseDTO register(RegisterDto passwordDto) throws ApiException;

    ResponseDTO updatePassword(RegisterDto credentials) throws ApiException;

    Role saveRole(Role role);
}
