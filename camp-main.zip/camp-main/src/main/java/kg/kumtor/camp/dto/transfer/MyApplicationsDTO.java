package kg.kumtor.camp.dto.transfer;

import lombok.*;

import java.util.Date;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MyApplicationsDTO {
    private long id;
    private Date dateCreated;
    TransferEmployeeDTO employee;
    private String applicationType;
    private Date plannedDate;
    private String info;
    private String status;
}
