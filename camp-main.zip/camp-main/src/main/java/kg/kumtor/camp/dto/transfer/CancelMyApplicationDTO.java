package kg.kumtor.camp.dto.transfer;

import lombok.*;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancelMyApplicationDTO {
    private long id;
    private String applicationType;
}
