package kg.kumtor.camp.dto.transfer.vahta;

import kg.kumtor.camp.dto.report.BusVahtaAppDTO;

import java.util.List;
import java.util.Objects;

public class BusVahtaReportsDto {

    private List<BusVahtaAppDTO> busVahtaUpList;

    private List<BusVahtaAppDTO> busVahtaDownList;

    private List<BusVahtaAppDTO> busVahtaUpContractList;

    private List<BusVahtaAppDTO> busVahtaDownContractList;

    private List<BusVahtaAppDTO> busVahtaUpGuestList;

    private List<BusVahtaAppDTO> busVahtaDownGuestList;

    public BusVahtaReportsDto() {
    }

    public List<BusVahtaAppDTO> getBusVahtaUpList() {
        return busVahtaUpList;
    }

    public void setBusVahtaUpList(List<BusVahtaAppDTO> busVahtaUpList) {
        this.busVahtaUpList = busVahtaUpList;
    }

    public List<BusVahtaAppDTO> getBusVahtaDownList() {
        return busVahtaDownList;
    }

    public void setBusVahtaDownList(List<BusVahtaAppDTO> busVahtaDownList) {
        this.busVahtaDownList = busVahtaDownList;
    }

    public List<BusVahtaAppDTO> getBusVahtaUpContractList() {
        return busVahtaUpContractList;
    }

    public void setBusVahtaUpContractList(List<BusVahtaAppDTO> busVahtaUpContractList) {
        this.busVahtaUpContractList = busVahtaUpContractList;
    }

    public List<BusVahtaAppDTO> getBusVahtaDownContractList() {
        return busVahtaDownContractList;
    }

    public void setBusVahtaDownContractList(List<BusVahtaAppDTO> busVahtaDownContractList) {
        this.busVahtaDownContractList = busVahtaDownContractList;
    }

    public List<BusVahtaAppDTO> getBusVahtaUpGuestList() {
        return busVahtaUpGuestList;
    }

    public void setBusVahtaUpGuestList(List<BusVahtaAppDTO> busVahtaUpGuestList) {
        this.busVahtaUpGuestList = busVahtaUpGuestList;
    }

    public List<BusVahtaAppDTO> getBusVahtaDownGuestList() {
        return busVahtaDownGuestList;
    }

    public void setBusVahtaDownGuestList(List<BusVahtaAppDTO> busVahtaDownGuestList) {
        this.busVahtaDownGuestList = busVahtaDownGuestList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BusVahtaReportsDto that = (BusVahtaReportsDto) o;
        return Objects.equals(busVahtaUpList, that.busVahtaUpList) && Objects.equals(busVahtaDownList, that.busVahtaDownList) && Objects.equals(busVahtaUpContractList, that.busVahtaUpContractList) && Objects.equals(busVahtaDownContractList, that.busVahtaDownContractList) && Objects.equals(busVahtaUpGuestList, that.busVahtaUpGuestList) && Objects.equals(busVahtaDownGuestList, that.busVahtaDownGuestList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(busVahtaUpList, busVahtaDownList, busVahtaUpContractList, busVahtaDownContractList, busVahtaUpGuestList, busVahtaDownGuestList);
    }

    @Override
    public String toString() {
        return "BusVahtaReportsDto{" +
                "busVahtaUpList=" + busVahtaUpList +
                ", busVahtaDownList=" + busVahtaDownList +
                ", busVahtaUpContractList=" + busVahtaUpContractList +
                ", busVahtaDownContractList=" + busVahtaDownContractList +
                ", busVahtaUpGuestList=" + busVahtaUpGuestList +
                ", busVahtaDownGuestList=" + busVahtaDownGuestList +
                '}';
    }
}
