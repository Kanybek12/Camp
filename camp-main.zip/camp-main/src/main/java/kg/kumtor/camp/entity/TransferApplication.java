package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "transfer_application",uniqueConstraints = {
        @UniqueConstraint(name = "unique_emp_code_and_transfer_date_from",
                columnNames = {"emp_code", "transfer_date_from"}),
        @UniqueConstraint(name = "unique_emp_code_and_transfer_date_to", columnNames = {"emp_code", "transfer_date_to"})})
public class TransferApplication {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @ManyToOne
    @JoinColumn(name = "visitor_type_id", foreignKey = @ForeignKey(name = "fk_visitor_type_id"))
    private VisitorType visitorType;

    @OneToOne
    @JoinColumn(name = "emp_code", foreignKey = @ForeignKey(name = "fk_emp_code"))
    private Employee empCode;

    @Column(name = "first_name", length = 255)
    private String firstName;

    @Column(name = "last_name", length = 255)
    private String lastName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_created")
    private LocalDateTime DateCreated;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date_birth")
    private LocalDate DateBirth;

    @Column(name = "pin", length = 50)
    private String pin;

    @Column(name = "phone_number", length = 50)
    private String phoneNumber;

    @ManyToOne
    @JoinColumn(name = "gender_id", foreignKey = @ForeignKey(name = "fk_gender_id"))
    private Gender genderId;

    @Column(name = "department", length = 255)
    private String department;

    @Column(name = "job_title", length = 255)
    private String jobTitle;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "transfer_date_from")
    private LocalDate transferDateFrom;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "transfer_date_to")
    private LocalDate transferDateTo;

//    @ManyToOne
//    @JoinColumn(name = "application_type_id", foreignKey = @ForeignKey(name = "fk_application_type_id"))
//    private ApplicationType applicationType;

    @Column(name = "bus_transfer_up")
    private boolean busTransferUp;

    @Column(name = "vahta_transfer_up")
    private boolean vahtaTransferUp;

    @Column(name = "bus_transfer_down")
    private boolean busTransferDown;

    @Column(name = "vahta_transfer_down")
    private boolean vahtaTransferDown;

    @Column(name = "on_car")
    private boolean onCar;
    @Column(name = "on_car_down")
    private boolean onCarDown;

    @Column(name = "receiving_side", length = 255)
    private String receivingSide;

    @Column(name="receiving_person")
    private Integer receivingPerson;

    @Column(name = "note")
    private String note;

    @Column(name = "agreement")
    private boolean agreement;

    @Column(name = "camp_live_need")
    private boolean campLiveNeed;

    @ManyToOne
    @JoinColumn(name = "status_id", foreignKey = @ForeignKey(name = "fk_status_id"))
    private Status statusId;

    @Column(name = "my_application")
    private boolean myApplication;

    @Column(name = "created_by")
    private Integer createdBy;
    @OneToOne
    @JoinColumn(name = "booking_id", foreignKey = @ForeignKey(name = "fk_booking_id"),nullable = true)
    private Booking booking;
}
