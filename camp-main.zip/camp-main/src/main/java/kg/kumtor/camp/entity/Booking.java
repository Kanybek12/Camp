package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(uniqueConstraints = {
        @UniqueConstraint(name = "unique_bed_in_date_in_date_out",
                columnNames = {"bed_id", "date_in", "date_out"}),
        @UniqueConstraint(name = "unique_emp_code_date_in_date_out", columnNames = {"emp_code", "date_in", "date_out"})})
public class Booking implements Serializable {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @OneToOne
    @JoinColumn(name = "emp_code", foreignKey = @ForeignKey(name = "fk_emp_code"), nullable = false)
    private Employee empCode;

    @OneToOne
    @JoinColumn(name = "bed_id", foreignKey = @ForeignKey(name = "fk_bed_id"), nullable = false)
    private Bed bedId;

    // LocalDate or LocalDateTime
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date_in", nullable = false)
    private LocalDate dateIn;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date_out", nullable = false)
    private LocalDate dateOut;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "check_in")
    private LocalDate checkIn;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "check_out")
    private LocalDate checkOut;

    @ManyToOne
    @JoinColumn(name = "status_id", foreignKey = @ForeignKey(name = "fk_status_id"))
    private Status statusId;

    @Column(name = "pay_account", length = 50)
    private String payAccount;

    @Column(name = "note", length = 255)
    private String note;

    @Column(name = "first_name", length = 255)
    private String firstName;

    @Column(name = "last_name", length = 255)
    private String lastName;

    @ManyToOne
    @JoinColumn(name = "booking_gender_id", foreignKey = @ForeignKey(name = "fk_gender_id"))
    private Gender genderId;

    @Column(name = "department", length = 255)
    private String department;

    @Column(name = "job_title", length = 255)
    private String jobTitle;

    @Column(name = "transit_status")
    private String transitStatus;

//    @OneToMany(mappedBy = "bookingId")
//    private Set<BookingHistory> bookingHistories;

    @Column(name = "on_schedule")
    private int onSchedule = 0;

//    public Booking(String changedBy, LocalDateTime dateChanged, Employee empCode, Bed bedId, LocalDate dateIn, LocalDate dateOut, LocalDate checkIn, LocalDate checkOut, Status statusId, String payAccount, String note, String firstName, String lastName, Gender genderId, String department, String jobTitle, String transitStatus, Set<BookingHistory> bookingHistories, int onSchedule) {
    public Booking(String changedBy, LocalDateTime dateChanged, Employee empCode, Bed bedId, LocalDate dateIn, LocalDate dateOut, LocalDate checkIn, LocalDate checkOut, Status statusId, String payAccount, String note, String firstName, String lastName, Gender genderId, String department, String jobTitle, String transitStatus,  int onSchedule) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.empCode = empCode;
        this.bedId = bedId;
        this.dateIn = dateIn;
        this.dateOut = dateOut;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.statusId = statusId;
        this.payAccount = payAccount;
        this.note = note;
        this.firstName = firstName;
        this.lastName = lastName;
        this.genderId = genderId;
        this.department = department;
        this.jobTitle = jobTitle;
        this.transitStatus = transitStatus;
//        this.bookingHistories = bookingHistories;
        this.onSchedule = onSchedule;
    }

}
