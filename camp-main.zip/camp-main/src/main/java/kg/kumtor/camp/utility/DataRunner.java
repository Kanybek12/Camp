package kg.kumtor.camp.utility;

import kg.kumtor.camp.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;

@Slf4j
//@Component
@RequiredArgsConstructor
public class DataRunner implements CommandLineRunner {

    private final DepartmentRepository departmentRepository;
    private final JobTitleRepository jobTitleRepository;
    private final EmployeeRepository employeeRepository;
    private final BlockRepository blockRepository;
    private final LocationRepository locationRepository;
    private final RoomRepository roomRepository;
    private final RoomCapacityRepository roomCapacityRepository;
    private final RoomCategoryRepository roomCategoryRepository;

    private final GenderRepository genderRepository;
    private final BedRepository bedRepository;
    private final BookingRepository bookingRepository;
    private final StatusRepository statusRepository;
    private final CostCenterRepository costCenterRepository;

    private final WorkLocationRepository workLocationRepository;
    private final VisitorTypeRepository visitorTypeRepository;
    private final CampRepository campRepository;

    @Override
    public void run(String... args) throws Exception {

//        campRepository.save(new Camp("CMDLRunner", LocalDateTime.now(), "Главный лагерь",
//                locationRepository.getById(1)));
//        campRepository.save(new Camp("CMDLRunner", LocalDateTime.now(), "Лагерь контрактников",
//                locationRepository.getById(2)));
//        campRepository.findAll().forEach((camp -> {
//            log.info("Inserted with CMDLRunner: {}", camp);
//        }));

//        visitorTypeRepository.save(new VisitorType("CMDLRunner", LocalDateTime.now(), "Штатный сотрудник рудника"));
//        visitorTypeRepository.save(new VisitorType("CMDLRunner", LocalDateTime.now(), "Сотрудник КГК"));
//        visitorTypeRepository.save(new VisitorType("CMDLRunner", LocalDateTime.now(), "Контрактник"));
//        visitorTypeRepository.save(new VisitorType("CMDLRunner", LocalDateTime.now(), "Гость"));
//        visitorTypeRepository.findAll().forEach((visitorType -> {
//            log.info("Inserting with CMDLRunner: {}", visitorType);
//        }));

//        departmentRepository.save(new Department("CMDLRunner", LocalDateTime.now(), "Mine Training", "Горный " +
//                "отдел. Треннинг"));
//        departmentRepository.save(new Department("CMDLRunner", LocalDateTime.now(), "IT Security", "Информационная " +
//                "безопасность"));
//        departmentRepository.findAll().forEach((department -> {
//            log.info("Inserting with CMDLRunner: {}", department);
//        }));

//        jobTitleRepository.save(new JobTitle("CMDLRunner", LocalDateTime.now(), "ACC002", "Accountant Business Advances 1",
//                "Бухгалтер", 1));
//        jobTitleRepository.save(new JobTitle("CMDLRunner", LocalDateTime.now(), "DRV001", "Driver",
//                "Водитель автомобиля", 1));
//        jobTitleRepository.findAll().forEach((jobTitle -> {
//            log.info("Inserting with CMDLRunner: {}", jobTitle);
//        }));

//        employeeRepository.save(new Employee("CMDLRunner", LocalDateTime.now(), 300001, "FirstName1", "MiddleName1",
//                "LastName1", "Имя1", "Отчество", "Фамилия", "A", "email1@kumtor.kg", null, null, "0123456789",
//                departmentRepository.getById(1L), jobTitleRepository.getById(1L), null,
//                0, null, genderRepository.getById(1), workLocationRepository.getById(1)));
//
//        employeeRepository.save(new Employee("CMDLRunner", LocalDateTime.now(), 300002, "FirstName2", "MiddleName2",
//                "LastName2", "Имя2", "Отчество2", "Фамилия2", "A", "email2@kumtor.kg", null, null, "0123456789",
//                departmentRepository.getById(2L), jobTitleRepository.getById(2L), null,
//                0, null,genderRepository.getById(1), workLocationRepository.getById(1)));
//
//        employeeRepository.save(new Employee("CMDLRunner", LocalDateTime.now(), 300003, "FirstName3", "MiddleName3",
//                "LastName3", "Имя3", "Отчество3", "Фамилия3", "A", "email3@kumtor.kg", null, null, "0123456789",
//                departmentRepository.getById(1L), jobTitleRepository.getById(1L), null,
//                0, null,genderRepository.getById(1), workLocationRepository.getById(1)));
//
//        employeeRepository.save(new Employee("CMDLRunner", LocalDateTime.now(), 300004, "FirstName4", "MiddleName4",
//                "LastName4", "Имя4", "Отчество4", "Фамилия4", "A", "email4@kumtor.kg", null, null, "0123456789",
//                departmentRepository.getById(2L), jobTitleRepository.getById(2L), null,
//                0, null, genderRepository.getById(1), workLocationRepository.getById(1)));
//
//        employeeRepository.findAll().forEach((employee -> {
//            log.info("Inserting with CMDLRunner: {}", employee);
//        }));

//        locationRepository.save(new Location("CMDLRunner", LocalDateTime.now(), "Main camp", "Главный лагерь",
//                (short) 1,
//                "A"));
//        locationRepository.save(new Location("CMDLRunner", LocalDateTime.now(), "Contract camp", "Лагерь контрактников",
//                (short) 1, "A"));
//        locationRepository.findAll().forEach((location -> {
//            log.info("Inserting with CMDLRunner: {}", location);
//        }));
//
//
//        blockRepository.save(new Block("CMDLRunner", LocalDateTime.now(), "01", locationRepository.getById(2)));
//        blockRepository.save(new Block("CMDLRunner", LocalDateTime.now(), "02", locationRepository.getById(2)));
//        blockRepository.findAll().forEach((block -> {
//            log.info("Inserting with CMDLRunner: {}", block);
//        }));
//
//        roomCapacityRepository.save(new RoomCapacity("CMDLRunner", LocalDateTime.now(), "Double", 2));
//        roomCapacityRepository.save(new RoomCapacity("CMDLRunner", LocalDateTime.now(), "Twelve", 12));
//        roomCapacityRepository.findAll().forEach((roomCapacity -> {
//            log.info("Inserting with CMDLRunner: {}", roomCapacity);
//        }));
//
//        roomCategoryRepository.save(new RoomCategory("CMDLRunner", LocalDateTime.now(), "Standard"));
//        roomCategoryRepository.save(new RoomCategory("CMDLRunner", LocalDateTime.now(), "VIP"));
//        roomCategoryRepository.findAll().forEach((roomCategory -> {
//            log.info("Inserting with CMDLRunner: {}", roomCategory);
//        }));
//
//        genderRepository.save(new Gender("CMDLRunner", LocalDateTime.now(), "Male"));
//        genderRepository.save(new Gender("CMDLRunner", LocalDateTime.now(), "Female"));
//        genderRepository.findAll().forEach((gender -> {
//            log.info("Inserting with CMDLRunner: {}", gender);
//        }));
//
//        statusRepository.save(new Status("CMDLRunner", LocalDateTime.now(), "Pending approval"));
//        statusRepository.save(new Status("CMDLRunner", LocalDateTime.now(), "Approved"));
//        statusRepository.save(new Status("CMDLRunner", LocalDateTime.now(), "Rejected"));
//        statusRepository.save(new Status("CMDLRunner", LocalDateTime.now(), "Check In"));
//        statusRepository.save(new Status("CMDLRunner", LocalDateTime.now(), "Check Out"));
//        statusRepository.findAll().forEach((statusCode -> {
//            log.info("Inserting with CMDLRunner: {}", statusCode);
//        }));
//
//        roomRepository.save(new Room("CMDLRunner", LocalDateTime.now(), blockRepository.getById(1), 1,
//                roomCapacityRepository.getById(2), roomCategoryRepository.getById(1), genderRepository.getById(1)));
//        roomRepository.save(new Room("CMDLRunner", LocalDateTime.now(), blockRepository.getById(2), 1,
//                roomCapacityRepository.getById(12), roomCategoryRepository.getById(2), genderRepository.getById(1)));
//        roomRepository.findAll().forEach((room -> {
//            log.info("Inserting with CMDLRunner: {}", room);
//        }));
//
//        bedRepository.save(new Bed("CMDLRunner", LocalDateTime.now(), roomRepository.getById(1L), "A", 1));
//        bedRepository.save(new Bed("CMDLRunner", LocalDateTime.now(), roomRepository.getById(2L), "A", 1));
//        bedRepository.save(new Bed("CMDLRunner", LocalDateTime.now(), roomRepository.getById(2L), "A", 2));
//        bedRepository.findAll().forEach((bed -> {
//            log.info("Inserting with CMDLRunner: {}", bed);
//        }));
//
//        costCenterRepository.save(new CostCenter("CMDLRunner", LocalDateTime.now(), "607.1", "IT Bishkek", "Бишкек. " +
//                "ИТ"));
//        costCenterRepository.save(new CostCenter("CMDLRunner", LocalDateTime.now(), "301.1", "Mill Administration", "ЗИФ. Администрация"));
//        costCenterRepository.findAll().forEach((costCenter -> {
//            log.info("Inserting with CMDLRunner: {}", costCenter);
//        }));
//
//        bookingRepository.save(new Booking("CMDLRunner", LocalDateTime.now(), employeeRepository.getById(300001),
//                bedRepository.getById(1L), LocalDate.of(2022, 7, 1), LocalDate.of(2022, 7, 15), LocalDate.of(2022, 7,
//                1), LocalDate.of(2022, 7, 15), statusRepository.getById(1), costCenterRepository.getById(1L),"nurs","mamytov",genderRepository.getById(1),"it","proger","test"));
//        bookingRepository.save(new Booking("CMDLRunner", LocalDateTime.now(), employeeRepository.getById(300002),
//                bedRepository.getById(2L), LocalDate.of(2022, 7, 10), LocalDate.of(2022, 7, 20), LocalDate.of(2022, 7
//                , 10), LocalDate.of(2022, 7, 20), statusRepository.getById(1), costCenterRepository.getById(2L),"tilek","mamytov",genderRepository.getById(1),"it","proger","test"));
//        bookingRepository.save(new Booking("CMDLRunner", LocalDateTime.now(), employeeRepository.getById(300002),
//                bedRepository.getById(2L), LocalDate.of(2022, 7, 15), LocalDate.of(2022, 7, 20), LocalDate.of(2022, 7
//                , 15), LocalDate.of(2022, 7, 20), statusRepository.getById(1), costCenterRepository.getById(1L),"esen","omurchiev",genderRepository.getById(1),"it","proger","test"));
//        bookingRepository.save(new Booking("CMDLRunner", LocalDateTime.now(), employeeRepository.getById(300002),
//                bedRepository.getById(2L), LocalDate.of(2022, 7, 15), LocalDate.of(2022, 7, 20), LocalDate.of(2022, 7
//                , 15), LocalDate.of(2022, 7, 20), statusRepository.getById(3), costCenterRepository.getById(2L),"kuba","abdybekov",genderRepository.getById(1),"it","proger","test"));
//        bookingRepository.findAll().forEach((booking -> {
//            log.info("Inserting with CMDLRunner: {}", booking);
//        }));

    }
}
