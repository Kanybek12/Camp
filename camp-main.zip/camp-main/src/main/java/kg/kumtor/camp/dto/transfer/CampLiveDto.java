package kg.kumtor.camp.dto.transfer;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;

public class CampLiveDto {
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateIn;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOut;

    public CampLiveDto() {
    }

    public CampLiveDto(LocalDate dateIn, LocalDate dateOut) {
        this.dateIn = dateIn;
        this.dateOut = dateOut;
    }

    public LocalDate getDateIn() {
        return dateIn;
    }

    public void setDateIn(LocalDate dateIn) {
        this.dateIn = dateIn;
    }

    public LocalDate getDateOut() {
        return dateOut;
    }

    public void setDateOut(LocalDate dateOut) {
        this.dateOut = dateOut;
    }
}
