package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.auth.KeycloakUserDto;
import kg.kumtor.camp.service.KeycloakService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(path = "api/keycloak/user")
public class KeycloakController {

    private final KeycloakService keycloakService;

//    @RolesAllowed("*")
    @PostMapping
    public String addUser(@RequestBody KeycloakUserDto userDto){
        System.out.println(userDto);
        keycloakService.addUser(userDto);
        return "Пользователь успешно добавлен";
    }

    @GetMapping(path = "/{userName}")
    public List<UserRepresentation> getUser(@PathVariable("userName") String userName){
        List<UserRepresentation> user = keycloakService.getUser(userName);
        return user;
    }
}
