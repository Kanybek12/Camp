package kg.kumtor.camp.dto.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FullBookingStatsDTO {

//    private BookingStatsDTO pendingApproval;
    private BookingStatsDTO approved;
    private BookingStatsDTO rejected;
}
