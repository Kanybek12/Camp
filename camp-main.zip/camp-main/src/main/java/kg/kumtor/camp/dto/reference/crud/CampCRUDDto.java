package kg.kumtor.camp.dto.reference.crud;

public class CampCRUDDto {
    private int id;
    private String nameRu;
    private String changedBy;
    private int locationId;
    private String locationName;
    private String statusCode;
    public CampCRUDDto() {
    }

    public CampCRUDDto(int id, String nameRu, String changedBy, int locationId, String locationName, String statusCode) {
        this.id = id;
        this.nameRu = nameRu;
        this.changedBy = changedBy;
        this.locationId = locationId;
        this.locationName = locationName;
        this.statusCode = statusCode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameRu() {
        return nameRu;
    }

    public void setNameRu(String nameRu) {
        this.nameRu = nameRu;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
