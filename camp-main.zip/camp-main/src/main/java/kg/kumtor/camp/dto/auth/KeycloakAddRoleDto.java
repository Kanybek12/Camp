package kg.kumtor.camp.dto.auth;

import lombok.Data;

@Data
public class KeycloakAddRoleDto {

    private String roleName;

    private String userName;
}
