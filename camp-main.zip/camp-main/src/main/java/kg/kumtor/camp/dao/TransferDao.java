package kg.kumtor.camp.dao;

import kg.kumtor.camp.dto.email.OwnCarInfo;
import kg.kumtor.camp.dto.email.TransferAppInfoDetail;
import kg.kumtor.camp.dto.email.TransferApplicationInfo;
import kg.kumtor.camp.dto.email.TransferEmpCodeList;
import kg.kumtor.camp.dto.report.BusVahtaAppDTO;
import kg.kumtor.camp.exception.ApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

import static kg.kumtor.camp.exception.ExceptionsEnum.EMPTY_RESULT;

@Slf4j
@Repository
public class TransferDao {
    private final JdbcTemplate jdbcTemplate;


    public TransferDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public OwnCarInfo getInfoOwnCar(Integer id) {
        String query = "select ta.emp_code, ta.first_name, ta.last_name, ta.status_id, ta.transfer_date_from as date_from, ta.transfer_date_to as date_to,  \n" +
                "\t   ct.car_number as car_number,\n" +
                "       ct.car_model  as car_model,\n" +
                "       ct.driver as driver\n" +
                "from camp.transfer_application ta right join camp.car_transfer ct on ta.id = ct.mine_application_id\n" +
                "where ta.id = ?\n" +
                "group by ta.emp_code,\n" +
                "       ta.first_name,\n" +
                "       ta.last_name,\n" +
                "       ta.status_id,\n" +
                "       ta.transfer_date_from,\n" +
                "       ta.transfer_date_to, car_number, car_model, driver;";
        Object[] args = new Object[]{id};
        return jdbcTemplate.queryForObject(query, args, new BeanPropertyRowMapper<>(OwnCarInfo.class));
    }

    public TransferApplicationInfo getInfoBooking(Long id) {
        String query = "select emp_code , first_name , last_name , status_id , date_in , date_out  " +
                "from camp.booking b where b.id = ?";
        Object[] args = new Object[]{id};
        return jdbcTemplate.queryForObject(query, args, new BeanPropertyRowMapper<>(TransferApplicationInfo.class));
    }

    public TransferApplicationInfo getStatusTransferApplication(Long id) {

        String query = "select ta.emp_code , ta.first_name , ta.last_name , ta.status_id,\n" +
                "  b.date_in , b.date_out , ta.on_car \n" +
                "from camp.transfer_application ta left join camp.booking b on ta.booking_id = b.id \n" +
                "where ta.id = ?";
        Object[] args = new Object[]{id};
        return jdbcTemplate.queryForObject(query, args, new BeanPropertyRowMapper<>(TransferApplicationInfo.class));
    }

    public List<TransferEmpCodeList> getTransferEmpCodeList(Integer transferAppId, Integer status) {
        String query = "select code, email, who from camp.get_info_for_email_notification(?,?)";
        Object[] args = new Object[]{transferAppId, status};
        return jdbcTemplate.query(query, args, new BeanPropertyRowMapper<>(TransferEmpCodeList.class));
    }

    public TransferAppInfoDetail getEmpCodeByBusTransferId(long id){
        String query = "SELECT ta.emp_code, ta.first_name, ta.last_name, \n" +
                "       ta.status_id, ta.transfer_date_from as date_in, ta.transfer_date_to as date_out, \n" +
                "       location_from.title_ru AS location_from, location_to.title_ru AS location_to\n" +
                "FROM camp.bus_transfer bt \n" +
                "LEFT JOIN camp.transfer_application ta on bt.mine_application_id = ta.id\n" +
                "LEFT JOIN camp.location location_from ON location_from.id = bt.location_from\n" +
                "LEFT JOIN camp.location location_to ON location_to.id = bt.location_to\n" +
                "where bt.id = ?";

        return jdbcTemplate.queryForObject(query, new Object [] {id}, new BeanPropertyRowMapper<>(TransferAppInfoDetail.class));
    }
    public List<BusVahtaAppDTO> getApprovedVahtaList(LocalDate date, Integer empCode,
                                                          Integer applicationType, Integer visitorType) throws ApiException {
        List<BusVahtaAppDTO> resultList = null;
        String query = "select \n" +
                "   t.transfer_id ,\n" +
                "   t.emp_code ,\n" +
                "   t.full_name ,\n" +
                "   t.visitor_type ,\n" +
                "   t.visitor_type_id ,\n" +
                "   t.transfer_date ,\n" +
                "   t.application_type ,\n" +
                "   t.note ,\n" +
                "   t.status ,\n" +
                "   t.camp_live_need ,\n" +
                "   t.department ,\n" +
                "   t.location_from ,\n" +
                "   t.location_to ,\n" +
                "   t.v2_location_from,\n" +
                "   t.v2_location_to,\n" +
                "   t.creator ,\n" +
                "   t.application_type_id\n" +
                "FROM (select \n" +
                "       ROW_NUMBER() OVER(PARTITION BY v.mine_application_id ORDER BY v.transfer_id asc) AS RN,\n" +
                "       v.transfer_id ,\n" +
                "       v.emp_code ,\n" +
                "       v.full_name ,\n" +
                "       v.visitor_type ,\n" +
                "       v.visitor_type_id ,\n" +
                "       v.transfer_date ,\n" +
                "       v.application_type ,\n" +
                "       v.note ,\n" +
                "       v.status ,\n" +
                "       v.camp_live_need ,\n" +
                "       v.department ,\n" +
                "       v2.location_from,\n" +
                "       v2.location_to,\n" +
                "       v.location_from as v2_location_from,\n" +
                "       v.location_to as v2_location_to,\n"+
                "       v.creator ,\n" +
                "       v.application_type_id \n" +
                "     from  camp.vw_vahta_without_settlement_applications v \n" +
                "           left join camp.vw_vahta_without_settlement_applications v2\n" +
                "       on v.mine_application_id = v2.mine_application_id \n" +
                "     and v.transfer_id <> v2.transfer_id\n" +
                "     WHERE v.status_id > 1\n" +
                "                AND (?::DATE IS NULL OR v.transfer_date = ?) \n" +
                "                AND (?::INTEGER IS NULL OR v.emp_code = ?) \n" +
                "                AND (?::INTEGER IS NULL OR v.application_type_id = ?) \n" +
                "                AND (?::INTEGER IS NULL OR v.visitor_type_id = ?)\n" +
                "                ) as t\n" +
                "where t.rn = 1";
        try {
            resultList = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType},
                    new BeanPropertyRowMapper<>(BusVahtaAppDTO.class));

            log.info("List of Vahta applications with status > 1 received");
        } catch (Exception ex) {
            log.error("Error while getting list of Vahta applications with status > 1: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
        return resultList;
    }

    public List<BusVahtaAppDTO> getApprovedBusList(LocalDate date, Integer empCode,
                                                              Integer applicationType, Integer visitorType) throws ApiException {
        List<BusVahtaAppDTO> resultList = null;
        String query = "select \n" +
                "   t.transfer_id ,\n" +
                "   t.emp_code ,\n" +
                "   t.full_name ,\n" +
                "   t.visitor_type ,\n" +
                "   t.visitor_type_id ,\n" +
                "   t.transfer_date ,\n" +
                "   t.application_type ,\n" +
                "   t.note ,\n" +
                "   t.status ,\n" +
                "   t.camp_live_need ,\n" +
                "   t.department ,\n" +
                "   t.location_from ,\n" +
                "   t.location_to ,\n" +
                "   t.v2_location_from,\n" +
                "   t.v2_location_to,\n" +
                "   t.creator ,\n" +
                "   t.application_type_id\n" +
                "FROM (select \n" +
                "       ROW_NUMBER() OVER(PARTITION BY v.mine_application_id ORDER BY v.transfer_id asc) AS RN,\n" +
                "       v.transfer_id ,\n" +
                "       v.emp_code ,\n" +
                "       v.full_name ,\n" +
                "       v.visitor_type ,\n" +
                "       v.visitor_type_id ,\n" +
                "       v.transfer_date ,\n" +
                "       v.application_type ,\n" +
                "       v.note ,\n" +
                "       v.status ,\n" +
                "       v.camp_live_need ,\n" +
                "       v.department ,\n" +
                "       v.location_from,\n" +
                "       v.location_to,\n"+
                "       v2.location_from  as v2_location_from,\n" +
                "       v2.location_to  as v2_location_to,\n" +
                "       v.creator ,\n" +
                "       v.application_type_id \n" +
                "     from  camp.vw_bus_without_settlement_applications v \n" +
                "           left join camp.vw_bus_without_settlement_applications v2\n" +
                "       on v.mine_application_id = v2.mine_application_id \n" +
                "     and v.transfer_id <> v2.transfer_id\n" +
                "     WHERE v.status_id > 1\n" +
                "                AND (?::DATE IS NULL OR v.transfer_date = ?) \n" +
                "                AND (?::INTEGER IS NULL OR v.emp_code = ?) \n" +
                "                AND (?::INTEGER IS NULL OR v.application_type_id = ?) \n" +
                "                AND (?::INTEGER IS NULL OR v.visitor_type_id = ?)\n" +
                "                ) as t\n" +
                "where t.rn = 1";
        try {
            resultList = jdbcTemplate.query(query,
                    new Object[]{date, date, empCode, empCode, applicationType, applicationType, visitorType, visitorType},
                    new BeanPropertyRowMapper<>(BusVahtaAppDTO.class));

            log.info("List of Bus applications with status > 1 received");
        } catch (Exception ex) {
            log.error("Error while getting list of Bus applications with status > 1: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
        return resultList;
    }
}
