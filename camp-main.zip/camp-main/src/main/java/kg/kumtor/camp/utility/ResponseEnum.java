package kg.kumtor.camp.utility;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResponseEnum {

    ROOM_CAPACITY_ADDED(201, "Запись с вместимостью комнаты успешно добавлена"),
    ROOM_CAPACITY_UPDATED(201, "Запись с вместимостью комнаты успешно обновлена"),
    ROOM_CATEGORY_ADDED(201, "Запись с категорией комнаты успешно добавлена"),
    ROOM_CATEGORY_UPDATED(201, "Запись с категорией комнаты успешно обновлена"),
    BED_ADDED(201, "Запись кровати успешно добавлена"),
    BED_UPDATED(201, "Запись кровати успешно обновлена"),
    BED_DELETED(201, "Запись(и) кровати(ей) успешно удалена(ы)"),
    EMPLOYEE_ADDED(201, "Запись пользователя успешно добавлена"),
    EMPLOYEE_UPDATED(201, "Запись пользователя успешно обновлена"),
    EMPLOYEE_DELETED(201, "Запись пользователя успешно удалена"),
    PERSONAL_TRANSFER_ASCENT_SAVED(201, "Информация по транспортировке на подъём успешно сохранена"),
    PERSONAL_TRANSFER_DESCENT_SAVED(201, "Информация по транспортировке на спуск успешно сохранена"),
    PERSONAL_TRANSFER_ASCENT_UPDATED(201, "Информация по транспортировке на подъём успешно обновлена"),
    PERSONAL_TRANSFER_DESCENT_UPDATED(201, "Информация по транспортировке на спуск успешно обновлена"),
    APPLICATION_FOR_SETTLEMENT_CANCELED(201, "Заявка на заселение успешно отменена"),
    USER_REGISTERED(201, "Пользователь успешно зарегистрирован"),
    CHECK_IN_SET(201, "Дата заезда успешно установлена"),
    CHECK_OUT_SET(201, "Дата выезда успешно установлена"),
    CHECK_IN_CANCELED(201, "Заезд успешно отменен"),
    APPROVER_ADDED(201, "Запись утвердителя успешно добавлена"),
    APPROVER_UPDATED(201, "Запись утвердителя успешно обновлена"),
    APPROVER_DELETED(201, "Запись утвердителя успешно удалена"),
    VISITOR_ADDED(201, "Запись постоянного жителя успешно добавлена"),
    VISITOR_DELETED(201, "Запись постоянного жителя успешно удалена"),
    ;

    private int code;
    private String message;
}
