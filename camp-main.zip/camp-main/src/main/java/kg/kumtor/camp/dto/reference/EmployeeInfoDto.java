package kg.kumtor.camp.dto.reference;

import java.time.LocalDate;

public class EmployeeInfoDto {
    private Integer id;
    private String firstName;
    private String lastName;
    private Integer gender;
    private String department;
    private Long departmentId;
    private String jobTitle;
    private Long jobTitleId;
    private LocalDate dateBirth;
    private String pin;
    private Integer campId;
    private Integer blockId;
    private Long roomId;
    private Integer genderId;
    private Long bedId;
    private String payAccount;
    private Integer employeeTypeId;

    public EmployeeInfoDto() {
    }

    public EmployeeInfoDto(Integer id, String firstName, String lastName, Integer gender, String department, Long departmentId, String jobTitle, Long jobTitleId, LocalDate dateBirth, String pin, Integer campId, Integer blockId, Long roomId, Integer genderId, Long bedId, String payAccount, Integer employeeTypeId) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.department = department;
        this.departmentId = departmentId;
        this.jobTitle = jobTitle;
        this.jobTitleId = jobTitleId;
        this.dateBirth = dateBirth;
        this.pin = pin;
        this.campId = campId;
        this.blockId = blockId;
        this.roomId = roomId;
        this.genderId = genderId;
        this.bedId = bedId;
        this.payAccount = payAccount;
        this.employeeTypeId = employeeTypeId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public LocalDate getDateBirth() {
        return dateBirth;
    }

    public void setDateBirth(LocalDate dateBirth) {
        this.dateBirth = dateBirth;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public Long getJobTitleId() {
        return jobTitleId;
    }

    public void setJobTitleId(Long jobTitleId) {
        this.jobTitleId = jobTitleId;
    }

    public Integer getCampId() {
        return campId;
    }

    public void setCampId(Integer campId) {
        this.campId = campId;
    }

    public Integer getBlockId() {
        return blockId;
    }

    public void setBlockId(Integer blockId) {
        this.blockId = blockId;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public Long getBedId() {
        return bedId;
    }

    public void setBedId(Long bedId) {
        this.bedId = bedId;
    }

    public Integer getGenderId() {
        return genderId;
    }

    public void setGenderId(Integer genderId) {
        this.genderId = genderId;
    }

    public String getPayAccount() {
        return payAccount;
    }

    public void setPayAccount(String payAccount) {
        this.payAccount = payAccount;
    }

    public Integer getEmployeeTypeId() {
        return employeeTypeId;
    }

    public void setEmployeeTypeId(Integer employeeTypeId) {
        this.employeeTypeId = employeeTypeId;
    }
}
