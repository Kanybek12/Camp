package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.email.Email;
import kg.kumtor.camp.exception.ApiException;

public interface NotificationService {
     void sendMessage(Email message) throws ApiException;
}
