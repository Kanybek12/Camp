package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.CostCenterDTO;
import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.reference.*;
import kg.kumtor.camp.dto.reference.crud.*;
import kg.kumtor.camp.dto.transfer.MyApplicationTypeDTO;
import kg.kumtor.camp.entity.*;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.*;
import kg.kumtor.camp.service.UtilityService;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.Principal;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;
import static kg.kumtor.camp.utility.ApplicationTypeEnum.*;
import static kg.kumtor.camp.utility.ResponseEnum.*;

@Slf4j
@Service
@javax.transaction.Transactional
public class UtilityServiceImpl implements UtilityService {
    private ModelMapper modelMapper;
    private final LocationRepository locationRepository;
    private final BlockRepository blockRepository;
    private final GenderRepository genderRepository;
    private final ApplicationTypeRepository applicationTypeRepository;
    private final CarTypeRepository carTypeRepository;
    private final CampRepository campRepository;
    private final RoomCapacityRepository roomCapacityRepository;
    private final RoomCategoryRepository roomCategoryRepository;
    private final RoomRepository roomRepository;
    private final JdbcTemplate jdbcTemplate;

    public UtilityServiceImpl(ModelMapper modelMapper, LocationRepository locationRepository, BlockRepository blockRepository, GenderRepository genderRepository, ApplicationTypeRepository applicationTypeRepository, CarTypeRepository carTypeRepository, CampRepository campRepository, RoomCapacityRepository roomCapacityRepository, RoomCategoryRepository roomCategoryRepository, RoomRepository roomRepository, JdbcTemplate jdbcTemplate) {
        this.modelMapper = modelMapper;
        this.locationRepository = locationRepository;
        this.blockRepository = blockRepository;
        this.genderRepository = genderRepository;
        this.applicationTypeRepository = applicationTypeRepository;
        this.carTypeRepository = carTypeRepository;
        this.campRepository = campRepository;
        this.roomCapacityRepository = roomCapacityRepository;
        this.roomCategoryRepository = roomCategoryRepository;
        this.roomRepository = roomRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<CampDto> getLocation() {
        return campRepository.find();
    }

    public List<BlockDto> getBlockByLocationId(Integer locationId) {
        return blockRepository.findBlockLocationId(locationId);
    }

    public List<GenderDto> getGender() {
        return genderRepository.findGenderBy();
    }

    @Override
    public List<VisitorTypeDTO> getVisitorTypes() throws ApiException {
        try {
            return jdbcTemplate.query("SELECT id, name FROM camp.visitor_type", new BeanPropertyRowMapper<>(VisitorTypeDTO.class));
        } catch (Exception ex) {
            log.error("Error in receiving list of visitor types: {}", ex.getMessage());
            throw new ApiException(VISITOR_TYPES_ERROR.getCode(), VISITOR_TYPES_ERROR.getMessage());
        }
    }

    @Override
    public List<DepartmentDTO> getDepartments() throws ApiException {
        try {
            List<DepartmentDTO> departments = jdbcTemplate.query(
                    "SELECT id, COALESCE(title_ru, title) AS title FROM camp.department_rm ORDER BY id",
                    new BeanPropertyRowMapper<>(DepartmentDTO.class));
        return departments;
        } catch (Exception ex) {
            log.error("Error in receiving list of departments: {}", ex.getMessage());
            throw new ApiException(DEPARTMENTS_ERROR.getCode(), DEPARTMENTS_ERROR.getMessage());
        }
    }

    public List<Map<String, Object>> getQuantityOfBedInRoom() {
        String query = "select capacity as name from camp.room_capacity order by capacity";
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            List<Map<String, Object>> response = jdbcTemplate.queryForList(query);
            if (response.size() != 0) {
                for (Map<String, Object> iterator : response) {
                    Map<String, Object> res = new HashMap<>();
                    res.put("name", String.valueOf(iterator.get("name")));
                    result.add(res);
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return result;
    }

    @Override
    public List<JobTitleDTO> getJobTitles() throws ApiException {
        try {
            List<JobTitleDTO> jobTitleDTOList = jdbcTemplate.query(
                    "SELECT id, code, COALESCE(title_ru, title) as title_ru FROM camp.job_title WHERE is_active = 1",
                    new BeanPropertyRowMapper<>(JobTitleDTO.class));
            return jobTitleDTOList;
        } catch (Exception ex) {
            log.error("Error in receiving list of job titles: {}", ex.getMessage());
            throw new ApiException(JOB_TITLES_ERROR.getCode(), JOB_TITLES_ERROR.getMessage());
        }
    }

    @Override
    public List<EmployeeDTO> getEmployees() throws ApiException {
        try {
            List<EmployeeDTO> employeeDTOList = jdbcTemplate.query(
                    "SELECT emp_code, COALESCE(CONCAT(last_name_ru, ' ',first_name_ru), " +
                            "CONCAT(last_name, ' ',first_name)) AS name " +
                            "FROM camp.employee " +
                            "WHERE status_code = 'A' ORDER BY emp_code",
                    new BeanPropertyRowMapper<>(EmployeeDTO.class));
            return employeeDTOList;
        } catch (Exception ex) {
            log.error("Error in receiving list of employees: {}", ex.getMessage());
            throw new ApiException(EMPLOYEES_ERROR.getCode(), EMPLOYEES_ERROR.getMessage());
        }
    }

    @Override
    public List<BedReferenceDTO> getBedReference(String campId, String blockId, String roomId, String bedType,
                                                 String status) throws ApiException {
        String query = "SELECT bed.id,\n"
                + "  bed.bed_number_in_room,\n"
                + "  room.room_num AS room,\n"
                + "  bed.status,\n"
                + "  type.title AS type,\n"
                + "  block.name AS block,\n"
                + "  camp.name_ru AS camp\n"
                + "FROM camp.bed AS bed\n"
                + "LEFT JOIN camp.bed_type AS type ON bed.bed_type_id = type.id\n"
                + "LEFT JOIN camp.room AS room ON bed.room_id = room.id\n"
                + "LEFT JOIN camp.block AS block ON room.block_id = block.id\n"
                + "LEFT JOIN camp.camp AS camp ON block.camp_id = camp.id\n"
                + "WHERE CAST(camp.id AS VARCHAR) LIKE ?\n"
                + "  AND CAST(block.id AS VARCHAR) LIKE ?\n"
                + "  AND CAST(room.id AS VARCHAR) LIKE ?\n"
                + "  AND CAST(type.id AS VARCHAR) LIKE ?\n"
                + "  AND bed.status LIKE ?\n"
                + "  AND bed.status = 'A'";
        try {
            log.info("Getting list of beds with filters: campId = {}, blockId = {}, roomId = {}, bedTypeId = {}, status= {}",
                    campId, blockId, roomId, bedType, status);
            List<BedReferenceDTO> bedReferenceDTOList = jdbcTemplate.query(query,
                    new BeanPropertyRowMapper<>(BedReferenceDTO.class),
                    campId, blockId, roomId, bedType, status);
            log.info("List of beds received");
            return bedReferenceDTOList;

        } catch (Exception ex) {
            log.error("Error in getting list of beds: {}", ex.getMessage());
            throw new ApiException(BED_LIST_ERROR.getCode(), BED_LIST_ERROR.getMessage());
        }
    }

    @Override
    public List<BedTypeDTO> getBedTypes() throws ApiException {
        String query = "SELECT id, title FROM camp.bed_type";
        try {
            log.info("Getting list of bedType");
            List<BedTypeDTO> bedTypeDTOList = jdbcTemplate.query(query, new BeanPropertyRowMapper<>(BedTypeDTO.class));
            log.info("List of bedType received");
            return bedTypeDTOList;
        } catch (Exception ex) {
            log.error("Error in getting list of bedType: {}", ex.getMessage());
            throw new ApiException(BED_TYPE_LIST_ERROR.getCode(), BED_TYPE_LIST_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO addBed(int bedTypeId) throws ApiException {
        String query = "INSERT INTO camp.bed (changed_by, date_changed, status, bed_type_id)\n" +
                "VALUES ('camp', now()::date, 'A', ?)";
        try {
            log.info("Adding new bed");
            jdbcTemplate.update(query, bedTypeId);
            log.info("New bed successfully added");
            return ResponseDTO.builder()
                    .code(201)
                    .message("Кровать успешно добавлена")
                    .build();
        } catch (Exception ex) {
            log.error("Error when adding new bed: {}", ex.getMessage());
            throw new ApiException(BED_ADD_ERROR.getCode(), BED_ADD_ERROR.getMessage());
        }
    }

    public List<Map<String,Object>> getBedsInStock() throws ApiException{
        String query = "SELECT b.id AS bed, r.id AS room, r.room_num AS room_name, bt.title AS bed_type\n"
                + "FROM camp.bed b\n"
                + "INNER JOIN camp.room r ON r.id = b.room_id\n"
                + "INNER JOIN camp.block b2 ON b2.id = r.block_id\n"
                + "INNER JOIN camp.bed_type bt on bt.id = b.bed_type_id\n"
                + "WHERE b2.\"name\" = 'Warehouse Block'\n"
                + "  AND b.status = 'A'";
        List<Map<String, Object>> bedList = new ArrayList<>();
        try {
            List<Map<String, Object>> resQuery = jdbcTemplate.queryForList(query);
            if (resQuery.size() == 0) {
               throw new ApiException();
            }
            for(Map<String,Object> iterator: resQuery){
                Map<String, Object> bed=new LinkedHashMap<>();
                bed.put("bedId", Integer.valueOf(String.valueOf(iterator.get("bed"))));
                bed.put("roomId", Integer.valueOf(String.valueOf(iterator.get("room"))));
                bed.put("roomName", String.valueOf(iterator.get("room_name")));
                bed.put("bedType", String.valueOf(iterator.get("bed_type")));
                bedList.add(bed);
            }
        }
        catch (Exception ex){
            log.error("Error in receiving list of beds in stock: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(),EMPTY_RESULT.getMessage());
        }
        return bedList;
    }

    public List<ApplicationTypeDto> getApplicationTypeList(){
        return applicationTypeRepository.find();
    }

    @Override
    public List<MyApplicationTypeDTO> getMyApplicationTypeList() {
        List<MyApplicationTypeDTO> applicationTypes = List.of(
                new MyApplicationTypeDTO(ASCENT.getName(), ASCENT.getNameRu()),
                new MyApplicationTypeDTO(DESCENT.getName(), DESCENT.getNameRu()),
                new MyApplicationTypeDTO(SETTLEMENT.getName(), SETTLEMENT.getNameRu()));
        return applicationTypes;
    }

    public List<CarTypeDto> getCarTypeList(){
        return carTypeRepository.find();
    }

    @Override
    public int getEmpCodeByAuthToken(KeycloakAuthenticationToken authentication) {
        Principal principal = (Principal) authentication.getPrincipal();
        KeycloakPrincipal<KeycloakSecurityContext> keycloakPrincipal =
                (KeycloakPrincipal<KeycloakSecurityContext>) principal;
        return Integer.valueOf(String.valueOf(keycloakPrincipal.getKeycloakSecurityContext().getToken().getOtherClaims().get("emp_code")));
    }

    public ResponseDTO createLocation(LocationCRUDDto locationCRUDDto)throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Location location=modelMapper.map(locationCRUDDto, Location.class);
        try {
            location.setDateChanged(LocalDateTime.now());
            log.info("Insert into table Location: "+ location);
            Location response=locationRepository.save(location);
            log.info("Insert into table Location was successfully!");
            result.setCode(200);
            result.setMessage("Локация успешно создана");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }
    public ResponseDTO editLocation(LocationCRUDDto locationCRUDDto)throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Location location=modelMapper.map(locationCRUDDto, Location.class);
        try {
            location.setDateChanged(LocalDateTime.now());
            log.info("Edit table Location: "+ location);
            Location response=locationRepository.save(location);
            log.info("Edit table Location was successfully!");
            result.setCode(200);
            result.setMessage("Локация успешно отредактирована!");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }

    public List<LocationCRUDDto> getLocationList()throws ApiException{
        return locationRepository.findAllLocations();
    }

    public ResponseDTO createCamp(CampCRUDDto campCRUDDto) throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Camp camp=modelMapper.map(campCRUDDto, Camp.class);
        try {
            camp.setDateChanged(LocalDateTime.now());
            log.info("Insert into table Camp: " + camp);
            Camp response = campRepository.save(camp);
            log.info("Insert into table Camp was successfully!");
            result.setCode(200);
            result.setMessage("Лагерь успешно создана");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }

    public ResponseDTO editCamp(CampCRUDDto campCRUDDto)throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Camp camp=modelMapper.map(campCRUDDto, Camp.class);
        try {
            camp.setDateChanged(LocalDateTime.now());
            log.info("Edit table Camp: "+ camp);
            Camp response=campRepository.save(camp);
            log.info("Edit table Camp was successfully!");
            result.setCode(200);
            result.setMessage("Лагерь успешно отредактирована!");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }
    public List<CampCRUDDto> getCampList(){
        return campRepository.findAllCamp();
    }

    public ResponseDTO createBlock(BlockCRUDDto blockCRUDDto) throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Block block=modelMapper.map(blockCRUDDto, Block.class);
        try {
            block.setDateChanged(LocalDateTime.now());
            log.info("Insert into table Block: " + block);
            Block response = blockRepository.save(block);
            log.info("Insert into table Block was successfully!");
            result.setCode(200);
            result.setMessage("Запись Блок успешно создана");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }

    public ResponseDTO editBlock(BlockCRUDDto blockCRUDDto)throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Block block=modelMapper.map(blockCRUDDto, Block.class);
        try {
            block.setDateChanged(LocalDateTime.now());
            log.info("Edit table Block: "+ block);
            Block response=blockRepository.save(block);
            log.info("Edit table Block was successfully!");
            result.setCode(200);
            result.setMessage("Запись Блок успешно отредактирована!");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }
    public List<BlockCRUDDto> getBlockList(){
        return blockRepository.findBlockList();
    }
    public ResponseDTO createRoom(RoomCRUDDto roomCRUDDto)throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Room room=new Room();
        try {
            room.setId(null);
            room.setDateChanged(LocalDateTime.now());
            room.setRoomNum(roomCRUDDto.getRoomNum());
            room.setChangedBy(roomCRUDDto.getChangedBy());
            room.setBlockId(Block.builder().id(roomCRUDDto.getBlockId()).build());
            room.setCategoryId(RoomCategory.builder().id(roomCRUDDto.getRoomCategoryId()).build());
            room.setRoomCapacity(RoomCapacity.builder().capacity(roomCRUDDto.getRoomCapacityId()).build());
            room.setGenderId(Gender.builder().id(roomCRUDDto.getRoomGenderId()).build());
            room.setStatusCode(roomCRUDDto.getStatusCode());
            log.info("Insert into table Room: " + room);
            Room response = roomRepository.save(room);
            log.info("Insert into table Room was successfully!");
            result.setCode(200);
            result.setMessage("Запись Комната успешно создана");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }
    public ResponseDTO editRoom(RoomCRUDDto roomCRUDDto)throws ApiException{
        ResponseDTO result=new ResponseDTO();
        Room room=new Room();
        try {
            room.setId(roomCRUDDto.getId());
            room.setDateChanged(LocalDateTime.now());
            room.setRoomNum(roomCRUDDto.getRoomNum());
            room.setChangedBy(roomCRUDDto.getChangedBy());
            room.setBlockId(Block.builder().id(roomCRUDDto.getBlockId()).build());
            room.setCategoryId(RoomCategory.builder().id(roomCRUDDto.getRoomCategoryId()).build());
            room.setRoomCapacity(RoomCapacity.builder().capacity(roomCRUDDto.getRoomCapacityId()).build());
            room.setGenderId(Gender.builder().id(roomCRUDDto.getRoomGenderId()).build());
            room.setStatusCode(roomCRUDDto.getStatusCode());
            log.info("Edit table Room: "+ room);
            Room response=roomRepository.save(room);
            log.info("Edit table Room was successfully!");
            result.setCode(200);
            result.setMessage("Запись Комната успешно отредактирована!");
        }
        catch (Exception ex){
            throw new ApiException(SAVE_ERROR.getCode(),SAVE_ERROR.getMessage());
        }
        return result;
    }
    public Map<String, Object> getRoomList(Integer page, Integer size)throws ApiException{
        Map<String, Object> result=new HashMap<>();
        String query="select r.id as id, r.changed_by as changed_by  , b.\"name\" ||'-'||r.room_num as room_name ,r.room_num as room_num \n" +
                ", b.name as block_name, r.block_id  as block_id, r.room_category_id as room_category_id, rc.name as room_category_name," +
                "r.room_gender_id  as gender_id,g.\"name\" as gender_name,r.room_capacity as capacity,r.status_code as status_code \n" +
                "from camp.room r\n" +
                "left join camp.block b on r.block_id =b.id \n" +
                "left join camp.room_category rc on rc.id =r.room_category_id \n" +
                "left join camp.gender g on g.id=r.room_gender_id where r.status_code='A'\n" +
                "order by room_name\n" +
                "              limit  ?\n" +
                "                  OFFSET ?";
        Object[] args=new Object[]{size,page};
        try {
            List<Map<String,Object>> response=jdbcTemplate.queryForList(query,args);
            List<Map<String,Object>> resList=new ArrayList<>();
            if(response.size()!=0){
                for(Map<String, Object> iterator: response){
                    Map<String, Object> roomElement=new LinkedHashMap<>();
                    roomElement.put("id", Integer.valueOf(String.valueOf(iterator.get("id"))));
                    roomElement.put("changedBy", String.valueOf(iterator.get("changed_by")));
                    roomElement.put("roomName", String.valueOf(iterator.get("room_name")));
                    roomElement.put("blockName", String.valueOf(iterator.get("block_name")));
                    roomElement.put("blockId", Integer.valueOf(String.valueOf(iterator.get("block_id"))));
                    if(String.valueOf(iterator.get("room_category_id")).equals("null")){
                        roomElement.put("roomCategoryId", null);
                    }else{
                    roomElement.put("roomCategoryId", String.valueOf(iterator.get("room_category_id")));}
                    roomElement.put("roomCategoryName", String.valueOf(iterator.get("room_category_name")));
                    if(String.valueOf(iterator.get("gender_id")).equals("null")){
                        roomElement.put("roomGenderId", null);
                    }
                    else {
                        roomElement.put("roomGenderId", Integer.valueOf(String.valueOf(iterator.get("gender_id"))));
                    }
                    roomElement.put("roomGenderName", String.valueOf(iterator.get("gender_name")));
                    if(String.valueOf(iterator.get("capacity")).equals("null")){
                        roomElement.put("roomCapacity", null);
                    }
                    else {
                        roomElement.put("roomCapacity",Integer.valueOf(String.valueOf(iterator.get("capacity"))));
                    }
                    roomElement.put("statusCode",String.valueOf(iterator.get("status_code")));
                    resList.add(roomElement);
                }
            }
            query="select count(1) as counter\n" +
        "from camp.room r\n" +
        "left join camp.block b on r.block_id =b.id \n" +
        "left join camp.room_category rc on rc.id =r.room_category_id \n" +
        "left join camp.gender g on g.id=r.room_gender_id where r.status_code='A'";
            Map<String,Object> responseCount=jdbcTemplate.queryForMap(query);
            result.put("totalPages", Integer.valueOf(String.valueOf(responseCount.get("counter"))).intValue()/size.intValue()+1);
            result.put("page", page+1);
            result.put("roomList", resList);
        }
        catch (Exception ex){
            throw new ApiException(500, "Error");
        }
        return result;
    }

    @Override
    public PageableResponseDTO getBedList(Pageable pageable) throws ApiException {
        String countQuery = "SELECT COUNT(1)\n"
                + "FROM camp.bed AS bed\n"
                + "LEFT JOIN camp.room AS room ON bed.room_id = room.id\n"
                + "LEFT JOIN camp.bed_type AS type ON bed.bed_type_id = type.id\n"
                + "WHERE status = 'A'";
        String resultQuery = "SELECT bed.id, bed_number_in_room, room_id, room.room_num, bed_type_id,\n"
                + "  type.title AS bed_type_title, status, bed.changed_by\n"
                + "FROM camp.bed AS bed\n"
                + "LEFT JOIN camp.room AS room ON bed.room_id = room.id\n"
                + "LEFT JOIN camp.bed_type AS type ON bed.bed_type_id = type.id\n"
                + "WHERE status = 'A'\n"
                + "LIMIT ? OFFSET ?";
        try {
            log.info("Getting number of beds");
            int count = jdbcTemplate.queryForObject(countQuery, Integer.class);
            log.info("Number of beds: {}", count);

            log.info("Getting list of beds");
            List<BedUtilityDTO> beds = jdbcTemplate.query(resultQuery,
                    new Object[]{pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BedUtilityDTO.class));
            log.info("List of beds received");
            PageImpl<BedUtilityDTO> bedPages = new PageImpl<>(beds, pageable, count);
            return PageableResponseDTO.builder()
                    .pageNumber(bedPages.getNumber() + 1)
                    .totalPages(bedPages.getTotalPages())
                    .content(bedPages.getContent())
                    .build();
        } catch (Exception ex) {
            log.error("Error in getting list of beds: {}", ex.getMessage());
            throw new ApiException(BED_LIST_ERROR.getCode(), BED_LIST_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO addBed(BedUtilityDTO bedDTO) throws ApiException {
        Integer max_beds = 0;
        try {
            max_beds = jdbcTemplate.queryForObject(
                    "SELECT MAX(capacity)\n"
                        + "FROM camp.room_capacity", Integer.class);

            if (bedDTO.getBedNumberInRoom() <= max_beds) {
                jdbcTemplate.update("INSERT INTO camp.bed(bed_number_in_room, changed_by, date_changed, status, bed_type_id, room_id)\n"
                                + "VALUES(?, ?, now()::timestamp, 'A', ?, ?)",
                        bedDTO.getBedNumberInRoom(), bedDTO.getChangedBy(), bedDTO.getBedTypeId(), bedDTO.getRoomId());
                jdbcTemplate.update("UPDATE camp.room\n"
                                + "SET room_capacity = (SELECT MIN(capacity)\n"
                                + "                     FROM camp.room_capacity\n"
                                + "                     WHERE capacity >= ?),\n"
                                + "  date_changed = now()\n"
                                + "WHERE id = ?",
                        bedDTO.getBedNumberInRoom(), bedDTO.getRoomId());
                log.info("Bed record successfully added to DB");
                return ResponseDTO.builder()
                        .code(BED_ADDED.getCode())
                        .message(BED_ADDED.getMessage())
                        .build();
            }
        } catch (Exception ex) {
            log.error("Error in adding bed record to DB: {}", ex.getMessage());
            throw new ApiException(BED_ADD_ERROR.getCode(), BED_ADD_ERROR.getMessage());
        }

        if (bedDTO.getBedNumberInRoom() > max_beds) {
            log.error("Limit on bed number per room {} was exceeded", max_beds);
            throw new ApiException(BED_MAX_EXCEEDED_ERROR.getCode(), BED_MAX_EXCEEDED_ERROR.getMessage());
        }

        return null;
    }

    @Override
    public ResponseDTO updateBed(BedUtilityDTO bedDTO) throws ApiException {
        try {
            jdbcTemplate.update("UPDATE camp.bed " +
                    "SET bed_number_in_room = ?, changed_by = ?, date_changed = now(), " +
                    "    bed_type_id = ?, room_id = ? " +
                    "WHERE id = ?", bedDTO.getBedNumberInRoom(), bedDTO.getChangedBy(), bedDTO.getBedTypeId(),
                    bedDTO.getRoomId(), bedDTO.getId());
            log.info("Bed with id = {} successfully updated", bedDTO.getId());
            return ResponseDTO.builder()
                    .code(BED_UPDATED.getCode())
                    .message(BED_UPDATED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while updating bed record: {}", ex.getMessage());
            throw new ApiException(BED_UPDATE_ERROR.getCode(), BED_UPDATE_ERROR.getMessage());
        }
    }

    @Transactional(rollbackFor = {Exception.class, SQLException.class})
    @Override
    public ResponseDTO deleteBed(List<Integer> ids) throws ApiException {
        int status = 3;
        int bed_id = 0;
        try {
            // кровати не должны быть забронированы или заняты в момент удаления
            for (Integer i: ids) {
                status = jdbcTemplate.queryForObject(
                        "SELECT CASE\n"
                                + "  WHEN EXISTS(SELECT book.bed_id\n"
                                + "              FROM camp.booking book\n"
                                + "              WHERE book.bed_id = bed.id\n"
                                + "                AND book.date_in <= Now()::date\n"
                                + "                AND book.date_out >= Now()::date\n"
                                + "                AND (book.status_id = 4 AND book.check_in IS NOT NULL)) THEN 1\n"
                                + "  WHEN EXISTS(SELECT book.bed_id\n"
                                + "              FROM camp.booking book\n"
                                + "              WHERE book.bed_id = bed.id\n"
                                + "                AND book.date_in <= Now()::date\n"
                                + "                AND book.date_out >= Now()::date\n"
                                + "                AND (book.status_id = 2 AND book.check_in IS NULL)) THEN 2\n"
                                + "  ELSE 3\n"
                                + "  END AS status\n"
                                + "FROM camp.bed bed\n"
                                + "WHERE bed.id = ?", Integer.class, i);

                if (status != 3) {
                    bed_id = i;
                    break;
                }
            }
        } catch (Exception ex) {
            log.error("Error while deleting bed(s) record in DB: {}", ex.getMessage());
            throw new ApiException(BED_DELETE_ERROR.getCode(), BED_DELETE_ERROR.getMessage());
        }

        if (status != 3) {
            String status_str = "забронирована";
            if (status == 2) status_str = "занята";

            throw new ApiException(BED_DELETE_ERROR.getCode(),
                    "Не удалось удалить запись кровати " + bed_id + ", она " + status_str + " в данный момент");
        }

        try {
            NamedParameterJdbcTemplate jdbcNamesTpl = new NamedParameterJdbcTemplate(this.jdbcTemplate);
            SqlParameterSource parameters = new MapSqlParameterSource("ids", ids);

            jdbcNamesTpl.update("WITH cte AS (\n"
                            + "  DELETE FROM camp.permanent_resident\n"
                            + "  WHERE bed_id IN (:ids)\n"
                            + ")\n"
                            + "UPDATE camp.bed\n"
                            + "SET status = 'C',\n"
                            + "  date_changed = now()\n"
                            + "WHERE id IN (:ids)",
                    parameters);

            this.jdbcTemplate.update("UPDATE camp.room\n"
                    + "SET room_capacity = (SELECT MIN(capacity)\n"
                    + "                     FROM camp.room_capacity\n"
                    + "                     WHERE capacity >= (SELECT COUNT(id)\n"
                    + "                                        FROM camp.bed\n"
                    + "                                        WHERE room_id = (SELECT room_id\n"
                    + "                                                         FROM camp.bed\n"
                    + "                                                         WHERE id IN (?)\n"
                    + "                                                         LIMIT 1)\n"
                    + "                                          AND status = 'A'\n"
                    + "                                       )\n"
                    + "                    ),\n"
                    + "  date_changed = now()\n"
                    + "WHERE id = (SELECT room_id\n"
                    + "            FROM camp.bed\n"
                    + "            WHERE id IN (?)\n"
                    + "            LIMIT 1)",
                    ids.get(0), ids.get(0));
            log.info("Status of bed(s) with id = {} changed to 'C'", ids);
            return ResponseDTO.builder()
                    .code(BED_DELETED.getCode())
                    .message(BED_DELETED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while deleting bed(s) record in DB: {}", ex.getMessage());
            throw new ApiException(BED_DELETE_ERROR.getCode(), BED_DELETE_ERROR.getMessage());
        }
    }

    @Override
    public List<EmployeeUtilityDTO> getEmployeeList() throws ApiException {
        try {
            List<EmployeeUtilityDTO> employeeList = jdbcTemplate.query(
                    "SELECT * FROM camp.employee WHERE employee_type_id = 4 AND status_code = 'A'",
                    new BeanPropertyRowMapper<>(EmployeeUtilityDTO.class));
            log.info("Employee list with type 'Guest' received");
            return employeeList;
        } catch (Exception ex) {
            log.error("Error while getting Employee list with type 'Guest'");
            throw new ApiException(EMPLOYEE_LIST_ERROR.getCode(), EMPLOYEE_LIST_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO addEmployee(EmployeeUtilityDTO employeeDTO) throws ApiException {
        try {
            jdbcTemplate.update("INSERT INTO camp.employee (" +
                    "changed_by, date_changed, email, first_name, first_name_ru, last_name, " +
                    "last_name_ru, middle_name, middle_name_ru, phone_no1, phone_no2, sin, " +
                    "gender_id, date_birth, status_code, employee_type_id, is_registered) " +
                    "SELECT ?, now()::timestamp, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'A', 4, 0",
                    employeeDTO.getChangedBy(), employeeDTO.getEmail(), employeeDTO.getFirstName(),
                    employeeDTO.getFirstNameRu(), employeeDTO.getLastName(), employeeDTO.getLastNameRu(),
                    employeeDTO.getMiddleName(), employeeDTO.getMiddleNameRu(), employeeDTO.getPhoneNum1(),
                    employeeDTO.getPhoneNum2(), employeeDTO.getSin(), employeeDTO.getGenderId(),
                    employeeDTO.getDateBirth());
            log.info("Employee with type 'Guest' added");
            return ResponseDTO.builder()
                    .code(EMPLOYEE_ADDED.getCode())
                    .message(EMPLOYEE_ADDED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while adding employee: {}", ex.getMessage());
            throw new ApiException(EMPLOYEE_ADD_ERROR.getCode(), EMPLOYEE_ADD_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO updateEmployee(EmployeeUtilityDTO employeeDTO) throws ApiException {
        try {
            if (employeeDTO.getEmpCode() == null) {
                throw new ApiException(EMPLOYEE_UPDATE_ERROR.getCode(), EMPLOYEE_UPDATE_ERROR.getMessage());
            };
            jdbcTemplate.update("UPDATE camp.employee SET " +
                            "changed_by = ?, date_changed = now()::timestamp, " +
                            "email = ?, first_name = ?, first_name_ru = ?, " +
                            "last_name = ?, last_name_ru = ?, middle_name = ?, " +
                            "middle_name_ru = ?, phone_no1 = ?, phone_no2 = ?, " +
                            "sin = ?, gender_id = ?, date_birth = ? " +
                            "WHERE emp_code = ?",
                    employeeDTO.getChangedBy(), employeeDTO.getEmail(), employeeDTO.getFirstName(),
                    employeeDTO.getFirstNameRu(), employeeDTO.getLastName(), employeeDTO.getLastNameRu(),
                    employeeDTO.getMiddleName(), employeeDTO.getMiddleNameRu(), employeeDTO.getPhoneNum1(),
                    employeeDTO.getPhoneNum2(), employeeDTO.getSin(), employeeDTO.getGenderId(),
                    employeeDTO.getDateBirth(), employeeDTO.getEmpCode());
            log.info("Employee with id = {} updated", employeeDTO.getEmpCode());
            return ResponseDTO.builder()
                    .code(EMPLOYEE_UPDATED.getCode())
                    .message(EMPLOYEE_UPDATED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while updating employee: {}", ex.getMessage());
            throw new ApiException(EMPLOYEE_UPDATE_ERROR.getCode(), EMPLOYEE_UPDATE_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO deleteEmployee(int empCode) throws ApiException {
        try {
            jdbcTemplate.update("UPDATE camp.employee SET status_code = 'C' WHERE emp_code = ?", empCode);
            log.info("Status of employee with id = {} changed to 'C'", empCode);
            return ResponseDTO.builder()
                    .code(EMPLOYEE_DELETED.getCode())
                    .message(EMPLOYEE_DELETED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while changing status of employee to 'C': {}", ex.getMessage());
            throw new ApiException(EMPLOYEE_DELETE_ERROR.getCode(), EMPLOYEE_DELETE_ERROR.getMessage());
        }
    }

    @Override
    public PageableResponseDTO getApproverList(Pageable pageable) throws ApiException {
        String countQuery = "SELECT count(1) FROM camp.approver WHERE status = 'A'";
        String resultQuery = "SELECT id, emp_code, approver_type_id, " +
                "type.title_ru AS approver_type_title, appr.changed_by " +
                "FROM camp.approver AS appr " +
                "LEFT JOIN camp.approver_type AS type ON appr.approver_type_id = type.id " +
                "WHERE appr.status = 'A' " +
                "LIMIT ? OFFSET ?";
        try {
            log.info("Getting number of records in 'approver' table");
            int count = jdbcTemplate.queryForObject(countQuery, Integer.class);
            log.info("Number of records in 'approver' table: {}", count);

            log.info("Getting list of records in 'approver' table");
            List<ApproverUtilityDTO> approvers = jdbcTemplate.query(resultQuery,
                    new Object[]{pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(ApproverUtilityDTO.class));
            log.info("List of records in 'approver' table received");
            PageImpl<ApproverUtilityDTO> approverPages = new PageImpl<>(approvers, pageable, count);
            return PageableResponseDTO.builder()
                    .pageNumber(approverPages.getNumber() + 1)
                    .totalPages(approverPages.getTotalPages())
                    .content(approverPages.getContent())
                    .build();
        } catch (Exception ex) {
            log.error("Error in getting list of records in 'approver' table: {}", ex.getMessage());
            throw new ApiException(APPROVER_LIST_ERROR.getCode(), APPROVER_LIST_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO addApprover(ApproverUtilityDTO approverDTO) throws ApiException {
        try {
            log.info("Adding new record to 'approver' table");
            jdbcTemplate.update("INSERT INTO camp.approver (" +
                    "changed_by, date_changed, emp_code, approver_type_id, status) " +
                    "SELECT ?, now()::timestamp, ?, ?, 'A'",
                    approverDTO.getChangedBy(), approverDTO.getEmpCode(), approverDTO.getApproverTypeId());
            log.info("New record added to 'approver' table");
            return ResponseDTO.builder()
                    .code(APPROVER_ADDED.getCode())
                    .message(APPROVER_ADDED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while adding new record to 'approver' table: {}", ex.getMessage());
            throw new ApiException(APPROVER_ADD_ERROR.getCode(), APPROVER_ADD_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO updateApprover(ApproverUtilityDTO approverDTO) throws ApiException {
        try {
            log.info("Updating record in 'approver' table with empCode: {}", approverDTO.getEmpCode());
            jdbcTemplate.update("UPDATE camp.approver " +
                    "SET changed_by = ?, date_changed = now()::timestamp, " +
                    "    approver_type_id = ?, emp_code = ? " +
                    "WHERE id = ?",
                    approverDTO.getChangedBy(), approverDTO.getApproverTypeId(), approverDTO.getEmpCode(),
                    approverDTO.getId());
            log.info("Record in 'approver' table with empCode = {} updated", approverDTO.getEmpCode());
            return ResponseDTO.builder()
                    .code(APPROVER_UPDATED.getCode())
                    .message(APPROVER_UPDATED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while updating record in 'approver' table with empCode: {}", approverDTO.getEmpCode());
            throw new ApiException(APPROVER_UPDATE_ERROR.getCode(), APPROVER_UPDATE_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO deleteApprover(int id) throws ApiException {
        try {
            log.info("Deleting record in 'approver' table with id = {}", id);
            jdbcTemplate.update("UPDATE camp.approver SET status = 'C' WHERE id = ?", id);
            log.info("Record in 'approver' table with id = {} deleted", id);
            return ResponseDTO.builder()
                    .code(APPROVER_DELETED.getCode())
                    .message(APPROVER_DELETED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Error while updating record in 'approver' table with id = {}", id);
            throw new ApiException(APPROVER_DELETE_ERROR.getCode(), APPROVER_DELETE_ERROR.getMessage());
        }
    }

    @Override
    public List<RoomCapacityUtilityDTO> getRoomCapacityList() throws ApiException {
        try {
            List<RoomCapacityUtilityDTO> roomCapacityList = roomCapacityRepository.findAllRoomCapacityDTO();
            log.info("Room capacity list received");
            return roomCapacityList;
        } catch (Exception ex) {
            log.error("Error in getting list of room capacity: {}", ex.getMessage());
            throw new ApiException(ROOM_CAPACITIES_ERROR.getCode(), ROOM_CAPACITIES_ERROR.getMessage());
        }

    }

    @Override
    public ResponseDTO addRoomCapacity(RoomCapacityUtilityDTO roomCapacityUtilityDTO) throws ApiException {
        try {
            Optional<RoomCapacity> roomCapacityCheck =
                    roomCapacityRepository.findById(roomCapacityUtilityDTO.getCapacity());
            if (roomCapacityCheck.isEmpty()) {
                RoomCapacity roomCapacity = modelMapper.map(roomCapacityUtilityDTO, RoomCapacity.class);
                roomCapacity.setDateChanged(LocalDateTime.now());
                roomCapacityRepository.save(roomCapacity);
                log.info("RoomCapacity record successfully added to DB");
                return ResponseDTO.builder()
                        .code(ROOM_CAPACITY_ADDED.getCode())
                        .message(ROOM_CAPACITY_ADDED.getMessage())
                        .build();
            } else {
                log.error("RoomCapacity record with capacity = {} already exists in DB", roomCapacityUtilityDTO.getCapacity());
                return ResponseDTO.builder()
                        .code(ROOM_CAPACITY_ALREADY_EXISTS.getCode())
                        .message(ROOM_CAPACITY_ALREADY_EXISTS.getMessage())
                        .build();
            }
        } catch (Exception ex) {
            log.error("Error in adding RoomCapacity record: {}", ex.getMessage());
            throw new ApiException(ROOM_CAPACITY_ADD_ERROR.getCode(), ROOM_CAPACITY_ADD_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO updateRoomCapacity(RoomCapacityUtilityDTO roomCapacityUtilityDTO) throws ApiException {
        try {
            roomCapacityRepository.findById(roomCapacityUtilityDTO.getCapacity()).orElseThrow();
            RoomCapacity roomCapacity = modelMapper.map(roomCapacityUtilityDTO, RoomCapacity.class);
            roomCapacityRepository.save(roomCapacity);
            log.info("Room capacity successfully updated in DB");
            return ResponseDTO.builder().code(ROOM_CAPACITY_UPDATED.getCode()).message(ROOM_CAPACITY_UPDATED.getMessage()).build();
        } catch (Exception ex) {
            log.error("Error in update Room capacity record in DB: {}", ex.getMessage());
            throw new ApiException(ROOM_CAPACITY_UPDATE_ERROR.getCode(), ROOM_CAPACITY_UPDATE_ERROR.getMessage());
        }
    }

    @Override
    public List<RoomCategoryUtilityDTO> getRoomCategoryList() throws ApiException {
        try {
            List<RoomCategoryUtilityDTO> roomCategoryList = roomCategoryRepository.findRoomCategoryListDTO();
            log.info("Room category list received");
            return roomCategoryList;
        } catch (Exception ex) {
            log.error("Error in getting list of Room category: {}", ex.getMessage());
            throw new ApiException(ROOM_CATEGORIES_ERROR.getCode(), ROOM_CATEGORIES_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO addRoomCategory(RoomCategoryUtilityDTO roomCategoryDTO) throws ApiException {
        try {
            RoomCategory roomCategory = modelMapper.map(roomCategoryDTO, RoomCategory.class);
            roomCategory.setDateChanged(LocalDateTime.now());
            roomCategoryRepository.save(roomCategory);
            log.info("Room category record added to DB: {}", roomCategory);
            return ResponseDTO.builder().code(ROOM_CATEGORY_ADDED.getCode()).message(ROOM_CATEGORY_ADDED.getMessage()).build();
        } catch (Exception ex) {
            log.error("Error in adding Room category record to DB: {}", ex.getMessage());
            throw new ApiException(ROOM_CATEGORY_ADD_ERROR.getCode(), ROOM_CATEGORY_ADD_ERROR.getMessage());
        }
    }

    @Override
    public ResponseDTO updateRoomCategory(RoomCategoryUtilityDTO roomCategoryDTO) throws ApiException {
        try {
            roomCategoryRepository.findById(roomCategoryDTO.getId()).orElseThrow();
            RoomCategory roomCategory = modelMapper.map(roomCategoryDTO, RoomCategory.class);
            roomCategoryRepository.save(roomCategory);
            log.info("Room category record updated in DB");
            return ResponseDTO.builder().code(ROOM_CATEGORY_UPDATED.getCode()).message(ROOM_CATEGORY_UPDATED.getMessage()).build();
        } catch (Exception ex) {
            log.error("Error in updating Room category record in DB: {}", ex.getMessage());
            throw new ApiException(ROOM_CATEGORY_UPDATE_ERROR.getCode(), ROOM_CATEGORY_UPDATE_ERROR.getMessage());
        }
    }
    @Override
    public List<CostCenterDTO> getCostCenter() throws ApiException {
        try {
            List<CostCenterDTO> costCenterList = jdbcTemplate.query(
                    "SELECT code, name_ru FROM camp.cost_center WHERE (code ~ '[[:alpha:]]+' OR code like '%.%') AND status = 'A'",
                    new BeanPropertyRowMapper<>(CostCenterDTO.class));
            log.info("CostCenter list received");
            return costCenterList;
        } catch (Exception ex) {
            log.error("Error while getting CostCenter list");
            throw new ApiException(COST_CENTER_ERROR.getCode(), COST_CENTER_ERROR.getMessage());
        }
    }
}
