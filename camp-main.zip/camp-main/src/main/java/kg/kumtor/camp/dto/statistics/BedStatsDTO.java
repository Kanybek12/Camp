package kg.kumtor.camp.dto.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BedStatsDTO {

    private int totalAvailableBeds;
    private int totalOccupiedBeds;
    private GenderDTO availableBeds;
    private GenderDTO occupiedBeds;
}
