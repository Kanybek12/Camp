package kg.kumtor.camp.utility;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ApplicationTypeEnum {

    ASCENT("ascent", "Подъём"),
    DESCENT("descent","Спуск"),
    SETTLEMENT("settlement","Заселение");

    private String name;
    private String nameRu;
}
