package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Room {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "block_id", foreignKey = @ForeignKey(name = "fk_block_id"))
    private Block blockId;

    @Column(name = "room_num", nullable = false)
    private String roomNum;

    @ManyToOne
    @JoinColumn(name = "room_capacity", foreignKey = @ForeignKey(name = "fk_room_capacity"))
    private RoomCapacity roomCapacity;

    @ManyToOne
    @JoinColumn(name = "room_category_id", foreignKey = @ForeignKey(name = "fk_category_id"))
    private RoomCategory categoryId;

    @ManyToOne
    @JoinColumn(name = "room_gender_id", foreignKey = @ForeignKey(name = "fk_gender_id"))
    private Gender genderId;

    @Column(name = "status_code", length = 10)
    private String statusCode;
}
