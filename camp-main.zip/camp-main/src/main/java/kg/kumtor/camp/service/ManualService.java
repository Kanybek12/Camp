package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.manual.ManualLocationDto;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.data.domain.Pageable;

public interface ManualService {

    PageableResponseDTO getLocationInfo(Integer empCode, Pageable pageable) throws ApiException;

    ResponseDTO updateLocation(ManualLocationDto manualLocationDto) throws ApiException;
}
