package kg.kumtor.camp.dto.transfer;

public class BusTransferDto {
    private Integer fromLocationId;
    private Integer toLocationId;

    public BusTransferDto() {
    }

    public BusTransferDto(Integer fromLocationId, Integer toLocationId) {
        this.fromLocationId = fromLocationId;
        this.toLocationId = toLocationId;
    }

    public Integer getFromLocationId() {
        return fromLocationId;
    }

    public void setFromLocationId(Integer fromLocationId) {
        this.fromLocationId = fromLocationId;
    }

    public Integer getToLocationId() {
        return toLocationId;
    }

    public void setToLocationId(Integer toLocationId) {
        this.toLocationId = toLocationId;
    }
}
