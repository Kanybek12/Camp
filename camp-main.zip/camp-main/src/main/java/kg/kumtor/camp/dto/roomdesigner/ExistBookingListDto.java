package kg.kumtor.camp.dto.roomdesigner;

import java.sql.Date;

public class ExistBookingListDto {
    private Integer empCode;
    private String fullName;
    private Integer bedId;
    private Date dateIn;
    private Date dateOut;
    private String status;
    private Integer bookedEmpCode;
    private String bookedFullName;
    private Integer bookedBedId;
    private Date bookedDateIn;
    private Date bookedDateOut;
    private String bookedStatus;

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }

    public Date getDateIn() {
        return dateIn;
    }

    public void setDateIn(Date dateIn) {
        this.dateIn = dateIn;
    }

    public Date getDateOut() {
        return dateOut;
    }

    public void setDateOut(Date dateOut) {
        this.dateOut = dateOut;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getBookedEmpCode() {
        return bookedEmpCode;
    }

    public void setBookedEmpCode(Integer bookedEmpCode) {
        this.bookedEmpCode = bookedEmpCode;
    }

    public String getBookedFullName() {
        return bookedFullName;
    }

    public void setBookedFullName(String bookedFullName) {
        this.bookedFullName = bookedFullName;
    }

    public Integer getBookedBedId() {
        return bookedBedId;
    }

    public void setBookedBedId(Integer bookedBedId) {
        this.bookedBedId = bookedBedId;
    }

    public Date getBookedDateIn() {
        return bookedDateIn;
    }

    public void setBookedDateIn(Date bookedDateIn) {
        this.bookedDateIn = bookedDateIn;
    }

    public Date getBookedDateOut() {
        return bookedDateOut;
    }

    public void setBookedDateOut(Date bookedDateOut) {
        this.bookedDateOut = bookedDateOut;
    }

    public String getBookedStatus() {
        return bookedStatus;
    }

    public void setBookedStatus(String bookedStatus) {
        this.bookedStatus = bookedStatus;
    }
}
