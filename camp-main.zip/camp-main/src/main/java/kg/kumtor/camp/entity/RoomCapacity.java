package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@Table(name = "room_capacity")
public class RoomCapacity {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @Column(name = "name")
    private String name;

    @Id
    @Column(name = "capacity")
//    @OneToMany(targetEntity = Room.class, mappedBy = "roomCapacityValue", fetch = FetchType.LAZY)
    private int capacity;

    public RoomCapacity(String changedBy, LocalDateTime dateChanged, String name, int capacity) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.name = name;
        this.capacity = capacity;
    }
}
