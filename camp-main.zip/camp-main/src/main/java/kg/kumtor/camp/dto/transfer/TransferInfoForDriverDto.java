package kg.kumtor.camp.dto.transfer;

import java.util.Date;

public class TransferInfoForDriverDto {
    private Long busTransferId;
    private String firstName;
    private String lastName;
    private String department;
    private String fromLocation;
    private String toLocation;
    private String transportType;
    private String transferType;
    private Date transferDate;
    private String transferStatus;
    private String applicationStatus;

    public TransferInfoForDriverDto() {
    }

    public TransferInfoForDriverDto(Long busTransferId, String firstName, String lastName, String department, String fromLocation, String toLocation, String transportType, String transferType, Date transferDate, String transferStatus, String applicationStatus) {
        this.busTransferId = busTransferId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
        this.transportType = transportType;
        this.transferType = transferType;
        this.transferDate = transferDate;
        this.transferStatus = transferStatus;
        this.applicationStatus = applicationStatus;
    }

    public Long getBusTransferId() {
        return busTransferId;
    }

    public void setBusTransferId(Long busTransferId) {
        this.busTransferId = busTransferId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public String getTransferType() {
        return transferType;
    }

    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }

    public Date getTransferDate() {
        return transferDate;
    }

    public void setTransferDate(Date transferDate) {
        this.transferDate = transferDate;
    }

    public String getTransferStatus() {
        return transferStatus;
    }

    public void setTransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }
}
