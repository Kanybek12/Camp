package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.BookingDao;
import kg.kumtor.camp.dao.EmployeeDao;
import kg.kumtor.camp.dto.BookingDetailForSetDto;
import kg.kumtor.camp.dto.BookingDto;
import kg.kumtor.camp.dto.EmployeeGuestDto;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.booking.CancelConflictBooking;
import kg.kumtor.camp.entity.Booking;
import kg.kumtor.camp.entity.Employee;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.BookingRepository;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.service.BookingCheckService;
import kg.kumtor.camp.service.BookingInfoService;
import kg.kumtor.camp.service.BookingService;
import kg.kumtor.camp.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BookingServiceImpl implements BookingService {

    Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);

    private final ModelMapper modelMapper;
    private final JdbcTemplate jdbcTemplate;
    private final EmployeeService employeeService;
    private final EmployeeRepository employeeRepository;
    private final BookingRepository bookingRepository;
    private final BookingInfoService bookingInfoService;

    private final BookingCheckService bookingCheckService;

    private final EmployeeDao employeeDao;

    private final BookingDao bookingDao;

    public BookingServiceImpl(ModelMapper modelMapper, JdbcTemplate jdbcTemplate, EmployeeService employeeService, EmployeeRepository employeeRepository, BookingRepository bookingRepository, BookingInfoService bookingInfoService, BookingCheckService bookingCheckService, EmployeeDao employeeDao, BookingDao bookingDao) {
        this.modelMapper = modelMapper;
        this.jdbcTemplate = jdbcTemplate;
        this.employeeService = employeeService;
        this.employeeRepository = employeeRepository;
        this.bookingRepository = bookingRepository;
        this.bookingInfoService = bookingInfoService;
        this.bookingCheckService = bookingCheckService;
        this.employeeDao = employeeDao;
        this.bookingDao = bookingDao;
    }

    @Transactional(rollbackOn = ApiException.class)
    public BookingDto saveBooking(BookingDto bookingDto) throws ApiException {

        if (bookingDto.getEmpCode() == null) {

            Employee employee = employeeRepository.findBySinAndStatusCode(bookingDto.getPassport(), "A");

            if (employee != null && employee.getEmpCode() != null) {
                bookingDto.setFirstName(employee.getFirstNameRu());
                bookingDto.setLastName(employee.getLastNameRu());
                bookingDto.setGenderId(employee.getGenderId().getId());
                bookingDto.setNote("from Camp");
                bookingDto.setEmpCode(employee.getEmpCode());
            } else {
                EmployeeGuestDto employeeGuestDto = new EmployeeGuestDto();
                employeeGuestDto.setChangedBy("system");
                employeeGuestDto.setFirstName(bookingDto.getFirstName());
                employeeGuestDto.setLastName(bookingDto.getLastName());
                employeeGuestDto.setGenderId(bookingDto.getGenderId());
                employeeGuestDto.setNote("from Camp");
                employeeGuestDto.setPin(bookingDto.getPassport());
                employeeGuestDto.setDepartment(bookingDto.getDepartment());
                employeeGuestDto.setJobTitle(bookingDto.getJobTitle());
                employeeGuestDto.setPayAccount(bookingDto.getPayAccount());
                Integer empCode = employeeService.createGuest(employeeGuestDto);
                bookingDto.setEmpCode(empCode);
            }
        }

        if (bookingDto.getDateIn().isAfter(bookingDto.getDateOut())) {
            throw new ApiException(500, "Дата заезда больше чем дата выезда! Пожалуйста укажите валидный период даты!");
        }
        bookingDto.setDateChanged(LocalDateTime.now());
        if (bookingDto.getPayAccount() == null) {
            String query = "SELECT camp.func_get_pay_account_by_empcode(?)";
            Object[] args = new Object[]{bookingDto.getEmpCode()};
            try {
                Map<String, Object> costCenterRes = jdbcTemplate.queryForMap(query, args);
                bookingDto.setPayAccount(String.valueOf(costCenterRes.get("func_get_pay_account_by_empcode")));
            } catch (Exception ex) {

            }
        }
        Booking booking = modelMapper.map(bookingDto, Booking.class);
        try {
            logger.info("Insert to Booking: " + bookingDto);
            Booking response = bookingRepository.save(booking);
            logger.info("Insert was successfully!");
            if (!response.getId().equals(null)) {
                bookingDto.setId(Long.valueOf(response.getId()));
                return bookingDto;
            }
        } catch (Exception ex) {
            logger.error("Insert to Booking failed1: " + bookingDto);
            logger.error("Insert to Booking failed2: " + ex.getMessage());
            throw new ApiException(500, "Кровать занят или у сотрудника уже есть бронь на этот отрезок времени");
        }
        return null;
    }

    @Transactional(rollbackOn = ApiException.class)
    public BookingDetailForSetDto updateStatusOfBooking(BookingDetailForSetDto book, Integer id, boolean regular) throws ApiException {
        List<Map<String, Object>> bookingList = new ArrayList<>();


            if (bookingCheckService.isExitBooking(book, id)) {
                String query = "select b.id as id, b.date_in as date_in, b.date_out as date_out, b.emp_code as emp_code from camp.booking b\n" +
                        "inner join camp.employee e on e.emp_code = b.emp_code\n" +
                        "where b.emp_code = ?\n" +
                        "and 0 < (select count(1) from camp.booking book where date_in > ? and emp_code = ?)\n" +
                        "and b.date_in > ? and b.status_id in (2, 4) order by b.id limit 1";
                Object[] args = new Object[]{book.getEmpCode(), book.getDateIn(), book.getEmpCode(), book.getDateIn()};
                List<Map<String, Object>> res = jdbcTemplate.queryForList(query, args);
                throw new ApiException(500, "На данную дату существует бронь, ближайшая дата брони " + res.get(0).get("date_in") + "-  " + res.get(0).get("date_out"));
            }

            if (regular == true) {
                try {
                    // получаем список графиков данного сотрудника
                    String query = "select b.id as id, b.date_in as date_in, b.date_out as date_out, b.emp_code as emp_code from camp.booking b\n" +
                            "inner join camp.employee e on e.emp_code = b.emp_code\n" +
                            "where b.emp_code = ?\n" +
                            "and 0 < (select count(1) from camp.booking book where date_in > ? and emp_code = ?)\n" +
                            "and b.date_in > ?";
                    Object[] args = new Object[]{book.getEmpCode(), book.getDateIn(), book.getEmpCode(), book.getDateIn()};
                    List<Map<String, Object>> res = jdbcTemplate.queryForList(query, args);
                    // пытаемся узнать кровать на данный отрезок времени свободна или нет
                    query = "SELECT b.id as name FROM camp.bed b\n" +
                            "                WHERE b.id not in(SELECT DISTINCT bed.id from camp.bed bed\n" +
                            "                WHERE bed.id IN (select DISTINCT bed_id FROM camp.booking WHERE\n" +
                            " date_in <= ? AND date_out >= ? and status_id in (1, 2, 4))\n" +
                            " and bed.status = 'A' group by bed.id) and b.id = ?";
                    for (Map<String, Object> iterator : res) {
                        args = new Object[]{LocalDate.parse(String.valueOf(iterator.get("date_out"))), LocalDate.parse(String.valueOf(iterator.get("date_in"))), book.getBedId()};
                        List<Map<String, Object>> bedId = jdbcTemplate.queryForList(query, args);
                        if (bedId.size() != 0) {
                            Map<String, Object> booking = new LinkedHashMap<>();
                            booking.put("id", String.valueOf(iterator.get("id")));
                            booking.put("dateIn", String.valueOf(iterator.get("date_in")));
                            booking.put("dateOut", String.valueOf(iterator.get("date_out")));
                            booking.put("empCode", String.valueOf(iterator.get("emp_code")));
                            bookingList.add(booking);
                        }
                    }
                    if (Integer.valueOf(bookingList.size()).equals(res.size())) {
                        query = "UPDATE camp.booking set bed_id=? where id=? and emp_code=?";
                        for (Map<String, Object> iterator1 : res) {
                            args = new Object[]{book.getBedId(), Integer.valueOf(String.valueOf(iterator1.get("id"))), Integer.valueOf(String.valueOf(iterator1.get("emp_code")))};
                            jdbcTemplate.update(query, args);
                        }
                    } else {
                        throw new ApiException(170, "Кровать для бронирования на постоянку занята");
                    }
                } catch (Exception ex) {
                    throw new ApiException(170, ex.getMessage());
                }
            }

            String query = "UPDATE camp.booking SET first_name=?,\n" +
                    "last_name=?, booking_gender_id=?, department=?, job_title=?, date_in=?, date_out=?,\n" +
                    "bed_id=?, status_id=?\n" +
                    "WHERE id=?";

            int status = book.getStatus() != null && book.getStatus() == 4 ? 4 : 2;

            Object[] args = new Object[]{book.getFirstName(), book.getLastName(), book.getGender(), book.getDepartment(),
                    book.getJobTitle(), book.getDateIn(), book.getDateOut(), book.getBedId(), status, id};
        try {
            int res = jdbcTemplate.update(query, args);

            if (res == 1) {
                // tkabirov, 01.12.2022: обновить также даты в таблице transfer_application
                query = "UPDATE camp.transfer_application\n"
                        + "SET transfer_date_from = ?,\n"
                        + "  transfer_date_to = ?\n"
                        + "WHERE booking_id = ?";
                args = new Object[]{book.getDateIn(), book.getDateOut(), id};
                res = jdbcTemplate.update(query, args);

                if (res == 0) {
                    throw new ApiException(151, "Заполните все обязательные поля");
                }

                return bookingInfoService.getBookingInfoByEmpCodeForSetBook(id);
            }
        } catch (Exception ex) {
            throw new ApiException(151, "Заполните все обязательные поля");
        }

        return null;
    }

    @Override
    public ResponseDTO cancelManualBooking(CancelConflictBooking info) throws ApiException {
        String changedByEmpCode = employeeDao.getAccessToken().getOtherClaims().get("emp_code").toString();
        bookingDao.cancelConflictBooking(info, changedByEmpCode);
        return ResponseDTO.builder()
                .code(200)
                .message("Ручная бронь успешна отменена")
                .build();
    }
}
