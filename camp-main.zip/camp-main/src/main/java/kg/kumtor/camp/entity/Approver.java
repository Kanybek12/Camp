package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "approver")
public class Approver {
    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @OneToOne
    @JoinColumn(name = "emp_code", foreignKey = @ForeignKey(name = "fk_emp_code"),nullable = false)
    private Employee empCode;

    @ManyToOne
    @JoinColumn(name="approver_type_id", foreignKey = @ForeignKey(name = "fk_approver_type_id"),nullable = false)
    private ApproverType approverType;

    @Column(nullable = false)
    private String status = "A";
}
