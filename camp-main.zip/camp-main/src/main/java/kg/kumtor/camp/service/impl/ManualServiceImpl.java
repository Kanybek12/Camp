package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.ManualDao;
import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.manual.ManualLocationDto;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.ManualService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ManualServiceImpl implements ManualService {

    private final ManualDao manualDao;

    public ManualServiceImpl(ManualDao manualDao) {
        this.manualDao = manualDao;
    }

    @Override
    public PageableResponseDTO getLocationInfo(Integer empCode, Pageable pageable) throws ApiException {
        return manualDao.getLocationInfo(empCode, pageable);
    }


    @Override
    public ResponseDTO updateLocation(ManualLocationDto manualLocationDto){
        try {
            manualDao.updateLocation(manualLocationDto);
        } catch (Exception e) {
            return new ResponseDTO(500, "не удалось обновить!");
        }
        return new ResponseDTO(200, "успешно обновлено");
    }
}
