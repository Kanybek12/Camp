package kg.kumtor.camp.dto.transfer;

import lombok.*;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MyApplicationTypeDTO {

    private String name;
    private String nameRu;
}
