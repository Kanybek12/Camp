package kg.kumtor.camp.dto.reference;

import kg.kumtor.camp.entity.Block;

public class BlockDto {
    private Integer id;
    private String name;
    public BlockDto() {
    }

    public BlockDto(Block block) {
        this.id = block.getId();
        this.name = block.getName();
    }

    public BlockDto(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
