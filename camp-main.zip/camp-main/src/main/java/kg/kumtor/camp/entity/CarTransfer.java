package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "car_transfer")
public class CarTransfer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Column(name = "car_number")
    private String carNumber;

    @Column(name = "car_model")
    private String carModel;

    @Column(name = "driver")
    private String driver;

    @ManyToOne
    @JoinColumn(name = "location_from", foreignKey = @ForeignKey(name = "fk_location_from"))
    private Location fromLocationId;

    @ManyToOne
    @JoinColumn(name = "location_to", foreignKey = @ForeignKey(name = "fk_location_to"))
    private Location toLocationId;

    @ManyToOne
    @JoinColumn(name = "car_type_id", foreignKey = @ForeignKey(name = "fk_car_type_id"))
    private CarType carTypeId;

    @ManyToOne
    @JoinColumn(name = "mine_application_id", foreignKey = @ForeignKey(name = "fk_mine_application_id"))
    private TransferApplication transferApplicationId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", foreignKey = @ForeignKey(name = "fk_application_type_id"))
    private ApplicationType applicationTypeId;

    @ManyToOne
    @JoinColumn(name = "transfer_status_id", foreignKey = @ForeignKey(name = "fk_transfer_status_id"))
    private TransferStatus transferStatusId;
}
