package kg.kumtor.camp.dao;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.manual.LocationDto;
import kg.kumtor.camp.dto.manual.ManualLocationDto;
import kg.kumtor.camp.exception.ApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;

import java.util.List;

import static kg.kumtor.camp.exception.ExceptionsEnum.EMPTY_RESULT;

@Slf4j
@Repository
public class ManualDao {
    private final JdbcTemplate jdbcTemplate;

    public ManualDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public PageableResponseDTO getLocationInfo(Integer empCode, Pageable pageable) throws ApiException {
        List<LocationDto> resultList = null;
        log.info("call getLocationInfo");
        String query = "select \n" +
                "           e.emp_code as emp_code,\n" +
                "           coalesce (NULLIF(e.last_name_ru,''), e.last_name) || ' ' || coalesce (NULLIF(e.first_name_ru,''), e.first_name ) as full_name,\n" +
                "           l.title_ru as current_location\n" +
                "       from camp.employee e\n" +
                "           left join camp.employee_location_recent elr on elr.emp_code = e.emp_code\n" +
                "           left join camp.\"location\" l on elr.location_id = l.id\n" +
                "       where (?::INTEGER IS NULL OR e.emp_code = ?) \n" +
                "           LIMIT ? offset ? ";
        try {
            resultList = jdbcTemplate.query(query,
                    new Object[]{empCode, empCode, pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(LocationDto.class));

            log.info("List of getLocationInfo");

            PageImpl<LocationDto> applicationsPages = new PageImpl<>(
                    resultList, pageable, count());
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            log.error("Error while getting list of getLocationInfo: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    public int count() {
        return jdbcTemplate.queryForObject("SELECT count(*) FROM camp.employee e\n" +
                "           left join camp.employee_location_recent elr on elr.emp_code = e.emp_code\n" +
                "           left join camp.\"location\" l on elr.location_id = l.id", Integer.class);
    }

    @Transactional(rollbackOn = ApiException.class)
    public void updateLocation(ManualLocationDto manualLocationDto) throws ApiException {
        log.info("call updateLocation : {}", manualLocationDto);
        String query = "insert into camp.employee_location_recent(date_changed,emp_code,location_id)\n" +
                "       values(now(),?, ?)\n" +
                "       on conflict (emp_code)\n" +
                "       do update set location_id = ?;";
        Object[] args = new Object[]{ manualLocationDto.getEmpCode(), manualLocationDto.getLocationId(), manualLocationDto.getLocationId()};

        try {
            int res = jdbcTemplate.update(query, args);
            if (res != 1) {
                throw new ApiException(500, "не удалось обновить");
            }
            log.info("successful updated");
        } catch (Exception ex) {
            throw new ApiException(500, " не удалось обновить");
        }

        if (manualLocationDto.isUpdateAutoBooking()){
            callAutoBookingSp(manualLocationDto);
        }
    }
    public void callAutoBookingSp(ManualLocationDto manualLocationDto) throws ApiException {
        log.info("call sp_refresh_location(empCode) params {}", manualLocationDto.getEmpCode());

        String query = "call camp.sp_refresh_location(?)";
        Object[] args = new Object[]{ manualLocationDto.getEmpCode()};

        jdbcTemplate.update(query, args);

        log.info("successful sp_refresh_location");
    }
}
