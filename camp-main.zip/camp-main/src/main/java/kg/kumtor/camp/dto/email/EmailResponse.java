package kg.kumtor.camp.dto.email;

import java.util.Objects;

public class EmailResponse {
    private String result;

    public EmailResponse() {

    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmailResponse that = (EmailResponse) o;
        return Objects.equals(result, that.result);
    }

    @Override
    public int hashCode() {
        return Objects.hash(result);
    }

    @Override
    public String toString() {
        return "EmailResponse{" +
                "result='" + result + '\'' +
                '}';
    }
}
