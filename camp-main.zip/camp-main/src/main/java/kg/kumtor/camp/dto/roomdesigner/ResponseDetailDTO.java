package kg.kumtor.camp.dto.roomdesigner;

import kg.kumtor.camp.dto.ResponseDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

public class ResponseDetailDTO extends ResponseDTO {
    private List<ExistBookingListDto> listResult;

    public ResponseDetailDTO(int code, String message, List<ExistBookingListDto> listResult) {
        super(code, message);
        this.listResult = listResult;
    }

    public List<ExistBookingListDto> getListResult() {
        return listResult;
    }

    public void setListResult(List<ExistBookingListDto> listResult) {
        this.listResult = listResult;
    }
}
