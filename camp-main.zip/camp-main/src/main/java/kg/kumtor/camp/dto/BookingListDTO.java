package kg.kumtor.camp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDate;
import java.util.Date;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingListDTO {

    private Long id;
    private int empCode;
    private String name;
    private String jobTitle;
    private String department;
    private LocalDate dateIn;
    private LocalDate dateOut;
    private LocalDate checkIn;
    private LocalDate checkOut;
    private String visitorType;
    private String status;
    private String creator;

}
