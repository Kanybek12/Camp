package kg.kumtor.camp.dto.reference;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BedReferenceDTO {

    private int id;
    private int numInRoom;
    private String room;
    private String status;
    private String type;
    private String block;
    private String camp;


}
