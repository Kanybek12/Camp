package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.RejectApplicationDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.statistics.ApplicationForSettlementDTO;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Map;

public interface ApplicationService {
    PageableResponseDTO getApplicationsForSettlement(Pageable pageable, String empCode, String dateIn, String dateOut,
                                                     String visitorTypeId, String departmentId, String jobTitleId,
                                                     String onSchedule) throws ApiException;

    ResponseDTO rejectApplicationForSettlement(int empCode, List<RejectApplicationDTO> rejectApplications) throws ApiException;
}
