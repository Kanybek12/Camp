package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.CarTypeDto;
import kg.kumtor.camp.entity.CarType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CarTypeRepository extends JpaRepository<CarType, Long> {
    @Query("SELECT new kg.kumtor.camp.dto.reference.CarTypeDto(u.id,u.name) FROM CarType u")
    List<CarTypeDto> find();
}
