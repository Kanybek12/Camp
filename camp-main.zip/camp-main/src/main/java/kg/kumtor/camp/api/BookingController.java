package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.BookingDetailForSetDto;
import kg.kumtor.camp.dto.BookingDto;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.booking.CancelConflictBooking;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.BookingService;
import lombok.AllArgsConstructor;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@AllArgsConstructor
@RequestMapping("/booking")
@RestController
public class BookingController {

    private final BookingService bookingService;

    @PostMapping(value = "/save")
    public ResponseEntity<BookingDto> saveBooking(@RequestBody BookingDto bookingDto) throws Exception {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        Principal principal = (Principal) authentication.getPrincipal();
        KeycloakPrincipal<KeycloakSecurityContext> keycloakPrincipal = (KeycloakPrincipal<KeycloakSecurityContext>) principal;

        String emp_code = keycloakPrincipal.getKeycloakSecurityContext().getToken().getOtherClaims().get("emp_code").toString();
        String given_name = keycloakPrincipal.getKeycloakSecurityContext().getToken().getGivenName();

        String val = emp_code != null && !emp_code.equals("") ? emp_code
                : (given_name != null && !given_name.equals("") ? given_name : "Undefined");
        bookingDto.setChangedBy(val);

        return ResponseEntity.ok(bookingService.saveBooking(bookingDto));
    }

    @PutMapping(value = "/edit-booking/{id}")
    public ResponseEntity<BookingDetailForSetDto> editBookingById(@PathVariable(value = "id") Integer bookingId,
                                                                  @RequestParam(value = "regular", required = false, defaultValue = "0") boolean regular,
                                                                  @RequestBody BookingDetailForSetDto book) throws Exception {
        return ResponseEntity.ok(bookingService.updateStatusOfBooking(book, bookingId, regular));
    }

    @PutMapping("/manual-booking-cancel")
    public ResponseDTO cancelManualBooking(@RequestBody CancelConflictBooking info) throws ApiException {
        return bookingService.cancelManualBooking(info);
    }
}
