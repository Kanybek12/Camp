package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "emp_code", nullable = false)
    private Integer empCode;

    @Column(name = "first_name", length = 100)
    private String firstName;

    @Column(name = "middle_name", length = 100)
    private String middleName;

    @Column(name = "last_name", length = 100)
    private String lastName;

    @Column(name = "first_name_ru", length = 100)
    private String firstNameRu;

    @Column(name = "middle_name_ru", length = 100)
    private String middleNameRu;

    @Column(name = "last_name_ru", length = 100)
    private String lastNameRu;

    @Column(name = "status_code", length = 1, nullable = false)
    private String statusCode;

    @Column(name = "email", unique = true, length = 100)
    private String email;

    @Column(name = "phone_no1", length = 20)
    private String phoneNo1;

    @Column(name = "phone_no2", length = 20)
    private String phoneNo2;

    // Social insurance number
    @Column(name = "sin")
    private String sin;

    @ManyToOne
    @JoinColumn(name = "department_id", foreignKey = @ForeignKey(name = "fk_department_id"))
    private Department departmentId;

    @ManyToOne
    @JoinColumn(name = "job_title_id", foreignKey = @ForeignKey(name = "fk_job_title_id"))
    private JobTitle jobTitleId;

    @Column(name = "password", columnDefinition = "TEXT")
    private String password;

    @Column(name = "is_registered", nullable = false)
    private int isRegistered = 0;

    @ManyToMany(fetch = FetchType.EAGER) // load all roles whenever load the user
    @Column(name = "roles")
    private Collection<Role> roles = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "gender_id", foreignKey = @ForeignKey(name = "fk_gender_id"))
    private Gender genderId;

    @ManyToOne
    @JoinColumn(name = "work_location_id", foreignKey = @ForeignKey(name = "fk_work_location_id"))
    private WorkLocation workLocationId;

    @ManyToOne
    @JoinColumn(name = "employee_type_id", foreignKey = @ForeignKey(name = "fk_employee_type_id"))
    private VisitorType employeeTypeId;

    @ManyToOne
    @JoinColumn(name = "cost_center_code", foreignKey = @ForeignKey(name = "fk_cost_center_code"),
            referencedColumnName = "code")
    private CostCenter costCenterCode;

    @ManyToOne
    @JoinColumn(name = "project_code", foreignKey = @ForeignKey(name = "fk_project_code"), referencedColumnName =
            "code")
    private Project projectCode;

    @Column(name = "pay_account", length = 50)
    private String payAccount;

    @ManyToOne
    @JoinColumn(name = "organization_id", nullable = true, foreignKey = @ForeignKey(name = "fk_organization_id"))
    private Organization organizationId;
    @Column(name = "date_birth")
    private LocalDate dateBirth;

    @Override
    public String toString() {
        return "Employee{" +
                "changedBy='" + changedBy + '\'' +
                ", dateChanged=" + dateChanged +
                ", empCode=" + empCode +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", firstNameRu='" + firstNameRu + '\'' +
                ", middleNameRu='" + middleNameRu + '\'' +
                ", lastNameRu='" + lastNameRu + '\'' +
                ", statusCode='" + statusCode + '\'' +
                ", email='" + email + '\'' +
                ", phoneNo1='" + phoneNo1 + '\'' +
                ", phoneNo2='" + phoneNo2 + '\'' +
                ", sin='" + sin + '\'' +
                ", departmentId=" + departmentId +
                ", jobTitleId=" + jobTitleId +
                ", password='" + password + '\'' +
                ", isRegistered=" + isRegistered +
                ", roles=" + roles +
                ", genderId=" + genderId +
                ", workLocationId=" + workLocationId +
                ", employeeTypeId=" + employeeTypeId +
                ", costCenterCode=" + costCenterCode +
                ", projectCode=" + projectCode +
                ", payAccount='" + payAccount + '\'' +
                ", organizationId=" + organizationId +
                ", dateBirth=" + dateBirth +
                '}';
    }
}
