package kg.kumtor.camp.dto.roomdesigner;

public class BedListDto {
    private Integer bedId;
    private Integer bedTypeId;

    public BedListDto() {
    }

    public BedListDto(Integer bedId, Integer bedTypeId) {
        this.bedId = bedId;
        this.bedTypeId=bedTypeId;
    }

    public Integer getBedTypeId() {
        return bedTypeId;
    }

    public void setBedTypeId(Integer bedTypeId) {
        this.bedTypeId = bedTypeId;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }
}
