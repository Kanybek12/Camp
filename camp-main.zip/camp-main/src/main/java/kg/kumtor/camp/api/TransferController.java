package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.transfer.*;
import kg.kumtor.camp.dto.transfer.update.UpdateDescentApplicationDTO;
import kg.kumtor.camp.dto.transfer.vahta.BusVahtaApplicationsDTO;
import kg.kumtor.camp.dto.transfer.vahta.VahtaApplicationStatisticsDto;
import kg.kumtor.camp.dto.transfer.vahta.VahtaApplicationStatusStatisticsDto;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.service.TransferService;
import kg.kumtor.camp.service.UtilityService;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@RequestMapping("/transfer")
@RestController
public class TransferController {
    private final TransferService transferService;
    private final EmployeeRepository employeeRepository;
    private final UtilityService utilityService;

    public TransferController(TransferService transferService, EmployeeRepository employeeRepository, UtilityService utilityService) {
        this.transferService = transferService;
        this.employeeRepository = employeeRepository;
        this.utilityService = utilityService;
    }

    @PutMapping(value = "/check-in")
    public ResponseDTO checkInTransfer(@RequestBody TransferCheckInDto transferCheckInDto) throws ApiException {
        return transferService.checkInTransfer(transferCheckInDto);
    }

    @PostMapping(value = "/save")
    public ResponseEntity<List<Map<String, Object>>> saveBooking(@RequestBody TransferApplicationDto transferApplicationDto) throws ApiException {
        return ResponseEntity.ok(transferService.saveTransfer(transferApplicationDto));
    }

    @GetMapping("/my-applications")
    public PageableResponseDTO myApplications(@RequestParam(value = "page", required = true) int page,
                                              @RequestParam(value = "dateCreated", required = false,
                                                          defaultValue = "%%") String dateCreated,
                                              @RequestParam(value = "plannedDate", required = false,
                                                              defaultValue = "%%") String plannedDate,
                                              @RequestParam(value = "applicationType", required = false,
                                                      defaultValue = "%%") String applicationType) throws ApiException {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);
        return transferService.getMyApplications(PageRequest.of(page - 1, 10), empCode, dateCreated, plannedDate, applicationType);
    }

    @GetMapping("/applications-for-others")
    public PageableResponseDTO applicationsForOthers(@RequestParam(value = "page", required = true) int page,
                                                         @RequestParam(value = "dateCreated", required = false,
                                                                 defaultValue = "%%") String dateCreated,
                                                         @RequestParam(value = "plannedDate", required = false,
                                                                 defaultValue = "%%") String plannedDate,
                                                         @RequestParam(value = "applicationType", required = false,
                                                                 defaultValue = "%%") String applicationType) throws ApiException {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);
        return transferService.getApplicationsForOthers(PageRequest.of(page - 1, 10), empCode, dateCreated, plannedDate, applicationType);
    }

    @PutMapping("/application/descent/{id}")
    public ResponseDTO updateDescentApplication(@PathVariable long id,
                                                @RequestBody UpdateDescentApplicationDTO application) throws ApiException{
        return transferService.updateDescentApplication(id, application);
    }

    @PutMapping("/applications/cancel")
    public ResponseDTO cancelMyApplications(@RequestBody List<CancelMyApplicationDTO> applications) throws ApiException {
        return transferService.cancelMyApplications(applications);
    }

    @GetMapping("/profile/personal-info")
    public PersonalInfoDTO getPersonalInfo() throws ApiException {
        KeycloakAuthenticationToken authentication =
                (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);
        return transferService.getPersonalInfo(empCode);
    }

    @GetMapping("/profile/transfer-ascent")
    public PersonalTransferDTO getPersonalTransferAscent() throws ApiException {
        KeycloakAuthenticationToken authentication =
                (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);
        return transferService.getPersonalTransferAscent(empCode);
    }

    @GetMapping("/profile/transfer-descent")
    public PersonalTransferDTO getPersonalTransferDescent() throws ApiException {
        KeycloakAuthenticationToken authentication =
                (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);
        return transferService.getPersonalTransferDescent(empCode);
    }

    @PutMapping("/profile/transfer-ascent")
    public ResponseDTO updatePersonalTransferAscent(@RequestBody PersonalTransferDTO info) throws ApiException {
        return transferService.updatePersonalTransferAscent(info);
    }

    @PutMapping("/profile/transfer-descent")
    public ResponseDTO updatePersonalTransferDescent(@RequestBody PersonalTransferDTO info) throws ApiException {
        return transferService.updatePersonalTransferDescent(info);
    }

    @GetMapping("/departments")
    public ResponseEntity<List<Map<String, Object>>> getDepartments() throws ApiException {
        return ResponseEntity.ok(transferService.getDepartmentsForTransfer());
    }

    @GetMapping("/transfer-type")
    public ResponseEntity<List<TransferTypeDto>> getTransferType() {
        return ResponseEntity.ok(transferService.getTransferType());
    }

    @GetMapping("/driver/transfer-info-list")
    public ResponseEntity<List<TransferInfoForDriverDto>> getTransferInfoForDriverList(
            @RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate transferDate,
            @RequestParam(value = "transfer-type", required = false) Integer transferType,
            @RequestParam(value = "location", required = false) Integer locationId) throws ApiException {
        return ResponseEntity.ok(transferService.getTransferInfoForDriver(transferDate, transferType, locationId));
    }

    @PutMapping("/approve/transfer-status")
    public ResponseEntity<ResponseDTO> editTransferApprove(@RequestBody List<TransferApproveDto> transferApproveDtos)throws ApiException{
        return ResponseEntity.ok(transferService.approveTransferRequest(transferApproveDtos));
    }
    @GetMapping("/approve/get-list")
    public ResponseEntity<Map<String, Object>> getTransferApplicationForApprove(@RequestParam(value="emp-code")Integer empCode)throws ApiException{
        return ResponseEntity.ok(transferService.getTransferApplicationsForApprove(empCode));
    }

    @GetMapping("/vahta/statistics")
    public ResponseEntity<VahtaApplicationStatisticsDto> getVahtaApplicaionStatistics(
            @RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate transferDate)throws ApiException{
        return ResponseEntity.ok(transferService.getVahtaApplicationStatistics(transferDate));
    }
    @GetMapping("/vahta-status/statistics")
    public ResponseEntity<VahtaApplicationStatusStatisticsDto> getVahtaApplicaionStatusStatistics(
            @RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate transferDate)throws ApiException{
        return ResponseEntity.ok(transferService.getVahtaApplicationStatusStatistics(transferDate));
    }

//    @RolesAllowed("transfer-coordinator")
    @GetMapping("/vahta/application-list")
    public PageableResponseDTO getVahtaApplicationList(@RequestParam(value = "transfer-date",required = false) @DateTimeFormat(pattern
            = "yyyy-MM-dd") LocalDate transferDate,
                                                                                 @RequestParam(value = "emp-code", required = false) Integer empCode,
                                                                                 @RequestParam(value = "application-type", required = false)Integer applicationType,
                                                                                 @RequestParam(value = "visitor-type", required = false)Integer visitorType,
                                                                                 @RequestParam(value = "page", required = false, defaultValue = "1") int page)
            throws ApiException{
        return transferService.getVahtaApplicationList(PageRequest.of(page - 1, 10), transferDate, empCode,
                applicationType, visitorType);
    }


    @GetMapping("/vahta/received-application-list")
    public PageableResponseDTO getReceivedVahtaApplicationList(@RequestParam(value = "transfer-date",
            required = false) @DateTimeFormat(pattern= "yyyy-MM-dd") LocalDate transferDate,
                                                       @RequestParam(value = "emp-code", required = false) Integer empCode,
                                                       @RequestParam(value = "application-type", required = false)Integer applicationType,
                                                       @RequestParam(value = "visitor-type", required = false)Integer visitorType,
                                                       @RequestParam(value = "page", required = false, defaultValue = "1") int page)
            throws ApiException{
        return transferService.getReceivedVahtaApplicationList(PageRequest.of(page - 1, 10), transferDate, empCode,
                applicationType, visitorType);
    }

    @PutMapping("/vahta/approve/{id}")
    public ResponseDTO approveVahtaApplication(@PathVariable("id") long id) throws ApiException {
        return transferService.approveVahtaApplication(id);
    }

    @PutMapping("/vahta/reject/{id}")
    public ResponseDTO rejectVahtaApplication(@PathVariable("id") long id) throws ApiException {
        return transferService.rejectVahtaApplication(id);
    }

    @PutMapping("/vahta/undo/{id}")
    public ResponseDTO undoVahtaApplication(@PathVariable("id") long id) throws ApiException {
        return transferService.undoVahtaApplication(id);
    }

//    @RolesAllowed("bus-dispatcher")
    @GetMapping("/bus/application-list")
    public PageableResponseDTO getBusApplicationList(@RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern
            = "yyyy-MM-dd") LocalDate transferDate,
                                                     @RequestParam(value = "emp-code", required = false) Integer empCode,
                                                     @RequestParam(value = "application-type", required = false) Integer applicationType,
                                                     @RequestParam(value = "visitor-type", required = false) Integer visitorType,
                                                     @RequestParam(value = "page", required = false, defaultValue = "1") int page)
            throws ApiException {
        return transferService.getBusApplicationList(PageRequest.of(page - 1, 10), transferDate, empCode,
                applicationType, visitorType);
    }

    @GetMapping("/bus/received-application-list")
    public PageableResponseDTO getReceivedBusApplicationList(@RequestParam(value = "transfer-date",
            required = false) @DateTimeFormat(pattern= "yyyy-MM-dd") LocalDate transferDate,
                                                               @RequestParam(value = "emp-code", required = false) Integer empCode,
                                                               @RequestParam(value = "application-type", required = false)Integer applicationType,
                                                               @RequestParam(value = "visitor-type", required = false)Integer visitorType,
                                                               @RequestParam(value = "page", required = false, defaultValue = "1") int page)
            throws ApiException{
        return transferService.getReceivedBusApplicationList(PageRequest.of(page - 1, 10), transferDate, empCode,
                applicationType, visitorType);
    }

    @PutMapping("/bus/approve/{id}")
    public ResponseDTO approveBusApplication(@PathVariable long id) throws ApiException {
        return transferService.approveBusApplication(id);
    }

    @PutMapping("/bus/reject/{id}")
    public ResponseDTO rejectBusApplication(@PathVariable long id) throws ApiException {
        return transferService.rejectBusApplication(id);
    }

    @PutMapping("/bus/undo/{id}")
    public ResponseDTO undoBusApplication(@PathVariable long id) throws ApiException {
        return transferService.undoBusApplication(id);
    }

    @GetMapping("/transfer/info")
    public ResponseEntity<List<TransferInfoDto>> getTransferInfoList(
            @RequestParam(value = "transfer-date", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate transferDate,
            @RequestParam(value = "transfer-type", required = false) Integer transferType,
            @RequestParam(value = "location", required = false) Integer locationId,
            @RequestParam(value = "emp-code",required = false) Integer empCode,
            @RequestParam(value="name",required = false) String name) throws ApiException {
        return ResponseEntity.ok(transferService.getTransferInfoList(transferDate, transferType, locationId,empCode,name));
    }

    @GetMapping("/all-transfer-list")
    public PageableResponseDTO getAllBookingList(@RequestParam(value = "transfer-date",required = false) @DateTimeFormat(pattern
            = "yyyy-MM-dd") LocalDate transferDate,
                                                 @RequestParam(value = "emp-code", required = false) Integer empCode,
                                                 @RequestParam(value = "application-type", required = false)Integer applicationType,
                                                 @RequestParam(value = "visitor-type", required = false)Integer visitorType,
                                                 @RequestParam(value = "status", required = false)Integer status,
                                                 @RequestParam(value = "page", required = false, defaultValue = "1") int page)
            throws ApiException{
        return transferService.getAllTransferList(PageRequest.of(page - 1, 10), transferDate, empCode,
                applicationType, visitorType, status);
    }
}
