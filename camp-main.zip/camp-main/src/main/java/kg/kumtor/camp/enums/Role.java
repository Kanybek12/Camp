package kg.kumtor.camp.enums;

public enum Role {
    BUS_DISPATCHER("bus-dispatcher"),
    SHIFT_BUS_DISPATCHER("shift-bus-dispatcher"),
    CREATOR("creator"),
    COORDINATOR("coordinator"),
    APPROVER("approver");
    private final String value;
    Role(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }
}
