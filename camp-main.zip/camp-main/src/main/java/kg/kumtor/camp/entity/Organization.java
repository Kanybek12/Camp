package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "organization")
public class Organization {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @ManyToOne
    @JoinColumn(name = "organization_type_id", foreignKey = @ForeignKey(name = "fk_organization_type_id"))
    private OrganizationType organizationTypeId;

    @Column(name = "parent_company")
    private String parentCompany;
}
