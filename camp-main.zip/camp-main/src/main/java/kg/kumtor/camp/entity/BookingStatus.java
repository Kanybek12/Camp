package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "booking_status")
public class BookingStatus {
    public BookingStatus(String changedBy, LocalDateTime dateChanged, String title) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.title = title;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Column(name = "title" ,nullable = false)
    private String title;

    public BookingStatus() {

    }
}
