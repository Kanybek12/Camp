package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.BookingStatusDto;
import kg.kumtor.camp.dto.reference.BlockDto;
import kg.kumtor.camp.entity.Bed;
import kg.kumtor.camp.entity.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingStatusRepository extends JpaRepository<BookingStatus, Long> {

    @Query("SELECT new kg.kumtor.camp.dto.BookingStatusDto(b.id, b.title) FROM BookingStatus b")
    List<BookingStatusDto> findAllStatus();

}
