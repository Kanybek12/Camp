package kg.kumtor.camp.dto.roomdesigner;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public class VisitorSaveRequestBody {
    private Integer empCode;
    private Integer bedId;

    @JsonProperty("isUpdateAutoBooking")
    private boolean isUpdateAutoBooking;
    public VisitorSaveRequestBody() {
    }

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }

    public boolean isUpdateAutoBooking() {
        return isUpdateAutoBooking;
    }

    public void setUpdateAutoBooking(boolean updateAutoBooking) {
        isUpdateAutoBooking = updateAutoBooking;
    }
}
