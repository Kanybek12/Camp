package kg.kumtor.camp.service.impl.report;

import kg.kumtor.camp.dto.report.BusVahtaAppDTO;
import kg.kumtor.camp.dto.transfer.vahta.BusVahtaReportsDto;
import kg.kumtor.camp.service.ExcelService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

@Slf4j
public class BusAndVahtaServiceImpl implements ExcelService {

    private XSSFWorkbook workbook;
    private XSSFSheet sheet[];
    private List<Row> rows0;
    private List<Row> rows1;
    private List<Row> rows2;
    private List<Row> rows3;
    private List<Row> rows4;
    private List<Row> rows5;

    private BusVahtaReportsDto reportsDto;

    public BusAndVahtaServiceImpl(BusVahtaReportsDto reportDto) {
        this.reportsDto = reportDto;
        workbook = new XSSFWorkbook();
        sheet = new XSSFSheet[6];
        rows0 = new ArrayList<>();
        rows1 = new ArrayList<>();
        rows2 = new ArrayList<>();
        rows3 = new ArrayList<>();
        rows4 = new ArrayList<>();
        rows5 = new ArrayList<>();
    }

    @Override
    public void writeHeader() {
        this.sheet[0] = workbook.createSheet("Спуск");
        this.sheet[1] = workbook.createSheet("Подъем");
        this.sheet[2] = workbook.createSheet("Спуск_Контрактники");
        this.sheet[3] = workbook.createSheet("Подъем_Контрактники");
        this.sheet[4] = workbook.createSheet("Спуск_Гостей");
        this.sheet[5] = workbook.createSheet("Подъем_Гостей");

        IntStream.range(0, 16 + (reportsDto.getBusVahtaDownList() == null ? 0 : reportsDto.getBusVahtaDownList().size())).forEach(i -> rows0.add(this.sheet[0].createRow(i)));
        IntStream.range(0, 16 + (reportsDto.getBusVahtaUpList() == null ? 0 : reportsDto.getBusVahtaUpList().size())).forEach(i -> rows1.add(this.sheet[1].createRow(i)));

        IntStream.range(0, 16 + (reportsDto.getBusVahtaDownList() == null ? 0 : reportsDto.getBusVahtaDownContractList().size())).forEach(i -> rows2.add(this.sheet[2].createRow(i)));
        IntStream.range(0, 16 + (reportsDto.getBusVahtaUpList() == null ? 0 : reportsDto.getBusVahtaUpContractList().size())).forEach(i -> rows3.add(this.sheet[3].createRow(i)));

        IntStream.range(0, 16 + (reportsDto.getBusVahtaDownList() == null ? 0 : reportsDto.getBusVahtaDownGuestList().size())).forEach(i -> rows4.add(this.sheet[4].createRow(i)));
        IntStream.range(0, 16 + (reportsDto.getBusVahtaUpList() == null ? 0 : reportsDto.getBusVahtaUpGuestList().size())).forEach(i -> rows5.add(this.sheet[5].createRow(i)));

        CellStyle styleHeader = workbook.createCellStyle();
        CellStyle styleSample = workbook.createCellStyle();
        XSSFFont fontHeader = workbook.createFont();
        XSSFFont fontSample = workbook.createFont();
        fontSample.setFontHeight(10);
        styleSample.setFont(fontSample);
        fontHeader.setBold(true);
        fontHeader.setFontHeight(10);
        styleHeader.setFont(fontHeader);

        setHeader("СПУСК", "П.Назначения", styleHeader, sheet[0], rows0);
        setHeader("ПОДЪЁМ", "П.Отправки", styleHeader, sheet[1], rows1);

        setHeader("СПУСК КОНТРАКТНИКИ", "П.Назначения", styleHeader, sheet[2], rows2);
        setHeader("ПОДЪЁМ КОНТРАКТНИКИ", "П.Отправки", styleHeader, sheet[3], rows3);

        setHeader("СПУСК ГОСТЕЙ", "П.Назначения", styleHeader, sheet[4], rows4);
        setHeader("ПОДЪЁМ ГОСТЕЙ", "П.Отправки", styleHeader, sheet[5], rows5);

    }

    @Override
    public void writeTransactionDataLines() {
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(8);
        style.setFont(font);

        reportsDto.getBusVahtaDownList().forEach(tr -> {
            int columnNum = 0;
            writeDataDown(reportsDto.getBusVahtaDownList(), tr, this.rows0, columnNum, style, this.sheet[0]);
        });

        reportsDto.getBusVahtaUpList().forEach(tr -> {
            int columnNum = 0;
            writeDataUp(reportsDto.getBusVahtaUpList(), tr, this.rows1, columnNum, style, this.sheet[1]);
        });

        // Contracts
        reportsDto.getBusVahtaDownContractList().forEach(tr -> {
            int columnNum = 0;
            writeDataDown(reportsDto.getBusVahtaDownContractList(), tr, this.rows2, columnNum, style, this.sheet[2]);
        });

        // Contracts
        reportsDto.getBusVahtaUpContractList().forEach(tr -> {
            int columnNum = 0;
            writeDataUp(reportsDto.getBusVahtaUpContractList(), tr, this.rows3, columnNum, style, this.sheet[3]);
        });

        // Guest
        reportsDto.getBusVahtaDownGuestList().forEach(tr -> {
            int columnNum = 0;
            writeDataDown(reportsDto.getBusVahtaDownGuestList(), tr, this.rows4, columnNum, style, this.sheet[4]);
        });
        // Guest
        reportsDto.getBusVahtaUpGuestList().forEach(tr -> {
            int columnNum = 0;
            writeDataUp(reportsDto.getBusVahtaUpGuestList(), tr, this.rows5, columnNum, style, this.sheet[5]);
        });
    }

    private void writeDataDown(List<BusVahtaAppDTO> busVahtaDownList, BusVahtaAppDTO tr, List<Row> rows, int columnNum, CellStyle style, XSSFSheet sheet) {
        createCell(rows.get(2 + busVahtaDownList.indexOf(tr)), columnNum, busVahtaDownList.indexOf(tr) + 1, style, sheet);
        createCell(rows.get(2 + busVahtaDownList.indexOf(tr)), columnNum + 1, tr.getFullName(), style, sheet);
        createCell(rows.get(2 + busVahtaDownList.indexOf(tr)), columnNum + 2, tr.getEmpCode(), style, sheet);
        createCell(rows.get(2 + busVahtaDownList.indexOf(tr)), columnNum + 3, tr.getDepartment(), style, sheet);
        createCell(rows.get(2 + busVahtaDownList.indexOf(tr)), columnNum + 4, tr.getV2LocationTo() != null ? tr.getV2LocationTo() : tr.getLocationTo(), style, sheet);
        createCell(rows.get(2 + busVahtaDownList.indexOf(tr)), columnNum + 9, tr.getTransferDate().toString(), style, sheet);
    }

    private void writeDataUp(List<BusVahtaAppDTO> busVahtaUpList, BusVahtaAppDTO tr, List<Row> rows, int columnNum, CellStyle style, XSSFSheet sheet) {
        createCell(rows.get(2 + busVahtaUpList.indexOf(tr)), columnNum, busVahtaUpList.indexOf(tr) + 1, style, sheet);
        createCell(rows.get(2 + busVahtaUpList.indexOf(tr)), columnNum + 1, tr.getFullName(), style, sheet);
        createCell(rows.get(2 + busVahtaUpList.indexOf(tr)), columnNum + 2, tr.getEmpCode(), style, sheet);
        createCell(rows.get(2 + busVahtaUpList.indexOf(tr)), columnNum + 3, tr.getDepartment(), style, sheet);
        createCell(rows.get(2 + busVahtaUpList.indexOf(tr)), columnNum + 4, tr.getV2LocationFrom() != null ? tr.getV2LocationFrom() : tr.getLocationFrom(), style, sheet);
        createCell(rows.get(2 + busVahtaUpList.indexOf(tr)), columnNum + 9, tr.getTransferDate().toString(), style, sheet);
    }
    @Override
    public void export(HttpServletResponse response) throws IOException {
        writeHeader();
        writeTransactionDataLines();
        ByteArrayInputStream inputStream = null;
        OutputStream outputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            workbook.write(byteArrayOutputStream);
            byte[] buffer = byteArrayOutputStream.toByteArray();

            outputStream = response.getOutputStream();
            inputStream = new ByteArrayInputStream(buffer);
            IOUtils.copy(inputStream, outputStream);
            workbook.close();
        } finally {
            try {
                if (outputStream != null)
                    outputStream.close();
            } catch (Exception e) {
                log.error("Error message: {}", e.toString());
            }
            try {
                if (inputStream != null)
                    inputStream.close();
            } catch (Exception ex) {
                log.error("Error message: {}", ex.toString());
            }
            try {
                if (byteArrayOutputStream != null)
                    byteArrayOutputStream.close();
            } catch (Exception ex) {
                log.error("Error message: {}", ex.toString());
            }
        }
    }

    @Override
    public void createCell(Row row, int columnCount, Object value, CellStyle style, XSSFSheet sheet) {
        // sheet.autoSizeColumn(columnCount);
        if (null == value)
            value = new String("");
        Cell cell = row.createCell(columnCount);
        if (value instanceof Integer) {
            cell.setCellValue((Integer) value);
        } else if (value instanceof Boolean) {
            cell.setCellValue((Boolean) value);
        } else if (value instanceof String) {
            cell.setCellValue((String) value);
        } else if (value instanceof Double) {
            cell.setCellValue((Double) value);
        } else if (value instanceof LocalDate) {
            cell.setCellValue((LocalDate) value);
        }
        style.setAlignment(HorizontalAlignment.LEFT);
        cell.setCellStyle(style);

    }

    private void setHeader(String type, String location, CellStyle styleHeader, XSSFSheet sheet, List<Row> rows) {
        //createCell(rows.get(0), 1, "ДАТА", styleHeader, sheet);
        createCell(rows.get(0), 1, type, styleHeader, sheet);

        createCell(rows.get(1), 0, "№", styleHeader, sheet);
        createCell(rows.get(1), 1, "ФИО", styleHeader, sheet);
        createCell(rows.get(1), 2, "Таб.номер", styleHeader, sheet);
        createCell(rows.get(1), 3, "Отдел", styleHeader, sheet);
        createCell(rows.get(1), 4, location, styleHeader, sheet);
        createCell(rows.get(1), 5, "Темпр", styleHeader, sheet);
        createCell(rows.get(1), 6, "Пульс", styleHeader, sheet);
        createCell(rows.get(1), 7, "Сатур-я", styleHeader, sheet);
        createCell(rows.get(1), 8, "АД", styleHeader, sheet);
        createCell(rows.get(1), 9, "Дата", styleHeader, sheet);
    }
}
