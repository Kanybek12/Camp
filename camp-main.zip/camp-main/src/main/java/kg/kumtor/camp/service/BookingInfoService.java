package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.*;
import kg.kumtor.camp.dto.booking.VacationInfo;
import kg.kumtor.camp.dto.reference.*;
import kg.kumtor.camp.dto.statistics.room.RoomInfoDTO;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Map;

public interface BookingInfoService {
    List<BlockDto> getBlockByDateAndLocationId(Integer locationId, Integer genderId, Date dateIn, Date dateOut) throws ApiException;
    List<RoomCategoryDto> getRoomCategory();
    List<RoomDto> getRoomByDateAndBlockAndGender(Integer roomId, Integer blockId, Date dateIn, Date dateOut, Integer genderId, Integer roomCapacity) throws ApiException;
    List<LocationDto> getLocation();
    Map<String, Object> getQuantityOfBedInRoom(Integer roomId, Date dateIn, Date dateOut);
    List<BedDto> getBed(Integer roomId, Date dateIn, Date dateOut, Integer bedId) throws ApiException;
    EmployeeInfoDto getEmployeeInfoByEmpCode(Integer empCode);

    List<Integer> getEmpCodes(Integer empType);

    Map<String, List<RoomInfoDTO>> getRoomsInfo();

    PageableResponseDTO getBookingApplications(Pageable pageable, String dateIn, String departmentId,
                                               String checkIn, String transitStatus, String visitorTypeId,
                                               String dateOut, String empCode) throws ApiException;

    ChangeBookingDto getBookingForChangeDate(Integer id) throws Exception;

    List<RoomFilterDto> getAllRoomsWithFilter(LocalDate dateIn, Integer locationId, String blockId, String roomId,
                                              Integer empCode, Integer empType, Integer status, Integer size, Integer page);
    List<BookingStatusDto> getBookingStatus();
    BookingDetailForSetDto getBookingInfoByEmpCodeForSetBook(Integer id);

    List<Map<String,Object>> getRoomCapacityList(Integer blockId, Integer genderId, Date dateIn, Date dateOut) throws ApiException ;
    Map<String, Object> getInfoForBookFromBookingListPage(Integer bedId, Date dateIn, Date dateOut) throws ApiException;
    List<Map<String, Object>> getBookingListByBedId(Integer bedId) throws ApiException;

    Integer getFreeBedId(Integer empCode, LocalDate dateIn, LocalDate dateOut) throws ApiException;
    PageableResponseDTO getAllBookingList(Pageable pageable, LocalDate dateIn, LocalDate dateOut,
                                          LocalDate checkIn, LocalDate checkOut, Integer empCode) throws ApiException;

    PageableResponseDTO getConflictBooking(Integer empCode, LocalDate dateIn, LocalDate dateOut, Integer empType, PageRequest of) throws ApiException;

    VacationInfo getVacationDetailInfo(int bedId) throws ApiException;
}
