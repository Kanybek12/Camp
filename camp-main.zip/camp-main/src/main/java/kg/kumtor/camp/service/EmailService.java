package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.transfer.CancelMyApplicationDTO;
import kg.kumtor.camp.dto.transfer.TransferApproveDto;
import kg.kumtor.camp.exception.ApiException;

import java.util.List;

public interface EmailService {
    void sendEmailApprovedTransfers(List<TransferApproveDto> transferApproveDto) throws ApiException;
    void sendEmailCancelMyApplications(List<CancelMyApplicationDTO> applications) throws ApiException;
    void sendEmailVahtaAndBusApproved(long busTransferId) throws ApiException;
    void sendEmailVahtaAndBusCanceled(long busTransferId) throws ApiException;
}
