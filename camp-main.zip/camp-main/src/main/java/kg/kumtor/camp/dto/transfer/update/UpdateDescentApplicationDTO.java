package kg.kumtor.camp.dto.transfer.update;

import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateDescentApplicationDTO {
    private int fromLocationId;
    private int toLocationId;
    private boolean busTransferDown;
    private boolean vahtaTransferDown;
    private boolean personalCarTransferDown;
    private boolean companyCarTransferDown;
    private String carModel;
    private String carNumber;
}
