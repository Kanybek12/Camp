package kg.kumtor.camp.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BookingApplicationDTO {

    private long id;
    private int empCode;
    private String name;
    private String jobTitle;
    private String department;
    private LocalDate dateIn;
    private LocalDate dateOut;
    private LocalDate checkIn;
    private String visitorType;
    private String onSchedule;
    private String transitStatus;
    private String note;
    private String bedNumberInRoom;


}
