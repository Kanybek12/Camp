package kg.kumtor.camp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;

public class BookingDetailForSetDto {
    private Integer empCode;
    private String firstName;
    private String lastName;
    private Integer gender;
    private String department;
    private String jobTitle;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateIn;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOut;
    private Integer location;
    private Integer block;
    private Integer room;
    private Integer bedId;
    private Integer roomGender;
    private Integer category;
    private Integer roomCapacity;

    private Integer status;

    public BookingDetailForSetDto() {
    }

    public BookingDetailForSetDto(Integer empCode, String firstName, String lastName, Integer gender, String department, String jobTitle, LocalDate dateIn, LocalDate dateOut, Integer location, Integer block, Integer room, Integer bedId, Integer roomGender, Integer category, Integer roomCapacity, Integer status) {
        this.empCode = empCode;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.department = department;
        this.jobTitle = jobTitle;
        this.dateIn = dateIn;
        this.dateOut = dateOut;
        this.location = location;
        this.block = block;
        this.room = room;
        this.bedId = bedId;
        this.roomGender = roomGender;
        this.category = category;
        this.roomCapacity = roomCapacity;
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public LocalDate getDateIn() {
        return dateIn;
    }

    public void setDateIn(LocalDate dateIn) {
        this.dateIn = dateIn;
    }

    public LocalDate getDateOut() {
        return dateOut;
    }

    public void setDateOut(LocalDate dateOut) {
        this.dateOut = dateOut;
    }

    public Integer getLocation() {
        return location;
    }

    public void setLocation(Integer location) {
        this.location = location;
    }

    public Integer getBlock() {
        return block;
    }

    public void setBlock(Integer block) {
        this.block = block;
    }

    public Integer getRoom() {
        return room;
    }

    public void setRoom(Integer room) {
        this.room = room;
    }

    public Integer getRoomGender() {
        return roomGender;
    }

    public void setRoomGender(Integer roomGender) {
        this.roomGender = roomGender;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Integer getRoomCapacity() {
        return roomCapacity;
    }

    public void setRoomCapacity(Integer roomCapacity) {
        this.roomCapacity = roomCapacity;
    }
}
