package kg.kumtor.camp.dto.manual;


import com.fasterxml.jackson.annotation.JsonProperty;

public class ManualLocationDto {
    private int empCode;
    private int locationId;

    @JsonProperty("isUpdateAutoBooking")
    private boolean isUpdateAutoBooking;

    public ManualLocationDto() {
    }

    public int getEmpCode() {
        return empCode;
    }

    public void setEmpCode(int empCode) {
        this.empCode = empCode;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public boolean isUpdateAutoBooking() {
        return isUpdateAutoBooking;
    }

    public void setUpdateAutoBooking(boolean updateAutoBooking) {
        this.isUpdateAutoBooking = updateAutoBooking;
    }
}
