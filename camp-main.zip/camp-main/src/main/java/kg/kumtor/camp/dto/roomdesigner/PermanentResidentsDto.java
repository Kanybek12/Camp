package kg.kumtor.camp.dto.roomdesigner;

import java.util.Objects;

public class PermanentResidentsDto {
    private String empCode;
    private String fullName;
    private String room;
    private String jobTitle;
    private String department;

    public PermanentResidentsDto(){}

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PermanentResidentsDto that = (PermanentResidentsDto) o;
        return Objects.equals(empCode, that.empCode) && Objects.equals(fullName, that.fullName) && Objects.equals(room, that.room) && Objects.equals(jobTitle, that.jobTitle) && Objects.equals(department, that.department);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empCode, fullName, room, jobTitle, department);
    }

    @Override
    public String toString() {
        return "PermanentResidentsDto{" +
                "empCode='" + empCode + '\'' +
                ", fullName='" + fullName + '\'' +
                ", room='" + room + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                ", department='" + department + '\'' +
                '}';
    }
}
