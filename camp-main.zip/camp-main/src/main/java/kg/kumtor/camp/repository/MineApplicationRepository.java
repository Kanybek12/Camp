package kg.kumtor.camp.repository;

import kg.kumtor.camp.entity.TransferApplication;
import org.hibernate.type.descriptor.sql.LongVarcharTypeDescriptor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MineApplicationRepository extends JpaRepository<TransferApplication, LongVarcharTypeDescriptor> {
}
