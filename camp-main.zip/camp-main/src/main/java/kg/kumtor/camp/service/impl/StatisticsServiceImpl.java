package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.statistics.*;
import kg.kumtor.camp.dto.statistics.room.FullRoomStatsDTO;
import kg.kumtor.camp.dto.statistics.room.RoomGenderDTO;
import kg.kumtor.camp.dto.statistics.room.RoomOccupationDTO;
import kg.kumtor.camp.dto.statistics.room.RoomSqlDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.StatisticsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class StatisticsServiceImpl implements StatisticsService {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public BedStatsDTO getBedStats() throws ApiException {
        String query = "WITH cte AS (\n"
                + "   SELECT g.room_gender,\n"
                + "     DIV((CASE\n"
                + "            WHEN g.room_gender = 'Мужской'\n"
                + "            THEN (SELECT COUNT(*)\n"
                + "                  FROM camp.vw_rep_camp_room_guide\n"
                + "                  WHERE room_gender = 'Мужской')\n"
                + "                  WHEN g.room_gender = 'Женский'\n"
                + "            THEN (SELECT COUNT(*)\n"
                + "                  FROM camp.vw_rep_camp_room_guide\n"
                + "                  WHERE room_gender = 'Женский')\n"
                + "          END), 2) number_of_seats_g,\n"
                + "     SUM(CASE\n"
                + "           WHEN b.check_in < CURRENT_DATE AND (b.check_out IS NULL OR b.check_out >= CURRENT_DATE) THEN 1\n"
                + "           ELSE 0\n"
                + "         END) AS cnt_before,\n"
                + "     SUM(CASE\n"
                + "           WHEN b.check_in = CURRENT_DATE THEN 1\n"
                + "           ELSE 0\n"
                + "         END) AS cnt_check_in,\n"
                + "     SUM(CASE\n"
                + "           WHEN b.check_out = CURRENT_DATE THEN 1\n"
                + "           ELSE 0\n"
                + "         END) AS cnt_check_out\n"
                + "   FROM camp.booking b\n"
                + "   JOIN camp.vw_rep_camp_room_guide g ON g.id = b.bed_id\n"
                + "   WHERE (b.check_in < CURRENT_DATE AND (b.check_out IS NULL OR b.check_out >= CURRENT_DATE))\n"
                + "         OR (b.check_in = CURRENT_DATE)\n"
                + "         OR (b.check_out = CURRENT_DATE)\n"
                + "   GROUP BY g.room_gender)\n"
                + "SELECT SUM(cte.number_of_seats_g) AS sum_number_of_seats_available,\n"
                + "  SUM(CASE\n"
                + "        WHEN cte.room_gender = 'Мужской' THEN cte.number_of_seats_g else 0\n"
                + "      END) AS number_of_seats_g_m,\n"
                + "  SUM(CASE\n"
                + "        WHEN cte.room_gender = 'Женский' THEN cte.number_of_seats_g else 0\n"
                + "      END) AS number_of_seats_g_w,\n"
                + "  SUM(cte.cnt_before::INTEGER + cte.cnt_check_in::INTEGER - cte.cnt_check_out::INTEGER) AS sum_occupied_beds,\n"
                + "  SUM(CASE\n"
                + "        WHEN cte.room_gender = 'Мужской' THEN cte.cnt_before::INTEGER + cte.cnt_check_in::INTEGER - cte.cnt_check_out::INTEGER else 0\n"
                + "      END) AS cnt_occupied_beds_m,\n"
                + "  SUM(CASE\n"
                + "        WHEN cte.room_gender = 'Женский' THEN cte.cnt_before::INTEGER + cte.cnt_check_in::INTEGER - cte.cnt_check_out::INTEGER else 0\n"
                + "      END) AS cnt_occupied_beds_w,\n"
                + "  SUM(cte.number_of_seats_g - (cte.cnt_before::INTEGER + cte.cnt_check_in::INTEGER - cte.cnt_check_out::INTEGER)) AS sum_available_beds,\n"
                + "  SUM(CASE\n"
                + "        WHEN cte.room_gender = 'Мужской' THEN (cte.number_of_seats_g - (cte.cnt_before::INTEGER + cte.cnt_check_in::INTEGER - cte.cnt_check_out::INTEGER)) else 0\n"
                + "      END) AS cnt_available_beds_m,\n"
                + "  SUM(CASE\n"
                + "        WHEN cte.room_gender = 'Женский' THEN (cte.number_of_seats_g - (cte.cnt_before::INTEGER + cte.cnt_check_in::INTEGER - cte.cnt_check_out::INTEGER)) else 0\n"
                + "      END) AS cnt_available_beds_w\n"
                + "FROM cte";

        try {
            BedStatsDTO bedStats = jdbcTemplate.queryForObject(query,
                    (rs, rowNum) -> new BedStatsDTO(
                            rs.getInt("sum_available_beds"),
                            rs.getInt("sum_occupied_beds"),
                            new GenderDTO(rs.getInt("cnt_available_beds_m"),
                                          rs.getInt("cnt_available_beds_w")),
                            new GenderDTO(rs.getInt("cnt_occupied_beds_m"),
                                    rs.getInt("cnt_occupied_beds_w"))
                    )
            );

            log.info("Getting number of available beds by gender:");
            log.info("Male: {}, Female: {}",
                    bedStats.getAvailableBeds().getMale(),
                    bedStats.getAvailableBeds().getFemale());

            log.info("Getting number of occupied beds by gender:");
            log.info("Male: {}, Female: {}",
                    bedStats.getOccupiedBeds().getMale(),
                    bedStats.getOccupiedBeds().getFemale());

            log.info("Getting number of total available and occupied beds:");
            log.info("Available: {}, Occupied: {}",
                    bedStats.getTotalAvailableBeds(),
                    bedStats.getTotalOccupiedBeds());

            return bedStats;

        } catch (Exception ex) {
            log.error("Error in receiving number of total available and occupied beds by gender: {}", ex.getMessage());
            throw new ApiException(BED_STATISTICS_ERROR.getCode(), BED_STATISTICS_ERROR.getMessage());
        }
    }

    @Override
    public FullRoomStatsDTO getRoomStats(String date, String camp, String block) throws ApiException {
        String partlyBookedTotalSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id IN (1, 2) AND " +
                "  book.date_in <= CAST(? AS DATE) AND book.date_out >= CAST(? AS DATE) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) < (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String fullyBookedTotalSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id IN (1, 2) " +
                "AND book.date_in <= CAST(? AS DATE) AND book.date_out >= CAST(? AS DATE) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) >= (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String partlyBookedMaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id IN (1, 2) " +
                "  AND room_gender_id = 1 " +
                "  AND book.date_in <= CAST(? AS DATE) AND book.date_out >= CAST(? AS DATE) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) < (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String fullyBookedMaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id IN (1, 2) " +
                "  AND room_gender_id = 1 " +
                "  AND book.date_in <= CAST(? AS DATE) AND book.date_out >= CAST(? AS DATE) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) >= (select count(*) " +
                "                    from camp.bed bed_inner " +
                "                    where bed_inner.room_id = room_id " +
                "                      and bed_inner.status = 'A')";

        String partlyBookedFemaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id IN (1, 2) " +
                "  AND room_gender_id = 2 " +
                "  AND book.date_in <= CAST(? AS DATE) AND book.date_out >= CAST(? AS DATE) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) < (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String fullyBookedFemaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id IN (1, 2) " +
                "  AND room_gender_id = 2 " +
                "  AND book.date_in <= CAST(? AS DATE) AND book.date_out >= CAST(? AS DATE) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) >= (select count(*) " +
                "                    from camp.bed bed_inner " +
                "                    where bed_inner.room_id = room_id " +
                "                      and bed_inner.status = 'A')";

        String fullyOccupiedTotalSQL = "SELECT room_id, room_capacity, count(1) AS bed_count, check_in, check_out " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id = 4 " +
                "  AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity, check_in, check_out " +
                "HAVING count(1) >= (select count(*) " +
                "                    from camp.bed bed_inner " +
                "                    where bed_inner.room_id = room_id " +
                "                      and bed_inner.status = 'A')";

        String partlyOccupiedTotalSQL = "SELECT room_id, room_capacity, count(1) AS bed_count, check_in, check_out " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id = 4 " +
                "  AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity, check_in, check_out " +
                "HAVING count(1) < (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String partlyOccupiedMaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id = 4 " +
                "  AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "  AND room_gender_id = 1 " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) < (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String fullyOccupiedMaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id = 4 " +
                "  AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "  AND room_gender_id = 1 " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) >= (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String partlyOccupiedFemaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id = 4 " +
                "  AND book.check_in <= CAST(? AS DATE) AND book.check_out >= CAST(? AS DATE) " +
                "  AND room_gender_id = 2 " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) < (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String fullyOccupiedFemaleSQL = "SELECT room_id, room_capacity, count(1) AS bed_count " +
                "FROM camp.room " +
                "  LEFT JOIN camp.bed on room.id = bed.room_id " +
                "  LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "  LEFT JOIN camp.block b on room.block_id = b.id " +
                "WHERE book.status_id = 4 " +
                "  AND book.check_in <= CAST(? AS DATE) AND book.check_out >= CAST(? AS DATE) " +
                "  AND room_gender_id = 2 " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND camp.bed.status = 'A' " +
                "GROUP BY room_id, room_gender_id, room_capacity " +
                "HAVING count(1) >= (select count(*) " +
                "                   from camp.bed bed_inner " +
                "                   where bed_inner.room_id = room_id " +
                "                     and bed_inner.status = 'A')";

        String fullyAvailableTotalSQL = "SELECT count(1) FROM camp.room " +
                "    LEFT JOIN camp.block block on room.block_id = block.id " +
                "         WHERE room.id NOT IN (SELECT room_id FROM camp.room " +
                "             LEFT JOIN camp.bed on room.id = bed.room_id " +
                "             LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "             LEFT JOIN camp.block b on room.block_id = b.id " +
                "    WHERE book.status_id = 4 " +
                "      AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "      AND camp.bed.status = 'A' " +
                "    GROUP BY room_id, room_gender_id, room_capacity " +
                "    HAVING count(1) >= (select count(*) " +
                "                        from camp.bed bed_inner " +
                "                        where bed_inner.room_id = room_id " +
                "                          and bed_inner.status = 'A')) " +
                "       AND CAST(block_id AS varchar) LIKE ? " +
                "       AND CAST(camp_id AS varchar) LIKE ?";

        String fullyAvailableMaleSQL = "SELECT count(1) FROM camp.room " +
                "  LEFT JOIN camp.block block on room.block_id = block.id " +
                "WHERE room.id NOT IN (SELECT room_id FROM camp.room " +
                "                               LEFT JOIN camp.bed on room.id = bed.room_id " +
                "                               LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "                               LEFT JOIN camp.block b on room.block_id = b.id " +
                "                      WHERE book.status_id = 4 " +
                "                          AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "                          AND camp.bed.status = 'A' " +
                "                      GROUP BY room_id, room_gender_id, room_capacity " +
                "                      HAVING count(1) >= (select count(*) " +
                "                                          from camp.bed bed_inner " +
                "                                          where bed_inner.room_id = room_id " +
                "                                            and bed_inner.status = 'A')) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND room_gender_id = 1";

        String fullyAvailableFemaleSQL = "SELECT count(1) FROM camp.room " +
                "  LEFT JOIN camp.block block on room.block_id = block.id " +
                "WHERE room.id NOT IN (SELECT room_id FROM camp.room " +
                "                               LEFT JOIN camp.bed on room.id = bed.room_id " +
                "                               LEFT JOIN camp.booking AS book on bed.id = book.bed_id " +
                "                               LEFT JOIN camp.block b on room.block_id = b.id " +
                "                      WHERE book.status_id = 4 " +
                "                          AND book.check_in <= CAST(? AS DATE) AND (book.check_out IS NULL OR book.check_out >= CAST(? AS DATE)) " +
                "                          AND camp.bed.status = 'A' " +
                "                      GROUP BY room_id, room_gender_id, room_capacity " +
                "                      HAVING count(1) >= (select count(*) " +
                "                                          from camp.bed bed_inner " +
                "                                          where bed_inner.room_id = room_id " +
                "                                            and bed_inner.status = 'A')) " +
                "  AND CAST(block_id AS varchar) LIKE ? " +
                "  AND CAST(camp_id AS varchar) LIKE ? " +
                "  AND room_gender_id = 2";

        // BOOKING
        try {
            log.info("Getting number of booked rooms by: fully, partly, gender...");
            List<RoomSqlDTO> fullyBookedTotal = jdbcTemplate.query(fullyBookedTotalSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper(RoomSqlDTO.class));
            log.info("FullyBookedTotal: {}", fullyBookedTotal);
            List<RoomSqlDTO> partlyBookedTotal = jdbcTemplate.query(partlyBookedTotalSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper(RoomSqlDTO.class));
            log.info("PartlyBookedTotal: {}", partlyBookedTotal);
            List<RoomSqlDTO> fullyBookedMale = jdbcTemplate.query(fullyBookedMaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper(RoomSqlDTO.class));
            log.info("FullyBookedMale: {}", fullyBookedMale);
            List<RoomSqlDTO> partlyBookedMale = jdbcTemplate.query(partlyBookedMaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper(RoomSqlDTO.class));
            log.info("PartlyBookedMale: {}", partlyBookedMale);
            List<RoomSqlDTO> fullyBookedFemale = jdbcTemplate.query(fullyBookedFemaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper(RoomSqlDTO.class));
            log.info("FullyBookedFemale: {}", fullyBookedFemale);
            List<RoomSqlDTO> partlyBookedFemale = jdbcTemplate.query(partlyBookedFemaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper(RoomSqlDTO.class));
            log.info("PartlyBookedFemale: {}", partlyBookedFemale);

            log.info("Number of booked rooms by: fully, partly, gender received");

            // OCCUPIED
            log.info("Getting number of occupied rooms by: fully, partly, gender...");
            List<RoomSqlDTO> fullyOccupiedTotal = jdbcTemplate.query(fullyOccupiedTotalSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper<>(RoomSqlDTO.class));
            log.info("FullyOccupiedTotal: {}", fullyOccupiedTotal);
            List<RoomSqlDTO> partlyOccupiedTotal = jdbcTemplate.query(partlyOccupiedTotalSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper<>(RoomSqlDTO.class));
            log.info("PartlyOccupiedTotal: {}", partlyOccupiedTotal);
            List<RoomSqlDTO> fullyOccupiedMale = jdbcTemplate.query(fullyOccupiedMaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper<>(RoomSqlDTO.class));
            log.info("FullyOccupiedMale: {}", fullyOccupiedMale);
            List<RoomSqlDTO> partlyOccupiedMale = jdbcTemplate.query(partlyOccupiedMaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper<>(RoomSqlDTO.class));
            log.info("PartlyOccupiedMale: {}", partlyOccupiedMale);
            List<RoomSqlDTO> fullyOccupiedFemale = jdbcTemplate.query(fullyOccupiedFemaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper<>(RoomSqlDTO.class));
            log.info("FullyOccupiedFemale: {}", fullyOccupiedFemale);
            List<RoomSqlDTO> partlyOccupiedFemale = jdbcTemplate.query(partlyOccupiedFemaleSQL, new Object[]{date, date, block,
                            camp},
                    new BeanPropertyRowMapper<>(RoomSqlDTO.class));
            log.info("PartlyOccupiedFemale: {}", partlyOccupiedFemale);

            log.info("Number of occupied rooms by: fully, partly, gender received");

            //AVAILABLE (COUNTS)
            log.info("Getting number of available rooms by: fully, gender...");
            int fullyAvailableTotal = jdbcTemplate.queryForObject(fullyAvailableTotalSQL, new Object[]{date, date, block,
                    camp}, Integer.class);
            log.info("FullyAvailableTotal (count): {}", fullyAvailableTotal);
            int fullyAvailableMale = jdbcTemplate.queryForObject(fullyAvailableMaleSQL, new Object[]{date, date, block,
                    camp}, Integer.class);
            log.info("FullyAvailableMale (count): {}", fullyAvailableMale);
            int fullyAvailableFemale = jdbcTemplate.queryForObject(fullyAvailableFemaleSQL, new Object[]{date, date, block,
                    camp}, Integer.class);
            log.info("FullyAvailableFemale (count): {}", fullyAvailableFemale);

            log.info("Number of available rooms by: fully, gender received");

            RoomGenderDTO availableFully = RoomGenderDTO.builder()
                    .maleRooms(fullyAvailableMale)
                    .femaleRooms(fullyAvailableFemale)
                    .total(fullyAvailableTotal)
                    .build();

            RoomGenderDTO availablePartly = RoomGenderDTO.builder()
                    .maleRooms(partlyOccupiedMale.size())
                    .femaleRooms(partlyOccupiedFemale.size())
                    .total(partlyOccupiedTotal.size())
                    .build();

            RoomGenderDTO occupiedFully = RoomGenderDTO.builder()
                    .maleRooms(fullyOccupiedMale.size())
                    .femaleRooms(fullyOccupiedFemale.size())
                    .total(fullyOccupiedTotal.size())
                    .build();

            RoomGenderDTO occupiedPartly = RoomGenderDTO.builder()
                    .maleRooms(partlyOccupiedMale.size())
                    .femaleRooms(partlyOccupiedFemale.size())
                    .total(partlyOccupiedTotal.size())
                    .build();

            RoomGenderDTO bookedFully = RoomGenderDTO.builder()
                    .maleRooms(fullyBookedMale.size())
                    .femaleRooms(fullyBookedFemale.size())
                    .total(fullyBookedTotal.size())
                    .build();

            RoomGenderDTO bookedPartly = RoomGenderDTO.builder()
                    .maleRooms(partlyBookedMale.size())
                    .femaleRooms(partlyBookedFemale.size())
                    .total(partlyBookedTotal.size())
                    .build();

            RoomOccupationDTO availableOccupation = RoomOccupationDTO.builder()
                    .fully(availableFully)
                    .partly(availablePartly)
                    .build();
            RoomOccupationDTO occupiedOccupation = RoomOccupationDTO.builder()
                    .fully(occupiedFully)
                    .partly(occupiedPartly)
                    .build();
            RoomOccupationDTO bookedOccupation = RoomOccupationDTO.builder()
                    .fully(bookedFully)
                    .partly(bookedPartly)
                    .build();

            FullRoomStatsDTO roomStatistics = FullRoomStatsDTO.builder()
                    .available(availableOccupation)
                    .occupied(occupiedOccupation)
                    .booked(bookedOccupation)
                    .build();

            log.info("Full room statistics: {}", roomStatistics);

            return roomStatistics;
        } catch (Exception ex) {
            log.error("Error in receiving room statistics: {}", ex.getMessage());
            throw new ApiException(ROOM_STATISTICS_ERROR.getCode(), ROOM_STATISTICS_ERROR.getMessage());
        }
    }

    @Override
    public FullBookingStatsDTO getBookingStats(LocalDate date) throws ApiException {
        if (date == null){
            date = LocalDate.now();
        }
        String contractPendingApprovalQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 1 AND date_in <= ? AND employee_type_id = 3";
        String contractApprovedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id IN (2,4) AND date_in <= ? AND employee_type_id = 3";
        String contractRejectedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 3 AND book.date_changed::date = ? AND employee_type_id = 3";

        String staffPendingApproveQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 1 AND date_in <= ? AND employee_type_id = 1";
        String staffApprovedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id IN (2,4) AND date_in <= ? AND employee_type_id = 1";
        String staffRejectedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 3 AND book.date_changed::date = ? AND employee_type_id = 1";

        String employeePendingApproveQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 1 AND date_in <= ? AND employee_type_id = 2";
        String employeeApprovedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id IN (2,4) AND date_in <= ? AND employee_type_id = 2";
        String employeeRejectedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 3 AND book.date_changed::date = ? AND employee_type_id = 2";

        String guestPendingApproveQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 1 AND date_in <= ? AND employee_type_id = 4";
        String guestApprovedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id IN (2,4) AND date_in <= ? AND employee_type_id = 4";
        String guestRejectedQuery = "SELECT count(1) FROM camp.booking AS book " +
                "LEFT JOIN camp.employee AS emp ON book.emp_code = emp.emp_code " +
                "WHERE status_id = 3 AND book.date_changed::date = ? AND employee_type_id = 4";

        try {
            log.info("Getting statistics on bookings with date_changed = {} ...", date);
            BookingStatsDTO pendingApproval = BookingStatsDTO.builder()
                    .contractors(jdbcTemplate.queryForObject(contractPendingApprovalQuery, Integer.class, new Object[]{date}))
                    .guests(jdbcTemplate.queryForObject(guestPendingApproveQuery, Integer.class, new Object[]{date}))
                    .staffMembers(jdbcTemplate.queryForObject(staffPendingApproveQuery, Integer.class, new Object[]{date}))
                    .employees(jdbcTemplate.queryForObject(employeePendingApproveQuery, Integer.class, new Object[]{date}))
                    .build();
            log.info("Bookings pending approval: {}", pendingApproval);

            BookingStatsDTO approved = BookingStatsDTO.builder()
                    .contractors(jdbcTemplate.queryForObject(contractApprovedQuery, Integer.class, new Object[]{date}))
                    .guests(jdbcTemplate.queryForObject(guestApprovedQuery, Integer.class, new Object[]{date}))
                    .staffMembers(jdbcTemplate.queryForObject(staffApprovedQuery, Integer.class, new Object[]{date}))
                    .employees(jdbcTemplate.queryForObject(employeeApprovedQuery, Integer.class, new Object[]{date}))
                    .build();
            log.info("Approved bookings: {}", approved);

            BookingStatsDTO rejected = BookingStatsDTO.builder()
                    .contractors(jdbcTemplate.queryForObject(contractRejectedQuery, Integer.class, new Object[]{date}))
                    .guests(jdbcTemplate.queryForObject(guestRejectedQuery, Integer.class, new Object[]{date}))
                    .staffMembers(jdbcTemplate.queryForObject(staffRejectedQuery, Integer.class, new Object[]{date}))
                    .employees(jdbcTemplate.queryForObject(employeeRejectedQuery, Integer.class, new Object[]{date}))
                    .build();
            log.info("Rejected bookings: {}", rejected);

            FullBookingStatsDTO fullBooking = FullBookingStatsDTO.builder()
                    //.pendingApproval(pendingApproval)
                    .approved(approved)
                    .rejected(rejected)
                    .build();
            log.info("Statistics on bookings with date_changed = {} received", date);
            return fullBooking;
        } catch (Exception ex) {
            log.error("Error in receiving booking statistics: {}", ex.getMessage());
            throw new ApiException(BOOKING_STATISTICS_ERROR.getCode(), BOOKING_STATISTICS_ERROR.getMessage());
        }
    }
}