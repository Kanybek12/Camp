package kg.kumtor.camp.service;

import org.springframework.data.domain.Pageable;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;

public interface ReportService {

    void getApprovedBusXls(LocalDate date, Integer empCode,
                           Integer applicationType, Integer visitorType, HttpServletResponse response) throws Exception;

    void getApprovedVahtaXls(LocalDate date, Integer empCode,
                             Integer applicationType, Integer visitorType, HttpServletResponse response) throws Exception;
}
