package kg.kumtor.camp.dto.transfer.vahta;

public class VahtaApplicationStatisticsDto {
    private VahtaTypeDto mineSiteEmployees;
    private VahtaTypeDto kumtorEmployees;
    private VahtaTypeDto contractors;

    public VahtaApplicationStatisticsDto() {
    }

    public VahtaApplicationStatisticsDto(VahtaTypeDto mineSiteEmployees, VahtaTypeDto kumtorEmployees, VahtaTypeDto contractors) {
        this.mineSiteEmployees = mineSiteEmployees;
        this.kumtorEmployees = kumtorEmployees;
        this.contractors = contractors;
    }

    public VahtaTypeDto getMineSiteEmployees() {
        return mineSiteEmployees;
    }

    public void setMineSiteEmployees(VahtaTypeDto mineSiteEmployees) {
        this.mineSiteEmployees = mineSiteEmployees;
    }

    public VahtaTypeDto getKumtorEmployees() {
        return kumtorEmployees;
    }

    public void setKumtorEmployees(VahtaTypeDto kumtorEmployees) {
        this.kumtorEmployees = kumtorEmployees;
    }

    public VahtaTypeDto getContractors() {
        return contractors;
    }

    public void setContractors(VahtaTypeDto contractors) {
        this.contractors = contractors;
    }
}
