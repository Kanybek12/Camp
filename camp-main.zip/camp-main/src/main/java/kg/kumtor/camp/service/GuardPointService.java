package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.guardpoint.GuardPointDTO;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;

public interface GuardPointService {

    PageableResponseDTO getGuardPointList(Pageable pageable, String enterDate, String exitDate,
                                          String checkInDate, String checkOutDate, String empCode) throws ApiException;
}
