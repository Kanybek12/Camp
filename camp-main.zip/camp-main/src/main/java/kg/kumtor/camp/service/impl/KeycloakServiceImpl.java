package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.auth.KeycloakUserDto;
import kg.kumtor.camp.dto.auth.RegisterDto;
import kg.kumtor.camp.entity.Employee;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.security.Credentials;
import kg.kumtor.camp.security.KeyCloakConfig;
import kg.kumtor.camp.service.AuthContractService;
import kg.kumtor.camp.service.KeycloakService;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RoleMappingResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class KeycloakServiceImpl implements KeycloakService {

    private final AuthContractService authContractService;
    private final EmployeeRepository employeeRepository;
    private final PasswordEncoder passwordEncoder;

    public KeycloakServiceImpl(@Lazy AuthContractService authContractService, EmployeeRepository employeeRepository, PasswordEncoder passwordEncoder) {
        this.authContractService = authContractService;
        this.employeeRepository = employeeRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void addUser(KeycloakUserDto userDto) {
        UsersResource usersResource = KeyCloakConfig.getInstance().realm(KeyCloakConfig.realm).users();

        CredentialRepresentation credential = Credentials.createPasswordCredentials(userDto.getPassword());

        UserRepresentation user = new UserRepresentation();

        user.setUsername(userDto.getUsername());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setEmail(userDto.getEmail());
        user.setCredentials(Collections.singletonList(credential));
        user.setEnabled(true);
        user.setEmailVerified(true);

        log.info("Adding user with username: {} to keycloak", userDto.getUsername());
        usersResource.create(user);
    }

    @Override
    public List<UserRepresentation> getUser(String userName) {
        UsersResource usersResource = KeyCloakConfig.getInstance().realm(KeyCloakConfig.realm).users();
        List<UserRepresentation> user = usersResource.search(userName, true);
        return user;
    }

    @Override
    public List<String> getAllRoles() {

        Keycloak keycloak = KeyCloakConfig.getInstance();

//        System.out.println(KeyCloakConfig.getInstance().realm("Camp").clients().findByClientId("camp-project")
//                .get(0).getClientId());

        ClientRepresentation clientRep = keycloak
                .realm("Camp")
                .clients()
                .findByClientId("camp-project")
                .get(0);

        System.out.println(keycloak.realm("Camp").clients());

        List<String> availableRoles = keycloak
                .realm("Camp")
                .clients()
                .get(clientRep.getId())
                .roles()
                .list()
                .stream()
                .map(RoleRepresentation::getName)
                .collect(Collectors.toList());
        return availableRoles;
    }

    @Override
    public void addRealmRoleToUser(String userName, String role_name) {

        Keycloak keycloak = KeyCloakConfig.getInstance();

        String clientId = keycloak
                .realm("Camp")
                .clients()
                .findByClientId("camp-project")
                .get(0)
                .getId();

        String userId = keycloak
                .realm("Camp")
                .users()
                .search(userName)
                .get(0)
                .getId();

        // Получить roleMappingResource указанного пользователя
        RoleMappingResource roleMappingResource = keycloak
                .realm("Camp")
                .users()
                .get(userId)
                .roles();


        // Назначаем роли Realm пользователям
        List<RoleRepresentation> realmRolesToAdd = new ArrayList<>();
        System.out.println(keycloak.realm("Camp").roles().get(role_name).getRoleUserMembers());
        RoleRepresentation realmRole = keycloak
                .realm("Camp")
                .roles()
                .get(role_name)
                .toRepresentation();
        System.out.println(realmRole);
        realmRolesToAdd.add(realmRole);
        roleMappingResource.realmLevel().add(realmRolesToAdd);
        log.info("Assigned a realm role {} to user: {}", role_name, userName);

        // Назначаем роль клиента пользователю
        List<RoleRepresentation> clientRolesToAdd = new ArrayList<RoleRepresentation>();
        RoleRepresentation clientRole = keycloak
                .realm("Camp")
                .clients()
                .get(clientId)
                .roles()
                .get(role_name).toRepresentation();
        clientRolesToAdd.add(clientRole);
        roleMappingResource.clientLevel(clientId).add(clientRolesToAdd);
        log.info("Assigned a client role {} to user: {}", role_name, userName);

        // Назначаем роль реалма пользователю
//        roleMappingResource.realmLevel().add(clientRolesToAdd);
    }
}
