package kg.kumtor.camp.dto.transfer;

import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferCheckInDto {
    private Integer transferId;
    private String transferDate;
    private Integer locationId;
}
