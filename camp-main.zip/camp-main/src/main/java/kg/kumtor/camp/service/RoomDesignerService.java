package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.roomdesigner.*;
import kg.kumtor.camp.exception.ApiException;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface RoomDesignerService {
    List<RoomDesignerDto> getRoomDesigner(LocalDate dateIn, Integer locationId, String blockId, String roomId,
                                          Integer roomCapacity, Integer status,Integer size, Integer page,Integer gender, Integer category, String empCode);
    Map<String, Object> getRoomDetail(Integer id);

    public ResponseDTO addVisitor(int empCode, VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException;

    public ResponseDTO deleteVisitor(VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException;

    Map<String, Object> editRoom(Long id, RoomEditRequestBody roomDetailDto);

    PageableResponseDTO getPermanentResidents(Integer empCode, Integer locationId, String blockId, String roomId, Integer gender,Boolean isExistPermanent, Pageable pageable) throws ApiException;
}
