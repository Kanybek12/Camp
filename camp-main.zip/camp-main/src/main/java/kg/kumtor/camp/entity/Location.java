package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Location {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    private String title;

    @Column(name = "title_ru" ,nullable = false)
    private String titleRu;

    @Column(name = "is_site_location", nullable = false)
    private short isSiteLocation;

    @Column(name = "status_code", length = 10, nullable = false)
    private String statusCode;

    @Column(name = "approver_type_id")
    private Integer approverTypeId;

    public Location(String changedBy, LocalDateTime dateChanged, String title, String titleRu, short isSiteLocation, String statusCode, int approverTypeId) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.title = title;
        this.titleRu = titleRu;
        this.isSiteLocation = isSiteLocation;
        this.statusCode = statusCode;
        this.approverTypeId = approverTypeId;
    }
}
