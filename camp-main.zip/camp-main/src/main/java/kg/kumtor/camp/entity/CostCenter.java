package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "cost_center")
public class CostCenter implements Serializable {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "code", nullable = false, unique = true)
    private String code;

    private String name;

    @Column(name = "name_ru")
    private String nameRu;

    @Column(name = "div_code")
    private String divCode;

    @Column(name = "department_code")
    private String departmentCode;

    @Column(nullable = false)
    private String status;

    @Override
    public String toString() {
        return "CostCenter{" +
                "changedBy='" + changedBy + '\'' +
                ", dateChanged=" + dateChanged +
                ", id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", nameRu='" + nameRu + '\'' +
                ", divCode='" + divCode + '\'' +
                ", departmentCode='" + departmentCode + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
