package kg.kumtor.camp.dto.reference.crud;

public class RoomCRUDDto {
    private Long id;
    private String roomNum;
    private String changedBy;
    private int blockId;
    private String blockName;
    private int roomCategoryId;
    private String roomCategoryName;
    private int roomGenderId;
    private String roomGenderName;
    private int roomCapacityId;
    private String roomCapacityName;
    private String statusCode;

    public RoomCRUDDto() {
    }

    public RoomCRUDDto(Long id, String roomNum, String changedBy, int blockId, String blockName, int roomCategoryId, String roomCategoryName, int roomGenderId, String roomGenderName, int roomCapacityId, String roomCapacityName, String statusCode) {
        this.id = id;
        this.roomNum = roomNum;
        this.changedBy = changedBy;
        this.blockId = blockId;
        this.blockName = blockName;
        this.roomCategoryId = roomCategoryId;
        this.roomCategoryName = roomCategoryName;
        this.roomGenderId = roomGenderId;
        this.roomGenderName = roomGenderName;
        this.roomCapacityId = roomCapacityId;
        this.roomCapacityName = roomCapacityName;
        this.statusCode = statusCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRoomNum() {
        return roomNum;
    }

    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public int getBlockId() {
        return blockId;
    }

    public void setBlockId(int blockId) {
        this.blockId = blockId;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public int getRoomCategoryId() {
        return roomCategoryId;
    }

    public void setRoomCategoryId(int roomCategoryId) {
        this.roomCategoryId = roomCategoryId;
    }

    public String getRoomCategoryName() {
        return roomCategoryName;
    }

    public void setRoomCategoryName(String roomCategoryName) {
        this.roomCategoryName = roomCategoryName;
    }

    public int getRoomGenderId() {
        return roomGenderId;
    }

    public void setRoomGenderId(int roomGenderId) {
        this.roomGenderId = roomGenderId;
    }

    public String getRoomGenderName() {
        return roomGenderName;
    }

    public void setRoomGenderName(String roomGenderName) {
        this.roomGenderName = roomGenderName;
    }

    public int getRoomCapacityId() {
        return roomCapacityId;
    }

    public void setRoomCapacityId(int roomCapacityId) {
        this.roomCapacityId = roomCapacityId;
    }

    public String getRoomCapacityName() {
        return roomCapacityName;
    }

    public void setRoomCapacityName(String roomCapacityName) {
        this.roomCapacityName = roomCapacityName;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
