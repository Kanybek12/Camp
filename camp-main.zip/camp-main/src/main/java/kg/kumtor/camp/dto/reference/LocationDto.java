package kg.kumtor.camp.dto.reference;

import kg.kumtor.camp.entity.Location;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.Valid;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Valid
@Builder
public class LocationDto {

    public LocationDto(Location location) {
        this.id = location.getId();
        this.title = location.getTitle();
        this.titleRu = location.getTitleRu();
        this.approverTypeId = location.getApproverTypeId();
    }

    @Column(name = "\"Id\"")
    private int id;

    @Column(name = "\"Title\"")
    private String title;

    @Column(name = "\"TitleRu\"")
    private String titleRu;

    @Column(name = "\"ApproverTypeId\"")
    private Integer approverTypeId;
}
