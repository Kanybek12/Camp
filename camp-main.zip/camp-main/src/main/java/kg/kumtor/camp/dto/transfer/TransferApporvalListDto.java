package kg.kumtor.camp.dto.transfer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TransferApporvalListDto {
    private Long transferId;
    private String fullName;
    private Integer empCode;
    private String department;
    private String jobTitle;
    private int visitorTypeId;
    private String visitorName;
    private boolean campLiveNeed;
    private int statusId;
    private String statusName;
    private String transferTypes;
    private Date dateFrom;
    private Date dateTo;
    private Date dateCreated;
    private Integer receivingPerson;
    private String receivingPersonName;
    private String transfer;
    private Integer approverEmpCode;
    private Integer approverType;
    private String approverName;
    private String creator;
}
