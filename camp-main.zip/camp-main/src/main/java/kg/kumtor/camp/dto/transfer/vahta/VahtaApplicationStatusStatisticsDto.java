package kg.kumtor.camp.dto.transfer.vahta;

public class VahtaApplicationStatusStatisticsDto {
    private VahtaTypeDto inProgress;
    private VahtaTypeDto approved;
    private VahtaTypeDto rejected;

    public VahtaApplicationStatusStatisticsDto() {
    }

    public VahtaApplicationStatusStatisticsDto(VahtaTypeDto inProgress, VahtaTypeDto approved, VahtaTypeDto rejected) {
        this.inProgress = inProgress;
        this.approved = approved;
        this.rejected = rejected;
    }

    public VahtaTypeDto getInProgress() {
        return inProgress;
    }

    public void setInProgress(VahtaTypeDto inProgress) {
        this.inProgress = inProgress;
    }

    public VahtaTypeDto getApproved() {
        return approved;
    }

    public void setApproved(VahtaTypeDto approved) {
        this.approved = approved;
    }

    public VahtaTypeDto getRejected() {
        return rejected;
    }

    public void setRejected(VahtaTypeDto rejected) {
        this.rejected = rejected;
    }
}
