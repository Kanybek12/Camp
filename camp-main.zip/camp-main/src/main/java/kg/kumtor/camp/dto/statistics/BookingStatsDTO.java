package kg.kumtor.camp.dto.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BookingStatsDTO {

    private int staffMembers;
    private int employees;
    private int contractors;
    private int guests;
}
