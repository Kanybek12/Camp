package kg.kumtor.camp.dto.email;

import java.util.Objects;

public class TransferEmpCodeList {

    private Integer code;
    private String email;
    private String who;

    public TransferEmpCodeList() {
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWho() {
        return who;
    }

    public void setWho(String who) {
        this.who = who;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransferEmpCodeList that = (TransferEmpCodeList) o;
        return Objects.equals(code, that.code) && Objects.equals(email, that.email) && Objects.equals(who, that.who);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, email, who);
    }

    @Override
    public String toString() {
        return "TransferEmpCodeList{" +
                "code=" + code +
                ", email='" + email + '\'' +
                ", who='" + who + '\'' +
                '}';
    }
}
