package kg.kumtor.camp.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PageableResponseDTO {
    private int pageNumber;
    private int totalPages;
//    private int pageSize;
    private Object content;
}
