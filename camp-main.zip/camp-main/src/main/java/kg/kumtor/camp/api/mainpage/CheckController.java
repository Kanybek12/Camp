package kg.kumtor.camp.api.mainpage;

import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.BookingCheckService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@Slf4j
@RequestMapping("/statistics")
public class CheckController {

    private final BookingCheckService bookingCheckService;

    public CheckController(BookingCheckService bookingCheckService) {
        this.bookingCheckService = bookingCheckService;
    }

    @RolesAllowed("coordinator")
    @PutMapping("/applications/booking/check-in")
    public ResponseDTO checkIn(@RequestBody Map<String, List<Map<String, Object>>> checkInBookings) throws ApiException {
        return bookingCheckService.checkIn(checkInBookings);
    }

    @RolesAllowed("coordinator")
    @PutMapping("/applications/booking/check-out")
    public ResponseDTO checkOut(@RequestBody Map<String, List<Map<String, Object>>> checkOutBookings) throws ApiException {
        return bookingCheckService.checkOut(checkOutBookings);
    }

    @RolesAllowed("coordinator")
    @PutMapping("/applications/booking/check-in/cancel")
    public ResponseDTO cancelCheckIn(@RequestBody Map<String, List<Long>> cancelCheckIn) throws ApiException {
        return bookingCheckService.cancelCheckIn(cancelCheckIn);
    }
}
