package kg.kumtor.camp.dto.statistics.room;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RoomInfoDTO {
//    private int roomId;
    private int bedNum;
    private int empCode;
    private String name;
    private boolean isFree;
}
