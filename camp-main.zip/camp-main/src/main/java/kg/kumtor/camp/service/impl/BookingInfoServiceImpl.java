package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.BookingDao;
import kg.kumtor.camp.dto.*;
import kg.kumtor.camp.dto.booking.ConflictBooking;
import kg.kumtor.camp.dto.booking.VacationInfo;
import kg.kumtor.camp.dto.reference.*;
import kg.kumtor.camp.dto.statistics.room.RoomCapacityInfoDTO;
import kg.kumtor.camp.dto.statistics.room.RoomInfoDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.BookingStatusRepository;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.repository.LocationRepository;
import kg.kumtor.camp.repository.RoomCategoryRepository;
import kg.kumtor.camp.service.BookingInfoService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;
import static kg.kumtor.camp.exception.ExceptionsEnum.EMPTY_RESULT;

@Service
@Slf4j
public class BookingInfoServiceImpl implements BookingInfoService {

    private final JdbcTemplate jdbcTemplate;

    private final LocationRepository locationRepository;

    private final EmployeeRepository employeeRepository;

    private final BookingStatusRepository bookingStatusRepository;

    private final RoomCategoryRepository roomCategoryRepository;

    private final BookingDao bookingDao;

    Logger logger = LoggerFactory.getLogger(TransferServiceImpl.class);

    public BookingInfoServiceImpl(JdbcTemplate jdbcTemplate, LocationRepository locationRepository, EmployeeRepository employeeRepository, BookingStatusRepository bookingStatusRepository, RoomCategoryRepository roomCategoryRepository, BookingDao bookingDao) {
        this.jdbcTemplate = jdbcTemplate;
        this.locationRepository = locationRepository;
        this.employeeRepository = employeeRepository;
        this.bookingStatusRepository = bookingStatusRepository;
        this.roomCategoryRepository = roomCategoryRepository;
        this.bookingDao = bookingDao;
    }

    @Override
    public List<BlockDto> getBlockByDateAndLocationId(Integer locationId, Integer genderId, Date dateIn, Date dateOut) throws ApiException {
        List<BlockDto> blockDtoList = new ArrayList<>();
        String query = "SELECT  b2.id, b2.\"name\"  \n" +
                "            from camp.bed b \n" +
                "                inner join camp.room r on r.id = b.room_id\n" +
                "                inner join camp.block b2 on b2.id = r.block_id\n" +
                "                inner join camp.camp c on c.id = b2.camp_id\n" +
                "            WHERE b.id not IN (select bed_id FROM camp.booking\n" +
                "                                                   WHERE date_in <= coalesce (?, date_in) \n" +
                "                                                       AND date_out >= coalesce (?, date_out)\n" +
                "                                                       AND status_id  in (2, 4)\n" +
                "                                 )\n" +
                "                  and c.id = coalesce (?, c.id)\n" +
                "                  and b2.\"name\" <> 'Warehouse'\n" +
                "                  and r.room_gender_id = coalesce (?, r.room_gender_id)\n" +
                "                  group by  b2.id, b2.\"name\" \n" +
                "                 order by b2.id asc;";

        Object[] args = new Object[]{dateOut, dateIn, locationId, genderId};
        try {
            List<Map<String, Object>> resBlock = jdbcTemplate.queryForList(query, args);
            System.out.println(resBlock.size());
            if (resBlock.size() == 0) {
                throw new ApiException();
            } else {
                for (Map<String, Object> iterator : resBlock) {
                    BlockDto blockDto = new BlockDto();
                    blockDto.setId(Integer.valueOf(String.valueOf(iterator.get("id"))));
                    blockDto.setName(String.valueOf(iterator.get("name")));
                    blockDtoList.add(blockDto);
                }
            }
        } catch (Exception ex) {
            throw new ApiException(500, "Свободных блоков нет");
        }
        return blockDtoList;
    }

    @Override
    public List<RoomCategoryDto> getRoomCategory() {
        return roomCategoryRepository.findAllCatogery();
    }

    @Override
    public List<RoomDto> getRoomByDateAndBlockAndGender(Integer roomId, Integer blockId, Date dateIn, Date dateOut, Integer genderId, Integer roomCapacity) throws ApiException {
        List<RoomDto> roomDtoList = new ArrayList<>();
        String query = "select r.id as id, "
                + "  r.room_num as room_num, "
                + "  bl.name as block_name "
                + "from camp.room r "
                + "inner join camp.block bl on bl.id = r.block_id "
                + "where r.id not in(SELECT DISTINCT bed.room_id "
                + "                  from camp.bed "
                + "                  left join camp.room r on r.id = bed.room_id "
                + "                  WHERE r.id != coalesce (?,0) "
                + "                    and bed.id IN (SELECT bed_id "
                + "                                   FROM camp.booking "
                + "                                   WHERE date_in <= ? AND date_out >=? "
                + "                                     and status_id in (2,4)) "
                + "                    and bed.status = 'A' "
                + "                  group by bed.room_id, r.room_capacity "
                + "                  having count(bed.id) = r.room_capacity) "
                + "  and (r.room_capacity = coalesce(?, r.room_capacity) "
                + "       or bl.name = 'Warehouse Block') "
                + "  and r.block_id = coalesce(?, r.block_id) "
                + "  and (r.room_gender_id = coalesce(?, r.room_gender_id) "
                + "       or bl.name = 'Warehouse Block') "
                + "order by r.room_num, bl.name";
        Object[] args = new Object[]{roomId, dateOut, dateIn, roomCapacity, blockId, genderId};
        try {
            List<Map<String, Object>> resBlock = jdbcTemplate.queryForList(query, args);
            if (resBlock.size() == 0) {
                throw new ApiException();
            }
            for (Map<String, Object> iterator : resBlock) {
                RoomDto roomDto = new RoomDto();
                roomDto.setId(Integer.valueOf(String.valueOf(iterator.get("id"))));
                roomDto.setName(String.valueOf(iterator.get("room_num")));
                roomDto.setBlockName(String.valueOf(iterator.get("block_name")));
                roomDtoList.add(roomDto);
            }
        } catch (Exception ex) {
            throw new ApiException(NO_FREE_ROOMS_ERROR.getCode(), NO_FREE_ROOMS_ERROR.getMessage());
        }
        return roomDtoList;
    }

    @Override
    public List<LocationDto> getLocation() {
        return locationRepository.find();
    }

    @Override
    public Map<String, Object> getQuantityOfBedInRoom(Integer roomId, Date dateIn, Date dateOut) {
        Map<String, Object> result = new HashMap<>();
        String query = "SELECT rc.capacity as name\n"
                + "FROM camp.room left join camp.room_capacity rc ON rc.capacity = room.room_capacity\n"
                + "WHERE room.id NOT IN(\n"
                + "  SELECT DISTINCT bed.room_id\n"
                + "  FROM camp.bed\n"
                + "  LEFT JOIN camp.room r on r.id = bed.room_id\n"
                + "  WHERE bed.id IN (SELECT bed_id\n"
                + "                   FROM camp.booking\n"
                + "                   WHERE date_in <= ? AND date_out >=? AND status_id in (2, 4))\n"
                + "    AND bed.status = 'A'\n"
                + "  GROUP BY bed.room_id, r.room_capacity\n"
                + "  HAVING COUNT(bed.id) = r.room_capacity)\n"
                + "  AND room.id = ?";
        Object[] args = new Object[]{dateOut, dateIn, roomId};
        try {
            List<Map<String, Object>> response = jdbcTemplate.queryForList(query, args);
            if (response.size() != 0) {
                result.put("name", String.valueOf(response.get(0).get("name")));
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return result;
    }

    @Override
    public List<Integer> getEmpCodes(Integer empType) {
        List<Integer> EmpCodes = new ArrayList<>();
        String query = "SELECT e.emp_code as emp_code FROM camp.employee e where e.status_code='A' AND e.employee_type_id= coalesce(?, e.employee_type_id) GROUP BY e.emp_code;";
        Object[] args = new Object[]{empType};
        try {
            List<Map<String, Object>> response = jdbcTemplate.queryForList(query, args);
            if (response.size() != 0) {
                for (Map<String, Object> iterator : response) {
                    EmpCodes.add(Integer.valueOf(String.valueOf(iterator.get("emp_code"))));
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return EmpCodes;
    }

    @Override
    public List<BedDto> getBed(Integer roomId, Date dateIn, Date dateOut, Integer bedId) throws ApiException {
        List<BedDto> bedDtoList = new ArrayList<>();

        String query = "SELECT DISTINCT bed.id AS id, bed.bed_number_in_room AS room_num, bed.room_id as room_id\n"
                + "FROM camp.bed bed\n"
                + "WHERE bed.room_id = coalesce (?, bed.room_id)\n"
                + "  AND bed.status = 'A'\n"
                + "  AND bed.id NOT IN (SELECT book.bed_id\n"
                + "                     FROM camp.booking book\n"
                + "                     INNER JOIN camp.bed bed ON bed.id = book.bed_id\n"
                + "                     WHERE bed.id != COALESCE(?, 0)\n"
                + "                       AND bed.room_id = COALESCE(?, bed.room_id)\n"
                + "                       AND book.date_in <= ?\n"
                + "                       AND book.date_out >= ?\n"
                + "                       AND book.status_id in (1, 2, 4)\n"
                + "                     GROUP BY book.bed_id)\n"
                + " ORDER BY bed.room_id, bed.id";

        Object[] args = new Object[]{roomId, bedId, roomId, dateOut, dateIn};
        try {
            List<Map<String, Object>> response = jdbcTemplate.queryForList(query, args);
            if (response.size() == 0) {
                throw new ApiException();
            } else {
                for (Map<String, Object> iterator : response) {
                    BedDto bedDto = new BedDto();
                    bedDto.setId(Integer.valueOf(String.valueOf(iterator.get("id"))));
                    bedDto.setBed_numder(Integer.valueOf(String.valueOf(iterator.get("room_num"))));
                    bedDto.setRoomId(Integer.valueOf(String.valueOf(iterator.get("room_id"))));
                    bedDtoList.add(bedDto);
                }
            }
        } catch (Exception ex) {
            throw new ApiException(500, "Свободных кроватей нет");
        }
        return bedDtoList;
    }

    @Override
    public EmployeeInfoDto getEmployeeInfoByEmpCode(Integer empCode) {
        return employeeRepository.findByEmpCodeForBooking(empCode);
    }

    @Override
    public Map<String, List<RoomInfoDTO>> getRoomsInfo() {
        String roomCapacityQuery = "SELECT id AS room_id, room_capacity\n"
                + "FROM camp.room";
        String roomInfoQuery = "SELECT bed_number_in_room, emp_code, CONCAT(first_name, ' ', last_name) AS name\n"
                + "FROM camp.bed\n"
                + "INNER JOIN camp.room AS r ON r.id = bed.room_id\n"
                + "INNER JOIN camp.booking AS book ON bed.id = book.bed_id\n"
                + "WHERE room_id = ?\n"
                + "  AND bed_number_in_room = ?\n"
                + "  AND date_in <= now()::date\n"
                + "  AND date_out >= now()::date\n"
                + "  AND camp.bed.status = 'A'";

        // [RoomCapacityInfoDTO(roomId=1, roomCapacity=2), RoomCapacityInfoDTO(roomId=2, roomCapacity=12)]
        List<RoomCapacityInfoDTO> roomCapacityList = jdbcTemplate.query(roomCapacityQuery, new BeanPropertyRowMapper<>(RoomCapacityInfoDTO.class));

        Map<String, List<RoomInfoDTO>> roomWithBeds = new HashMap<>();

        for (RoomCapacityInfoDTO roomCapacity : roomCapacityList) {
            List<RoomInfoDTO> rooms = new ArrayList<>();
            for (int i = 1; i <= roomCapacity.getRoomCapacity(); i++) {
                try {
                    RoomInfoDTO roomInfo = jdbcTemplate.queryForObject(roomInfoQuery, new BeanPropertyRowMapper<>(RoomInfoDTO.class), new Object[]{roomCapacity.getRoomId(), i});
                    roomInfo.setBedNum(i);
                    rooms.add(roomInfo);
                } catch (EmptyResultDataAccessException ex) {
                    rooms.add(new RoomInfoDTO(i, 0, null, true));
                }
            }
            roomWithBeds.put("room " + roomCapacity.getRoomId(), rooms);
        }
        return roomWithBeds;
    }

    @Override
    public PageableResponseDTO getBookingApplications(Pageable pageable, String dateIn, String departmentId, String checkIn, String transitStatus, String visitorTypeId, String dateOut, String empCode) throws ApiException {
        String countQuery = "SELECT count(1)\n"
                + "FROM camp.booking AS book\n"
                + "  LEFT JOIN camp.employee AS emp on emp.emp_code = book.emp_code\n"
                + "  LEFT JOIN camp.employee_rm_department AS edep ON book.emp_code = edep.emp_code\n"
                + "  LEFT JOIN camp.department_rm AS deprm ON edep.department_rm_id = deprm.id\n"
                + "  LEFT JOIN camp.job_title AS jt on emp.job_title_id = jt.id\n"
                + "  LEFT JOIN camp.visitor_type vt on emp.employee_type_id = vt.id\n"
                + "WHERE book.status_id IN (2, 4)\n"
                + "  AND book.check_out IS NULL\n"
                + "  AND COALESCE(CAST(book.date_in AS VARCHAR), '') LIKE ?\n"
                + "  AND COALESCE(CAST(deprm.id AS VARCHAR), '') LIKE ?\n"
                + "  AND COALESCE(CAST(check_in AS VARCHAR), '') LIKE ?\n"
                + "  AND COALESCE(transit_status, '') LIKE ?\n"
                + "  AND CAST(vt.id AS VARCHAR) LIKE ?\n"
                + "  AND COALESCE(CAST(book.date_out AS VARCHAR), '') LIKE ?\n"
                + "  AND CAST(emp.emp_code AS VARCHAR) LIKE ?";

        String resultQuery = "SELECT book.id,\n"
                + "  emp.emp_code,\n"
                + "  coalesce(emp.last_name_ru || ' ' || emp.first_name_ru,\n"
                + "  emp.last_name || ' ' || emp.first_name) AS name,\n"
                + "  coalesce (coalesce(jt.title_ru, jt.title), gdi.job_title )  AS job_title,\n"
                + "  coalesce(coalesce (deprm.title_ru, deprm.title), coalesce (dep.title_ru, dep.title), gdi.department) AS department,\n"
                + "  book.date_in,\n"
                + "  book.date_out,\n"
                + "  book.check_in,\n"
                // tkabirov: Стажер КГК
                + "  CASE\n"
                + "    WHEN CAST(emp.emp_code AS VARCHAR) LIKE '2%' THEN 'Стажер КГК'\n"
                + "    ELSE vt.name\n"
                + "  END AS visitor_type,\n"
                // + "  vt.name AS visitor_type,\n"
                + "  CASE\n"
                + "    WHEN on_schedule = 0 THEN 'Не по графику'\n"
                + "    WHEN on_schedule = 1 THEN 'По графику'\n"
                + "  END AS on_schedule,\n"
                + "  transit_status,\n"
                + "  note,"
                + "  bl.\"name\" || '-' || r.room_num  || '-' || b.bed_number_in_room  as bed_number_in_room\n"
                + "FROM camp.booking AS book\n"
                + "  LEFT JOIN camp.employee AS emp on emp.emp_code = book.emp_code\n"
                + "  LEFT JOIN camp.employee_rm_department AS edep ON emp.emp_code = edep.emp_code\n"
                + "  LEFT JOIN camp.department_rm AS deprm ON edep.department_rm_id = deprm.id\n"
                + "  LEFT JOIN camp.department AS dep on emp.department_id = dep.id\n"
                + "  LEFT JOIN camp.job_title AS jt on emp.job_title_id = jt.id\n"
                + "  LEFT JOIN camp.visitor_type vt on emp.employee_type_id = vt.id\n"
                + "  LEFT JOIN camp.guest_detail_info gdi on emp.emp_code = gdi.emp_code\n"
                + "  LEFT JOIN camp.bed b on b.id = book.bed_id\n"
                + "  LEFT JOIN camp.room r on r.id = b.room_id\n"
                + "  LEFT JOIN camp.block bl on bl.id = r.block_id\n"
                + "WHERE book.status_id IN (2, 4)\n"
                + "  AND book.check_out IS NULL\n"
                + "  AND COALESCE(CAST(book.date_in AS VARCHAR), '') LIKE ?\n"
                + "  AND COALESCE(CAST(deprm.id AS VARCHAR), '') LIKE ?\n"
                + "  AND COALESCE(CAST(check_in AS VARCHAR), '') LIKE ?\n"
                + "  AND COALESCE(transit_status, '') LIKE ?\n"
                + "  AND CAST(vt.id AS VARCHAR) LIKE ?\n"
                + "  AND COALESCE(CAST(book.date_out AS VARCHAR), '') LIKE ?\n"
                + "  AND CAST(emp.emp_code AS VARCHAR) LIKE ?\n"
                + "ORDER BY book.date_in\n"
                + "LIMIT ? OFFSET ?";

        try {
            int count = jdbcTemplate.queryForObject(countQuery, Integer.class, dateIn, departmentId, checkIn, transitStatus, visitorTypeId, dateOut, empCode);
            List<BookingApplicationDTO> bookings = jdbcTemplate.query(resultQuery, new BeanPropertyRowMapper<>(BookingApplicationDTO.class),
                    dateIn, departmentId, checkIn, transitStatus, visitorTypeId, dateOut, empCode, pageable.getPageSize(), pageable.getOffset());
            log.info("Getting a list of applications for booking...");

            PageImpl<BookingApplicationDTO> bookingPages = new PageImpl<>(bookings, pageable, count);
            log.info("Applications for bookings:");
            bookings.forEach(bookingApplicationDTO -> {
                log.info(bookingApplicationDTO.toString());
            });
            log.info("List of applications for booking received");
            return PageableResponseDTO.builder().pageNumber(bookingPages.getNumber() + 1).totalPages(bookingPages.getTotalPages()).content(bookingPages.getContent()).build();
        } catch (Exception ex) {
            log.error("Error in receiving a list of bookings: {}", ex.getMessage());
            throw new ApiException(BOOKINGS_NOT_FOUND.getCode(), BOOKINGS_NOT_FOUND.getMessage());
        }
    }

    @Override
    public ChangeBookingDto getBookingForChangeDate(Integer id) throws Exception {
        ChangeBookingDto changeBookingDto = new ChangeBookingDto();
        String query = "SELECT book.id AS id,\n"
                + "  book.emp_code AS emp_code,\n"
                + "  book.last_name AS last_name,\n"
                + "  book.first_name AS first_name,\n"
                + "  book.booking_gender_id AS gender,\n"
                + "  book.department AS department,\n"
                + "  book.job_title AS job_title,\n"
                + "  book.date_in AS date_in,\n"
                + "  book.date_out AS date_out,\n"
                + "  l.id AS location_id,\n"
                + "  b.id AS block_id,\n"
                + "  r.room_capacity AS room_capacity,\n"
                + "  r.id AS room_id,\n"
                + "  r.room_category_id AS room_category_id,\n"
                + "  bed.id AS bed_id,\n"
                + "  r.room_gender_id AS room_gender\n"
                + "FROM camp.booking book\n"
                + "INNER JOIN camp.bed bed on bed.id = book.bed_id\n"
                + "INNER JOIN camp.room r on r.id = bed.room_id\n"
                + "INNER JOIN camp.block b on b.id = r.block_id\n"
                + "INNER JOIN camp.camp l on l.id = b.camp_id\n"
                + "WHERE book.id = ?";
        Object[] args = new Object[]{id};
        try {
            Map<String, Object> response = jdbcTemplate.queryForMap(query, args);
            changeBookingDto.setId(Long.valueOf(String.valueOf(response.get("id"))));
            changeBookingDto.setEmpCode(Integer.valueOf(String.valueOf(response.get("emp_code"))));
            changeBookingDto.setLastName(String.valueOf(response.get("last_name")));
            changeBookingDto.setFirstName(String.valueOf(response.get("last_name")));
            changeBookingDto.setGender(Integer.valueOf(String.valueOf(response.get("gender"))));
            changeBookingDto.setDepartment(String.valueOf(response.get("department")));
            changeBookingDto.setJobTitle(String.valueOf(response.get("job_title")));
            changeBookingDto.setDateIn(LocalDate.parse(String.valueOf(response.get("date_in"))));
            changeBookingDto.setDateOut(LocalDate.parse(String.valueOf(response.get("date_out"))));
            changeBookingDto.setLocationId(Integer.valueOf(String.valueOf(response.get("location_id"))));
            changeBookingDto.setBlockId(Integer.valueOf(String.valueOf(response.get("block_id"))));
            changeBookingDto.setRoomCapacity(Integer.valueOf(String.valueOf(response.get("room_capacity"))));
            changeBookingDto.setRoomCategory(Integer.valueOf(String.valueOf(response.get("room_category_id"))));
            changeBookingDto.setRoomId(Integer.valueOf(String.valueOf(response.get("room_id"))));
            changeBookingDto.setBedId(Integer.valueOf(String.valueOf(response.get("bed_id"))));
            changeBookingDto.setRoomGender(Integer.valueOf(String.valueOf(response.get("room_gender"))));
        } catch (EmptyResultDataAccessException ex) {
            log.info("No record found in database with id " + id + "! message: " + ex.getMessage());
            log.error("No record found in database with id " + id + "! message: " + ex.getMessage());
            return changeBookingDto;
        }
        return changeBookingDto;
    }

    @Override
    public List<RoomFilterDto> getAllRoomsWithFilter(LocalDate dateIn, Integer locationId, String blockId, String roomId, Integer empCode, Integer empType, Integer status, Integer size, Integer page) {
        page = (page - 1) * size;
        if (dateIn == null) {
            dateIn = LocalDate.now();
        }
        roomId = (roomId.equals("")) ? null : roomId;
        blockId = (blockId.equals("")) ? null : blockId;
        List<RoomFilterDto> roomFilterDtos = new ArrayList<>();
        List<Map<String, Object>> resultOfRooms = new ArrayList<>();
        String query = "SELECT * FROM camp.getRooms(?,?, ?, ?, ?,?,?,?,?)";
        String queryRooms = " select b.name ||'-'||LPAD(cast(r.room_num as varchar), 2, '0') as room from camp.room r inner join camp.block b on r.block_id=b.id order by b.name, r.room_num ";
        Object[] args = new Object[]{dateIn, locationId, blockId, roomId, empCode, empType, status, page, size};
        try {
            List<Map<String, Object>> resultRoom = jdbcTemplate.queryForList(queryRooms);
            List<Map<String, Object>> roomName = new ArrayList<>();
            if (resultRoom.size() != 0) {
                for (Map<String, Object> room : resultRoom) {
                    Map<String, Object> roomNum = new HashMap<>();
                    roomNum.put("room", String.valueOf(room.get("room")));
                    roomName.add(roomNum);
                }
            }
            List<Map<String, Object>> response = jdbcTemplate.queryForList(query, args);
            if (response.size() != 0) {
                for (Map<String, Object> rooms : roomName) {
                    RoomFilterDto room = new RoomFilterDto();
                    room.setRoom(String.valueOf(rooms.get("room")).trim());
                    List<BedFilterDto> bedList = new ArrayList<>();
                    for (Map<String, Object> iterator : response) {
                        BedFilterDto res = new BedFilterDto();
                        if (String.valueOf(rooms.get("room")).equals(String.valueOf(iterator.get("room")))) {
                            res.setBedNum(Long.valueOf(String.valueOf(iterator.get("bed_num")).trim()));
                            res.setStatus(Integer.valueOf(String.valueOf(iterator.get("status")).trim()));
                            res.setDepartment((String) iterator.get("department"));
                            if (String.valueOf(iterator.get("emp_info")).equals("null")) {
                                res.setEmpCode("");
                            } else {
                                res.setEmpCode(String.valueOf(iterator.get("emp_info")).trim());
                            }
                            if (String.valueOf(iterator.get("date_in")).equals("null")) {
                                res.setDateIn(null);
                            } else {
                                res.setDateIn(LocalDate.parse(String.valueOf(iterator.get("date_in")).trim()));
                            }
                            if (String.valueOf(iterator.get("date_out")).equals("null")) {
                                res.setDateOut(null);
                            } else {
                                res.setDateOut(LocalDate.parse(String.valueOf(iterator.get("date_out")).trim()));
                            }
                            if (String.valueOf(iterator.get("department")).equals("null")) {
                                res.setDepartment(null);
                            } else {
                                res.setDepartment(String.valueOf(iterator.get("department")).trim());
                            }
                            if (String.valueOf(iterator.get("booking_id")).equals("null")) {
                                res.setBookingId(null);
                            }
                            else{
                                res.setBookingId(Integer.valueOf(String.valueOf(iterator.get("booking_id")).trim()));
                            }

                            bedList.add(res);
                        }
                    }
                    room.setBedList(bedList);
                    roomFilterDtos.add(room);
                }
                //remove empty rooms
                for (int i = roomFilterDtos.size(); i > 0; i--) {
                    if (roomFilterDtos.get(i - 1).getBedList().size() == 0) {
                        roomFilterDtos.remove(i - 1);
                    }
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return roomFilterDtos;
    }

    @Override
    public List<BookingStatusDto> getBookingStatus() {
        return bookingStatusRepository.findAllStatus();
    }

    @Override
    public BookingDetailForSetDto getBookingInfoByEmpCodeForSetBook(Integer id) {
        BookingDetailForSetDto bookingDetailForSetDto = new BookingDetailForSetDto();
        String query = "select\n" +
                "  emp_code, first_name, last_name, gender_id, department,\n" +
                "  job_title, date_in, date_out, status, location, block,\n" +
                "  room, bed_id, room_gender, category, room_capacity, Priority\n" +
                "from (\n" +
                "      select\n" +
                "        book.emp_code as emp_code,\n" +
                "        book.first_name as first_name,\n" +
                "        book.last_name as last_name,\n" +
                "        book.booking_gender_id as gender_id,\n" +
                "        book.department as department,\n" +
                "        book.job_title as job_title,\n" +
                "        book.date_in as date_in,\n" +
                "        book.date_out as date_out,\n" +
                "        book.status_id as status,\n" +
                "        loc.id as location,\n" +
                "        b.id as block,\n" +
                "        r.id as room,\n" +
                "        bed.id as bed_id,\n" +
                "        r.room_gender_id as room_gender, \n" +
                "        r.room_category_id as category ,\n" +
                "        r.room_capacity as room_capacity,\n" +
                "        0 as Priority\n" +
                "      from camp.booking book\n" +
                "      right join camp.permanent_resident p on book.emp_code = p.emp_code\n" +
                "      left join camp.bed bed on bed.id = p.bed_id\n" +
                "      left join camp.room r on r.id = bed.room_id   \n" +
                "      left join camp.block b on b.id = r.block_id\n" +
                "      left join camp.camp loc on loc.id = b.camp_id\n" +
                "      where book.id = ?\n" +
                "        and book.status_id not in(2, 4)\n" +
                "      union\n" +
                "      select \n" +
                "        book.emp_code as emp_code,\n" +
                "        book.first_name as first_name,\n" +
                "        book.last_name as last_name, \n" +
                "        book.booking_gender_id as gender_id,\n" +
                "        book.department as department,\n" +
                "        book.job_title as job_title,\n" +
                "        book.date_in as date_in,\n" +
                "        book.date_out as date_out,\n" +
                "        book.status_id as status,\n" +
                "        loc.id as location,\n" +
                "        b.id as block,\n" +
                "        r.id as room,\n" +
                "        bed.id as bed_id,\n" +
                "        r.room_gender_id as room_gender,\n" +
                "        r.room_category_id as category,\n" +
                "        r.room_capacity as room_capacity,\n" +
                "        1 as Priority\n" +
                "   from camp.booking book\n" +
                "      left join camp.bed bed on bed.id = book.bed_id\n" +
                "      left join camp.room r on r.id = bed.room_id\n" +
                "      left join camp.block b on b.id = r.block_id\n" +
                "      left join camp.camp loc on loc.id = b.camp_id\n" +
                "   where book.id = ?\n" +
                "   ) as test\n" +
                "order by Priority\n" +
                "limit 1;";
        Object[] args = new Object[]{id, id };
        try {
            Map<String, Object> res = jdbcTemplate.queryForMap(query, args);
            if (!String.valueOf(res.get("emp_code")).equals("null")) {
                bookingDetailForSetDto.setEmpCode(Integer.valueOf(String.valueOf(res.get("emp_code"))));
            }
            bookingDetailForSetDto.setFirstName(String.valueOf(res.get("first_name")));
            bookingDetailForSetDto.setLastName(String.valueOf(res.get("last_name")));
            if (!String.valueOf(res.get("gender_id")).equals("null")) {
                bookingDetailForSetDto.setGender(Integer.valueOf(String.valueOf(res.get("gender_id"))));
            }
            bookingDetailForSetDto.setDepartment(String.valueOf(res.get("department")));
            bookingDetailForSetDto.setJobTitle(String.valueOf(res.get("job_title")));
            bookingDetailForSetDto.setDateIn(LocalDate.parse(String.valueOf(res.get("date_in"))));
            bookingDetailForSetDto.setDateOut(LocalDate.parse(String.valueOf(res.get("date_out"))));
            bookingDetailForSetDto.setStatus(Integer.valueOf(String.valueOf(res.get("status"))));
            if (!String.valueOf(res.get("location")).equals("null")) {
                bookingDetailForSetDto.setLocation(Integer.valueOf(String.valueOf(res.get("location"))));
            }
            if (!String.valueOf(res.get("block")).equals("null")) {
                bookingDetailForSetDto.setBlock(Integer.valueOf(String.valueOf(res.get("block"))));
            }
            if (!String.valueOf(res.get("room")).equals("null")) {
                bookingDetailForSetDto.setRoom(Integer.valueOf(String.valueOf(res.get("room"))));
            }
            if (!String.valueOf(res.get("bed_id")).equals("null")) {
                bookingDetailForSetDto.setBedId(Integer.valueOf(String.valueOf(res.get("bed_id"))));
            }
            if (!String.valueOf(res.get("room_gender")).equals("null")) {
                bookingDetailForSetDto.setRoomGender(Integer.valueOf(String.valueOf(res.get("room_gender"))));
            }
            if (!String.valueOf(res.get("category")).equals("null")) {
                bookingDetailForSetDto.setCategory(Integer.valueOf(String.valueOf(res.get("category"))));
            }
            if (!String.valueOf(res.get("room_capacity")).equals("null")) {
                bookingDetailForSetDto.setRoomCapacity(Integer.valueOf(String.valueOf(res.get("room_capacity"))));
            }



        } catch (Exception ex) {
            return null;
        }
        return bookingDetailForSetDto;
    }

    @Override
    public List<Map<String, Object>> getRoomCapacityList(Integer blockId, Integer genderId, Date dateIn, Date dateOut) throws ApiException {
        List<Map<String, Object>> resultRoomCapacity = new ArrayList<>();
        String query = "select rc.capacity as id, rc.\"name\" as name\n"
                + "from camp.block b\n"
                + "inner join camp.room r on b.id = r.block_id\n"
                + "inner join camp.room_capacity rc on r.room_capacity = rc.capacity\n"
                + "where b.id = coalesce(?, b.id)\n"
                + "  and r.id not in (SELECT DISTINCT bed.room_id\n"
                + "                   from camp.bed left join camp.room r on r.id = bed.room_id\n"
                + "                   WHERE bed.id IN (SELECT bed_id\n"
                + "                                    FROM camp.booking\n"
                + "                                    WHERE date_in <= ? and date_out >= ? and status_id in (1, 2, 4))\n"
                + "                                    group by bed.room_id, r.room_capacity\n"
                + "                                    having count(bed.id) = r.room_capacity)\n"
                + "  and r.room_gender_id = coalesce(?, r.room_gender_id)\n"
                + "group by rc.capacity, rc.\"name\"\n"
                + "order by rc.capacity";
        Object[] args = new Object[]{blockId, dateOut, dateIn, genderId};
        try {
            List<Map<String, Object>> resQuery = jdbcTemplate.queryForList(query, args);
            if (resQuery.size() == 0) {
                throw new ApiException();
            }
            for (Map<String, Object> iterator : resQuery) {
                Map<String, Object> res = new LinkedHashMap<>();
                res.put("id", Integer.valueOf(String.valueOf(iterator.get("id"))));
                res.put("name", String.valueOf(iterator.get("name")));
                resultRoomCapacity.add(res);
            }
        } catch (Exception ex) {
            throw new ApiException(170, "Empty result");
        }
        return resultRoomCapacity;
    }

    @Override
    public Map<String, Object> getInfoForBookFromBookingListPage(Integer bedId, Date dateIn, Date dateOut) throws ApiException {
        Map<String, Object> res = new LinkedHashMap<>();
        String query = "SELECT loc.id AS camp,\n"
                + "  r.room_gender_id AS gender,\n"
                + "  b.id AS block,\n"
                + "  r.room_capacity AS capacity,\n"
                + "  r.room_category_id AS category,\n"
                + "  r.id AS room,\n"
                + "  bed.id AS bed\n"
                + "FROM camp.bed bed\n"
                + "INNER JOIN camp.room r ON r.id = bed.room_id\n"
                + "INNER JOIN camp.block b ON b.id = r.block_id\n"
                + "INNER JOIN camp.camp loc ON loc.id = b.camp_id\n"
                + "WHERE bed.id = ? AND ? NOT IN (SELECT bed_id\n"
                + "                               FROM camp.booking\n"
                + "                               WHERE date_in <= ? AND date_out >= ? AND status_id in (1, 2, 4))\n"
                + "  AND bed.status = 'A'";
        Object[] args = new Object[]{bedId, bedId, dateOut, dateIn};
        try {
            Map<String, Object> resQuery = jdbcTemplate.queryForMap(query, args);
            if (resQuery.size() == 0) {
                throw new ApiException();
            }
            res.put("campId", String.valueOf(resQuery.get("camp")).equals("null") ? null : Integer.valueOf(String.valueOf(resQuery.get("camp"))));
            res.put("gender", String.valueOf(resQuery.get("gender")).equals("null") ? null : Integer.valueOf(String.valueOf(resQuery.get("gender"))));
            res.put("block", String.valueOf(resQuery.get("block")).equals("null") ? null : Integer.valueOf(String.valueOf(resQuery.get("block"))));
            res.put("roomCapacity", String.valueOf(resQuery.get("capacity")).equals("null") ? null : Integer.valueOf(String.valueOf(resQuery.get("capacity"))));
            res.put("roomCategory", String.valueOf(resQuery.get("category")).equals("null") ? null : Integer.valueOf(String.valueOf(resQuery.get("category"))));
            res.put("roomId", String.valueOf(resQuery.get("room")).equals("null") ? null : Integer.valueOf(String.valueOf(resQuery.get("room"))));
            res.put("bedId", String.valueOf(resQuery.get("bed")));

        } catch (Exception ex) {
            throw new ApiException(170, "Эта кровать занята! Пожалуйста выберите другую кровать");
        }
        return res;
    }

    @Override
    public List<Map<String, Object>> getBookingListByBedId(Integer bedId) throws ApiException {
        List<Map<String, Object>> response = new ArrayList<>();
        Map<String, Object> res = new LinkedHashMap<>();
        String query = "select b.date_in as date_in , b.date_out as date_out, b.emp_code as emp_code, b.first_name as first_name, b.last_name as last_name  from camp.booking b where b.bed_id=? \n" + "and b.date_in>? and b.status_id not in (3)\n";
        Object[] args = new Object[]{bedId, LocalDateTime.now()};
        try {
            List<Map<String, Object>> resQuery = jdbcTemplate.queryForList(query, args);
            if (resQuery.size() == 0) {
                res.put("message", "На эту кровать нет забронированных сотрудников");
                response.add(res);
                return response;
            } else {
                for (Map<String, Object> iterator : resQuery) {
                    Map<String, Object> bookingInfo = new LinkedHashMap<>();
                    bookingInfo.put("dateIn", String.valueOf(iterator.get("date_in")));
                    bookingInfo.put("dateOut", String.valueOf(iterator.get("date_out")));
                    bookingInfo.put("empCode", String.valueOf(iterator.get("emp_code")));
                    bookingInfo.put("firstName", String.valueOf(iterator.get("first_name")));
                    bookingInfo.put("lastName", String.valueOf(iterator.get("last_name")));
                    response.add(bookingInfo);
                }
            }
        } catch (Exception ex) {
            throw new ApiException(500, ex.getMessage());
        }
        return response;
    }

    @Override
    public Integer getFreeBedId(Integer empCode, LocalDate dateIn, LocalDate dateOut) throws ApiException {
        Integer result;
        String query = "SELECT b.id AS id, b2.\"name\" AS name\n"
                + "FROM camp.bed b\n"
                + "INNER JOIN camp.room r ON r.id = b.room_id\n"
                + "INNER JOIN camp.block b2 ON b2.id = r.block_id\n"
                + "INNER JOIN camp.camp c on c.id = b2.camp_id\n"
                + "WHERE b.id NOT IN (SELECT DISTINCT bed.id\n"
                + "                   FROM camp.bed bed\n"
                + "                   WHERE bed.id IN (SELECT bed_id\n"
                + "                                    FROM camp.booking\n"
                + "                                    WHERE date_in <= ? AND date_out >= ? AND status_id in (1, 2, 4))\n"
                + "                                    GROUP BY bed.id)\n"
                + "  AND c.id = (SELECT CASE WHEN e.employee_type_id in (1, 2, 4) THEN 1 ELSE 2 END\n"
                + "              FROM camp.employee e\n"
                + "              WHERE e.emp_code = ?)\n"
                + "  AND b2.\"name\" <> 'Warehouse'\n"
                + "  AND b.status = 'A'\n"
                + "ORDER BY b2.\"name\", b.id\n"
                + "LIMIT 1";
        Object[] args = new Object[]{dateOut, dateIn, empCode};
        try {
            List<Map<String, Object>> resQuery = jdbcTemplate.queryForList(query, args);
            if (resQuery.size() == 0) {
                throw new ApiException("Свободных мест нет, обратитесь к координатору лагеря");
            }
            result = Integer.valueOf(String.valueOf(resQuery.get(0).get("id")));
        } catch (Exception ex) {
            throw new ApiException(500, ex.getMessage());
        }
        return result;
    }

    public PageableResponseDTO getAllBookingList(Pageable pageable, LocalDate dateIn, LocalDate dateOut,
                                                 LocalDate checkIn, LocalDate checkOut, Integer empCode) throws ApiException {
        Integer applicationsCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM camp.vw_get_all_booking_list" +
                        " WHERE (?::DATE IS NULL OR date_in = ?)\n" +
                        " AND (?::DATE IS NULL OR date_out = ?)\n" +
                        " AND (?::DATE IS NULL OR check_in = ?)\n" +
                        " AND (?::DATE IS NULL OR check_out = ?)\n" +
                        " AND (?::INTEGER IS NULL OR emp_code = ?)",
                new Object[]{dateIn, dateIn, dateOut, dateOut, checkIn, checkIn, checkOut, checkOut, empCode, empCode},
                Integer.class);
        if (applicationsCount == null) {
            applicationsCount = 0;
        }

        String query = "SELECT * FROM camp.vw_get_all_booking_list " +
                " WHERE (?::DATE IS NULL OR date_in = ?)\n" +
                " AND (?::DATE IS NULL OR date_out = ?)\n" +
                " AND (?::DATE IS NULL OR check_in = ?)\n" +
                " AND (?::DATE IS NULL OR check_out = ?)\n" +
                " AND (?::INTEGER IS NULL OR emp_code = ?)\n" +
                "ORDER BY id DESC\n" +
                " LIMIT ? OFFSET ?";
        try {
            logger.info("Getting list of Transfer applications");

            List<BookingListDTO> applications = jdbcTemplate.query(query,
                    new Object[]{dateIn, dateIn, dateOut, dateOut, checkIn, checkIn, checkOut, checkOut, empCode, empCode, pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(BookingListDTO.class));

            logger.info("List of Transfer applications received");

            PageImpl<BookingListDTO> applicationsPages = new PageImpl<>(applications, pageable,
                    applicationsCount);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of Transfer applications {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    @Override
    public PageableResponseDTO getConflictBooking(Integer empCode, LocalDate dateIn, LocalDate dateOut, Integer empType, PageRequest pageable) throws ApiException {

        Integer count = jdbcTemplate.queryForObject(
                "SELECT count(cb.emp_code)\n" +
                        "FROM camp.conflict_booking cb  \n" +
                        "INNER JOIN camp.booking b on b.bed_id = cb.bed_id  \n" +
                        "AND b.id = cb.id \n" +
                        "AND cb.date_in <= b.date_out\n" +
                        "AND cb.date_out >= b.date_in\n" +
                        "LEFT JOIN camp.bed AS bed ON cb.bed_id = bed.id\n" +
                        "LEFT JOIN camp.room AS room ON bed.room_id = room.id\n" +
                        "LEFT JOIN camp.block AS block ON room.block_id = block.id\n" +
                        "LEFT JOIN camp.employee e on cb.emp_code = e.emp_code \n" +
                        "WHERE (b.status_id not in(3, 6) AND cb.status_id not in (3, 6)) \n" +
                        "AND (?::INTEGER IS NULL OR cb.emp_code = ?)\n" +
                        "AND (?::DATE IS NULL OR cb.date_in = ?)\n" +
                        "AND (?::DATE IS NULL OR cb.date_out = ?)\n" +
                        "AND (?::INTEGER IS NULL or e.employee_type_id = ?)",
                new Object[]{ empCode, empCode, dateIn, dateIn, dateOut, dateOut, empType, empType},
                Integer.class);

        if (count == null) {
            count = 0;
        }

        String query = "SELECT \n" +
                "       cb.id as conf_id,\n" +
                "       cb.emp_code as conf_emp_code,\n" +
                "       cb.first_name as conf_first_name,\n" +
                "       cb.last_name as conf_last_name,\n" +
                "       cb.last_name || ' ' || cb.first_name as conf_full_name,\n" +
                "       cb.date_in as conf_date_in,\n" +
                "       cb.date_out as conf_date_out,\n" +
                "       cb.status_id as conf_status_id,\n" +
                "       'Комната: ' || block.name || '-' || room.room_num || '-'\n" +
                "       || b.bed_id                                        AS room_info,\n" +
                "       b.id,\n" +
                "       b.emp_code,\n" +
                "       b.first_name,\n" +
                "       b.last_name, \n" +
                "       b.last_name || ' ' || b.first_name as full_name,\n" +
                "       b.date_in ,\n" +
                "       b.date_out,\n" +
                "       b.status_id     \n" +
                "FROM camp.conflict_booking cb  \n" +
                "INNER JOIN camp.booking b on b.bed_id = cb.bed_id  \n" +
                "AND b.id = cb.id \n" +
                "AND cb.date_in <= b.date_out\n" +
                "AND cb.date_out >= b.date_in\n" +
                "LEFT JOIN camp.bed AS bed ON cb.bed_id = bed.id\n" +
                "LEFT JOIN camp.room AS room ON bed.room_id = room.id\n" +
                "LEFT JOIN camp.block AS block ON room.block_id = block.id\n" +
                "LEFT JOIN camp.employee e on cb.emp_code = e.emp_code \n" +
                "WHERE (b.status_id not in(3, 6) AND cb.status_id not in (3, 6)) \n" +
                "AND (?::INTEGER IS NULL OR cb.emp_code = ?)\n" +
                "AND (?::DATE IS NULL OR cb.date_in = ?)\n" +
                "AND (?::DATE IS NULL OR cb.date_out = ?)\n" +
                "AND (?::INTEGER is NULL or e.employee_type_id = ?)\n" +
                "ORDER BY cb.date_changed  DESC\n" +
                "LIMIT ? OFFSET ?";
        try {
            logger.info("Getting list of conflict booking ");

            List<ConflictBooking> applications = jdbcTemplate.query(query,
                    new Object[]{empCode,empCode,dateIn, dateIn, dateOut, dateOut, empType, empType, pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(ConflictBooking.class));

            logger.info("List of conflict booking received");

            PageImpl<ConflictBooking> applicationsPages = new PageImpl<>(applications, pageable,
                    count);
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            logger.error("Error while getting list of conflict booking {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    @Override
    public VacationInfo getVacationDetailInfo(int bedId) throws ApiException {
        return bookingDao.getVacationDetailInfo(bedId);
    }
}
