package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.GuardPointService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@CrossOrigin(origins = "*")
@AllArgsConstructor
@RequestMapping("/guard-point")
@RestController
public class GuardPointPageController {

    private GuardPointService guardPointService;

    @GetMapping
    public PageableResponseDTO guardPointList(@RequestParam(value = "page", required = true) int page,
                                              @RequestParam(value = "enter-date", required = false,
                                                      defaultValue = "") String enterDate,
                                              @RequestParam(value = "exit-date", required = false,
                                                      defaultValue = "") String exitDate,
                                              @RequestParam(value = "checkin-date", required = false, defaultValue =
                                                      "") String checkInDate,
                                              @RequestParam(value = "checkout-date", required = false, defaultValue =
                                                      "") String checkOutDate,
                                              @RequestParam(value = "empcode", required = false, defaultValue = "%%") String empCode) throws ApiException {
        return guardPointService.getGuardPointList(PageRequest.of(page - 1, 10), enterDate, exitDate, checkInDate,
                checkOutDate, empCode);
    }
}
