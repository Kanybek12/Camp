package kg.kumtor.camp.dto.transfer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PersonalInfoDTO {
    private int empCode;
    private String firstName;
    private String lastName;
    private int employeeTypeId;
    private long jobTitleId;
    private long departmentId;
    private String sin;
    private int genderId;
    private LocalDate dateBirth;
    private String medicalExamination;
}
