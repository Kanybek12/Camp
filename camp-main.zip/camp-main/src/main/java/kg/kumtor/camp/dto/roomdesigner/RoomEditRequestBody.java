package kg.kumtor.camp.dto.roomdesigner;

import java.util.List;

public class RoomEditRequestBody {
    private Integer gender;
    private Integer roomCapacity;
    private Integer roomCategory;
    private List<BedEditListDto> bedListDtos;

    public RoomEditRequestBody() {
    }

    public RoomEditRequestBody(Integer gender, Integer roomCapacity, Integer roomCategory, List<BedEditListDto> bedListDtos) {
        this.gender = gender;
        this.roomCapacity = roomCapacity;
        this.roomCategory = roomCategory;
        this.bedListDtos = bedListDtos;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getRoomCapacity() {
        return roomCapacity;
    }

    public void setRoomCapacity(Integer roomCapacity) {
        this.roomCapacity = roomCapacity;
    }

    public Integer getRoomCategory() {
        return roomCategory;
    }

    public void setRoomCategory(Integer roomCategory) {
        this.roomCategory = roomCategory;
    }

    public List<BedEditListDto> getBedListDtos() {
        return bedListDtos;
    }

    public void setBedListDtos(List<BedEditListDto> bedListDtos) {
        this.bedListDtos = bedListDtos;
    }
}
