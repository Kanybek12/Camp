package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.ApplicationTypeDto;
import kg.kumtor.camp.entity.ApplicationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationTypeRepository extends JpaRepository<ApplicationType, Long> {
    @Query("SELECT new kg.kumtor.camp.dto.reference.ApplicationTypeDto(u.id,u.name) FROM ApplicationType u")
    List<ApplicationTypeDto> find();
}
