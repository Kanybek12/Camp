package kg.kumtor.camp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class BookingDto {
    private Long id;
    private String firstName;
    private String lastName;
    private String jobTitle;
    private String department;
    private String note;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateIn;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOut;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate checkOut;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate checkIn;

    private Integer genderId;
    private Integer bedId;
    private String payAccount;
    private Integer statusId;
    private Integer empCode;

    private String passport;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime dateChanged;
    private String changedBy;

    public BookingDto() {
    }

    public BookingDto(String firstName, String lastName, String jobTitle, String department, String note, LocalDate dateIn, LocalDate dateOut, LocalDate checkOut, LocalDate checkIn, Integer genderId, Integer bedId, String payAccount, Integer statusId, Integer empCode, LocalDateTime dateChanged, String changedBy) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.jobTitle = jobTitle;
        this.department = department;
        this.note = note;
        this.dateIn = dateIn;
        this.dateOut = dateOut;
        this.checkOut = checkOut;
        this.checkIn = checkIn;
        this.genderId = genderId;
        this.bedId = bedId;
        this.payAccount = payAccount;
        this.statusId = statusId;
        this.empCode = empCode;
        this.dateChanged = dateChanged;
        this.changedBy = changedBy;
    }

    @Override
    public String toString() {
        return "BookingDto{" +
                "id='" + id + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                ", department='" + department + '\'' +
                ", note='" + note + '\'' +
                ", dateIn=" + dateIn +
                ", dateOut=" + dateOut +
                ", checkOut=" + checkOut +
                ", checkIn=" + checkIn +
                ", genderId=" + genderId +
                ", bedId=" + bedId +
                ", costCenterId=" + payAccount +
                ", statusId=" + statusId +
                ", empCode=" + empCode +
                ", dateChanged=" + dateChanged +
                ", changedBy='" + changedBy + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BookingDto that = (BookingDto) o;
        return Objects.equals(id, that.id) && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(jobTitle, that.jobTitle) && Objects.equals(department, that.department) && Objects.equals(note, that.note) && Objects.equals(dateIn, that.dateIn) && Objects.equals(dateOut, that.dateOut) && Objects.equals(checkOut, that.checkOut) && Objects.equals(checkIn, that.checkIn) && Objects.equals(genderId, that.genderId) && Objects.equals(bedId, that.bedId) && Objects.equals(payAccount, that.payAccount) && Objects.equals(statusId, that.statusId) && Objects.equals(empCode, that.empCode) && Objects.equals(dateChanged, that.dateChanged) && Objects.equals(changedBy, that.changedBy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, firstName, lastName, jobTitle, department, note, dateIn, dateOut, checkOut, checkIn, genderId, bedId, payAccount, statusId, empCode, dateChanged, changedBy);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public LocalDate getDateIn() {
        return dateIn;
    }

    public void setDateIn(LocalDate dateIn) {
        this.dateIn = dateIn;
    }

    public LocalDate getDateOut() {
        return dateOut;
    }

    public void setDateOut(LocalDate dateOut) {
        this.dateOut = dateOut;
    }

    public LocalDate getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(LocalDate checkOut) {
        this.checkOut = checkOut;
    }

    public LocalDate getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(LocalDate checkIn) {
        this.checkIn = checkIn;
    }

    public Integer getGenderId() {
        return genderId;
    }

    public void setGenderId(Integer genderId) {
        this.genderId = genderId;
    }

    public Integer getBedId() {
        return bedId;
    }

    public void setBedId(Integer bedId) {
        this.bedId = bedId;
    }

    public String getPayAccount() {
        return payAccount;
    }

    public void setPayAccount(String payAccount) {
        this.payAccount = payAccount;
    }

    public Integer getStatusId() {
        return statusId;
    }

    public void setStatusId(Integer statusId) {
        this.statusId = statusId;
    }

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public LocalDateTime getDateChanged() {
        return dateChanged;
    }

    public void setDateChanged(LocalDateTime dateChanged) {
        this.dateChanged = dateChanged;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }
}
