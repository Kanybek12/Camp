package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.EmployeeDao;
import kg.kumtor.camp.dao.TransferDao;
import kg.kumtor.camp.dto.email.*;
import kg.kumtor.camp.dto.transfer.CancelMyApplicationDTO;
import kg.kumtor.camp.dto.transfer.TransferApproveDto;
import kg.kumtor.camp.enums.Role;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.EmailService;
import kg.kumtor.camp.service.NotificationService;
import org.keycloak.representations.AccessToken;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmailServiceImpl implements EmailService {
    private final NotificationService notificationService;
    private final TransferDao transferDao;
    private final EmployeeDao employeeDao;

    public EmailServiceImpl(NotificationService notificationService, TransferDao transferDao, EmployeeDao employeeDao) {
        this.notificationService = notificationService;
        this.transferDao = transferDao;
        this.employeeDao = employeeDao;
    }

    @Override
    public void sendEmailApprovedTransfers(List<TransferApproveDto> transferApproveDto) throws ApiException {

        for (TransferApproveDto iterator : transferApproveDto) {

            TransferApplicationInfo transferApplication = transferDao.getStatusTransferApplication(iterator.getTransferApplicationId());

            if (transferApplication == null || transferApplication.isOnCar()) {

                Integer transferApplicationId = (int) (long) iterator.getTransferApplicationId();
                OwnCarInfo carInfo = transferDao.getInfoOwnCar(transferApplicationId);

                if (carInfo.getStatusId().equals(1)) {

                    List<TransferEmpCodeList> responseList = transferDao.getTransferEmpCodeList(transferApplicationId, 1);

                    for (int i = 0; i < responseList.size(); i++) {
                        Email email = new Email();
                        email.setFrom("kgc.flow@kumtor.kg");
                        email.setTo(String.valueOf(responseList.get(i).getEmail()));
                        email.setHeader("Заявка на транспорт и проживание в лагере");

                        String body = String.format(
                                "<table border=\"0\" cellspacing=\"0\" cellpadding=\"8\" dir=\"ltr\">\n" +
                                        "<tbody><tr><td align=\"left\" valign=\"top\"><div style=\"font-family:'Segoe UI Semilight','Segoe UI',Verdana,sans-serif; color:#444444\">\n" +
                                        "<div style=\"margin-bottom:21px; font-size:18px\">Уважаемый пользователь!\n" +
                                        "<br aria-hidden=\"true\">\n" +
                                        "<p><b>Заявка на транспортировку и проживание в лагере рудника Кумтор утверждена. \n" +
                                        "<br aria-hidden=\"true\">%1$s  %2$s (Таб.№ %3$s) \n" +
                                        "<br aria-hidden=\"true\">c %4$s по %5$s<br aria-hidden=\"true\">\n" +
                                        "<br aria-hidden=\"true\">Номер машины: %6$s<br aria-hidden=\"true\">\n" +
                                        "Марка машины: %7$s<br aria-hidden=\"true\">\n" +
                                        "Водитель: %8$s<br aria-hidden=\"true\"></b></p>" +
                                        "С уважением,<br aria-hidden=\"true\">\n" +
                                        "КГК Процесс </div></div></td></tr></tbody></table>", carInfo.getFirstName(), carInfo.getLastName(),
                                carInfo.getEmpCode(), carInfo.getDateFrom(), carInfo.getDateTo(),
                                carInfo.getCarNumber(), carInfo.getCarModel(), carInfo.getDriver());
                        email.setBody(body);
                        notificationService.sendMessage(email);

                    }
                } else if (carInfo.getStatusId().equals(3)) {
                    InfoApprover infoApprover = employeeDao.getInfoApproverByEmpCode(iterator.getApproverEmpCode());

                    String emailTo = employeeDao.getEmailByEmpCode(carInfo.getEmpCode());

                    Email email = new Email();
                    email.setFrom("kgc.flow@kumtor.kg");
                    email.setTo(emailTo);
                    email.setHeader("Заявка на транспорт и проживание в лагере");

                    String body = String.format(
                            "<table border=\"0\" cellspacing=\"0\" cellpadding=\"8\" dir=\"ltr\">\n" +
                                    "<tbody><tr><td align=\"left\" valign=\"top\"><div style=\"font-family:'Segoe UI Semilight','Segoe UI',Verdana,sans-serif; color:#444444\">\n" +
                                    "<div style=\"margin-bottom:21px; font-size:18px\">Уважаемый пользователь!\n" +
                                    "<br aria-hidden=\"true\">\n" +
                                    "<p><b>Ваша заявка на транспортировку и проживание в лагере рудника Кумтор отклонена. \n" +
                                    "<br aria-hidden=\"true\">Причина: отклонен пользователем %1$s %2$s %3$s \n" +
                                    "<br aria-hidden=\"true\">%4$s  %5$s  (Таб.№ %6$s )\n" +
                                    "<br aria-hidden=\"true\">c %7$s по %8$s <br aria-hidden=\"true\"></b></p>\n" +
                                    "С уважением,<br aria-hidden=\"true\">\n" +
                                    "КГК Процесс </div></div></td></tr></tbody></table>", infoApprover.getFirstName(), infoApprover.getLastName(), infoApprover.getTitle(), carInfo.getFirstName(), carInfo.getLastName(),
                            carInfo.getEmpCode(), carInfo.getDateFrom(), carInfo.getDateTo());
                    email.setBody(body);
                    notificationService.sendMessage(email);

                }
            } else if (transferApplication != null && transferApplication.getStatusId().equals("1") && !transferApplication.isOnCar()) {

                Integer transferApplicationId = (int) (long) iterator.getTransferApplicationId();

                List<TransferEmpCodeList> transferEmpCodeLists = transferDao.getTransferEmpCodeList(transferApplicationId, 1);

                for (int i = 0; i < transferEmpCodeLists.size(); i++) {
                    Email email = new Email();
                    email.setFrom("kgc.flow@kumtor.kg");
                    email.setTo(String.valueOf(transferEmpCodeLists.get(i).getEmail()));
                    email.setHeader("Заявка на транспорт и проживание в лагере");

                    String body = String.format(
                            "<table border=\"0\" cellspacing=\"0\" cellpadding=\"8\" dir=\"ltr\">\n" +
                                    "<tbody><tr><td align=\"left\" valign=\"top\"><div style=\"font-family:'Segoe UI Semilight','Segoe UI',Verdana,sans-serif; color:#444444\">\n" +
                                    "<div style=\"margin-bottom:21px; font-size:18px\">Уважаемый пользователь!\n" +
                                    "<br aria-hidden=\"true\">\n" +
                                    "<p><b>Заявка на транспортировку и проживание в лагере рудника Кумтор утверждена. \n" +
                                    "<br aria-hidden=\"true\">%1$s  %2$s (Таб.№ %3$s) \n" +
                                    "<br aria-hidden=\"true\">c %4$s по %5$s<br aria-hidden=\"true\">\n" +
                                    "<a href=\"https://camp.kumtor.kg/#/approve-requests\" target=\"_blank\" rel=\"noopener noreferrer\" data-auth=\"NotApplicable\" data-safelink=\"true\" data-linkindex=\"0\">\n" +
                                    "Cсылка на  заявку.</a> </b></p>С уважением,<br aria-hidden=\"true\">\n" +
                                    "КГК Процесс </div></div></td></tr></tbody></table>", transferApplication.getFirstName(), transferApplication.getLastName(),
                            transferApplication.getEmpCode(), transferApplication.getDate_in(), transferApplication.getDate_out());
                    email.setBody(body);
                    notificationService.sendMessage(email);
                }
            } else if (transferApplication != null && transferApplication.getStatusId().equals("3")) {
                InfoApprover infoApprover = employeeDao.getInfoApproverByEmpCode(iterator.getApproverEmpCode());
                String emailTo = employeeDao.getEmailByEmpCode(transferApplication.getEmpCode());

                Email email = new Email();
                email.setFrom("kgc.flow@kumtor.kg");
                email.setTo(emailTo);
                email.setHeader("Заявка на транспорт и проживание в лагере");

                String body = String.format(
                        "<table border=\"0\" cellspacing=\"0\" cellpadding=\"8\" dir=\"ltr\">\n" +
                                "<tbody><tr><td align=\"left\" valign=\"top\"><div style=\"font-family:'Segoe UI Semilight','Segoe UI',Verdana,sans-serif; color:#444444\">\n" +
                                "<div style=\"margin-bottom:21px; font-size:18px\">Уважаемый пользователь!\n" +
                                "<br aria-hidden=\"true\">\n" +
                                "<p><b>Ваша заявка на транспортировку и проживание в лагере рудника Кумтор отклонена. \n" +
                                "<br aria-hidden=\"true\">Причина: отклонен пользователем %1$s %2$s %3$s \n" +
                                "<br aria-hidden=\"true\">%4$s  %5$s  (Таб.№ %6$s )\n" +
                                "<br aria-hidden=\"true\">c %7$s по %8$s <br aria-hidden=\"true\"></b></p>\n" +
                                "С уважением,<br aria-hidden=\"true\">\n" +
                                "КГК Процесс </div></div></td></tr></tbody></table>", infoApprover.getFirstName(), infoApprover.getLastName(), infoApprover.getTitle(), transferApplication.getFirstName(), transferApplication.getLastName(),
                        transferApplication.getEmpCode(), transferApplication.getDate_in(), transferApplication.getDate_out());
                email.setBody(body);
                notificationService.sendMessage(email);
            }
        }


    }

    @Override
    public void sendEmailCancelMyApplications(List<CancelMyApplicationDTO> applications) throws ApiException {
        String emailTo = null;
        TransferApplicationInfo transferApplicationInfo = null;

        for (CancelMyApplicationDTO application : applications) {

            if (application.getApplicationType().equalsIgnoreCase("заселение")) {
                transferApplicationInfo = transferDao.getInfoBooking(application.getId());
            } else {
                transferApplicationInfo = transferDao.getStatusTransferApplication(application.getId());
            }
            emailTo = employeeDao.getEmailByEmpCode(transferApplicationInfo.getEmpCode());
            Email email = new Email();
            email.setFrom("kgc.flow@kumtor.kg");
            email.setTo(emailTo);
            email.setHeader("Заявка на транспорт и проживание в лагере");

            String body = String.format(
                    "<table border=\"0\" cellspacing=\"0\" cellpadding=\"8\" dir=\"ltr\">\n" +
                            "<tbody><tr><td align=\"left\" valign=\"top\"><div style=\"font-family:'Segoe UI Semilight','Segoe UI',Verdana,sans-serif; color:#444444\">\n" +
                            "<div style=\"margin-bottom:21px; font-size:18px\">Уважаемый пользователь!\n" +
                            "<br aria-hidden=\"true\">\n" +
                            "<p><b>Ваша заявка на транспортировку и проживание в лагере рудника Кумтор была отменена Вами. \n" +
                            "<br aria-hidden=\"true\">%1$s  %2$s (Таб.№ %3$s) \n" +
                            "<br aria-hidden=\"true\">c %4$s по %5$s<br aria-hidden=\"true\">\n" +
                            "<a href=\"https://camp.kumtor.kg/#/approve-requests\" target=\"_blank\" rel=\"noopener noreferrer\" data-auth=\"NotApplicable\" data-safelink=\"true\" data-linkindex=\"0\">\n" +
                            "Cсылка на Вашу заявку</a> </b></p>С уважением,<br aria-hidden=\"true\">\n" +
                            "КГК Процесс </div></div></td></tr></tbody></table>", transferApplicationInfo.getFirstName(), transferApplicationInfo.getLastName(),
                    transferApplicationInfo.getEmpCode(), transferApplicationInfo.getDate_in(), transferApplicationInfo.getDate_out());
            email.setBody(body);
            notificationService.sendMessage(email);
        }

    }
    @Override
    public void sendEmailVahtaAndBusApproved(long busTransferId) throws ApiException {
        sendEmailVahtaAndBus(busTransferId, "одобрена ");
    }

    @Override
    public void sendEmailVahtaAndBusCanceled(long busTransferId) throws ApiException {
        sendEmailVahtaAndBus(busTransferId, "отклонена ");
    }

    private void sendEmailVahtaAndBus(long busTransferId, String type)throws ApiException{
        AccessToken accessToken = employeeDao.getAccessToken();

        String title = accessToken.getResourceAccess().get(accessToken.getIssuedFor()).getRoles().contains(Role.BUS_DISPATCHER.getValue()) ? "координатором пассажирских перевозок." : "диспетчером в Бишкеке.";

        TransferAppInfoDetail transferAppInfoDetail = transferDao.getEmpCodeByBusTransferId(busTransferId);
        String emailTo = employeeDao.getEmailByEmpCode(transferAppInfoDetail.getEmpCode());

        Email email = new Email();
        email.setFrom("kgc.flow@kumtor.kg");
        email.setTo(emailTo);
        email.setHeader("Заявка на транспортировку");

        String dateIn = transferAppInfoDetail.getDate_in();
        String dateOut = transferAppInfoDetail.getDate_out();

        if (dateIn.equals("1900-01-01")) {
            dateIn = dateOut;
        } else if (dateOut.equals("1900-01-01")) {
            dateOut = dateIn;
        }

        String body = String.format("<table border=\"0\" cellspacing=\"0\" cellpadding=\"8\" dir=\"ltr\">\n" +
                        "<tbody><tr><td align=\"left\" valign=\"top\"><div style=\"font-family:'Segoe UI Semilight','Segoe UI',Verdana,sans-serif; color:#444444\">\n" +
                        "<div style=\"margin-bottom:21px; font-size:18px\">Уважаемый пользователь!\n" +
                        "<br aria-hidden=\"true\">\n" +
                        "<p><b>Ваша заявка на транспортировку %1$s \n" +
                        "<br aria-hidden=\"true\">%2$s  %3$s (Таб.№ %4$s) \n" +
                        "<br aria-hidden=\"true\">c %5$s по %6$s<br aria-hidden=\"true\">\n" +
                        "по маршруту %7$s - %8$s</b>\n" +
                        "</p>С уважением,<br aria-hidden=\"true\">\n" +
                        "КГК Процесс </div></div></td></tr></tbody></table>", type + title, transferAppInfoDetail.getFirstName(), transferAppInfoDetail.getLastName(),
                transferAppInfoDetail.getEmpCode(), dateIn, dateOut, transferAppInfoDetail.getLocationFrom(), transferAppInfoDetail.getLocationTo());
        email.setBody(body);
        notificationService.sendMessage(email);
    }
}
