package kg.kumtor.camp.api.mainpage;

import kg.kumtor.camp.dto.statistics.BedStatsDTO;
import kg.kumtor.camp.dto.statistics.FullBookingStatsDTO;
import kg.kumtor.camp.dto.statistics.room.FullRoomStatsDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.StatisticsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.time.LocalDate;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@Slf4j
@RequestMapping("/statistics")
public class StatisticsController {
    private final StatisticsService statisticsService;

    public StatisticsController(StatisticsService statisticsService) {
        this.statisticsService = statisticsService;
    }

    @RolesAllowed("coordinator")
    @GetMapping("/beds")
    public BedStatsDTO getBedStats() throws ApiException {
        return statisticsService.getBedStats();
    }

    @RolesAllowed("coordinator")
    @GetMapping("/rooms")
    public FullRoomStatsDTO getRoomStats(@RequestParam(value = "date", required = false) String date,
                                         @RequestParam(value = "camp", required = false, defaultValue = "%%") String camp,
                                         @RequestParam(value = "block", required = false, defaultValue = "%%") String block) throws ApiException {
        if (date == null) {
            date = LocalDate.now().toString();
        }
        return statisticsService.getRoomStats(date, camp, block);
    }

    @RolesAllowed("coordinator")
    @GetMapping("/bookings")
    public FullBookingStatsDTO getBookingStats(@RequestParam(value = "date", required = false)
                                               @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) throws ApiException {
        return statisticsService.getBookingStats(date);
    }
}
