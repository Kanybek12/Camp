package kg.kumtor.camp.dto.transfer;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.Column;
import java.time.LocalDate;
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferApplicationDto {
    private Integer visitorTypeId;
    private Integer empCode;
    private String changedBy;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateBirth;
    private Integer genderId;
    @JsonProperty("pin")
    private String PIN;
    private String department;
    private String jobTitle;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate transferDateFrom;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate transferDateTo;
//    private Integer applicationTypeId;
    private boolean busTransferUp;
    private BusTransferDto busTransferUpDto;
    private boolean vahtaTransferUp;
    private BusTransferDto vahtaTransferUpDto;
    private boolean carTransfer;
    private CarTransferDto carTransferDto;
    private boolean carTransferDown;
    private CarTransferDto carTransferDownDto;
    private String receivingSide;
    private String note;
    private boolean agreement;
    private boolean campLiveNeed;
    private boolean busTransferDown;
    private BusTransferDto busTransferDownDto;
    private boolean vahtaTransferDown;
    private BusTransferDto vahtaTransferDownDto;
    private Integer receivingPerson;
    private boolean myApplication;
    private Integer createdBy;
}
