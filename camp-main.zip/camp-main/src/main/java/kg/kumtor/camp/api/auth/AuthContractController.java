package kg.kumtor.camp.api.auth;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.auth.KeycloakAddRoleDto;
import kg.kumtor.camp.dto.auth.RegisterDto;
import kg.kumtor.camp.dto.auth.SinCheckDto;
import kg.kumtor.camp.entity.Employee;
import kg.kumtor.camp.entity.Role;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.AuthContractService;
import kg.kumtor.camp.service.KeycloakService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static kg.kumtor.camp.exception.ExceptionsEnum.INVALID_SIN;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@CrossOrigin("*")
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/api")
public class AuthContractController {

    private final AuthContractService authContractService;

    private final KeycloakService keycloakService;

    @PostMapping("/addRole")
    public void addRoleToUser(@RequestBody KeycloakAddRoleDto roleDto) {
        keycloakService.addRealmRoleToUser(roleDto.getUserName(), roleDto.getRoleName());
    }

    @GetMapping("/roles")
    public List<String> getAllRoles() {
        return keycloakService.getAllRoles();
    }

    @PostMapping("/check/empcode")
    public ResponseDTO checkIsRegistered(@RequestBody Map<String, Integer> empCode) throws ApiException {
        if (authContractService.checkIsRegistered(empCode)) {
            return ResponseDTO.builder()
                    .code(200)
                    .message("Пользователь зарегистрирован и имеет пароль")
                    .build();
        } else {
            return ResponseDTO.builder()
                    .code(402)
                    .message("Пользователь не зарегистрирован и не имеет пароль")
                    .build();
        }
    }

    @PostMapping("/check/sin")
    public ResponseDTO checkSin(@RequestBody SinCheckDto sinDto) throws ApiException {
        boolean checkSin = authContractService.checkEmpCodeAndSin(sinDto.getEmpCode(), sinDto.getSin());
        if (checkSin) {
            return ResponseDTO.builder()
                    .code(200)
                    .message("Введён корректный ИНН")
                    .build();
        } else {
            throw new ApiException(INVALID_SIN.getCode(), INVALID_SIN.getMessage());
        }
    }

    @PostMapping(value = "/register", produces = "application/json")
    public ResponseDTO register(@RequestBody @Valid RegisterDto registerDto) throws ApiException {
        return authContractService.register(registerDto);
    }

    @PostMapping(value = "/update-password", produces = "application/json")
    public ResponseDTO updatePassword(@RequestBody RegisterDto credentials) throws ApiException {
        return authContractService.updatePassword(credentials);
    }

    @GetMapping("/token/refresh")
    public void refreshToken(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String authorizationHeader = request.getHeader(AUTHORIZATION);
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            try {
                String refresh_token = authorizationHeader.substring("Bearer ".length());
                Algorithm algorithm = Algorithm.HMAC256("SAljp2EhxBpdKsRSiEtOQhwupINgRLCf".getBytes(StandardCharsets.UTF_8)); // Use the same
                log.info("Provided refresh token: {}", refresh_token);
                // algorithm as defined in CustomAuthenticationFilter
                JWTVerifier verifier = JWT.require(algorithm).build();
                DecodedJWT decodedJWT = verifier.verify(refresh_token);
                String username = decodedJWT.getSubject();
                Employee employee = authContractService.getEmployee(username);
                String access_token = JWT.create()
                        .withSubject(String.valueOf(employee.getEmpCode()))
//                        .withExpiresAt(new Date(System.currentTimeMillis() + 10 * 60 * 1000)) // 10 min
                        .withExpiresAt(new Date(System.currentTimeMillis() + 30 * 60 * 1000)) // 30 min
                        .withIssuer(request.getRequestURL().toString())
                        .withClaim("roles",
                                employee.getRoles().stream().map(Role::getName).collect(Collectors.toList()))
                        .sign(algorithm);

                Map<String, String> tokens = new HashMap<>();
                tokens.put("access_token", access_token);
                tokens.put("refresh_token", refresh_token);
                response.setContentType(APPLICATION_JSON_VALUE);
                new ObjectMapper().writeValue(response.getOutputStream(), tokens);
            } catch (Exception exception) {
                log.error("Error logging in: {}", exception.getLocalizedMessage());
                log.error("Provided refresh token: {}", authorizationHeader.substring("Bearer ".length()));
                response.setHeader("error", exception.getLocalizedMessage());
                response.setStatus(OK.value());
                //response.sendError(FORBIDDEN.value());
                Map<String, String> error = new HashMap<>();
                error.put("code", "403");
                error.put("error_message", exception.getLocalizedMessage());
                response.setContentType(APPLICATION_JSON_VALUE);
                new ObjectMapper().writeValue(response.getOutputStream(), error);
            }
        } else {
            throw new RuntimeException("Refresh token is missing");
        }
    }
}
