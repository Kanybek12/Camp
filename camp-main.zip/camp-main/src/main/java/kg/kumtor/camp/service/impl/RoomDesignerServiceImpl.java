package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.RoomDesignerDao;
import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.roomdesigner.*;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.RoomDesignerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;
import static kg.kumtor.camp.utility.ResponseEnum.*;

@Service
@Slf4j
public class RoomDesignerServiceImpl implements RoomDesignerService {
    private final JdbcTemplate jdbcTemplate;

    private final RoomDesignerDao roomDesignerDao;

    public RoomDesignerServiceImpl(JdbcTemplate jdbcTemplate, RoomDesignerDao roomDesignerDao) {
        this.jdbcTemplate = jdbcTemplate;
        this.roomDesignerDao = roomDesignerDao;
    }

    public List<RoomDesignerDto> getRoomDesigner(LocalDate dateIn, Integer locationId, String blockId, String roomId,
                                                 Integer roomCapacity, Integer status, Integer size, Integer page, Integer gender, Integer category, String empCode) {
        page=(page-1)*size;
        if (dateIn == null) {
            dateIn = LocalDate.now();
        }
        roomId= (roomId.equals("")) ? null : roomId;
        blockId=(blockId.equals("")) ? null : blockId;
        List<RoomDesignerDto> roomDesignerDtos=new ArrayList<>();
        String query = "SELECT * FROM camp.get_room_designer(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Object[] args = new Object[]{dateIn, locationId, blockId, roomId, roomCapacity, status, page, size, gender, category, empCode};
        try {
            List<Map<String, Object>> response = jdbcTemplate.queryForList(query, args);
            if (response.size() != 0) {
                for (Map<String, Object> room : response){
                    RoomDesignerDto roomDesignerDto=new RoomDesignerDto();
                    roomDesignerDto.setRoom(String.valueOf(room.get("room")));
                    roomDesignerDto.setRoomCapacity(Integer.valueOf(String.valueOf(room.get("room_capacity"))));
                    roomDesignerDto.setGender(String.valueOf(room.get("gender")));
                    roomDesignerDto.setRoomCategory(String.valueOf(room.get("room_category")));
                    roomDesignerDto.setRoomCategoryId(Integer.valueOf(String.valueOf(room.get("room_category_id"))));
                    roomDesignerDto.setStatusText(String.valueOf(room.get("status_text")));
                    roomDesignerDto.setStatus(Integer.valueOf(String.valueOf(room.get("status"))));
                    roomDesignerDto.setRoomId(Long.valueOf(String.valueOf(room.get("room_id"))));
                    roomDesignerDtos.add(roomDesignerDto);
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return roomDesignerDtos;
    }

    public Map<String, Object> getRoomDetail(Integer id){
        Map<String, Object> roomDetailDto=new LinkedHashMap<>();
        List<Map<String,Object>> bedListDtos=new ArrayList<>();
        String query="\n" +
                "SELECT b.name ||'-'||LPAD(CAST(r.room_num AS varchar), 2, '0') AS room,\n" +
                "                r.room_gender_id||'- '||g.name as gender_id, r.room_capacity as room_capacity, r.room_category_id||'- '||rc.name_ru  as room_category_id,\n" +
                "                c.name_ru as camp, b.\"name\" as block\n" +
                "                from camp.room r \n" +
                "                 INNER JOIN camp.block b ON r.block_id=b.id \n" +
                "                 inner join camp.gender g on g.id=r.room_gender_id \n" +
                "                 inner join camp.room_category rc on rc.id=r.room_category_id \n" +
                "                 inner join camp.camp c on c.id =b.camp_id \n" +
                "                 where r.id=? \n" +
                "                group by b.name, r.room_num,gender_id, room_capacity,room_category_id,rc.name_ru, c.name_ru , b.\"name\" ";
        String queryBedList="SELECT bed.id as bed_id,bed.bed_type_id||'- '||bt.title  as bed_type,bed.bed_number_in_room bed_num\n" +
                "                FROM camp.bed bed\n" +
                "                inner join camp.room r on r.id=bed.room_id\n" +
                "                inner join camp.bed_type bt on bed.bed_type_id=bt.id \n" +
                "                where r.id=?\n" +
                "                  and bed.status='A'\n" +
                "                order by bed_num";
        Object[] args = new Object[]{id};
        try {
            List<Map<String, Object>> response = jdbcTemplate.queryForList(queryBedList, args);
            if (response.size() != 0) {
                Map<String, Object> roomRes = jdbcTemplate.queryForMap(query,args);
                roomDetailDto.put("room",String.valueOf(roomRes.get("room")));
                roomDetailDto.put("gender",String.valueOf(roomRes.get("gender_id")));
                roomDetailDto.put("roomCapacity",Integer.valueOf(String.valueOf(roomRes.get("room_capacity"))));
                roomDetailDto.put("roomCategory",String.valueOf(roomRes.get("room_category_id")));
                roomDetailDto.put("location",String.valueOf(roomRes.get("camp")));
                roomDetailDto.put("block",String.valueOf(roomRes.get("block")));
                for (Map<String, Object> room : response) {
                    Map<String,Object> bedListDto = new LinkedHashMap<>();
                    bedListDto.put("bedId", Integer.valueOf(String.valueOf(room.get("bed_id"))));
                    if (!String.valueOf(room.get("bed_type")).equals("null")) {
                        bedListDto.put("bedTypeId",String.valueOf(room.get("bed_type")));

                        // tkabirov, 29.11.22: добавить постоянных жителей
                        String queryVisitors = "select emp_code\n" +
                                "from camp.permanent_resident\n" +
                                "where bed_id = ?\n" +
                                "order by emp_code";
                        List<Integer> visitors = jdbcTemplate.queryForList(queryVisitors, Integer.class, Integer.valueOf(String.valueOf(room.get("bed_id"))));
                        bedListDto.put("visitors", visitors);
                    }

                    bedListDtos.add(bedListDto);
                }
                roomDetailDto.put("bedListDtos",bedListDtos);
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return roomDetailDto;
    }

    public ResponseDetailDTO addVisitor(int empCode, VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException {
        try {

            boolean existPermanentResident = jdbcTemplate.queryForObject("SELECT EXISTS(SELECT 1 FROM camp.permanent_resident pr WHERE pr.emp_code  = ?)",
                    Boolean.class, visitorSaveDetailDto.getEmpCode());
            if(existPermanentResident){
                return new ResponseDetailDTO(ALREADY_EXIST_PERMANENT_VISITOR.getCode(), ALREADY_EXIST_PERMANENT_VISITOR.getMessage(), null);
            }
            if(visitorSaveDetailDto.isUpdateAutoBooking()){
                List<ExistBookingListDto> listResult =  roomDesignerDao.callAutoBookingFunc(visitorSaveDetailDto);
                if(listResult.size() != 0)  {
                    return new ResponseDetailDTO(203, VISITOR_ADD_ERROR.getMessage(), listResult);
                }
            }
            jdbcTemplate.update("insert into camp.permanent_resident(emp_code, room_id, changed_by, date_changed, bed_id)\n" +
                            "values(?,\n" +
                            "  (select room_id from camp.bed where id = ?),\n" +
                            "  (select coalesce(max(first_name), 'system') from camp.employee where emp_code = ?),\n" +
                            "  now(),\n" +
                            "?)",
                    visitorSaveDetailDto.getEmpCode(), visitorSaveDetailDto.getBedId(), Integer.valueOf(empCode), visitorSaveDetailDto.getBedId());
            return new ResponseDetailDTO(VISITOR_ADDED.getCode(), VISITOR_ADDED.getMessage(), null);
        } catch (Exception ex) {
            log.error("Visitor add error: " + ex.getMessage());
            return new ResponseDetailDTO(VISITOR_ADD_ERROR.getCode(), VISITOR_ADD_ERROR.getMessage(), null);
        }
    }

    public ResponseDTO deleteVisitor(VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException {
        try {
            int rows_deleted = jdbcTemplate.update("delete from camp.permanent_resident\n" +
                            "where emp_code = ?\n" +
                            "  and bed_id = ?",
                    visitorSaveDetailDto.getEmpCode(), visitorSaveDetailDto.getBedId());
            log.info("Visitor with empCode: " + visitorSaveDetailDto.getEmpCode() + " deleted from bedId: " + visitorSaveDetailDto.getBedId());

            if (rows_deleted == 0) {
                return ResponseDTO.builder()
                        .code(VISITOR_NO_EMP_DELETE_ERROR.getCode())
                        .message(VISITOR_NO_EMP_DELETE_ERROR.getMessage())
                        .build();
            }

            return ResponseDTO.builder()
                    .code(VISITOR_DELETED.getCode())
                    .message(VISITOR_DELETED.getMessage())
                    .build();
        } catch (Exception ex) {
            log.error("Visitor add error: " + ex.getMessage());
            return ResponseDTO.builder()
                    .code(VISITOR_DELETE_ERROR.getCode())
                    .message(VISITOR_DELETE_ERROR.getMessage())
                    .build();
        }
    }

    public Map<String, Object> editRoom(Long id, RoomEditRequestBody roomDetailDto){
        String query = "UPDATE camp.room SET room_gender_id = ?, room_category_id = ?, date_changed = now() WHERE id = ?";
        Object[] args = new Object[]{roomDetailDto.getGender(), roomDetailDto.getRoomCategory(), id};
        try {
            jdbcTemplate.update(query, args);
         } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return getRoomDetail(Integer.valueOf(Math.toIntExact(id)));
    }

    @Override
    public PageableResponseDTO getPermanentResidents(Integer empCode, Integer locationId, String blockId, String roomId, Integer gender, Boolean isExistPermanent, Pageable pageable) throws ApiException {
        return roomDesignerDao.getPermanentResidents(empCode,locationId,blockId,roomId,gender,isExistPermanent, pageable);
    }
}