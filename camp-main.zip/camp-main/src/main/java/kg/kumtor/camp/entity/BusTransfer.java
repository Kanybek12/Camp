package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "bus_transfer")
public class BusTransfer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @ManyToOne
    @JoinColumn(name = "location_from", foreignKey = @ForeignKey(name = "fk_location_from"))
    private Location fromLocation;

    @ManyToOne
    @JoinColumn(name = "location_to", foreignKey = @ForeignKey(name = "fk_location_to"))
    private Location toLocation;

    @ManyToOne
    @JoinColumn(name = "mine_application_id", foreignKey = @ForeignKey(name = "fk_mine_application_id"))
    private TransferApplication transferApplicationId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", foreignKey = @ForeignKey(name = "fk_application_type_id"))
    private ApplicationType applicationTypeId;

    @ManyToOne
    @JoinColumn(name = "transfer_type_id", foreignKey = @ForeignKey(name = "fk_transfer_type_id"))
    private TransferType transferTypeId;

    @ManyToOne
    @JoinColumn(name = "transfer_status_id", foreignKey = @ForeignKey(name = "fk_transfer_status_id"))
    private TransferStatus transferStatusId;
}
