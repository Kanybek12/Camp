package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.BookingDetailForSetDto;
import kg.kumtor.camp.dto.BookingDto;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.booking.CancelConflictBooking;
import kg.kumtor.camp.exception.ApiException;

public interface BookingService {
    BookingDto saveBooking(BookingDto booking) throws Exception;
    BookingDetailForSetDto updateStatusOfBooking(BookingDetailForSetDto book,Integer id,boolean regular) throws Exception;
    ResponseDTO cancelManualBooking(CancelConflictBooking info) throws ApiException;
}
