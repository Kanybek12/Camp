package kg.kumtor.camp.dto.manual;

import java.util.Objects;

public class LocationDto {
    private int empCode;
    private String fullName;
    private String currentLocation;

    public LocationDto() {
    }

    public int getEmpCode() {
        return empCode;
    }

    public void setEmpCode(int empCode) {
        this.empCode = empCode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LocationDto location = (LocationDto) o;
        return empCode == location.empCode && Objects.equals(fullName, location.fullName) && Objects.equals(currentLocation, location.currentLocation);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empCode, fullName, currentLocation);
    }

    @Override
    public String toString() {
        return "Location{" +
                "empCode=" + empCode +
                ", fullName='" + fullName + '\'' +
                ", currentLocation='" + currentLocation + '\'' +
                '}';
    }
}
