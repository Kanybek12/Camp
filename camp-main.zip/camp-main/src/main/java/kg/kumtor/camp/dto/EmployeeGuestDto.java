package kg.kumtor.camp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeGuestDto {
    private Integer empCode;
    private String changedBy;
    private String firstName;
    private String lastName;
    private String pin;
    private String note;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateBirth;
    private int genderId;
    private String jobTitle;
    private String department;
    private String payAccount;
}
