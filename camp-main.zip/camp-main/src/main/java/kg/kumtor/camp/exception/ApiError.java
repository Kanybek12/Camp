package kg.kumtor.camp.exception;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.lang.annotation.Annotation;
import java.time.LocalDateTime;

public class ApiError {

    private int status;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private LocalDateTime timestamp=LocalDateTime.now();
    private String message;

    private ApiError() {
        timestamp = LocalDateTime.now();
    }

    public ApiError(int status, String message) {
        this.status = status;
        this.message = message;
    }

    public static ApiError fromApiException(ApiException apiException){
        return new ApiError(apiException.getCode(), apiException.getMessage());
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

//    @Override
//    public String value() {
//        return null;
//    }
//
//    @Override
//    public Class<? extends Annotation> annotationType() {
//        return null;
//    }
}
