package kg.kumtor.camp.api.mainpage;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.RejectApplicationDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.ApplicationService;
import kg.kumtor.camp.service.UtilityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/statistics")
public class ApplicationController {
    private final ApplicationService applicationService;
    private final UtilityService utilityService;

    @RolesAllowed("coordinator")
    @GetMapping("/applications/settlement")
    PageableResponseDTO getApplicationsForSettlement(@RequestParam(value = "page", required = true) int page,
                                                     @RequestParam(value = "department-id", required = false, defaultValue = "%%") String departmentId,
                                                     @RequestParam(value = "job-title-id", required = false, defaultValue = "%%") String jobTitleId,
                                                     @RequestParam(value = "date-in", required = false, defaultValue = "%%") String dateIn,
                                                     @RequestParam(value = "date-out", required = false, defaultValue = "%%") String dateOut,
                                                     @RequestParam(value = "visitor-type-id", required = false, defaultValue = "%%") String visitorTypeId,
                                                     @RequestParam(value = "on-schedule", required = false, defaultValue = "%%") String onSchedule,
                                                     @RequestParam(value = "empCode", required = false, defaultValue = "%%") String empCode) throws ApiException {
        return applicationService.getApplicationsForSettlement(PageRequest.of(page - 1, 10), empCode, dateIn, dateOut,
                visitorTypeId, departmentId, jobTitleId, onSchedule);
    }

    @RolesAllowed("coordinator")
    @DeleteMapping("applications/settlement/reject")
    public ResponseDTO rejectApplicationForSettlement(@RequestBody List<RejectApplicationDTO> rejectApplications) throws ApiException {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);
        return applicationService.rejectApplicationForSettlement(empCode, rejectApplications);
    }

}
