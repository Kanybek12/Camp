package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "work_location")
public class WorkLocation {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(nullable = false)
    private String name;

    @Column(name = "name_ru", nullable = false)
    private String nameRu;

    @Column(name = "is_active", nullable = false)
    private int isActive;

    @Column(name = "is_site_location", nullable = false)
    private int isSiteLocation;

    public WorkLocation(int id, String name, String nameRu, int isActive, int isSiteLocation) {
        this.id = id;
        this.name = name;
        this.nameRu = nameRu;
        this.isActive = isActive;
        this.isSiteLocation = isSiteLocation;
    }
}
