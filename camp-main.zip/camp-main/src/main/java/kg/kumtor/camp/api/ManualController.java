package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.manual.ManualLocationDto;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.ManualService;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequestMapping("/manual")
@RestController
public class ManualController {
    private final ManualService manualService;

    public ManualController(ManualService manualService) {
        this.manualService = manualService;
    }

    @GetMapping(value = "/getManualLocation")
    public ResponseEntity<PageableResponseDTO> getManualLocation(@RequestParam(value = "emp-code", required = false) Integer empCode,
                                                                 @RequestParam(value = "page", required = false, defaultValue = "1") int page,
                                                                 @RequestParam(value = "size", required = false, defaultValue = "10") int size) throws ApiException {
        return ResponseEntity.ok(manualService.getLocationInfo(empCode, PageRequest.of(page - 1, size)));
    }

    @PutMapping(value = "/updateLocationInfo")
    public ResponseEntity<ResponseDTO> updateLocationInfo(@RequestBody ManualLocationDto manualLocationDto) throws Exception {
        return ResponseEntity.ok(manualService.updateLocation(manualLocationDto));
    }


}
