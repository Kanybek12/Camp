package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.EmployeeInfoDto;
import kg.kumtor.camp.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    Employee findEmployeeByEmpCode(int empCode);

    Employee findEmployeeByEmpCodeAndSin(int empCode, int sin);

    boolean existsByEmpCode(int empCode);

    Employee findByEmpCode(Integer empCode);
    @Query("SELECT new kg.kumtor.camp.dto.reference.EmployeeInfoDto(emp.empCode," +
            " coalesce(emp.firstNameRu, emp.firstName)," +
            " coalesce(emp.lastNameRu,emp.lastName)," +
            " emp.genderId.id," +
            " coalesce(coalesce(d.titleRu, d.title),o.name)," +
            " coalesce(d.id,o.id)," +
            " coalesce(jt.titleRu, jt.title)," +
            " jt.id," +
            " coalesce(emp.dateBirth,'1900-01-01')," +
            " emp.sin," +
            " b.campId.id," +
            " b.id," +
            " r.id," +
            " r.genderId.id," +
            " bed.id," +
            " emp.payAccount," +
            " emp.employeeTypeId.id) " +
            "FROM Employee emp left join Department d on d.id = emp.departmentId.id \n" +
            "                  left join PermanentResident pr on pr.empCode = emp.empCode \n" +
            "                  left join Room r on r.id = pr.room.id \n" +
            "                  left join Block b on b.id = r.blockId.id \n" +
            "                  left join Bed bed on bed.id = pr.bed.id \n" +
            "                  left join Organization o on o.id = emp.organizationId.id \n" +
            "                  left join JobTitle jt on jt.id = emp.jobTitleId.id where emp.empCode= :empCode")
    EmployeeInfoDto findByEmpCodeForBooking(@Param("empCode") Integer empCode);
    Employee getEmployeeByEmailIgnoreCase(String email);

    Employee findBySinAndStatusCode(String inn, String statusCode);

}
