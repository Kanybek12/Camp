package kg.kumtor.camp.dto.reference.crud;

public class LocationCRUDDto {
    private int id;
    private byte isSiteLocation;
    private String statusCode;
    private String title;
    private String titleRu;
    private String changedBy;

    public LocationCRUDDto() {
    }

    public LocationCRUDDto(int id, short isSiteLocation, String statusCode, String title, String titleRu, String changedBy) {
        this.id = id;
        this.isSiteLocation = (byte)isSiteLocation;
        this.statusCode = statusCode;
        this.title = title;
        this.titleRu = titleRu;
        this.changedBy = changedBy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte getIsSiteLocation() {
        return isSiteLocation;
    }

    public void setIsSiteLocation(byte isSiteLocation) {
        this.isSiteLocation = isSiteLocation;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitleRu() {
        return titleRu;
    }

    public void setTitleRu(String titleRu) {
        this.titleRu = titleRu;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }
}
