package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.crud.RoomCategoryUtilityDTO;
import kg.kumtor.camp.entity.RoomCategory;
import kg.kumtor.camp.dto.reference.RoomCategoryDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoomCategoryRepository extends JpaRepository<RoomCategory, Integer> {

    @Query("SELECT new kg.kumtor.camp.dto.reference.RoomCategoryDto(r.id, r.nameRu) FROM RoomCategory r WHERE r.id<>3")
    List<RoomCategoryDto> findAllCatogery();

    @Query("SELECT NEW kg.kumtor.camp.dto.reference.crud.RoomCategoryUtilityDTO(rc.id, rc.changedBy, rc.name, rc.nameRu) " +
            "FROM RoomCategory AS rc ORDER BY rc.id")
    List<RoomCategoryUtilityDTO> findRoomCategoryListDTO();
}
