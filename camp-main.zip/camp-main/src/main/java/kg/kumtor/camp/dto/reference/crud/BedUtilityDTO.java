package kg.kumtor.camp.dto.reference.crud;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BedUtilityDTO {

    private Long id = null;
    private int bedNumberInRoom;
    private long roomId;
    private String roomNum;
    private int bedTypeId;
    private String bedTypeTitle;
    private String status;
    private String changedBy;
}
