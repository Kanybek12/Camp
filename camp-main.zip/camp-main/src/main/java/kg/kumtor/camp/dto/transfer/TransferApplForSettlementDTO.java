package kg.kumtor.camp.dto.transfer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransferApplForSettlementDTO {
    private long id;
    private LocalDate dateIn;
    private LocalDate dateOut;
    private String camp;
    private String room;
    private int bed;
    private String note;
    private String status;
}
