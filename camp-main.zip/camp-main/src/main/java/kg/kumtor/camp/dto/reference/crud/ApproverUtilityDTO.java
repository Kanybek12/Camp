package kg.kumtor.camp.dto.reference.crud;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApproverUtilityDTO {

    private Integer id = null;
    private int empCode;
    private int approverTypeId;
    private String approverTypeTitle;
    private String changedBy;
}
