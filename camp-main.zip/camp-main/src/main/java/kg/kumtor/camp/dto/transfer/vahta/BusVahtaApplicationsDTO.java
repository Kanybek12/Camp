package kg.kumtor.camp.dto.transfer.vahta;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BusVahtaApplicationsDTO {
    private Long transferId;
    private int empCode;
    private String fullName;
    private String visitorType;
    private LocalDate transferDate;
    private String applicationType;
    private String note;
    private String status;
    private boolean campLiveNeed;
    private String department;
    private String locationFrom;
    private String locationTo;
    private String creator;
    private String applicationTypeId;
}
