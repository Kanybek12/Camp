package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.crud.RoomCapacityUtilityDTO;
import kg.kumtor.camp.entity.RoomCapacity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoomCapacityRepository extends JpaRepository<RoomCapacity, Integer> {

    @Query("SELECT NEW kg.kumtor.camp.dto.reference.crud.RoomCapacityUtilityDTO (rc.capacity, rc.name, rc.changedBy) FROM " +
            "RoomCapacity AS rc ORDER BY rc.capacity")
    List<RoomCapacityUtilityDTO> findAllRoomCapacityDTO();
}
