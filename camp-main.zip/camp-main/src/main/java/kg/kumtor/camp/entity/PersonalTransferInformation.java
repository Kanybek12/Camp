package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "personal_transfer_information")
public class PersonalTransferInformation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @OneToOne
    @JoinColumn(name = "emp_code", foreignKey = @ForeignKey(name = "fk_emp_code"))
    private Employee empCode;

    @Column(name = "bus_transfer")
    private Boolean busTransfer;

    @ManyToOne
    @JoinColumn(name = "bus_location_from", foreignKey = @ForeignKey(name = "fk_bus_location_from"))
    private Location busLocationFrom;

    @ManyToOne
    @JoinColumn(name = "bus_location_to", foreignKey = @ForeignKey(name = "fk_bus_location_to"))
    private Location busLocationTo;

    @Column(name = "vahta_transfer")
    private Boolean vahtaTransfer;

    @ManyToOne
    @JoinColumn(name = "vahta_location_from", foreignKey = @ForeignKey(name = "fk_vahta_location_from"))
    private Location vahtaLocationFrom;

    @ManyToOne
    @JoinColumn(name = "vahta_location_to", foreignKey = @ForeignKey(name = "fk_vahta_location_to"))
    private Location vahtaLocationTo;

//    @Column(name = "personal_car_transfer")
//    private boolean personalCarTransfer;

//    @ManyToOne
//    @JoinColumn(name = "personal_car_location_from", foreignKey = @ForeignKey(name = "fk_personal_car_location_from"))
//    private Location personalCarLocationFrom;
//
//    @ManyToOne
//    @JoinColumn(name = "personal_car_location_to", foreignKey = @ForeignKey(name = "fk_personal_car_location_to"))
//    private Location personalCarLocationTo;

//    @Column(name = "company_car_transfer")
//    private boolean companyCarTransfer;

//    @ManyToOne
//    @JoinColumn(name = "company_car_location_from", foreignKey = @ForeignKey(name = "fk_company_car_location_from"))
//    private Location companyCarLocationFrom;
//
//    @ManyToOne
//    @JoinColumn(name = "company_car_location_to", foreignKey = @ForeignKey(name = "fk_company_car_location_to"))
//    private Location companyCarLocationTo;

    @Column(name = "car_transfer")
    private Boolean carTransfer;

    @ManyToOne
    @JoinColumn(name = "car_location_from", foreignKey = @ForeignKey(name = "fk_car_location_from"))
    private Location carLocationFrom;

    @ManyToOne
    @JoinColumn(name = "car_location_to", foreignKey = @ForeignKey(name = "fk_car_location_to"))
    private Location carLocationTo;

    @ManyToOne
    @JoinColumn(name = "car_type_id", foreignKey = @ForeignKey(name = "fk_car_type_id"))
    private CarType carTypeId;

    @Column(name = "car_number")
    private String carNumber;

    @Column(name = "car_model")
    private String carModel;

    @Column(name = "driver")
    private String driver;

    @ManyToOne
    @JoinColumn(name = "medical_examination_id", foreignKey = @ForeignKey(name = "fk_medical_examination_id"))
    private MedicalExamination medicalExaminationId;

    @ManyToOne
    @JoinColumn(name = "transfer_type_id", foreignKey = @ForeignKey(name = "fk_transfer_type_id"))
    private ApplicationType transferType;
}
