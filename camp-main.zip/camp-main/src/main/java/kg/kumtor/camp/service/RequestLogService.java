package kg.kumtor.camp.service;

import kg.kumtor.camp.entity.RequestLog;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface RequestLogService {
    RequestLog createLog(HttpServletRequest request);

    void addOrUpdateLog(HttpServletRequest request, HttpServletResponse response,ModelAndView modelAndView);
}
