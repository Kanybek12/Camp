package kg.kumtor.camp.dto.reference.crud;

public class BlockCRUDDto {
    private int id;
    private String name;
    private String changedBy;
    private int campId;
    private String campName;
    private String statusCode;
    public BlockCRUDDto() {
    }

    public BlockCRUDDto(int id, String name, String changedBy, int campId, String campName, String statusCode) {
        this.id = id;
        this.name = name;
        this.changedBy = changedBy;
        this.campId = campId;
        this.campName = campName;
        this.statusCode = statusCode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public int getCampId() {
        return campId;
    }

    public void setCampId(int campId) {
        this.campId = campId;
    }

    public String getCampName() {
        return campName;
    }

    public void setCampName(String campName) {
        this.campName = campName;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
