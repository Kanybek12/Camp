package kg.kumtor.camp.exception;

import kg.kumtor.camp.api.*;
import kg.kumtor.camp.api.auth.AuthContractController;
import kg.kumtor.camp.api.mainpage.ApplicationController;
import kg.kumtor.camp.api.mainpage.CheckController;
import kg.kumtor.camp.api.mainpage.InfoController;
import kg.kumtor.camp.api.mainpage.StatisticsController;
import kg.kumtor.camp.dto.ExceptionModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.IOException;

@ControllerAdvice(assignableTypes = {BookingController.class, BookingInfoController.class,
        ApplicationController.class, CheckController.class, InfoController.class, StatisticsController.class,
        AuthContractController.class, GuardPointPageController.class, KeycloakController.class, UtilityController.class, TransferController.class})
public class GlobalControllerAdvice {
    Logger logger = LoggerFactory.getLogger(GlobalControllerAdvice.class);

    @ExceptionHandler(value = {IOException.class, Throwable.class})
    public ResponseEntity<ApiError> handleIOException(ApiException ex) {
        MultiValueMap<String, String> headers = null;
        return new ResponseEntity(ApiError.fromApiException(ex), headers, ex.getCode());
    }

    @ExceptionHandler(value = ApiException.class)
    public ResponseEntity handleException(ApiException ex) {
        ExceptionModel exceptionModel = new ExceptionModel();
        exceptionModel.setCode(ex.getCode());
        exceptionModel.setMessage(ex.getMessage());
        logger.info("Error : {}", exceptionModel);
        return new ResponseEntity<>(exceptionModel, HttpStatus.OK);
    }
}
