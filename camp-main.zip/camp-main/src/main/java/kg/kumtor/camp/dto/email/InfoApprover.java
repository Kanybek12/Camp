package kg.kumtor.camp.dto.email;

import java.util.Objects;

public class InfoApprover {

    private Integer empCode;
    private String email;
    private String firstName;
    private String lastName;
    private String title;

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfoApprover that = (InfoApprover) o;
        return Objects.equals(empCode, that.empCode) && Objects.equals(email, that.email) && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(title, that.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empCode, email, firstName, lastName, title);
    }

    @Override
    public String toString() {
        return "EmpCodeApproverList{" +
                "empCode=" + empCode +
                ", email='" + email + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", title='" + title + '\'' +
                '}';
    }
}
