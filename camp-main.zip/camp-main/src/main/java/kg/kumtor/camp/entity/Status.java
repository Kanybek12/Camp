package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "status")
public class Status {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "title_ru", nullable = false)
    private String titleRu;

    public Status(String changedBy, LocalDateTime dateChanged, String title, String titleRu) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.title = title;
        this.titleRu = titleRu;
    }
}
