package kg.kumtor.camp.repository;

import kg.kumtor.camp.entity.CarTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CarVisitRepository extends JpaRepository<CarTransfer, Long> {
}
