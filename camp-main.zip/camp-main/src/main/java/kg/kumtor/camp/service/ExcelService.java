package kg.kumtor.camp.service;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface ExcelService {

    void writeHeader();
    void writeTransactionDataLines();

    void export(HttpServletResponse response) throws IOException;

    void createCell(Row row, int columnCount, Object value, CellStyle style, XSSFSheet sheet);
}
