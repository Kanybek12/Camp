package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Bed {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "room_id", foreignKey = @ForeignKey(name = "fk_room_id"))
    private Room roomId;

    @Column(name = "status", nullable = false, length = 1)
    private String status = "A";

    @Column(name = "bed_number_in_room")
    private int bedNumberInRoom;
    @ManyToOne
    @JoinColumn(name = "bed_type_id", foreignKey = @ForeignKey(name = "fk_bed_type_id"))
    private BedType bedTypeId;

    public Bed(String changedBy, LocalDateTime dateChanged, Room roomId, String status, int bedNumberInRoom,BedType bedTypeId) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.roomId = roomId;
        this.status = status;
        this.bedNumberInRoom = bedNumberInRoom;
        this.bedTypeId=bedTypeId;
    }
}
