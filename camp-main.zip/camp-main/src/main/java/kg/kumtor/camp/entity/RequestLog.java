package kg.kumtor.camp.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "request_log", schema = "camp")
public class RequestLog implements Serializable {

    private static final int VARCHAR_MAX_LENGTH = 4000;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "client_ip")
    private String clientIP;
    @Column(name = "timestamp", insertable = false, nullable = false)
    private LocalDateTime timestamp = LocalDateTime.now();

    @Column(name = "request_url")
    private String requestUrl;

    @Column(name = "in_params")
    private String inParams;

    @Column(name = "out_params")
    private String outParams;

    @Column(name = "request_method")
    private String requestMethod;

    @Column(name = "http_status")
    private String httpStatus;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "emp_code")
    private Employee employee;

    @Column(name = "session_id")
    private String sessionId;

    public RequestLog() {

    }

    public RequestLog(String clientIP, String requestUrl, String requestMethod) {
        this.clientIP = clientIP;
        this.requestUrl = requestUrl;
        this.requestMethod = requestMethod;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getInParams() {
        return inParams;
    }

    public void setInParams(String inParams) {
        if (inParams.length() < VARCHAR_MAX_LENGTH)
            this.inParams = inParams;
        else
            this.inParams = inParams.substring(0, VARCHAR_MAX_LENGTH);
    }

    public String getOutParams() {
        return outParams;
    }

    public void setOutParams(String outParams) {
        if (outParams.length() < VARCHAR_MAX_LENGTH)
            this.outParams = outParams;
        else
            this.outParams = outParams.substring(0, VARCHAR_MAX_LENGTH);
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(String httpStatus) {
        this.httpStatus = httpStatus;
    }


    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    @Override
    public String toString() {
        return "RequestLog{" +
                "id=" + id +
                ", clientIP='" + clientIP + '\'' +
                ", timestamp=" + timestamp +
                ", requestUrl='" + requestUrl + '\'' +
                ", inParams='" + inParams + '\'' +
                ", outParams='" + outParams + '\'' +
                ", requestMethod='" + requestMethod + '\'' +
                ", httpStatus='" + httpStatus + '\'' +
                ", employee=" + employee +
                ", sessionId='" + sessionId + '\'' +
                '}';
    }
}
