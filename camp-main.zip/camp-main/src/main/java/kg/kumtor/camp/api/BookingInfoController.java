package kg.kumtor.camp.api;


import kg.kumtor.camp.dto.*;
import kg.kumtor.camp.dto.booking.VacationInfo;
import kg.kumtor.camp.dto.reference.*;
import kg.kumtor.camp.dto.statistics.room.RoomInfoDTO;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.BookingInfoService;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequestMapping("/booking")
@RestController
public class BookingInfoController {

    private final BookingInfoService bookingInfoService;

    public BookingInfoController(BookingInfoService bookingInfoService) {
        this.bookingInfoService = bookingInfoService;
    }

    @GetMapping(value = "/get-block/by-date")
    public ResponseEntity<List<BlockDto>> getBlock(@RequestParam(value = "location-id", required = false, defaultValue  = "1") Integer locationId,
                                                   @RequestParam(value = "gender-id", required = false) Integer genderId,
                                                   @RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateIn,
                                                   @RequestParam(value = "date-out", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateOut) throws ApiException {

        return ResponseEntity.ok(bookingInfoService.getBlockByDateAndLocationId(locationId, genderId, dateIn, dateOut));
    }

    @GetMapping(value = "/get/room-category")
    public ResponseEntity<List<RoomCategoryDto>> getRoomCategory() {
        return ResponseEntity.ok(bookingInfoService.getRoomCategory());
    }

    @GetMapping(value = "/get-room/by-date")
    public ResponseEntity<List<RoomDto>> getRoom(@RequestParam(value = "block-id", required = false) Integer blockId, @RequestParam(value = "gender-id", required = false) Integer genderId,
                                                 @RequestParam(value = "room-capacity", required = false) Integer roomCapacity,
                                                 @RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateIn,
                                                 @RequestParam(value = "date-out", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateOut,
                                                 @RequestParam(value = "room-id", required = false) Integer roomId) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getRoomByDateAndBlockAndGender(roomId, blockId, dateIn, dateOut, genderId, roomCapacity));
    }

    @GetMapping(value = "/get-location")
    public ResponseEntity<List<LocationDto>> getLocation() {
        return ResponseEntity.ok(bookingInfoService.getLocation());
    }

    @GetMapping(value = "/get-room/quantity")
    public ResponseEntity<Map<String, Object>> getRoomQuantity(@RequestParam(value = "room-id") Integer roomId,
                                                               @RequestParam(value = "date-in") @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateIn,
                                                               @RequestParam(value = "date-out") @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateOut) {
        return ResponseEntity.ok(bookingInfoService.getQuantityOfBedInRoom(roomId, dateIn, dateOut));
    }

    @GetMapping(value = "/get-room/capacity")
    public ResponseEntity<List<Map<String, Object>>> getRoomCapacity(@RequestParam(value = "block-id", required = false) Integer blockId,
                                                                     @RequestParam(value = "gender-id", required = false) Integer genderId,
                                                                     @RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateIn,
                                                                     @RequestParam(value = "date-out", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateOut) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getRoomCapacityList(blockId, genderId, dateIn, dateOut));
    }

    @GetMapping(value = "/get-bed")
    public ResponseEntity<List<BedDto>> getBed(@RequestParam(value = "room-id", required = false) Integer roomId,
                                               @RequestParam(value = "bed-id", required = false) Integer bedId,
                                               @RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateIn,
                                               @RequestParam(value = "date-out", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateOut) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getBed(roomId, dateIn, dateOut, bedId));
    }

    @GetMapping(value = "/get-employee/{emp-code}")
    public ResponseEntity<EmployeeInfoDto> getEmployeeByEmpCode(@PathVariable(value = "emp-code") Integer empCode) {
        return ResponseEntity.ok(bookingInfoService.getEmployeeInfoByEmpCode(empCode));
    }

    @GetMapping(value = "/get-emp-codes")
    public ResponseEntity<List<Integer>> getEmpCodes(@RequestParam(value = "visitor-type", required = false) Integer empType) {
        return ResponseEntity.ok(bookingInfoService.getEmpCodes(empType));
    }

    @GetMapping("/rooms-info")
    public Map<String, List<RoomInfoDTO>> getRooms() {
        return bookingInfoService.getRoomsInfo();
    }

    @GetMapping(value = "/get-booking-for-change/{id}")
    public ResponseEntity<ChangeBookingDto> getBookingInfoForChangeDate(@PathVariable(value = "id") Integer bookingId) throws Exception {
        return ResponseEntity.ok(bookingInfoService.getBookingForChangeDate(bookingId));
    }

    @GetMapping(value = "/get-all-rooms/filter")
    public ResponseEntity<List<RoomFilterDto>> getAllRoomsWithFilter(@RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateIn,
                                                                     @RequestParam(value = "location-id", required = false) Integer locationId, @RequestParam(value = "block-name", required = false) String blockId, @RequestParam(value = "room-num", required = false) String roomId,
                                                                     @RequestParam(value = "emp-code", required = false) Integer empCode, @RequestParam(value = "emp-type", required = false) Integer empType, @RequestParam(value = "status", required = false) Integer status,
                                                                     @RequestParam(value = "page", required = false, defaultValue = "1") Integer page, @RequestParam(value = "size", required = false, defaultValue = "9") Integer size) {
        return ResponseEntity.ok(bookingInfoService.getAllRoomsWithFilter(dateIn, locationId, blockId, roomId, empCode, empType, status, size, page));
    }

    @GetMapping(value = "/get-booking-status")
    public ResponseEntity<List<BookingStatusDto>> getBookingStatus() {
        return ResponseEntity.ok(bookingInfoService.getBookingStatus());
    }

    @GetMapping(value = "/set-booking/{id}")
    public ResponseEntity<BookingDetailForSetDto> getBookingInfoForSetById(@PathVariable(value = "id") Integer bookingId) throws Exception {
        return ResponseEntity.ok(bookingInfoService.getBookingInfoByEmpCodeForSetBook(bookingId));
    }

    @GetMapping(value = "/from-booking-list")
    public ResponseEntity<Map<String, Object>> getInfoFromBookingListPageToBooking(@RequestParam(value = "bed-id", required = false) Integer bedId,
                                                                                   @RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateIn,
                                                                                   @RequestParam(value = "date-out", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateOut) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getInfoForBookFromBookingListPage(bedId, dateIn, dateOut));
    }

    @GetMapping(value = "/bed-info")
    public ResponseEntity<List<Map<String, Object>>> getBookingListByBedId(@RequestParam(value = "bed-id", required = false) Integer bedId) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getBookingListByBedId(bedId));
    }
    @GetMapping("/all-booking-list")
    public PageableResponseDTO getAllBookingList(@RequestParam(value = "page", required = false, defaultValue = "1") int page,
                                                 @RequestParam(value = "dateIn", required = false,
                                                         defaultValue = "") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateIn,
                                                 @RequestParam(value = "dateOut", required = false,
                                                         defaultValue = "") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateOut,
                                                 @RequestParam(value = "checkIn", required = false, defaultValue =
                                                         "") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate checkIn,
                                                 @RequestParam(value = "checkOut", required = false, defaultValue =
                                                         "") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate checkOut,
                                                 @RequestParam(value = "emp-code", required = false) Integer empCode)
            throws ApiException{
        return bookingInfoService.getAllBookingList(PageRequest.of(page - 1, 10), dateIn, dateOut, checkIn, checkOut, empCode);
    }

    @GetMapping(value = "/get-conflict-booking")
    public ResponseEntity<PageableResponseDTO> getConflictBooking(@RequestParam(value = "emp-code", required = false) Integer empCode,
                                                                    @RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateIn,
                                                                    @RequestParam(value = "date-out", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateOut,
                                                                    @RequestParam(value = "emp-type", required = false) Integer empType,
                                                                    @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
                                                                    @RequestParam(value = "size", required = false, defaultValue = "9") Integer size) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getConflictBooking(empCode, dateIn, dateOut, empType,PageRequest.of(page - 1, size)));
    }

    @GetMapping(value = "/vacation-detail-info/{bedId}")
    public ResponseEntity<VacationInfo> getVacationDetailInfo(@PathVariable(value = "bedId") int bedId) throws ApiException {
        return ResponseEntity.ok(bookingInfoService.getVacationDetailInfo(bedId));
    }
}
