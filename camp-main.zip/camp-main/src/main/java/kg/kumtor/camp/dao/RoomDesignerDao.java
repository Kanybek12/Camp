package kg.kumtor.camp.dao;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.manual.LocationDto;
import kg.kumtor.camp.dto.roomdesigner.ExistBookingListDto;
import kg.kumtor.camp.dto.roomdesigner.PermanentResidentsDto;
import kg.kumtor.camp.dto.roomdesigner.VisitorSaveRequestBody;
import kg.kumtor.camp.exception.ApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.List;

import static kg.kumtor.camp.exception.ExceptionsEnum.EMPTY_RESULT;

@Repository
@Slf4j
public class RoomDesignerDao {

    private final JdbcTemplate jdbcTemplate;

    public RoomDesignerDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public PageableResponseDTO getPermanentResidents(Integer empCode, Integer locationId, String blockId, String roomId, Integer gender,Boolean isExistPermanent, Pageable pageable) throws ApiException {
        List<PermanentResidentsDto> resultList = null;
        log.info("call getPermanentResidents");
        String query = "select\n" +
                "e.emp_code,\n" +
                "coalesce (e.last_name_ru || ' ' || e.first_name_ru , e.last_name || ' ' || e.last_name) as fullName,\n" +
                "b.name || '-' || LPAD(CAST(r.room_num AS varchar), 2, '0') AS room,\n" +
                "coalesce (jt.title_ru, jt.title) AS job_title,\n" +
                "(COALESCE(dr.title_ru, d.title_ru, ''::character varying)::text || ' '::text) || COALESCE('/ '::text || o.name::text, ''::text) as department\n" +
                "from camp.employee e\n" +
                "left join camp.permanent_resident pr on pr.emp_code = e.emp_code\n" +
                "left join camp.room r on pr.room_id = r.id\n" +
                "left join camp.block b on r.block_id = b.id \n" +
                "left JOIN camp.organization o ON e.organization_id = o.id\n" +
                "left JOIN camp.department d ON e.department_id = d.id\n" +
                "LEFT JOIN camp.employee_rm_department erd ON e.emp_code = erd.emp_code\n" +
                "LEFT JOIN camp.department_rm dr ON dr.id = erd.department_rm_id\n" +
                "LEFT JOIN camp.job_title AS jt on e.job_title_id = jt.id\n" +
                "where e.status_code = 'A' \n" +
                "AND e.employee_type_id = 1 --Штатный сотрудник рудника\n" +
                "AND (?::INTEGER IS NULL OR e.emp_code = ?)\n" +
                "AND (?::INTEGER IS NULL OR b.camp_id = ?)\n" +
                "AND (?::varchar = '' OR b.name = ?)\n" +
                "AND (?::varchar = '' OR r.room_num = ?)\n" +
                "AND (?::INTEGER IS NULL OR r.room_gender_id = ?)\n" +
                (isExistPermanent == null? "" : isExistPermanent ? "AND b.name is not null \n" : "AND b.name is null \n") +
                "LIMIT ? OFFSET ?";
        try {
            resultList = jdbcTemplate.query(query,
                    new Object[]{empCode, empCode, locationId, locationId, blockId, blockId, roomId, roomId, gender, gender, pageable.getPageSize(), pageable.getOffset()},
                    new BeanPropertyRowMapper<>(PermanentResidentsDto.class));

            log.info("List of getPermanentResidents");

            PageImpl<PermanentResidentsDto> applicationsPages = new PageImpl<>(
                    resultList, pageable, countPermanentList(isExistPermanent));
            return PageableResponseDTO.builder()
                    .pageNumber(applicationsPages.getNumber() + 1)
                    .totalPages(applicationsPages.getTotalPages())
                    .content(applicationsPages.getContent())
                    .build();
        } catch (Exception ex) {
            log.error("Error while getting list of getPermanentResidents: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }

    public int countPermanentList(Boolean isExistPermanent) {
        return jdbcTemplate.queryForObject("select\n" +
                "count(1) \n" +
                "from camp.employee e\n" +
                "left join camp.permanent_resident pr on pr.emp_code = e.emp_code\n" +
                "left join camp.room r on pr.room_id = r.id\n" +
                "left join camp.block b on r.block_id = b.id \n" +
                "left JOIN camp.organization o ON e.organization_id = o.id\n" +
                "left JOIN camp.department d ON e.department_id = d.id\n" +
                "LEFT JOIN camp.employee_rm_department erd ON e.emp_code = erd.emp_code\n" +
                "LEFT JOIN camp.department_rm dr ON dr.id = erd.department_rm_id\n" +
                "LEFT JOIN camp.job_title AS jt on e.job_title_id = jt.id\n" +
                "where e.status_code = 'A' \n" +
                "AND e.employee_type_id = 1 --Штатный сотрудник рудника\n" +
                (isExistPermanent == null ? "" : isExistPermanent ? "AND b.name is not null" : "AND b.name is null"), Integer.class);
    }

    public List<ExistBookingListDto> callAutoBookingFunc(VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException {
        String query = "select emp_code," +
                "full_name," +
                "bed_id," +
                "date_in," +
                "date_out," +
                "status," +
                "booked_emp_code," +
                "booked_full_name," +
                "booked_bed_id," +
                "booked_date_in," +
                "booked_date_out," +
                "booked_status from camp.func_refresh_room(?, ?)";
        try {

            log.info("List of get ExistBookingList");

            return  jdbcTemplate.query(query,
                    new Object[]{ visitorSaveDetailDto.getEmpCode(), visitorSaveDetailDto.getBedId() },
                    new int[] {Types.INTEGER, Types.INTEGER},
                    new BeanPropertyRowMapper<>(ExistBookingListDto.class));
        } catch (Exception ex) {
            log.error("Error while getting list of callAutoBookingFunc: {}", ex.getMessage());
            throw new ApiException(EMPTY_RESULT.getCode(), EMPTY_RESULT.getMessage());
        }
    }
}
