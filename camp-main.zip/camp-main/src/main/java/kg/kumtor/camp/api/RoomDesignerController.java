package kg.kumtor.camp.api;

import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.roomdesigner.RoomDesignerDto;
import kg.kumtor.camp.dto.roomdesigner.RoomEditRequestBody;
import kg.kumtor.camp.dto.roomdesigner.VisitorSaveRequestBody;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.RoomDesignerService;
import kg.kumtor.camp.service.UtilityService;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RequestMapping("/room-designer")
@RestController
public class RoomDesignerController {
    private final RoomDesignerService roomDesignerService;
    private final UtilityService utilityService;

    public RoomDesignerController(RoomDesignerService roomDesignerService, UtilityService utilityService) {
        this.roomDesignerService = roomDesignerService;
        this.utilityService = utilityService;
    }
    @GetMapping(value = "/get/room")
    public ResponseEntity<List<RoomDesignerDto>> getRoomDesigner(@RequestParam(value = "date-in", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateIn ,
                                                                 @RequestParam(value = "location-id", required = false) Integer locationId,
                                                                 @RequestParam(value = "block-name", required = false) String blockId,
                                                                 @RequestParam(value = "room-num", required = false) String roomId,
                                                                 @RequestParam(value = "room-capacity", required = false) Integer roomCapacity,
                                                                 @RequestParam(value = "status", required = false) Integer status,
                                                                 @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
                                                                 @RequestParam(value = "size", required = false, defaultValue = "5") Integer size,
                                                                 @RequestParam(value = "gender", required = false) Integer gender,
                                                                 @RequestParam(value = "category", required = false) Integer category,
                                                                 @RequestParam(value = "empCode", required = false, defaultValue = "") String empCode){
        return ResponseEntity.ok(roomDesignerService.getRoomDesigner(dateIn,locationId,blockId,roomId,roomCapacity,status, size, page, gender, category, empCode));
    }
    @GetMapping(value = "/get/room-details/{id}")
    public ResponseEntity<Map<String, Object>> getRoomDetail(@PathVariable(value = "id") Integer id){
        return ResponseEntity.ok(roomDesignerService.getRoomDetail(id));
    }

    @PutMapping(value = "/edit/room/{id}")
    public ResponseEntity<Map<String, Object>>editRoom(@PathVariable(value = "id") Long id,
                                                       @RequestBody RoomEditRequestBody roomDetailDto){
        return ResponseEntity.ok(roomDesignerService.editRoom(id, roomDetailDto));
    }

    @PostMapping(value = "/visitors")
    public ResponseDTO saveVisitor(@RequestBody VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException {
        KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        int empCode = utilityService.getEmpCodeByAuthToken(authentication);

        return roomDesignerService.addVisitor(empCode, visitorSaveDetailDto);
    }

    @DeleteMapping(value = "/visitors")
    public ResponseDTO deleteVisitor(@RequestBody VisitorSaveRequestBody visitorSaveDetailDto) throws ApiException {
        return roomDesignerService.deleteVisitor(visitorSaveDetailDto);
    }

    @GetMapping(value = "/get/permanent-resident")
    public ResponseEntity<PageableResponseDTO> getPermanentResidents(
                                                                             @RequestParam(value = "emp-code", required = false, defaultValue = "") Integer empCode,
                                                                             @RequestParam(value = "location-id", required = false) Integer locationId,
                                                                             @RequestParam(value = "block-name", required = false) String blockId,
                                                                             @RequestParam(value = "room-num", required = false) String roomId,
                                                                             @RequestParam(value = "gender", required = false) Integer gender,
                                                                             @RequestParam(value = "is-exist-permanent", required = false) Boolean isExistPermanent,
                                                                             @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
                                                                             @RequestParam(value = "size", required = false, defaultValue = "10") Integer size) throws ApiException {
        return ResponseEntity.ok(roomDesignerService.getPermanentResidents(empCode,locationId,blockId,roomId,gender,isExistPermanent, PageRequest.of(page - 1, size)));
    }
}
