package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.auth.KeycloakUserDto;
import kg.kumtor.camp.dto.auth.RegisterDto;
import org.keycloak.representations.idm.UserRepresentation;

import java.util.List;

public interface KeycloakService {
    void addUser(KeycloakUserDto userDto);

    List<UserRepresentation> getUser(String userName);

    List<String> getAllRoles();

    void addRealmRoleToUser(String userName, String role_name);
}
