package kg.kumtor.camp.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ExceptionsEnum {

    APPLICATIONS_FOR_SETTLEMENT_NOT_FOUND(500, "Не удалось получить список заявок на заселение"),
    APPLICATIONS_FOR_SETTLEMENT_NOT_REJECTED(500, "Не удалось отменить заявку на заселение"),
    PASSWORDS_DONT_MATCH(400, "Пароли не совпадают"),
    INVALID_SIN(400, "Введён некорректный ИНН"),
    EMPLOYEE_NOT_FOUND(409, "Сотрудник с табельным номером %s не найден в системе"),
    EMPLOYEE_DONT_HAVE_SIN(409, "У сотрудника с табельным номером %s не указан ИНН в базе данных"),
    BOOKINGS_NOT_FOUND(500, "Не удалось получить список броней"),
    CHECKIN_ALREADY_EXISTS(400, "Невозможно установить дату. Дата заезда уже установлена"),
    NO_CHECKIN_DATE(400, "Невозможно установить дату выезда. Дата заезда не установлена"),
    CHECKOUT_DATE_BEFORE_CHECKIN(400, "Невозможно установить дату выезда. Дата выезда меньше даты заезда"),
    CHECKOUT_ALREADY_EXISTS(400, "Дата выезда уже установлена"),
    CHECKIN_NOT_CANCELED(400, "У брони некорректный статус или не указана дата заезда"),
    GUARDPOINT_RECORDS_NOT_FOUND(500, "Не удалось получить список записей с GuardPoint"),
    BED_STATISTICS_ERROR(500, "Не удалось получить общее количество свободных и занятых койко-мест по гендеру"),
    ROOM_STATISTICS_ERROR(500, "Не удалось получить отчет по комнатам"),
    BOOKING_STATISTICS_ERROR(500, "Не удалдось получить отчет по броням"),
    VISITOR_TYPES_ERROR(500, "Не удалось получить список типов посетителей"),
    DEPARTMENTS_ERROR(500, "Не удалось получить список отделов"),
    JOB_TITLES_ERROR(500, "Не удалось получить список должностей"),
    EMPLOYEES_ERROR(500, "Не удалось получить список сотрудников"),
    EMPTY_RESULT(500, "Ничего не найдено"),
    SAVE_ERROR(500,"Не удалось сохранить запись"),
    UPDATE_ERROR(500, "Не удалось обновить запись"),
    ROOM_CAPACITY_UPDATE_ERROR(500, "Не удалось обновить запись с вместимостью комнаты"),
    ROOM_CAPACITIES_ERROR(500, "Не удалось получить список вместимостей комнат"),
    ROOM_CAPACITY_ADD_ERROR(500, "Не удалось добавить запись с вместимостью комнат"),
    ROOM_CAPACITY_ALREADY_EXISTS(403, "Запись с такой вместимостью комнат уже существует"),
    ROOM_CATEGORY_UPDATE_ERROR(500, "Не удалось обновить запись с категорией комнат"),
    ROOM_CATEGORIES_ERROR(500, "Не удалось получить список категорий комнат"),
    ROOM_CATEGORY_ADD_ERROR(500, "Не удалось добавить запись с категорией комнат"),
    BED_LIST_ERROR(500, "Не удалось получить список кроватей"),
    BED_TYPE_LIST_ERROR(500,  "Не удалось получить список типов кроватей"),
    BED_ADD_ERROR(500, "Не удалось добавить запись кровати"),
    BED_UPDATE_ERROR(500, "Не удалось обновить запись кровати"),
    BED_DELETE_ERROR(500, "Не удалось удалить запись(и) кровати(ей)"),
    BED_MAX_EXCEEDED_ERROR(500, "Превышено максимальное число кроватей на комнату"),
    EMPLOYEE_LIST_ERROR(500, "Не удалось получить список пользователей с типом 'Гость'"),
    EMPLOYEE_ADD_ERROR(500, "Не удалось добавить пользователя с типом 'Гость'"),
    EMPLOYEE_UPDATE_ERROR(500, "Не удалось обновить пользователя с типом 'Гость'"),
    EMPLOYEE_DELETE_ERROR(500, "Не удалось удалить пользователя с типом 'Гость'"),
    PERSONAL_INFO_ERROR(500, "Не удалось получить личную информацию для пользователя: "),
    PERSONAL_TRANSFER_ASCENT_ERROR(500, "Не удалось получить информацию по трансортировке на подъём"),
    PERSONAL_TRANSFER_DESCENT_ERROR(500, "Не удалось получить информацию по трансортировке на спуск"),
    PERSONAL_TRANSFER_ASCENT_SAVE_ERROR(500, "Не удалось сохранить информацию по транспортировке на подъём"),
    PERSONAL_TRANSFER_DESCENT_SAVE_ERROR(500, "Не удалось сохранить информацию по транспортировке на спуск"),
    APPROVER_LIST_ERROR(500, "Не удалось получить список утвердителей"),
    APPROVER_ADD_ERROR(500, "Не удалось добавить утвердителя"),
    APPROVER_UPDATE_ERROR(500, "Не удалось обновить утвердителя"),
    APPROVER_DELETE_ERROR(500, "Не удалось удалить утвердителя"),
    NO_FREE_ROOMS_ERROR(500, "Свободных комнат нет"),
    VISITOR_ADD_ERROR(500, "Не удалось добавить постоянного жителя"),
    VISITOR_ADD_MORE_THAN_TWO_ERROR(500, "Нельзя размещать более двух постоянных жителей на одной кровати"),
    VISITOR_ADD_SAME_EMP_ERROR(500, "Нельзя размещать того же жителя на одной кровати второй раз"),
    VISITOR_DELETE_ERROR(500, "Не удалось удалить постоянного жителя"),
    VISITOR_NO_EMP_DELETE_ERROR(500, "Передан номер постоянного жителя, не размещенного на данной кровати"),

    ALREADY_EXIST_PERMANENT_VISITOR(500, "Уже существует такой постоянный житель!"),
    COST_CENTER_ERROR(500, "Не удалось получить список центра затраты");

    private int code;
    private String message;
}
