package kg.kumtor.camp.dao;

import kg.kumtor.camp.dto.booking.CancelConflictBooking;
import kg.kumtor.camp.dto.booking.VacationInfo;
import kg.kumtor.camp.exception.ApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.*;
import java.time.LocalDateTime;

@Slf4j
@Repository
public class BookingDao {

    private static final String ERROR_MESSAGE = "Ошибка при отмене ручной брони";
    private final JdbcTemplate jdbcTemplate;

    public BookingDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public void cancelConflictBooking(CancelConflictBooking info, String changedByEmpCode) throws ApiException {

        try (Connection con = jdbcTemplate.getDataSource().getConnection();
             PreparedStatement ps = con.prepareStatement(
                           "UPDATE camp.booking SET status_id = 6, changed_by = ?, date_changed = ? WHERE id = ?;"
                             + "UPDATE camp.conflict_booking SET status_id = 6, changed_by = ?, date_changed = ? WHERE id = ?;"
                             + "UPDATE camp.transfer_application SET status_id = 2, changed_by = ?, date_changed = ? WHERE booking_id = ?")) {
            con.setAutoCommit(false);
            int res = 0;
            ps.setString(1, changedByEmpCode);
            ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            ps.setLong(3, info.getId());
            ps.setString(4, changedByEmpCode);
            ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            ps.setLong(6, info.getConfId());
            ps.setString(7, changedByEmpCode);
            ps.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
            ps.setLong(9, info.getConfId());
            res += ps.executeUpdate();
            con.commit();
            if (res == 0) {
                throw new ApiException(500, ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            throw new ApiException(500, ERROR_MESSAGE);
        }

    }

    public VacationInfo getVacationDetailInfo(int bedId) {
        String query = " select esv.emp_code,\n" +
                " e.emp_code || ' ' || coalesce(e.last_name_ru, e.last_name ) || ' ' || coalesce(e.first_name_ru,  e.first_name) as emp_info,\n" +
                " MIN(esv.date_sel) as date_in,\n" +
                " MAX(esv.date_sel) as date_out\n" +
                " FROM camp.permanent_resident pr \n" +
                " INNER JOIN camp.employee_schedule_vacation esv ON esv.emp_code = pr.emp_code\n" +
                " left join camp.employee e on pr.emp_code = e.emp_code  \n" +
                " WHERE pr.bed_id = ? \n" +
                " GROUP by esv.emp_code , e.emp_code;";
        return jdbcTemplate.queryForObject(query, new Object[]{ bedId }, new int[] { Types.INTEGER }, new BeanPropertyRowMapper<>(VacationInfo.class));
    }
}
