package kg.kumtor.camp.entity;

import lombok.*;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import javax.persistence.*;

@Entity
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "guest_detail_info", schema = "camp")
public class GuestDetailInfo {

    @Id
    @Column(name = "emp_code")
    private int empCode;

    @Column(name = "department")
    private String department;

    @Column(name = "job_title")
    private String jobTitle;

    @Column(name = "changed_by")
    private String changedBy;

    @Column(name = "date_changed")
    private LocalDateTime dateChanged;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_code", referencedColumnName = "emp_code", insertable = false, updatable = false)
    private Employee employee;
}