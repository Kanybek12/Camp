package kg.kumtor.camp.repository;

import kg.kumtor.camp.entity.WorkLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WorkLocationRepository extends JpaRepository<WorkLocation, Integer> {
}
