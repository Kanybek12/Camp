package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "job_title")
public class JobTitle {

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed" , nullable = false)
    private LocalDateTime dateChanged;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "code", nullable = false, unique = true)
    private String code;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "title_ru")
    private String titleRu;

    @Column(name = "is_active",length = 1, nullable = false)
    private int isActive;

    public JobTitle(String changedBy, LocalDateTime dateChanged, String code, String title, String titleRu, int isActive) {
        this.changedBy = changedBy;
        this.dateChanged = dateChanged;
        this.code = code;
        this.title = title;
        this.titleRu = titleRu;
        this.isActive = isActive;
    }
}
