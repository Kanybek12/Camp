package kg.kumtor.camp.dto.transfer;

public class BusTransferResponseDto {
    private String fromLocationName;
    private String toLocationName;

    public BusTransferResponseDto() {
    }

    public BusTransferResponseDto(String fromLocationName, String toLocationName) {
        this.fromLocationName = fromLocationName;
        this.toLocationName = toLocationName;
    }

    public String getFromLocationName() {
        return fromLocationName;
    }

    public void setFromLocationName(String fromLocationName) {
        this.fromLocationName = fromLocationName;
    }

    public String getToLocationName() {
        return toLocationName;
    }

    public void setToLocationName(String toLocationName) {
        this.toLocationName = toLocationName;
    }
}
