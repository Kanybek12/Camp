package kg.kumtor.camp.dto.booking;

import lombok.*;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancelConflictBooking {
    private long id;
    private long confId;
}
