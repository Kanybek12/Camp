package kg.kumtor.camp.dto.transfer;

import lombok.*;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferEmployeeDTO {

    private int empCode;
    private String name;
    private String visitorType;
}
