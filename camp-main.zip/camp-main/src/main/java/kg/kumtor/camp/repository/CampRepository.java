package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.reference.CampDto;
import kg.kumtor.camp.dto.reference.LocationDto;
import kg.kumtor.camp.dto.reference.crud.CampCRUDDto;
import kg.kumtor.camp.entity.Camp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CampRepository extends JpaRepository<Camp, Integer> {
    @Query("SELECT new kg.kumtor.camp.dto.reference.CampDto(u.id,u.nameRu) FROM Camp u ORDER BY u.id")
    List<CampDto> find();

    @Query("SELECT NEW kg.kumtor.camp.dto.reference.crud.CampCRUDDto(c.id, c.nameRu, c.changedBy, l.id,l.titleRu, c.statusCode) FROM Camp c INNER JOIN Location l on l.id=c.locationId.id WHERE c.statusCode='A'")
    List<CampCRUDDto> findAllCamp();
}
