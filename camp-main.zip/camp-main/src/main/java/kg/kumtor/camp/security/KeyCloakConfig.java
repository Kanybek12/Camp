package kg.kumtor.camp.security;

import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.keycloak.OAuth2Constants;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;

public class KeyCloakConfig {

    static Keycloak keycloak = null;
    final static String serverUrl = "http://kgbismanast:8180/auth/";
    public final static String realm = "Camp";
    final static String clientId = "camp-project";
    final static String clientSecret = "SAljp2EhxBpdKsRSiEtOQhwupINgRLCf";

    public KeyCloakConfig() {
    }

//    @Bean
//    public Keycloak keycloak(KeycloakSpringBootProperties props) {
//        return KeycloakBuilder.builder()
//                .serverUrl(props.getAuthServerUrl())
//                .realm(props.getRealm())
//                .grantType(OAuth2Constants.CLIENT_CREDENTIALS)
//                .clientId(props.getResource())
//                .clientSecret((String) props.getCredentials().get("secret"))
//                .build();
//    }

    public static Keycloak getInstance() {
        if (keycloak == null) {
            keycloak = KeycloakBuilder.builder()
                    .serverUrl(serverUrl)
                    .realm(realm)
                    .grantType(OAuth2Constants.CLIENT_CREDENTIALS)
                    .clientId(clientId)
                    .clientSecret(clientSecret)
                    .resteasyClient(new ResteasyClientBuilder().connectionPoolSize(10).build())
                    .build();
        }
        return keycloak;
    }
}
