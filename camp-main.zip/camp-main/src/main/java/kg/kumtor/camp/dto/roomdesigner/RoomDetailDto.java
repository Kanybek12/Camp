package kg.kumtor.camp.dto.roomdesigner;

import java.util.List;

public class RoomDetailDto {
    private String room;
    private Integer gender;
    private Integer room_capacity;
    private Integer room_category;
    private List<BedListDto> bedListDtos;

    public RoomDetailDto() {
    }

    public RoomDetailDto(String room, Integer gender, Integer room_capacity, Integer room_category, List<BedListDto> bedListDtos) {
        this.room = room;
        this.gender = gender;
        this.room_capacity = room_capacity;
        this.room_category = room_category;
        this.bedListDtos = bedListDtos;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getRoom_capacity() {
        return room_capacity;
    }

    public void setRoom_capacity(Integer room_capacity) {
        this.room_capacity = room_capacity;
    }

    public Integer getRoom_category() {
        return room_category;
    }

    public void setRoom_category(Integer room_category) {
        this.room_category = room_category;
    }

    public List<BedListDto> getBedListDtos() {
        return bedListDtos;
    }

    public void setBedListDtos(List<BedListDto> bedListDtos) {
        this.bedListDtos = bedListDtos;
    }
}
