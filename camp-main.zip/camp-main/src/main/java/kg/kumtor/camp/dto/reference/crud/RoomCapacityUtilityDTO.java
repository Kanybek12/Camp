package kg.kumtor.camp.dto.reference.crud;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoomCapacityUtilityDTO implements Serializable {

    private int capacity;
    private String name;
    private String changedBy;
}
