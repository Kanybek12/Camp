package kg.kumtor.camp.dto.transfer;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferListDTO {

    private Long id;
    private int empCode;
    private String name;
    private String visitorType;
    private String department;
    private Date transferDate;
    private String applicationType;
    private String status;
    private String locationFrom;
    private String locationTo;
    private String creator;

}
