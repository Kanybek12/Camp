package kg.kumtor.camp.dto.transfer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PersonalTransferDTO {

    private int empCode;
    private Boolean busTransfer = false;
    private Integer busFrom;
    private Integer busTo;
    private Boolean vahtaTransfer = false;
    private Integer vahtaFrom;
    private Integer vahtaTo;
    private Boolean carTransfer = false;
    private Integer carFrom;
    private Integer carTo;
    private String carNumber;
    private String carModel;
    private String driver;
    private Integer carTypeId;
    private String medicalExaminationId;
}
