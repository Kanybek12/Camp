package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.BookingDetailForSetDto;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.exception.ApiException;

import java.util.List;
import java.util.Map;

public interface BookingCheckService {
    ResponseDTO checkIn(Map<String, List<Map<String, Object>>> checkInBookings) throws ApiException;

    ResponseDTO checkOut(Map<String, List<Map<String, Object>>> checkOutBookings) throws ApiException;
    ResponseDTO cancelCheckIn(Map<String, List<Long>> cancelBookings) throws ApiException;
    boolean isExitBooking(BookingDetailForSetDto book, Integer id) throws ApiException;
}
