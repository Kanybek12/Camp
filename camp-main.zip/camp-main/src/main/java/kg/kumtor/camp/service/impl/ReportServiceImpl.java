package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dao.TransferDao;
import kg.kumtor.camp.dto.report.BusVahtaAppDTO;
import kg.kumtor.camp.dto.transfer.vahta.BusVahtaReportsDto;
import kg.kumtor.camp.service.ExcelService;
import kg.kumtor.camp.service.ReportService;
import kg.kumtor.camp.service.impl.report.BusAndVahtaServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ReportServiceImpl implements ReportService {


    private final TransferDao transferDao;


    public ReportServiceImpl(TransferDao transferDao) {
        this.transferDao = transferDao;
    }

    @Override
    public void getApprovedBusXls(LocalDate date, Integer empCode,
                                  Integer applicationType, Integer visitorType, HttpServletResponse response) throws Exception {

        log.info("call getApprovedVahtaXls");
        List<BusVahtaAppDTO> approvedBusList = transferDao.getApprovedBusList(date, empCode, applicationType, visitorType);

        generateExcel(response, approvedBusList);
    }

    @Override
    public void getApprovedVahtaXls(LocalDate date, Integer empCode,
                                    Integer applicationType, Integer visitorType, HttpServletResponse response) throws Exception {

        log.info("call getApprovedVahtaXls");
        List<BusVahtaAppDTO> approvedVahtaList = transferDao.getApprovedVahtaList(date, empCode, applicationType, visitorType);

        generateExcel(response, approvedVahtaList);
    }
    private void generateExcel(HttpServletResponse response, List<BusVahtaAppDTO> approvedBusList) throws IOException {
        BusVahtaReportsDto busReportsDto = new BusVahtaReportsDto();

        busReportsDto.setBusVahtaDownList(approvedBusList.stream().filter(i -> i.getApplicationTypeId().equals("1") && (i.getVisitorTypeId().equals("1") || i.getVisitorTypeId().equals("2"))).collect(Collectors.toList()));
        busReportsDto.setBusVahtaUpList(approvedBusList.stream().filter(i -> i.getApplicationTypeId().equals("2") && (i.getVisitorTypeId().equals("1") || i.getVisitorTypeId().equals("2"))).collect(Collectors.toList()));

        busReportsDto.setBusVahtaDownContractList(approvedBusList.stream().filter(i -> i.getApplicationTypeId().equals("1") && i.getVisitorTypeId().equals("3")).collect(Collectors.toList()));
        busReportsDto.setBusVahtaUpContractList(approvedBusList.stream().filter(i -> i.getApplicationTypeId().equals("2") && i.getVisitorTypeId().equals("3")).collect(Collectors.toList()));

        busReportsDto.setBusVahtaDownGuestList(approvedBusList.stream().filter(i -> i.getApplicationTypeId().equals("1") && i.getVisitorTypeId().equals("4")).collect(Collectors.toList()));
        busReportsDto.setBusVahtaUpGuestList(approvedBusList.stream().filter(i -> i.getApplicationTypeId().equals("2") && i.getVisitorTypeId().equals("4")).collect(Collectors.toList()));

        ExcelService excelService = new BusAndVahtaServiceImpl(busReportsDto);
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        String fileName = String.format("Manifest_%s.xlsx", currentDateTime);

        response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, String.format("attachment; filename=\"%s\"", fileName));
        excelService.export(response);
        log.info("Excel file created successfully. [{}.xlsx]", fileName);
    }
}
