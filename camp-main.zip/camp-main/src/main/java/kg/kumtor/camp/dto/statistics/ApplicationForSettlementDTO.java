package kg.kumtor.camp.dto.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationForSettlementDTO {

    private int id;
    private int empCode;
    private String name;
    private String jobTitle;
    private String department;
    private Date dateIn;
    private Date dateOut;
    private String visitorType;
    private String schedule;
    private String note;
}
