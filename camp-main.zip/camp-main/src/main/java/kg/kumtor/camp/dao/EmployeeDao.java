package kg.kumtor.camp.dao;

import kg.kumtor.camp.dto.email.InfoApprover;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class EmployeeDao {

    private final JdbcTemplate jdbcTemplate;

    public EmployeeDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public InfoApprover getInfoApproverByEmpCode(Integer empCode) {
        String query = "select e.emp_code, e.email, coalesce (e.first_name_ru, e.first_name )  as first_name, coalesce (last_name_ru, last_name ) as last_name , at2.title_ru as title \n" +
                "from camp.approver a  \n" +
                "left join camp.employee e on   a.emp_code = e.emp_code\n" +
                "left join camp.approver_type at2 on a.approver_type_id = at2.id\n" +
                "where a.status = 'A' and a.emp_code = ? ;";
        Object[] args = new Object[]{empCode};
        return jdbcTemplate.queryForObject(query, args, new BeanPropertyRowMapper<>(InfoApprover.class));
    }

    public String getEmailByEmpCode(Integer empCode) {
        String query = "select email  from camp.employee e where e.emp_code = ? ;";
        Object[] args = new Object[]{empCode};
        return jdbcTemplate.queryForObject(query, args, String.class);
    }
    public AccessToken  getAccessToken() {
        KeycloakAuthenticationToken token = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        return token.getAccount().getKeycloakSecurityContext().getToken();
    }
}
