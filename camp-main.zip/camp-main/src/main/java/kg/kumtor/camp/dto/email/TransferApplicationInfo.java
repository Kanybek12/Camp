package kg.kumtor.camp.dto.email;

import java.util.Objects;

public class TransferApplicationInfo {
    private Integer empCode;
    private String firstName;
    private String lastName;
    private String statusId;

    private String date_in;

    private String date_out;

    private boolean onCar;

    public Integer getEmpCode() {
        return empCode;
    }

    public void setEmpCode(Integer empCode) {
        this.empCode = empCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getStatusId() {
        return statusId;
    }

    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    public String getDate_in() {
        return date_in;
    }

    public void setDate_in(String date_in) {
        this.date_in = date_in;
    }

    public String getDate_out() {
        return date_out;
    }

    public void setDate_out(String date_out) {
        this.date_out = date_out;
    }

    public boolean isOnCar() {
        return onCar;
    }

    public void setOnCar(boolean onCar) {
        this.onCar = onCar;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransferApplicationInfo that = (TransferApplicationInfo) o;
        return onCar == that.onCar && Objects.equals(empCode, that.empCode) && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(statusId, that.statusId) && Objects.equals(date_in, that.date_in) && Objects.equals(date_out, that.date_out);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empCode, firstName, lastName, statusId, date_in, date_out, onCar);
    }

    @Override
    public String toString() {
        return "TransferApplicationInfo{" +
                "empCode=" + empCode +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", statusId='" + statusId + '\'' +
                ", date_in='" + date_in + '\'' +
                ", date_out='" + date_out + '\'' +
                ", onCar=" + onCar +
                '}';
    }
}
