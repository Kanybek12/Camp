package kg.kumtor.camp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "transfer_approval")
public class TransferApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "changed_by", nullable = false)
    private String changedBy;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "date_changed", nullable = false)
    private LocalDateTime dateChanged;

    @OneToOne
    @JoinColumn(name = "transfer_application_id", foreignKey = @ForeignKey(name = "fk_transfer_application_id"))
    private TransferApplication transferApplicationId;

    @ManyToOne
    @JoinColumn(name = "supervisor", foreignKey = @ForeignKey(name = "fk_supervisor"))
    private Status supervisor;

    @ManyToOne
    @JoinColumn(name = "medical", foreignKey = @ForeignKey(name = "fk_medical"))
    private Status medical;

    @ManyToOne
    @JoinColumn(name = "hr", foreignKey = @ForeignKey(name = "fk_hr"))
    private Status hr;

    @ManyToOne
    @JoinColumn(name = "mine_site_administration", foreignKey = @ForeignKey(name = "fk_mine_site_administration"))
    private Status mineSiteAdministration;

    @ManyToOne
    @JoinColumn(name = "mine_site_directors", foreignKey = @ForeignKey(name = "fk_mine_site_directors"))
    private Status mineSiteDirectors;

    @ManyToOne
    @JoinColumn(name = "curator_of_contractors", foreignKey = @ForeignKey(name = "fk_curator_of_contractors"))
    private Status curatorOfContractors;
}
