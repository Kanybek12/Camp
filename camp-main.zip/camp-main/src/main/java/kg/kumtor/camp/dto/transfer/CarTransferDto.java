package kg.kumtor.camp.dto.transfer;

import kg.kumtor.camp.entity.CarType;

public class CarTransferDto {
    private String carNumber;
    private String carModel;
    private String driverName;
    private Integer carTypeId;
    private Integer fromLocationId;
    private Integer toLocationId;
    public CarTransferDto() {
    }

    public CarTransferDto(String carNumber, String carModel, String driverName, Integer carTypeId, Integer fromLocationId, Integer toLocationId) {
        this.carNumber = carNumber;
        this.carModel = carModel;
        this.driverName = driverName;
        this.carTypeId = carTypeId;
        this.fromLocationId = fromLocationId;
        this.toLocationId = toLocationId;
    }

    public Integer getFromLocationId() {
        return fromLocationId;
    }

    public void setFromLocationId(Integer fromLocationId) {
        this.fromLocationId = fromLocationId;
    }

    public Integer getToLocationId() {
        return toLocationId;
    }

    public void setToLocationId(Integer toLocationId) {
        this.toLocationId = toLocationId;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }
    public Integer getCarTypeId() {
        return carTypeId;
    }

    public void setCarTypeId(Integer carTypeId) {
        this.carTypeId = carTypeId;
    }
}
