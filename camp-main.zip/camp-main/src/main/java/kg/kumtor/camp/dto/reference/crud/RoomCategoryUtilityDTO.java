package kg.kumtor.camp.dto.reference.crud;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoomCategoryUtilityDTO implements Serializable {

    private Integer id = null;
    private String changedBy;
    private String name;
    private String nameRu;
}
