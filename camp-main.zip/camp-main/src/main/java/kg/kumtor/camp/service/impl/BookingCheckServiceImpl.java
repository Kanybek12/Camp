package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.BookingDetailForSetDto;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.entity.Booking;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.BookingRepository;
import kg.kumtor.camp.repository.StatusRepository;
import kg.kumtor.camp.service.BookingCheckService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;
import static kg.kumtor.camp.utility.ResponseEnum.*;

@Service
@Slf4j
public class BookingCheckServiceImpl implements BookingCheckService {
    private final BookingRepository bookingRepository;
    private final StatusRepository statusRepository;

    private final JdbcTemplate jdbcTemplate;

    public BookingCheckServiceImpl(BookingRepository bookingRepository, StatusRepository statusRepository, JdbcTemplate jdbcTemplate) {
        this.bookingRepository = bookingRepository;
        this.statusRepository = statusRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public ResponseDTO checkIn(Map<String, List<Map<String, Object>>> checkInBookings) throws ApiException {

        List<Map<String, Object>> list = checkInBookings.get("id");

        for (int i = 0; i < list.size(); i++) {
            Long id = Long.valueOf((Integer) list.get(i).get("id"));
            Booking booking = bookingRepository.getById(id);
            log.info("Booking with id {}: {}", id, booking);
            log.info("Old status of booking with id {}: {}", id, booking.getStatusId());

            try {
                String date = (String) list.get(i).get("data");
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                booking.setCheckIn(LocalDate.parse(date, dateTimeFormatter));
                booking.setStatusId(statusRepository.getById(4)); // Check In
                bookingRepository.save(booking);
                log.info("Check-in date for booking with id {} set for {} and booking status changed for '{}'", id, LocalDate.now(), statusRepository.getById(4).getTitle());
            } catch (Exception e) {
                log.error("checkIn date {}", e.getCause());
                log.error(CHECKIN_ALREADY_EXISTS.getMessage());
                throw new ApiException(CHECKIN_ALREADY_EXISTS.getCode(), CHECKIN_ALREADY_EXISTS.getMessage());
            }
        }
        return ResponseDTO.builder().
                code(CHECK_IN_SET.getCode()).
                message(CHECK_IN_SET.getMessage()).
                build();
    }

    @Override
    public ResponseDTO checkOut(Map<String, List<Map<String, Object>>> checkOutBookings) throws ApiException {

        List<Map<String, Object>> list = checkOutBookings.get("id");

        for (int i = 0; i < list.size(); i++) {
            Long id = Long.valueOf((Integer) list.get(i).get("id"));
            Booking booking = bookingRepository.getById(id);
            log.info("Booking with id {}: {}", id, booking);
            log.info("Old status of booking with id {}: {}", id, booking.getStatusId());

            String date = (String) list.get(i).get("data");
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            booking.setCheckOut(LocalDate.parse(date, dateTimeFormatter));
            booking.setStatusId(statusRepository.getById(5)); // Check Out

            if (booking.getCheckIn() == null) {
                log.error(NO_CHECKIN_DATE.getMessage());
                throw new ApiException(NO_CHECKIN_DATE.getCode(), NO_CHECKIN_DATE.getMessage());
            } else if (booking.getCheckOut() != null && booking.getCheckOut().isBefore(booking.getCheckIn())) {
                throw new ApiException(CHECKOUT_DATE_BEFORE_CHECKIN.getCode(), CHECKOUT_DATE_BEFORE_CHECKIN.getMessage());
            }
            try {

                bookingRepository.save(booking);
                log.info("Check-out date for booking with id {} set for {} and booking status changed for '{}'", id, LocalDate.now(), statusRepository.getById(5).getTitle());

            } catch (Exception e) {
                log.error("checkOut date {}", e.getCause());
                log.error(CHECKOUT_ALREADY_EXISTS.getMessage());
                throw new ApiException(CHECKOUT_ALREADY_EXISTS.getCode(), CHECKOUT_ALREADY_EXISTS.getMessage());
            }
        }
        return ResponseDTO.builder().
                code(CHECK_OUT_SET.getCode()).
                message(CHECK_OUT_SET.getMessage()).
                build();
    }

    @Override
    public ResponseDTO cancelCheckIn(Map<String, List<Long>> cancelBookings) throws ApiException {
        for (long id : cancelBookings.get("id")) {
            Booking booking = bookingRepository.findById(id).orElseThrow();

            if (booking.getStatusId().getId() != 4 || booking.getCheckIn() == null) {
                log.error("Booking with id {} has incorrect data for cancel check-in", id);
                throw new ApiException(CHECKIN_NOT_CANCELED.getCode(), CHECKIN_NOT_CANCELED.getMessage());
            }
            booking.setCheckIn(null);
            booking.setStatusId(statusRepository.getById(2)); // Approved
            log.info("Check-in cancelled for booking with id: {}", id);
            bookingRepository.save(booking);
        }
        return ResponseDTO.builder().code(CHECK_IN_CANCELED.getCode()).message(CHECK_IN_CANCELED.getMessage()).build();
    }

    @Override
    public boolean isExitBooking(BookingDetailForSetDto book, Integer id) throws ApiException {

        String query = "SELECT * FROM camp.isExitBooking(?, ?, ?)";

        Object[] args = new Object[]{book.getDateIn(), book.getDateOut(), book.getBedId()};

        List<Map<String, Object>> response = jdbcTemplate.queryForList(query, args);

        return (boolean) response.get(0).get("isexitbooking");
    }
}
