package kg.kumtor.camp.dto;

import java.util.List;

public class RoomFilterDto {
    private String room;
    private List<BedFilterDto> bedList;

    public RoomFilterDto() {
    }

    public RoomFilterDto(String room, List<BedFilterDto> bedList) {
        this.room = room;
        this.bedList = bedList;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public List<BedFilterDto> getBedList() {
        return bedList;
    }

    public void setBedList(List<BedFilterDto> bedList) {
        this.bedList = bedList;
    }
}
