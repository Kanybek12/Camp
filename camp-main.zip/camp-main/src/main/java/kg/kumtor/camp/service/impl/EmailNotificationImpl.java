package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.email.Email;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

@Service
@Slf4j
public class EmailNotificationImpl implements NotificationService {

    private final JavaMailSender emailSender;

    public EmailNotificationImpl(JavaMailSender emailSender) {
        this.emailSender = emailSender;
    }

    @Override
    public void sendMessage(Email email) throws ApiException {
        try {
            JavaMailSenderImpl sender = new JavaMailSenderImpl();
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(email.getFrom());
            helper.setTo(email.getTo());
            helper.setSubject(email.getHeader());
            helper.setText(email.getBody(), true);
            emailSender.send(message);
        } catch (MailException | MessagingException e) {
            log.error("Error in emailSender: {}", e.getMessage());
            throw new ApiException();
        }
        log.info("Email send successfully!");
    }
}
