package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.statistics.BedStatsDTO;
import kg.kumtor.camp.dto.statistics.FullBookingStatsDTO;
import kg.kumtor.camp.dto.statistics.room.FullRoomStatsDTO;
import kg.kumtor.camp.exception.ApiException;

import java.time.LocalDate;

public interface StatisticsService {

    BedStatsDTO getBedStats() throws ApiException;

    FullRoomStatsDTO getRoomStats(String date, String camp, String block) throws ApiException;

    FullBookingStatsDTO getBookingStats(LocalDate date) throws ApiException;
}
