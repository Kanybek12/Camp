package kg.kumtor.camp.dto;

import java.time.LocalDate;

public class BedFilterDto {
    private Long bedNum;
    private Integer status;
    private String empCode;
    private LocalDate dateIn;
    private LocalDate dateOut;
    private Integer bookingId;

    private String department;

    public BedFilterDto() {
    }

    public BedFilterDto(Long bedNum, Integer status, String empCode, LocalDate dateIn, LocalDate dateOut, Integer bookingId, String department) {
        this.bedNum = bedNum;
        this.status = status;
        this.empCode = empCode;
        this.dateIn = dateIn;
        this.dateOut = dateOut;
        this.bookingId = bookingId;
        this.department = department;
    }

    public Long getBedNum() {
        return bedNum;
    }

    public void setBedNum(Long bedNum) {
        this.bedNum = bedNum;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public LocalDate getDateIn() {
        return dateIn;
    }

    public void setDateIn(LocalDate dateIn) {
        this.dateIn = dateIn;
    }

    public LocalDate getDateOut() {
        return dateOut;
    }

    public void setDateOut(LocalDate dateOut) {
        this.dateOut = dateOut;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
