package kg.kumtor.camp.repository;

import kg.kumtor.camp.dto.transfer.TransferTypeDto;
import kg.kumtor.camp.entity.TransferType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransferTypeRepository extends JpaRepository<TransferType, Long> {
    @Query("SELECT NEW kg.kumtor.camp.dto.transfer.TransferTypeDto(t.id, t.name) FROM TransferType t")
    List<TransferTypeDto> findAllTransfer();
}
