package kg.kumtor.camp.service;

import kg.kumtor.camp.dto.CostCenterDTO;
import kg.kumtor.camp.dto.EmployeeGuestDto;
import kg.kumtor.camp.dto.PageableResponseDTO;
import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.reference.*;
import kg.kumtor.camp.dto.reference.crud.*;
import kg.kumtor.camp.dto.transfer.MyApplicationTypeDTO;
import kg.kumtor.camp.exception.ApiException;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

public interface UtilityService {
    List<CampDto> getLocation();
    List<BlockDto> getBlockByLocationId(Integer locationId);
    List<GenderDto> getGender();
    List<VisitorTypeDTO> getVisitorTypes() throws ApiException;
    List<DepartmentDTO> getDepartments() throws ApiException;
    List<Map<String , Object>> getQuantityOfBedInRoom();
    List<JobTitleDTO> getJobTitles() throws ApiException;
    List<EmployeeDTO> getEmployees() throws ApiException;
    List<BedReferenceDTO> getBedReference(String campId, String blockId, String roomId, String bedType,
                                          String status) throws ApiException;
    List<BedTypeDTO> getBedTypes() throws ApiException;
    ResponseDTO addBed(int bedTypeId) throws ApiException;
    List<Map<String,Object>> getBedsInStock()throws ApiException;
    List<ApplicationTypeDto> getApplicationTypeList();
    List<MyApplicationTypeDTO> getMyApplicationTypeList();
    List<CarTypeDto> getCarTypeList();
    int getEmpCodeByAuthToken(KeycloakAuthenticationToken authentication);
    ResponseDTO createLocation(LocationCRUDDto locationCRUDDto)throws ApiException;
    ResponseDTO editLocation(LocationCRUDDto locationCRUDDto)throws ApiException;
    List<LocationCRUDDto> getLocationList()throws ApiException;
    ResponseDTO createCamp(CampCRUDDto campCRUDDto) throws ApiException;
    ResponseDTO editCamp(CampCRUDDto campCRUDDto)throws ApiException;
    List<CampCRUDDto> getCampList();
    ResponseDTO createBlock(BlockCRUDDto blockCRUDDto) throws ApiException;
    ResponseDTO editBlock(BlockCRUDDto blockCRUDDto)throws ApiException;
    List<BlockCRUDDto> getBlockList();
    ResponseDTO createRoom(RoomCRUDDto roomCRUDDto)throws ApiException;
    ResponseDTO editRoom(RoomCRUDDto roomCRUDDto)throws ApiException;
    List<RoomCapacityUtilityDTO> getRoomCapacityList() throws ApiException;
    ResponseDTO addRoomCapacity(RoomCapacityUtilityDTO roomCapacityUtilityDTO) throws ApiException;
    ResponseDTO updateRoomCapacity(RoomCapacityUtilityDTO roomCapacityUtilityDTO) throws ApiException;
    List<RoomCategoryUtilityDTO> getRoomCategoryList() throws ApiException;
    ResponseDTO addRoomCategory(RoomCategoryUtilityDTO roomCategoryDTO) throws ApiException;
    ResponseDTO updateRoomCategory(RoomCategoryUtilityDTO roomCategoryDTO) throws ApiException;
    Map<String, Object> getRoomList(Integer page, Integer size)throws ApiException;
    PageableResponseDTO getBedList(Pageable pageable) throws ApiException;
    ResponseDTO addBed(BedUtilityDTO bedDTO) throws ApiException;
    ResponseDTO updateBed(BedUtilityDTO bedDTO) throws ApiException;
    ResponseDTO deleteBed(List<Integer> ids) throws ApiException;
    List<EmployeeUtilityDTO> getEmployeeList() throws ApiException;
    ResponseDTO addEmployee(EmployeeUtilityDTO employeeDTO) throws ApiException;
    ResponseDTO updateEmployee(EmployeeUtilityDTO employeeDTO) throws ApiException;
    ResponseDTO deleteEmployee(int empCode) throws ApiException;
    PageableResponseDTO getApproverList(Pageable pageable) throws ApiException;
    ResponseDTO addApprover(ApproverUtilityDTO approverDTO) throws ApiException;
    ResponseDTO updateApprover(ApproverUtilityDTO approverDTO) throws ApiException;
    ResponseDTO deleteApprover(int id) throws ApiException;
    List<CostCenterDTO> getCostCenter() throws ApiException;
}
