package kg.kumtor.camp.service.impl;

import kg.kumtor.camp.dto.ResponseDTO;
import kg.kumtor.camp.dto.auth.KeycloakUserDto;
import kg.kumtor.camp.dto.auth.RegisterDto;
import kg.kumtor.camp.entity.Employee;
import kg.kumtor.camp.entity.Role;
import kg.kumtor.camp.exception.ApiException;
import kg.kumtor.camp.repository.EmployeeRepository;
import kg.kumtor.camp.repository.RoleRepository;
import kg.kumtor.camp.security.KeyCloakConfig;
import kg.kumtor.camp.service.AuthContractService;
import kg.kumtor.camp.service.KeycloakService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import static kg.kumtor.camp.exception.ExceptionsEnum.*;
import static kg.kumtor.camp.utility.ResponseEnum.USER_REGISTERED;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class AuthContractServiceImpl implements AuthContractService, UserDetailsService {

    private final EmployeeRepository employeeRepository;

    private final RoleRepository roleRepository;

    private final PasswordEncoder passwordEncoder;

    private final KeycloakService keycloakService;

    @Override
    public UserDetails loadUserByUsername(String empCode) throws UsernameNotFoundException {
        Employee employee = employeeRepository.findEmployeeByEmpCode(Integer.parseInt(empCode));
        if (employee == null) {
            log.error("Employee with empcode {} not found in DB", empCode);
            throw new UsernameNotFoundException("Пользователь не найден в системе");
        } else {
            log.info("Employee with empcode {} found in DB", empCode);
        }
        Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        employee.getRoles().forEach((role -> {
            authorities.add(new SimpleGrantedAuthority(role.getName()));
        }));
        return new User(String.valueOf(employee.getEmpCode()),
                employee.getPassword(), authorities);
    }

    @Override
    public Employee getEmployee(String empCode) {
        log.info("Fetching employee with emp code {}", empCode);
        return employeeRepository.findEmployeeByEmpCode(Integer.parseInt(empCode));
    }

    @Override
    public ResponseDTO register(RegisterDto registerDto) throws ApiException {

        int empCode = registerDto.getEmpCode();
        String password1 = registerDto.getPassword();
        String password2 = registerDto.getPasswordConfirm();
        String sin = registerDto.getSin();
        Employee employee = employeeRepository.findEmployeeByEmpCode(empCode);

        if (!checkEmpCodeAndSin(empCode, sin)) {
            throw new ApiException(INVALID_SIN.getCode(), INVALID_SIN.getMessage());
        }

        log.info("Changing status of isRegistered for employee with empcode: {}", empCode);
        employee.setIsRegistered(1);
        log.info("Assigning ROLE_USER to an employee with empcode: {}", empCode);
        Role role = roleRepository.findByName("ROLE_USER");
        employee.getRoles().add(role);
        log.info("Saving password for employee with empcode: {}", empCode);
        if (password1.equals(password2)) {
            employee.setPassword(passwordEncoder.encode(password1));

            KeycloakUserDto keycloakUser = KeycloakUserDto.builder()
                    .username(String.valueOf(registerDto.getEmpCode()))
                    .firstName("testFirstName")
                    .lastName("testLastName")
                    .password(registerDto.getPassword())
                    .role("contractor")
                    .build();
            keycloakService.addUser(keycloakUser);
            keycloakService.addRealmRoleToUser(String.valueOf(employee.getEmpCode()), "contractor");
            log.info("User Added in keycloak with role 'contractor'");
            return ResponseDTO.builder()
                    .code(USER_REGISTERED.getCode())
                    .message(USER_REGISTERED.getMessage())
                    .build();
        } else {
            throw new ApiException(PASSWORDS_DONT_MATCH.getCode(), PASSWORDS_DONT_MATCH.getMessage());
        }
    }


    @Override
    public Role saveRole(Role role) {
        log.info("Saving new role {} to the DB", role.getName());
        return roleRepository.save(role);
    }

    @Override
    public ResponseDTO updatePassword(RegisterDto credentials) throws ApiException {

        int empCode = credentials.getEmpCode();
        String password1 = credentials.getPassword();
        String password2 = credentials.getPasswordConfirm();
        String sin = credentials.getSin();
        Employee employee = employeeRepository.findEmployeeByEmpCode(empCode);

        if (password1.equals(password2)){
            if (checkEmpCodeAndSin(empCode, sin)){

                employee.setPassword(passwordEncoder.encode(password1));
                log.info("Password updated in database for employee: {}", empCode);

                CredentialRepresentation credential = new CredentialRepresentation();
                credential.setType(CredentialRepresentation.PASSWORD);
                credential.setValue(credentials.getPassword());
                credential.setTemporary(false);

                UsersResource usersResource = KeyCloakConfig.getInstance().realm(KeyCloakConfig.realm).users();
                List<UserRepresentation> user = usersResource.search(String.valueOf(credentials.getEmpCode()), true);
                log.info("Get user {} from keycloak with id: {}", user.get(0).getUsername(), user.get(0).getId());
                String userId =  user.get(0).getId();

                usersResource.get(userId).resetPassword(credential);
                log.info("Password updated in keycloak for user: {}", user.get(0).getUsername());
                return ResponseDTO.builder()
                        .code(200)
                        .message("Пароль для пользователя " + empCode + " успешно обновлён")
                        .build();
            } else {
                log.error(INVALID_SIN.getMessage());
                throw new ApiException(INVALID_SIN.getCode(), INVALID_SIN.getMessage());
            }
        } else {
            log.error(PASSWORDS_DONT_MATCH.getMessage());
            throw new ApiException(PASSWORDS_DONT_MATCH.getCode(), PASSWORDS_DONT_MATCH.getMessage());
        }
    }

    @Override
    public boolean checkIsRegistered(Map<String, Integer> empCode) throws ApiException {
        Employee employee = employeeRepository.findEmployeeByEmpCode(empCode.get("empCode"));
        if (employee != null) {
            int isRegistered = employee.getIsRegistered();
            return isRegistered == 1; // returns true or false
        } else {
            throw new ApiException(EMPLOYEE_NOT_FOUND.getCode(), String.format(EMPLOYEE_NOT_FOUND.getMessage(),
                    empCode.get("empCode")));
        }
    }

    @Override
    public boolean checkEmpCodeAndSin(int empCode, String sin) throws ApiException {
        Employee employee = employeeRepository.findEmployeeByEmpCode(empCode);
        if (employee == null) {
            throw new ApiException(EMPLOYEE_NOT_FOUND.getCode(), String.format(EMPLOYEE_NOT_FOUND.getMessage(), empCode));
        }
        String employeeSin = employee.getSin();
        if (employeeSin == null) {
            throw new ApiException(EMPLOYEE_DONT_HAVE_SIN.getCode(), String.format(EMPLOYEE_DONT_HAVE_SIN.getMessage(), empCode));
        }
        String sinLastFiveDigits = employeeSin.substring(employeeSin.length() - 5);
        return sin.equals(sinLastFiveDigits); // returns true or false
    }
}
