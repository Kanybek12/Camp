package kg.kumtor.camp.repository;

import kg.kumtor.camp.entity.BusTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BusVisitRepository extends JpaRepository<BusTransfer, Long> {
    @Query("SELECT tp.name FROM BusTransfer bt INNER JOIN TransferType tp ON bt.transferTypeId.id=tp.id WHERE bt.id= :id")
    String getTransferTypeById(@Param("id") Long id);
}
