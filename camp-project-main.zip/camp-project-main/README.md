# Camp App (package)

A Camp Project

## Install the dependencies
```bash
yarn
# or
npm install
```

### Start the app in development mode (hot-code reloading, error reporting, etc.)
```bash
QENV=dev quasar dev
```

### Start the app in development mode (hot-code reloading, error reporting, etc.)
```bash
QENV=test quasar dev
```

### Lint the files
```bash
yarn lint
# or
npm run lint
```

### Build the app for test
```bash
QENV=test quasar build


### Build the app for production
```bash
QENV=prod quasar build
```

### Customize the configuration
See [Configuring quasar.config.js](https://v2.quasar.dev/quasar-cli-webpack/quasar-config-js).
