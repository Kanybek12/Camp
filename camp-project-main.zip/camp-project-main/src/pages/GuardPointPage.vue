<template>
  <div class="checkinOut" style="padding: 16px">
    <GuardPointFilter/>
    <GuardPointList :list-data = "settlementData" :pages="getPages"/>
  </div>
</template>

<script>
import { mainStore } from 'stores/main-store'
import GuardPointFilter from 'components/guard-point/GuardPointFilter'
import GuardPointList from 'components/guard-point/GuardPointList'
import { ref } from 'vue'

export default {
  name: 'GuardPointPage',
  components: { GuardPointList, GuardPointFilter },
  setup () {
    return {
      store: mainStore(),
      totalPages: ref(0)
    }
  },
  computed: {
    settlementData () {
      return this.store.guardPointData.content ?? []
    },
    getPages () {
      return this.store.guardPointData.totalPages
    }
  },
  created () {
    this.store.getGuardPoint(
      this.store.guardPointParams.page, '', '', '', '', '')
  }
}
</script>
