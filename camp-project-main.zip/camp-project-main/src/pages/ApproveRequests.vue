<template>
  <div class="checkinOut" style="width: 100%; padding: 24px">
      <q-table title="Заявки на утверждение" ref="tableRef" tabindex="0" row-key="transferId" selection="multiple"
               :rows="approveData" :columns="columns1" :pagination="paginationElements" :filter="filter"
               v-model:selected="selectedApproveList" no-data-label="Данные отсутствуют" no-results-label="Данные по фильтру не найдены">
        <template v-slot:top-left>
          <q-input
            borderless dense
            debounce="300"
            filled
            color="primary"
            v-model="filter"
            clearable
            placeholder="Поиск">
            <template v-slot:append>
              <q-icon name="search" />
            </template>
          </q-input>
        </template>
        <template v-slot:no-data="{ message }">
            <span>
            {{ message }}
          </span>
        </template>
         <template v-slot:top-right>
          <div class="checkinOut__block__table-list">
            <q-btn label="Принять" :disable="selectedApproveList.length < 1" no-caps
                   color="green" class="checkinOut__block__table-list__btn" @click="approveRequest('A')">
              <q-tooltip>Принять заявку</q-tooltip>
            </q-btn>
            <q-btn label="Отклонить" :disable="selectedApproveList.length < 1" color="red" no-caps
                   class="checkinOut__block__table-list__btn" @click="approveRequest('R')">
              <q-tooltip>Отклонить заявку</q-tooltip>
            </q-btn>
          </div>
        </template>
      </q-table>
  </div>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'
import { useQuasar } from 'quasar'
const columns1 = [
  { name: 'empCode', label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', label: 'ФИО', align: 'left', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold', sortable: true },
  { name: 'department', label: 'Отдел', align: 'left', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold', sortable: true },
  { name: 'visitorName', align: 'left', label: 'Тип', field: 'visitorName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateFrom', align: 'left', label: 'Дата заезда', field: 'dateFrom', headerStyle: 'font-size: 13px; font-weight:bold', sortable: true },
  { name: 'dateTo', align: 'left', label: 'Дата выезда', field: 'dateTo', headerStyle: 'font-size: 13px; font-weight:bold', sortable: true },
  { name: 'transferTypes', align: 'left', label: 'Тип заявки', field: 'transferTypes', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'transfer', align: 'left', label: 'Информация о поездке', field: 'transfer', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'creator', align: 'left', label: 'Кем создано', field: 'creator', headerStyle: 'font-size: 13px; font-weight:bold' }
]
export default {
  name: 'ApproveRequests',
  setup () {
    const $q = useQuasar()
    const filter = ref('')
    return {
      isLoading: ref(true),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      model: ref(null),
      filter,
      approveOptions: [],
      tab: ref('checkin'),
      columns1,
      store: mainStore(),
      visitorType: ref(''),
      transferType: ref(''),
      employeeCode: ref(''),
      employeesData: ref(''),
      transferDate: ref(''),
      dateIn: ref(''),
      dateOut: ref(''),
      selectedApproveList: ref([]),
      empCode: ref(''),
      paginationElements: {
        descending: false,
        rowsPerPage: 50
      }
    }
  },
  watch: {
    approveData (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    }
  },
  computed: {
    approveData () {
      return this.store.approveList.content ?? []
    },
    visitorTypeData () {
      return this.store.modifiedVisitorsRef
    },
    transferTypeData () {
      return this.store.modifiedApplicationRef
    }
  },
  created () {
    this.empCode = localStorage.getItem('empCode')
    this.store.getApproveList(this.empCode)
    this.employeesData = this.store.modifiedEmployees
    this.store.getGender()
    this.store.getRoomCategory()
    this.store.getEmpCodes()
    this.store.getSchedule()
    this.store.getDepartments()
    this.store.getJobTitles()
    this.store.getVisitors()
    this.store.getEmployees()
    this.store.getApplicationType()
    this.store.getLocations()
  },
  methods: {
    approveRequest (status) {
      const data = []
      let approveReq = false
      if (status === 'A') approveReq = true
      else if (status === 'R') approveReq = false
      this.selectedApproveList.map(res => data.push({
        transferApplicationId: res.transferId,
        approverEmpCode: res.approverEmpCode,
        approverType: res.approverType,
        changedBy: res.approverName,
        approve: approveReq
      }))
      this.store.approveRequestsFun(data).then(res => {
        if (res.status === 200) {
          this.showNotif(res.data.message, res.data.code)
          this.store.getApproveList(this.empCode)
          this.selectedApproveList.length = 0
        } else {
          this.showNotif('error', res.status)
        }
      })
    },
    filterFn (val, update) {
      if (!val) {
        update(() => {
          this.approveOptions = this.approveData
        })
        return
      }
      update(() => {
        const needle = val.toLowerCase()
        this.approveOptions = this.approveData.filter(v => v.value.toLowerCase().indexOf(needle) > -1)
      })
    },
    filterOn () {
      this.clearForm()
    },
    filterOff () {
      this.store.getApproveList(this.empCode)
      this.clearForm()
    },
    clearForm () {
      this.employeeCode = ''
      this.visitorType = ''
      this.transferType = ''
      this.dateIn = ''
      this.dateOut = ''
    }
  }
}
</script>
