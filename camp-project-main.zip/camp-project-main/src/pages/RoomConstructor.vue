<template>
  <div class="flex indexPage">
    <RoomTapMenu class="indexPage__checkInOut"/>
  </div>
</template>

<script>
import { mainStore } from 'stores/main-store'
import RoomTapMenu from 'components/room-constructor/RoomTapMenu'
export default {
  name: 'RoomConstructor',
  components: {
    RoomTapMenu
  },
  setup () {
    return {
      store: mainStore()
    }
  },
  created () {
    this.store.getGender()
    this.store.getRoomCategory()
    this.store.getRoomCapacity()
    this.store.getLocation()
    this.store.getBlocks('')
    this.store.getRoomByParams(
      { dateIn: '', dateOut: '', blockId: '', genderId: '', roomId: '' }
    )
  }
}
</script>

<style lang="scss" scoped>
.wrapper{
  background-color: #EFF3FB;
  display: flex;
  flex-direction: column;
  //padding-top: 50px;
  //width: 100%;
  //height: 100%;
  align-items: center;
  margin: 24px;
}
.components{
  display: flex;
  width: 100%;
  height: 100%;
}
</style>
