<template>
  <div class="flex indexPage">
    <div class="indexPage__timesheetComponents">
      <DiagramReportForm :diagram-data="diagramData" class="indexPage__diagramReportForm"/>
      <RoomReportForm :room-data="roomReportData" class="indexPage__roomReportForm" />
      <EmpReportForm :booking-data="bookingsReportData" class="indexPage__empReportForm"/>
    </div>
    <CheckInOut class="indexPage__checkInOut" />
  </div>
</template>

<script>
import RoomReportForm from 'components/main-page/RoomReportForm.vue'
import DiagramReportForm from 'components/main-page/DiagramReportForm.vue'
import EmpReportForm from 'components/main-page/EmpReportForm.vue'
import CheckInOut from 'components/main-page/CheckInOut'
import { mainStore } from 'stores/main-store'

export default {
  name: 'IndexPage',
  components: {
    RoomReportForm,
    DiagramReportForm,
    EmpReportForm,
    CheckInOut
  },
  setup () {
    return {
      store: mainStore()
    }
  },
  computed: {
    diagramData () {
      return this.store.beds ?? []
    },
    roomReportData () {
      return this.store.getRoomReportData ?? []
    },
    bookingsReportData () {
      return this.store.getBookingData ?? []
    }
  },
  async created () {
    await this.store.getStatistics('beds')
    await this.store.getStatistics('rooms')
    await this.store.getStatistics('bookings')
    await this.store.getGender()
    await this.store.getRoomCategory()
    await this.store.getEmpCodes()
    await this.store.getSchedule()
    await this.store.getDepartments()
    await this.store.getJobTitles()
    await this.store.getVisitors()
    await this.store.getEmployees()
    await this.store.getApplicationType()
    await this.store.getLocations()
  }
}
</script>
