<template>
  <div class="column ctrp__gap-8" style="padding: 20px">
    <q-card style="width: 100%">
      <q-card-section>
        <filter-archive/>
      </q-card-section>
    </q-card>
    <table-archive :list="getList" :page-sum="getPageSum" style="width: 100%"/>
  </div>
</template>

<script>
import TableArchive from 'components/archive/TableArchive'
import { mainStore } from 'stores/main-store'
import FilterArchive from 'components/archive/FilterArchive'

export default {
  name: 'ArchivePage',
  components: { FilterArchive, TableArchive },
  setup () {
    return {
      store: mainStore()
    }
  },
  created () {
    this.store.getArchiveData(
      this.store.archiveFilterData.page
    )
  },
  computed: {
    getList () {
      return this.store.archiveData.content ?? []
    },
    getPageSum () {
      return this.store.archiveData.totalPages ?? 1
    }
  }
}
</script>

<style scoped>

</style>
