<template>
<div class="auth-page">
  <section class="u-align-center u-section-2" style="height: 100vh" id="carousel_9d74"
           data-image-width="1980" data-image-height="1214">
    <div class="u-valign-middle u-sheet-1">
      <div class="u-align-center u-group">
        <div class="u-container-layout">
          <div>
            <img width="164" src="~assets/logo_new.png" alt="KUMTOR">
          </div>
          <div class="u-border-1 u-border-grey-dark-1 u-line u-line-horizontal u-line-1"></div>
          <p class="u-text u-text-default u-text-2 auth-title">Добро пожаловать в приложение "Лагерь"</p>
        </div>
      </div>
      <div class="u-group u-group-2">
        <div class="row auth-btn-block">
          <q-btn label="Войти" class="ap-btn ap-btn__flat" no-caps flat @click="dialogFor1btn=true"/>
<!--          <q-btn label="Контрактник"-->
<!--                 class="ap-btn ap-btn__flat"-->
<!--                 no-caps flat-->
<!--                 @click="dialogFor2btn=true"/>-->
        </div>
      </div>
    </div>
  </section>
  <q-dialog v-model="dialogFor2btn" persistent transition-show="scale" transition-hide="scale">
    <q-card class="auth-card">
      <q-toolbar>
        <q-avatar size="35px" font-size="20px" class="auth-icon-in" text-color="white" icon="login"/>
        <q-toolbar-title>
          <span class="text-weight-bold">{{titleFor1Dialog}}</span>
        </q-toolbar-title>
        <q-btn flat round dense v-close-popup icon="close" @click="clear"/>
      </q-toolbar>
      <div v-if="titleFor1Dialog === 'Регистрация'"
           class="text-weight-light text-grey" style="font-size: 14px;padding: 16px 0 0 16px">
        *Табельный № не зарегистрирован. Пройдите регистрацию
      </div>
      <q-card-section>
        <q-input label="Введите табельный номер" mask="######" autofocus square outlined
                 v-model="empCode" :disable="isPassport" :rules="[val => !!val || '']"
                 @keyup.enter="checkEmpCode">
          <template v-slot:append>
            <q-icon v-if="empCode !== ''" class="cursor-pointer" name="clear" @click.stop="empCode = ''">
              <q-tooltip>Очистить</q-tooltip>
            </q-icon>
          </template>
        </q-input>
        <q-input label="Введите пароль" autofocus square outlined class="m-t-12" v-if="isPassword" v-model="password"
                 :rules="[val => !!val || 'Введите пароль']" :type="isPwd1 ? 'password' : 'text'" @keyup.enter="check">
          <template v-slot:append>
            <q-icon class="cursor-pointer" :name="isPwd1 ? 'visibility_off' : 'visibility'" @click="isPwd1 = !isPwd1"/>
            <q-icon v-if="password !== ''" class="cursor-pointer" name="clear" @click.stop="password = ''">
              <q-tooltip>Очистить</q-tooltip>
            </q-icon>
          </template>
        </q-input>
        <div v-if="isPassword" class="text" @click="recoveryPassword">Забыли пароль?</div>
        <q-input label="Введите 5 последних цифр ИНН" class="m-t-12" mask="######" autofocus square outlined
                 v-if="isPassport" v-model="passport" @keyup.enter="check"
                 :rules="[val => !!val || '']" :disable="isRegistration || isRecoveryPassword">
          <template v-slot:append>
            <q-icon v-if="passport !== ''" class="cursor-pointer" name="clear" @click.stop="passport = ''">
              <q-tooltip>Очистить</q-tooltip>
            </q-icon>
          </template>
        </q-input>
        <div v-if="isRegistration || isRecoveryPassword">
          <q-input label="Придумайте пароль" class="m-t-12" autofocus square outlined
                   v-model="newPassword" :rules="[val => !!val, isValidPassword]" :type="isPwd2 ? 'password' : 'text'">
            <template v-slot:append>
              <q-icon class="cursor-pointer" :name="isPwd2 ? 'visibility_off' : 'visibility'" @click="isPwd2 = !isPwd2"/>
              <q-icon v-if="newPassword !== ''" class="cursor-pointer" name="clear" @click.stop="newPassword = ''">
                <q-tooltip>Очистить</q-tooltip>
              </q-icon>
            </template>
          </q-input>
          <q-input label="Повторите пароль" class="m-t-12" square outlined v-model="repeatPassword"
                   :type="isPwd3 ? 'password' : 'text'" :rules="[val => !!val, isValidRepeatPassword]">
            <template v-slot:append>
              <q-icon class="cursor-pointer" :name="isPwd3 ? 'visibility_off' : 'visibility'" @click="isPwd3 = !isPwd3"/>
              <q-icon v-if="repeatPassword !== ''" class="cursor-pointer" name="clear" @click.stop="repeatPassword = ''">
                <q-tooltip>Очистить</q-tooltip>
              </q-icon>
            </template>
          </q-input>
        </div>
      </q-card-section>
      <q-card-actions align="right" class="bg-white text-teal">
        <q-btn flat no-caps style="color: #3b47b5;" :disable="isLoading" v-if="isTabNoBtn" @click="checkEmpCode">
          <span v-if="!isLoading">Далее</span>
          <q-spinner-dots v-if="isLoading" color="primary" size="2em"/>
        </q-btn>
        <q-btn :disable="isLoading"
               v-if="isPassport && !isRegistration &&!isRecoveryPassword || isPassword && !isRegistration && !isRecoveryPassword"
               flat no-caps style="color: #3b47b5;" @click="check">
          <span v-if="!isLoading">Далее</span>
          <q-spinner-dots v-if="isLoading" color="primary" size="2em"/>
        </q-btn>
        <q-btn :disable="newPassword && repeatPassword && isLoading" v-if="isRegistration"
               flat no-caps style="color: #3b47b5;" @click="registration">
          <span v-if="!isLoading">Зарегистрировать</span>
          <q-spinner-dots v-if="isLoading" color="primary" size="2em"/>
        </q-btn>
        <q-btn :disable="newPassword && repeatPassword && isLoading"
               v-if="isRecoveryPassword" flat no-caps style="color: #3b47b5;" @click="recovery">
          <span v-if="!isLoading">Восстановить пароль</span>
          <q-spinner-dots v-if="isLoading" color="primary" size="2em"/>
        </q-btn>
      </q-card-actions>
    </q-card>
  </q-dialog>
  <q-dialog v-model="dialogFor1btn" persistent transition-show="scale" transition-hide="scale">
    <q-card class="auth-card">
      <q-toolbar>
        <q-avatar size="35px" font-size="20px" class="auth-icon-in" text-color="white" icon="login"/>
        <q-toolbar-title>
          <span class="text-weight-bold">Авторизация</span>
        </q-toolbar-title>
        <q-btn flat round dense v-close-popup icon="close" @click="clear"/>
      </q-toolbar>
      <q-card-section>
        <q-input autofocus square outlined lazy-rules class="m-b-12" suffix="@kumtor.kg" placeholder="example@kumtor.kg"
                 v-model="empLogin" @keyup.enter="loginUser" :rules="[val => !!val || 'Введите логин', isValidEmail]">
          <template v-slot:append>
            <q-icon v-if="empLogin !== ''" class="cursor-pointer" name="clear" @click.stop="empLogin = ''">
              <q-tooltip>Очистить</q-tooltip>
            </q-icon>
          </template>
        </q-input>
        <q-input placeholder="password" square outlined v-model="password" @keyup.enter="loginUser"
                 :type="isPwd4 ? 'password' : 'text'" :rules="[val => !!val || 'Введите пароль']">
          <template v-slot:append>
            <q-icon class="cursor-pointer" :name="isPwd4 ? 'visibility_off' : 'visibility'" @click="isPwd4 = !isPwd4"/>
            <q-icon class="cursor-pointer" name="clear" v-if="password !== ''" @click.stop="password = ''">
              <q-tooltip>Очистить</q-tooltip>
            </q-icon>
          </template>
        </q-input>
      </q-card-section>
      <q-card-actions align="right" class="bg-white text-teal">
        <q-btn class="ap-btn1 ap-btn1__flat" flat no-caps style="color: #ffffff;" @click="loginUser">
          <span v-if="!isLoading">Войти</span>
          <q-spinner-dots v-if="isLoading" color="primary" size="2em"/>
        </q-btn>
      </q-card-actions>
    </q-card>
  </q-dialog>
</div>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'
import axios from 'axios'

export default {
  name: 'AuthorizationPage',
  setup () {
    const $q = useQuasar()
    return {
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'top',
          color: code === 200 ? 'green' : 'red'
        })
      },
      store: mainStore(),
      isLoading: ref(false),
      dialogFor2btn: ref(false),
      dialogFor1btn: ref(false),
      isPassword: ref(false),
      isPassport: ref(false),
      isRegistration: ref(false),
      isRecoveryPassword: ref(false),
      isForgotPass: ref(false),
      isTabNoBtn: ref(true),
      isPwd1: ref(true),
      isPwd2: ref(true),
      isPwd3: ref(true),
      isPwd4: ref(true),
      empCode: ref(''),
      empLogin: ref(''),
      password: ref(''),
      passport: ref(''),
      newPassword: ref(''),
      repeatPassword: ref(''),
      titleFor1Dialog: ref('Авторизация')
    }
  },
  methods: {
    isValidEmail (val) {
      if (this.dialogFor1btn) {
        let emailPattern
        if (this.empLogin.includes('@')) {
          emailPattern = /^(?=[a-zA-Z0-9@._%+-]{6,254}$)[a-zA-Z0-9._%+-]{1,64}@(?:[a-zA-Z0-9-]{1,63}\.){1,8}[a-zA-Z]{2,63}$/
        } else if (!this.empLogin.includes('@')) {
          emailPattern = /^(?=[a-zA-Z0-9@._%+-]{6,254}$)[a-zA-Z0-9._%+-]{1,64}/
        }
        return emailPattern.test(val) || 'Некоректные данные'
      } else return ''
    },
    isValidRepeatPassword (val) {
      if (val !== this.newPassword) return 'Пароли не совпадают' || ''
    },
    isValidPassword (val) {
      if (val.trim().length > 16) return 'Максимальная длина пароля - 16 символов'
      else if (val.trim().length < 8) return 'Минимальная длина пароля - 8 символов'
      else {
        const emailPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$_.*])(?=(.*[a-zA-Z]){4}).{8,20}$/
        return emailPattern.test(val) || 'Пароль должен содержать заглавные и строчные буквы, цифры и символы !@#$_-.*'
      }
    },
    recoveryPassword () {
      this.isPassword = false
      this.isPassport = true
      this.isForgotPass = true
    },
    recovery () {
      this.isLoading = true
      if (this.empLogin.length > 0) {
        this.empCode = this.empLogin.includes('@kumtor.kg') ? this.empLogin : this.empLogin + '@kumtor.kg'
      }
      const data = {
        empCode: this.empCode,
        sin: this.passport,
        password: this.newPassword,
        passwordConfirm: this.repeatPassword
      }
      this.store.recoveryPass(data)
        .then((res) => {
          if (res?.data.code === 200) {
            this.isPassport = false
            this.isRecoveryPassword = false
            this.isForgotPass = false
            this.isPassword = true
            this.showNotif(res?.data?.message, 200)
          } else this.showNotif(res?.data?.message, 400)
          this.isLoading = true
        })
        .finally(() => { this.isLoading = false })
    },
    loginUser () {
      if ((this.empLogin.length > 0 || this.empCode.length > 0) && this.password.length > 0) {
        this.isLoading = true
        if (this.empLogin.length > 0) {
          this.empCode = this.empLogin.includes('@kumtor.kg')
            ? this.empLogin : this.empLogin + '@kumtor.kg'
        }
        const data = {
          username: this.empCode,
          password: this.password,
          grant_type: 'password',
          client_id: process.env.client_id,
          realm: process.env.realm,
          client_secret: process.env.client_secret
        }
        this.store.loginUserStore(data)
          .then((res) => {
            if (res?.data?.access_token) {
              const token = `Bearer ${res?.data?.access_token}`
              const empCode = JSON.parse(atob(res.data?.access_token.split('.')[1])).emp_code
              localStorage.setItem('empCode', empCode)
              const decodedJWT = JSON.parse(atob(res.data?.access_token.split('.')[1]))
              axios.defaults.headers.common.Authorization = token
              const refreshToken = `${res?.data?.refresh_token}`
              localStorage.setItem('refresh_token', refreshToken)
              localStorage.setItem('token', token)
              localStorage.setItem('key', 'true')
              if (decodedJWT?.resource_access[process.env.client_id]) {
                localStorage.setItem('camp_role', decodedJWT?.resource_access[process.env.client_id]?.roles)
                this.getReference()
                this.$router.push({ path: '/request-list' })
              } else {
                this.showNotif('Нет никаких доступов')
              }
            }
            if (res.data?.code === 401) this.showNotif('Неверный логин или пароль', 400)
            this.isLoading = false
          })
      } else {
        this.showNotif('Заполните все обязательные поля', 0)
      }
    },
    getReference () {
      this.store.getGender()
      this.store.getRoomCategory()
      this.store.getEmpCodes()
      this.store.getSchedule()
      this.store.getDepartments()
      this.store.getJobTitles()
      this.store.getVisitors()
      this.store.getEmployees()
      this.store.getApplicationType()
      this.store.getLocation()
    },
    clear () {
      this.isTabNoBtn = true
      this.isPassport = false
      this.isPassword = false
      this.isRegistration = false
      this.empCode = ''
      this.passport = ''
      this.password = ''
      this.newPassword = ''
      this.repeatPassword = ''
      this.titleFor1Dialog = 'Авторизация'
    },
    checkEmpCode () {
      if (!this.empCode) {
        this.showNotif('Заполните обязательные поля', 400)
      } else {
        this.isLoading = true
        this.store.checkEmpCodeStore({ empCode: this.empCode })
          .then((el) => {
            if (el?.data?.code === 402) {
              this.titleFor1Dialog = 'Регистрация'
              this.isPassport = true
              this.isTabNoBtn = false
              this.showNotif(el?.data?.message, 400)
            }
            if (el?.data?.code === 200) {
              this.isPassword = true
              this.isTabNoBtn = false
              localStorage.setItem('emp', this.empCode)
              this.showNotif(el?.data?.message, 200)
            } else if (el?.data?.code === 400) {
              this.isPassport = true
              this.isTabNoBtn = false
              this.showNotif(el?.data?.message, 400)
            } else if (el?.data?.code === 404) {
              this.showNotif(el?.data?.message, 400)
            } else if (el?.data?.code === 409) {
              this.showNotif(el?.data?.message, 400)
            }
            this.isLoading = false
          })
          .finally(() => { this.isLoading = false })
      }
    },
    checkPassport () {
      this.isLoading = true
      const data = {
        empCode: this.empCode,
        sin: this.passport
      }
      this.store.checkPassportStore(data)
        .then((el) => {
          if (el?.data.code === 200) {
            if (!this.isForgotPass) this.isRegistration = true
            else this.isRecoveryPassword = true
            this.showNotif(el?.data?.message, 200)
          }
          if (el?.data.code === 400) {
            this.showNotif(el?.data?.message, 400)
            this.clear()
          }
          if (el?.data.code === 404) this.showNotif(el?.data?.message, 400)
        })
        .finally(() => { this.isLoading = false })
    },
    check () {
      if (this.isPassport && this.passport) this.checkPassport()
      if (this.isPassword) this.loginUser()
    },
    registration () {
      this.isLoading = true
      const data = {
        empCode: this.empCode,
        sin: this.passport,
        password: this.newPassword,
        passwordConfirm: this.repeatPassword
      }
      this.store.registerContractUser(data)
        .then((res) => {
          if (res?.data.code === 200) {
            this.isRegistration = false
            this.isPassport = false
            this.titleFor1Dialog = 'Авторизация'
            this.isPassword = true
            this.showNotif(res?.data?.message, 200)
          } else this.showNotif(res?.data?.message, 400)
          this.isLoading = true
        })
        .finally(() => { this.isLoading = false })
    }
  }
}
</script>
