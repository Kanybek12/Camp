<template>
  <div class="report">
    <div class="report__select-wrapper">
      <p class="report__select-title">Выгрузка отчета</p>
      <q-select
        class="select m-b-16 report__select"
        outlined
        v-model="selectedReport"
        :options="reportData"
        label="Выберите отчет"
      />
    </div>
    <iframe
      class="select m-b-16 report__iframe"
      title="CampDailyTest-TM"
      :src="selectedReport?.value ?? defaultReport"
    />
  </div>
</template>

<script>
import { ref } from 'vue'
const reportData = [
  {
    label: 'Ежедневный отчет',
    value: 'https://app.powerbi.com/reportEmbed?reportId=3b5c397c-4864-4fa0-b669-a11f612f5462&autoAuth=true&ctid=30f55b9e-dc49-493e-a20c-0fbb510a0971'
  },
  {
    label: 'Ежемесячный отчет',
    value: 'https://app.powerbi.com/reportEmbed?reportId=27c103a0-2395-4a3a-bc4a-3379b027dc15&autoAuth=true&ctid=30f55b9e-dc49-493e-a20c-0fbb510a0971'
  },
  {
    label: 'Отчет по заполняемости',
    value: 'https://app.powerbi.com/reportEmbed?reportId=c008bddb-2698-4589-8ea3-68180b3c736d&autoAuth=true&ctid=30f55b9e-dc49-493e-a20c-0fbb510a0971'
  }
]

export default {
  name: 'ReportsPage',
  setup () {
    return {
      selectedReport: ref(null),
      defaultReport: ref('https://app.powerbi.com/reportEmbed?reportId=eb8127b7-f2d8-4a7b-b2dd-e70fa6e30d8d&autoAuth=true&ctid=30f55b9e-dc49-493e-a20c-0fbb510a0971&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLWVhc3QtYXNpYS1hLXByaW1hcnktcmVkaXJlY3QuYW5hbHlzaXMud2luZG93cy5uZXQvIn0%3D'),
      reportData
    }
  }
}
</script>

<style scoped>

</style>
