<template>
  <div class="row no-wrap rlp__main">
    <div class="column no-wrap max-width">
      <div class="row ctrp__gap-8 rlp__main__form">
        <q-card class="row no-wrap max_x_max">
          <q-tabs v-model="tabMain" dense active-bg-color="secondary" active-color="white" indicator-color="secondary">
            <q-tab label="Мои заявки" name="my-applications" no-caps />
            <q-tab label="Заявки на других" name="applications-for-others" no-caps />
          </q-tabs>
        </q-card>
        <my-requests-filter :tab-main="tabMain"/>
      </div>
      <div class="column ctrp__gap-8">
        <RequestList :tab="tabMain"/>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import RequestList from 'components/request-list-page/RequestList'
import MyRequestsFilter from 'components/request-list-page/MyRequestsFilter'

export default {
  name: 'RequestListPage',
  components: { MyRequestsFilter, RequestList },
  setup () {
    return {
      store: mainStore(),
      model: ref('one'),
      tabMain: ref('my-applications'),
      tab: ref('up'),
      requestType: ref(''),
      createdDate: ref(''),
      dateIn: ref('')
    }
  },
  created () {
    this.store.getRequestsListByParam('my-applications', 1)
  },
  computed: {
    requestsOptions () {
      return this.store.modifiedApplicationRef
    }
  },
  watch: {
    tabMain (val) {
      if (val === 'my-applications') this.store.getRequestsListByParam('my-applications', 1)
      else if (val === 'applications-for-others') this.store.getRequestsListByParam('applications-for-others', 1)
    }
  }
}
</script>
