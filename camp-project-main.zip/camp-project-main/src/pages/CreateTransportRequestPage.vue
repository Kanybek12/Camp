<template>
  <div class="q-pa-md">
    <q-stepper ref="stepper"
               color="primary"
               v-model="step"
               active-color="secondary"
               animated>
      <q-step title="Создание заявки"
              icon="settings"
              :name="1"
              :done="step > 1">
        <FirstStepCard @nextStep="getNextStep"/>
      </q-step>
      <q-step title="Заявка на транспортировку"
              icon="directions_bus"
              :name="2"
              :done="step > 2">
        <SecondStepCard @nextStep="getNextStep"
                        @previousStep="getPreviousStep"/>
      </q-step>
      <q-step title="Заявка создана"
              icon="playlist_add_check"
              :name="4">
        <q-card class="max_x_max ctrp-center">
          <q-card-section>
            <div class="row" style="gap: 24px">
              <q-icon name="task_alt"
                      size="55px"
                      color="green"/>
              <div class="column">
                <div style="font-weight: 600;font-size: 22px;">Ваша заявка создана</div>
                <div>Детали заявки можно посмотреть в разделе "Мои заявки"</div>
              </div>
            </div>
          </q-card-section>
          <q-separator/>
          <q-card-section style="display: flex; justify-content: flex-end">
            <q-btn flat no-caps style="background-color: #5F8BFF; color: #FFFFFF; display: flex; width: 150px"
                   label="Ок" @click="getMyRequestList"/>
          </q-card-section>
        </q-card>
      </q-step>
    </q-stepper>
  </div>
</template>

<script>
import { ref } from 'vue'
import FirstStepCard from 'components/create-transport-request-page/FirstStepCard'
import SecondStepCard from 'components/create-transport-request-page/SecondStepCard'
import { mainStore } from 'stores/main-store'

export default {
  name: 'CreateTransportRequestPage',
  components: { SecondStepCard, FirstStepCard },
  setup () {
    return {
      store: mainStore(),
      step: ref(1)
    }
  },
  methods: {
    getNextStep () {
      this.$refs.stepper.next()
    },
    getPreviousStep () {
      this.$refs.stepper.previous()
    },
    getMyRequestList () {
      this.store.getRequestsListByParam('my-applications', 1)
      this.$router.push('/request-list')
    }
  },
  created () {
    this.store.getLocations()
  }
}
</script>
