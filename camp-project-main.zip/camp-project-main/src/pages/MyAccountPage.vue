<template>
  <div class="column wrap" style="padding: 20px; gap: 24px; width: max-content; margin: 0 auto">
    <PersonalInfo :person-info="getPersonInfoList"/>
    <div class="row" style="justify-content: space-between">
      <Climb :val="`up`"/>
      <Climb :val="`down`"/>
    </div>
  </div>
</template>

<script>
import PersonalInfo from 'components/my-account-page/PersonalInfo'
import Climb from 'components/my-account-page/Climb'
import { mainStore } from 'stores/main-store'
export default {
  name: 'MyAccountPage',
  components: { Climb, PersonalInfo },
  setup () {
    return {
      store: mainStore()
    }
  },
  created () {
    this.store.getLocations()
    this.store.getGender()
    this.store.getRoomCategory()
    this.store.getEmpCodes()
    this.store.getSchedule()
    this.store.getDepartments()
    this.store.getJobTitles()
    this.store.getVisitors()
    this.store.getEmployees()
  },
  computed: {
    getPersonInfoList () {
      return this.store.personData ?? []
    }
  }
}
</script>
