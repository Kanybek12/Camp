<template>
  <div class="column ctrp__gap-8" style="padding: 20px">
    <q-card style="width: 100%">
      <q-card-section>
        <filter-location/>
      </q-card-section>
    </q-card>
    <table-manual-location :list="getList" :page-sum="getPageSum" style="width: 100%"/>
  </div>
</template>

<script >
import { manualLocationStore } from 'stores/ManualLocationStore'
import TableManualLocation from 'components/manual-location/TableManualLocation'
import FilterLocation from 'components/manual-location/FilterLocation'

export default {
  name: 'ManualLocationPage',
  components: { TableManualLocation, FilterLocation },
  setup () {
    return {
      store: manualLocationStore()
    }
  },
  created () {
    this.store.getLocationInfo(
      this.store.locationFilterData.page
    )
  },
  computed: {
    getList () {
      return this.store.locationList.content ?? []
    },
    getPageSum () {
      return this.store.locationList.totalPages ?? 1
    }
  }
}
</script>

<style scoped>

</style>
