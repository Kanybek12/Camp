<template>
  <div class="flex indexPage" style="margin-top: 20px">
    <div class="indexPage__timesheetComponents" v-if="role === 'shift-bus-dispatcher'">
      <ShiftRequestReport :title="reportTitle" :data="vahtaReportData" style="margin-right: 20px"/>
      <ShiftStatusReport :data="vahtaStatusReportData" />
    </div>
    <requests-list :role="role"/>
  </div>
</template>

<script>
import ShiftRequestReport from 'components/driver-components/ShiftRequestReport'
import ShiftStatusReport from 'components/driver-components/ShiftStatusReport'
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'
import RequestsList from 'components/driver-components/RequestsList'

export default {
  name: 'DriverIndexPage',
  components: {
    RequestsList,
    ShiftRequestReport,
    ShiftStatusReport
  },
  setup () {
    return {
      store: mainStore(),
      date: ref(''),
      role: ref()
    }
  },
  computed: {
    reportTitle () {
      return this.role === 'bus-dispatcher' ? 'Заявки на автобус' : 'Заявки на вахтовку'
    },
    vahtaReportData () {
      return this.store.getVahtaData ?? []
    },
    vahtaStatusReportData () {
      return this.store.getVahtaStatusData ?? []
    }
  },
  async created () {
    await this.store.vahtaStatistic('')
    await this.store.vahtaStatusStatistic('')
    await this.store.getApplicationTypeVahta()
    await this.store.getEmployees()
    await this.store.getVisitors()
    await this.store.getLocations()
    this.store.transferDataFilter.page = 1
    if (localStorage.getItem('camp_role').split(',').find(el => el === 'bus-dispatcher')) {
      await this.store.busRequest()
      await this.store.allBusRequests()
      this.role = 'bus-dispatcher'
    }
    if (localStorage.getItem('camp_role').split(',').find(el => el === 'shift-bus-dispatcher')) {
      await this.store.vahtaRequest()
      await this.store.allVahtaRequest()
      this.role = 'shift-bus-dispatcher'
    }
  }
}
</script>
