<template>
  <div class="column ctrp__gap-8" style="padding: 20px">
    <q-card style="width: 100%">
      <q-card-section>
        <filter-archive-transfer/>
      </q-card-section>
    </q-card>
    <table-archive-transfer :list="getList" :page-sum="getPageSum" style="width: 100%"/>
  </div>
</template>

<script>
import TableArchiveTransfer from 'components/archive/TableArchiveTransfer'
import { mainStore } from 'stores/main-store'
import FilterArchiveTransfer from 'components/archive/FilterArchiveTransfer'

export default {
  name: 'ArchivePageTransfer',
  components: { TableArchiveTransfer, FilterArchiveTransfer },
  setup () {
    return {
      store: mainStore()
    }
  },
  created () {
    this.store.getArchiveTransferData(
      this.store.archiveTransferData.page
    )
  },
  computed: {
    getList () {
      return this.store.archiveTransferData.content ?? []
    },
    getPageSum () {
      return this.store.archiveTransferData.totalPages ?? 1
    }
  }
}
</script>

<style scoped>

</style>
