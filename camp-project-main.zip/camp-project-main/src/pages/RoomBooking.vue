<template>
  <div class="room-booking">
    <SingleRoomBooking v-if="currentPath === 'single' || currentPath === 'qw'" />
    <MultiplyRoomBooking v-if="currentPath === 'multi'"/>
    <div class="room-booking__info">
      <div class="room-booking__info_title">
        Информация о брони
      </div>
      <BookingInformation :date1="store.plannedDateIn" />
      <div class="room-booking__info_buttons">
        <q-btn color="green" v-if="currentPath === 'qw'" label="Бронировать" @click="createBooking"
               :disable="this.store.cardBooking.plannedDateIn && this.store.cardBooking.plannedDateOut"/>
        <q-btn color="green" v-if="currentPath !== 'qw'" label="Бронировать" @click="putBooking"/>
      </div>
    </div>
    <q-dialog v-model="successDialod">
      <div class="column" style="width: 300px; background: #FFFFFF; padding: 12px;">
        <div class="room-booking__info_title" style="text-align: center">Комната успешно забронирована</div>
        <div class="row" style="justify-content: flex-end">
          <q-btn flat label="Ок" no-caps @click="$router.push('/booking-list')"/>
        </div>
      </div>
    </q-dialog>
  </div>
</template>

<script>
import { ref, defineComponent } from 'vue'
import { mainStore } from 'stores/main-store'
import SingleRoomBooking from 'components/room-booking/SingleRoomBooking'
import MultiplyRoomBooking from 'components/room-booking/MultiplyRoomBooking'
import BookingInformation from 'components/room-booking/BookingInformation'
import { useQuasar } from 'quasar'

export default defineComponent({
  name: 'RoomBooking',
  components: {
    SingleRoomBooking,
    MultiplyRoomBooking,
    BookingInformation
  },
  setup () {
    const $q = useQuasar()
    return {
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'top',
          color: code === 200 ? 'green' : 'red'
        })
      },
      filter: ref(''),
      selected: ref([]),
      store: mainStore(),
      firstName: ref(''),
      lastName: ref(''),
      empCode: ref(''),
      jobTitle: ref(''),
      department: ref(''),
      gender: ref(''),
      plannedDateIn: ref(''),
      plannedDateOut: ref(''),
      camp: ref(''),
      block: ref(''),
      room: ref(''),
      bed: ref(''),
      genderSelect: ref(''),
      sum: ref(''),
      roomType: ref(''),
      optionsRoom: ref([]),
      armorType: ref(''),
      multiSelectData: ref(null),
      successDialod: ref(false),
      currentPath: ref('qw')
    }
  },
  watch: {
    '$route' (vsl) {
      if (this.$route.fullPath !== '/room-booking') {
        localStorage.setItem('selectType', '')
        localStorage.setItem('selectedData', '')
        localStorage.setItem('switchType', '')
        this.store.cardBooking.plannedDateIn = ''
        this.store.cardBooking.plannedDateOut = ''
        this.store.cardBooking.cardFIO = ''
        this.store.cardBooking.bed = ''
        this.store.cardBooking.title = ''
      }
    }
  },
  created () {
    const selectType = localStorage.getItem('switchType')
    if (selectType === 'multi') {
      this.currentPath = 'multi'
    }
    if (selectType === 'single') {
      this.currentPath = 'single'
    }
    if (selectType === 'booking1') {
      this.currentPath = 'single'
    }
  },
  computed: {
    getLocation () {
      return this.store.modifiedLocationRef
    },
    getBlock () {
      return this.store.modifiedBlockRef
    },
    getGender () {
      return this.store.modifiedGenderRef
    },
    getRoomCat () {
      return this.store.modifiedRoomCategory
    },
    getButton () {
      return this.store.saveBooking.dateOut !== ''
    }
  },
  methods: {
    clearBedCard () {
      this.store.cardBooking.cardFIO = ''
      this.store.cardBooking.plannedDateIn = ''
      this.store.cardBooking.plannedDateOut = ''
      this.store.cardBooking.title = ''
    },
    createBooking () {
      if (this.store.settle === true) {
        this.store.saveBooking.checkIn = this.store.cardBooking.plannedDateIn
        this.store.saveBooking.statusId = 4
        this.store.saveBooking1().then((el) => {
          if (el.status === 200) {
            if (el.data.code === 500) this.showNotif(el.data.message, 400)
            if (el.data.message) this.showNotif(el.data.message, 400)
            else {
              this.successDialod = true
              this.clearBedCard()
            }
          }
        })
      } else {
        this.store.saveBooking1().then((el) => {
          if (el.status === 200) {
            if (el.data.code === 500) this.showNotif(el.data.message, 400)
            if (el.data.message) this.showNotif(el.data.message, 400)
            else {
              this.successDialod = true
              this.clearBedCard()
            }
          }
        })
      }
    },
    putBooking () {
      const singleData = localStorage.getItem('selectedData')
      const singleDataObj = JSON.parse(singleData)
      let id
      let arr
      if (JSON.parse(localStorage.getItem('selectedData'))?.id) {
        id = JSON.parse(localStorage.getItem('selectedData'))?.id
      } else if (JSON.parse(localStorage.getItem('selectedData'))[0]?.id) {
        id = singleDataObj[0].id
      } else id = localStorage.getItem('bookingId')
      this.store.putBooking1(id).then((el) => {
        if (el.status === 200) {
          if (localStorage.getItem('switchType') === 'multi') {
            if (el.data.message) this.showNotif(el.data.message, 400)
            else {
              arr = JSON.parse(localStorage.getItem('selectedData'))
              arr.splice(arr.findIndex(res => res.empCode === this.store.putBooking.empCode), 1)
              localStorage.setItem('selectedData', JSON.stringify(arr))
              this.store.selDataMulti = arr
              this.showNotif('Успешно', 200)
            }
          } else {
            if (el.data.message) this.showNotif(el.data.message, 400)
            else {
              this.clearBedCard()
              this.$router.push('/booking-list')
            }
          }
        } else {
          this.showNotif('Ошибка', 400)
        }
      })
    }
  }
})
</script>
