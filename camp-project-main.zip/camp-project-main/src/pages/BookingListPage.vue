<template>
  <div class="flex timesheetComponents" style="margin-top: 20px">
    <FilterBookingList/>
    <RoomsBookingList :booking-data="bookingList" v-model:list="bookingList"/>
  </div>
</template>

<script>
import RoomsBookingList from 'components/RoomsBookingList'
import FilterBookingList from 'components/FilterBookingList'
import { mainStore } from 'stores/main-store'

export default {
  name: 'BookingListPage',
  components: {
    RoomsBookingList,
    FilterBookingList
  },
  setup () {
    return {
      store: mainStore()
    }
  },
  computed: {
    bookingList () {
      return this.store.bookingList ?? []
    }
  },
  async created () {
    this.store.getBlocks('')
    this.store.getStatusList()
    this.store.getLocation()
    this.store.getLocation()
    this.store.getRoomsList('', '', '')
    this.store.getRoomsListFilter('', '', '', '', '', '', '')
  }
}
</script>

<style lang="scss" scoped>
.timesheetComponents{
  display: flex;
  justify-content: flex-start;
  gap: 8px;
  padding: 0 20px;
  width: 100%;
  background-color: $bg-color;
}
</style>
