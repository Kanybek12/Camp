import { defineStore } from 'pinia'
import { deleteRequest, getRequest, postRequest, putRequest } from 'stores/http-request'
import axios from 'axios'

const url = process.env.API_URL

export const mainStore = defineStore('mainStore', {
  state: () => ({
    visitorsData: [],
    requestsData: [],
    emp: [],
    beds: [],
    rooms: [],
    roomsList: [],
    statusListRef: [],
    bookings: [],
    employees: [],
    locationRef: [],
    blockRef: [],
    selDataMulti: [],
    scheduleRef: [],
    employeesRef: [],
    costCenterRef: [],
    genderRef: [],
    bedTypeRef: [],
    departmentsRef: [],
    jobTitlesRef: [],
    roomsDetails: [],
    visitorsRef: [],
    applicationRef: [],
    roomByParams: [],
    bedByParams: [],
    locations: [],
    ascend: [],
    ascendData: [],
    descend: [],
    descendData: [],
    settlementRoom: [],
    bedQuantityByParams: [],
    guardPointData: [],
    busReq: [],
    allBusReq: [],
    booking: {
      pages: 0,
      content: []
    },
    settlement: {
      pages: 0,
      content: []
    },
    conflicts: {
      pages: 0,
      content: []
    },
    roomCategory: [],
    roomCapacity: [],
    bookingList: [],
    empCodes: [],
    allRoomsForConstructor: [],
    employee: [],
    selectedMulti: [],
    cardBooking: {
      plannedDateIn: '',
      plannedDateOut: '',
      cardFIO: '',
      bed: '',
      title: ''
    },
    saveBooking: {
      changedBy: 'hand_booking',
      dateChanged: '2022-07-21 16:05:30',
      empCode: '',
      bedId: '',
      dateIn: '',
      dateOut: '',
      checkIn: null,
      checkOut: null,
      statusId: 2,
      payAccount: '',
      firstName: '',
      lastName: '',
      genderId: '',
      department: '',
      jobTitle: '',
      note: '',
      passport: ''
    },
    bookingTheList: [],
    personData: [],
    putBooking: {
      empCode: '',
      firstName: '',
      lastName: '',
      gender: '',
      department: '',
      jobTitle: '',
      dateIn: '',
      dateOut: '',
      location: '',
      block: '',
      room: '',
      bedId: '',
      roomGender: '',
      category: '',
      passport: '',
      status: ''
    },
    guardPointParams: {
      dateIn: '',
      dateOut: '',
      dateInCamp: '',
      dateOutCamp: '',
      employeeCode: '',
      page: 1
    },
    archiveData: [],
    archiveFilterData: {
      page: 1,
      empCode: '',
      dateIn: '',
      dateOut: '',
      checkIn: '',
      checkOut: ''
    },
    archiveTransferData: [],
    archiveFilterTransferData: {
      page: 1,
      empCode: '',
      visitorType: '',
      appType: '',
      date: '',
      status: ''
    },
    transferData: {
      visitorTypeId: '',
      empCode: '',
      changedBy: '',
      firstName: '',
      lastName: '',
      phoneNumber: '',
      dateBirth: '',
      genderId: '',
      pin: '',
      department: '',
      jobTitle: '',
      transferDateTo: '',
      transferDateFrom: '',
      busTransferUp: false,
      busTransferUpDto: {
        fromLocationId: '',
        toLocationId: ''
      },
      vahtaTransferUp: false,
      vahtaTransferUpDto: {
        fromLocationId: '',
        toLocationId: ''
      },
      busTransferDown: false,
      busTransferDownDto: {
        fromLocationId: '',
        toLocationId: ''
      },
      vahtaTransferDown: false,
      vahtaTransferDownDto: {
        fromLocationId: '',
        toLocationId: ''
      },
      carTransfer: false,
      carTransferDto: {
        carNumber: '',
        carModel: '',
        driverName: '',
        carTypeId: '',
        fromLocationId: '',
        toLocationId: ''
      },
      carTransferDown: false,
      carTransferDownDto: {
        carNumber: '',
        carModel: '',
        driverName: '',
        carTypeId: '',
        fromLocationId: '',
        toLocationId: ''
      },
      receivingSide: '',
      receivingPerson: '',
      note: '',
      agreement: false,
      campLiveNeed: false,
      myApplication: false
    },
    vahtaRef: [],
    vahtaReq: [],
    allVahtaReq: [],
    vahtaRefStatus: [],
    getTransferList: [],
    approveList: [],
    applicationRefVahta: [],
    requestsFilterData: {
      createdDate: '',
      dateIn: '',
      requestType: ''
    },
    transferDataFilter: {
      page: 1,
      empCode: '',
      visitorType: '',
      appType: '',
      date: ''
    },
    settle: false,
    gender: '',
    camp: '',
    block: '',
    room: '',
    bed: '',
    permanentResidentList: [],
    permanentResidentFilterData: {
      page: 1,
      size: 50,
      empCode: '',
      locationId: '',
      blockId: '',
      roomId: '',
      gender: '',
      isExistPermanent: ''
    }
  }),
  getters: {
    modifiedEmpRef: (state) => {
      const arr = []
      state?.emp?.map(el => (arr.push(el.code + ' | ' + el.name)))
      return arr
    },
    modifiedLocationRef: (state) => {
      const arr = []
      state?.locationRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.titleRu
        })))
      return arr
    },
    modifiedApplicationRef: (state) => {
      const arr = []
      state?.applicationRef?.map(el => (arr.push(
        {
          value: el.name,
          label: el.nameRu
        })))
      return arr
    },
    modifiedApplicationRefVahta: (state) => {
      const arr = []
      state?.applicationRefVahta?.map(el => (arr.push(
        {
          value: el.id,
          label: el.name
        })))
      return arr
    },
    modifiedVisitorsRef: (state) => {
      const arr = []
      state?.visitorsRef?.map(el => (arr.push({
        value: el.id,
        label: el.name
      })))
      return arr
    },
    modifiedRoomByParam: (state) => {
      const arr = []
      state?.roomByParams?.map(el => (arr.push({ value: el.id, label: el.name })))
      return arr
    },
    modifiedRoomsList: (state) => {
      const arr = []
      state?.roomsList?.map(el => (arr.push({ value: el.id, label: el.blockName + ' - ' + el.name })))
      return arr
    },
    modifiedBedQuantityByParam: (state) => {
      return [{
        value: 1,
        label: state.bedQuantityByParams?.name
      }]
    },
    modifiedBedByParam: (state) => {
      const arr = []
      state?.bedByParams?.map(el => (arr.push(
        {
          value: el.id,
          label: el.bed_numder
        }
      )))
      return arr
    },
    modifiedStatusListRef: (state) => {
      const arr = []
      state?.statusListRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.status
        }
      )))
      return arr
    },
    modifiedBedTypesRef: (state) => {
      const arr = []
      state?.bedTypeRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.title
        }
      )))
      return arr
    },
    modifiedBlockRef: (state) => {
      const arr = []
      state?.blockRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.name
        }
      )))
      return arr
    },
    modifiedGenderRef: (state) => {
      const arr = []
      state?.genderRef?.map(el => (arr.push({ value: el.id, label: el.name })))
      return arr
    },
    modifiedGenderRefForParam: (state) => {
      const arr = []
      state?.genderRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.name
        }
      )))
      return arr
    },
    modifiedRoomCategory: (state) => {
      const arr = []
      state?.roomCategory?.map(el => (arr.push(
        {
          value: el.id,
          label: el.name
        }
      )))
      return arr
    },
    modifiedRoomCapacity: (state) => {
      const arr = []
      state?.roomCapacity?.map(el => (arr.push(
        {
          value: el.id,
          label: el.id
        }
      )))
      return arr
    },
    modifiedSchedule: (state) => {
      const arr = []
      state?.scheduleRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.title
        }
      )))
      return arr
    },
    modifiedDepartments: (state) => {
      const arr = []
      state?.departmentsRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.title
        }
        // el.id + ' - ' + el.title
      )))
      return arr
    },
    modifiedEmployees: (state) => {
      const arr = []
      state?.employeesRef?.map(el => (arr.push(
        {
          value: el.empCode,
          label: el.empCode + ' | ' + el.name
        }
      )))
      return arr
    },
    modifiedCostCenters: (state) => {
      const arr = []
      state?.costCenterRef?.map(el => (arr.push(
        {
          value: el.code,
          label: el.code + ' | ' + el.name
        }
      )))
      return arr
    },
    modifiedLocations: (state) => {
      const arr = []
      state?.locations?.map(el => (arr.push(
        {
          value: el.id,
          label: el.titleRu
        }
      )))
      return arr
    },
    modifiedLocationsBusDispatcher: (state) => {
      const arr = []
      state?.locations?.filter(el => el.approverTypeId === 7).map(el => (arr.push(
        {
          value: el.id,
          label: el.titleRu
        }
      )))
      return arr
    },
    modifiedLocationsShiftBusDispatcher: (state) => {
      const arr = []
      state?.locations?.filter(el => el.approverTypeId === 8).map(el => (arr.push(
        {
          value: el.id,
          label: el.titleRu
        }
      )))
      return arr
    },
    modifiedJobTitles: (state) => {
      const arr = []
      state?.jobTitlesRef?.map(el => (arr.push(
        {
          value: el.id,
          label: el.titleRu
        }
      )))
      return arr
    },
    modifiedEmpCodes: (state) => {
      const arr = []
      state?.empCodes?.map(el => (arr.push(el + '')))
      return arr
    },
    getBookingData (state) {
      const arr = []
      // eslint-disable-next-line array-callback-return
      Object.keys(state?.bookings).map((el) => {
        const name = el === 'approved' ? 'Назначенные'
          : 'Отклоненные'
        const obj = {
          name,
          ...state?.bookings[el]
        }
        arr.push(obj)
      })
      return arr
    },
    getVahtaStatusData (state) {
      const arr = []
      // eslint-disable-next-line array-callback-return
      Object.keys(state?.vahtaRefStatus).map((el) => {
        const name = el === 'approved' ? 'Одобрена'
          : el === 'inProgress' ? 'Не обработано'
            : 'Отклонено'
        const obj = {
          name,
          ...state?.vahtaRefStatus[el]
        }
        arr.push(obj)
      })
      return arr
    },
    getVahtaData (state) {
      const arr = []
      // eslint-disable-next-line array-callback-return
      Object.keys(state?.vahtaRef).map((el) => {
        const name = el === 'mineSiteEmployees' ? 'Штатные сотрудники'
          : el === 'kumtorEmployees' ? 'Сотрудники КГК'
            : 'Контрактники'
        const obj = {
          name,
          ...state?.vahtaRef[el]
        }
        arr.push(obj)
      })
      return arr
    },
    getRoomReportData (state) {
      const arr = []
      // eslint-disable-next-line array-callback-return
      Object.keys(state?.rooms).map((el) => {
        const name = el === 'available' ? 'Свободные'
          : el === 'occupied' ? 'Занятые'
            : 'Забронированные'
        const obj = {
          name,
          ...state?.rooms[el]
        }
        arr.push(obj)
      })
      return arr
    }
  },
  actions: {
    vahtaStatistic (date) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/vahta/statistics?transfer-date=${date}`, accessToken)
        .then((el) => {
          this.vahtaRef = el?.data
        })
        .catch(err => err)
    },
    vahtaStatusStatistic (date) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/vahta-status/statistics?transfer-date=${date}`, accessToken)
        .then((el) => {
          this.vahtaRefStatus = el?.data
        })
        .catch(err => err)
    },
    vahtaRequest (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/vahta/application-list?page=${this.transferDataFilter.page}&transfer-date=${this.transferDataFilter.date}&emp-code=${this.transferDataFilter.empCode}&application-type=${this.transferDataFilter.appType}&visitor-type=${this.transferDataFilter.visitorType}`, accessToken)
        .then((el) => {
          this.vahtaReq = el?.data
        })
        .catch(err => err)
    },
    allVahtaRequest (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/vahta/received-application-list?page=${this.transferDataFilter.page}&transfer-date=${this.transferDataFilter.date}&emp-code=${this.transferDataFilter.empCode}&application-type=${this.transferDataFilter.appType}&visitor-type=${this.transferDataFilter.visitorType}`, accessToken)
        .then((el) => {
          this.allVahtaReq = el?.data
        })
        .catch(err => err)
    },
    downloadExcelFile (type, empCode, visitorType, appType, date) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      axios({
        url: `${url}/api/report/${type}/xls?transfer-date=${date}&emp-code=${empCode}&application-type=${appType}&visitor-type=${visitorType}`,
        method: 'GET',
        header: accessToken,
        responseType: 'blob'
      }).then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = document.createElement('a')
        link.href = url
        link.setAttribute('download', 'Manifest.xlsx')
        document.body.appendChild(link)
        link.click()
      })
    },
    busRequest (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/bus/application-list?page=${this.transferDataFilter.page}&transfer-date=${this.transferDataFilter.date}&emp-code=${this.transferDataFilter.empCode}&application-type=${this.transferDataFilter.appType}&visitor-type=${this.transferDataFilter.visitorType}`, accessToken)
        .then((el) => {
          this.busReq = el?.data
        })
        .catch(err => err)
    },
    allBusRequests (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/bus/received-application-list?page=${this.transferDataFilter.page}&transfer-date=${this.transferDataFilter.date}&emp-code=${this.transferDataFilter.empCode}&application-type=${this.transferDataFilter.appType}&visitor-type=${this.transferDataFilter.visitorType}`, accessToken)
        .then((el) => {
          this.allBusReq = el?.data
        })
        .catch(err => err)
    },
    getRefreshToken () {
      const body = {
        grant_type: 'refresh_token',
        refresh_token: localStorage.getItem('refresh_token'),
        client_id: process.env.client_id,
        realm: process.env.realm,
        client_secret: process.env.client_secret
      }
      postRequest(process.env.API_AUTH_REFRESH_URL, body) // test
        .then((ref) => {
          if (ref?.data?.access_token) {
            const token = `Bearer ${ref?.data?.access_token}`
            const refreshToken = `${ref?.data?.refresh_token}`
            localStorage.setItem('refresh_token', refreshToken)
            localStorage.setItem('token', token)
            localStorage.setItem('key', 'true')
            axios.defaults.headers.common.Authorization = token
          } else {
            localStorage.clear()
            this.router.push('/login')
          }
        })
        .catch(err => err)
    },
    loginUserStore (data) {
      return postRequest(process.env.API_AUTH_URL, data)
        .then((el) => el)
        .catch(err => err)
    },
    getGuardPoint (page, enterDate, exitDate, checkinDate, checkoutDate, empCode) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/guard-point?page=${page}&enter-date=${enterDate}&exit-date=${exitDate}&checkin-date=${checkinDate}&checkout-date=${checkoutDate}&empcode=${empCode}`, accessToken).then(res => {
        if (res) {
          this.guardPointData = res.data
        }
      })
    },
    // получение архива всех заявок
    getArchiveData () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/all-booking-list?page=${this.archiveFilterData.page}&dateIn=${this.archiveFilterData.dateIn}&dateOut=${this.archiveFilterData.dateOut}&checkIn=${this.archiveFilterData.checkIn}&checkOut=${this.archiveFilterData.checkOut}&emp-code=${this.archiveFilterData.empCode}`, accessToken).then(res => {
        if (res) {
          this.archiveData = res.data
        }
      })
    },
    getArchiveTransferData () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/all-transfer-list?page=${this.archiveFilterTransferData.page}&transfer-date=${this.archiveFilterTransferData.date}&emp-code=${this.archiveFilterTransferData.empCode}&application-type=${this.archiveFilterTransferData.appType}&visitor-type=${this.archiveFilterTransferData.visitorType}&status=${this.archiveFilterTransferData.status}`, accessToken).then(res => {
        if (res) {
          this.archiveTransferData = res.data
        }
      })
    },
    getApproveList (empCode) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/approve/get-list?emp-code=${empCode}`, accessToken).then(res => {
        if (res) {
          this.approveList = res.data
        }
      })
    },
    getPersonData () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/profile/personal-info`, accessToken)
        .then((res) => {
          if (res) this.personData = res.data
        })
    },
    getTransferList (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/driver/transfer-info-list?transfer-date=${data.date}&transfer-type=${data.transferType}&location=${data.location}`, accessToken)
        .then((res) => {
          if (res) this.driverList = res.data
        })
    },
    getDescendData () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/profile/transfer-descent`, accessToken)
        .then((res) => {
          if (res) this.descendData = res.data
        })
    },
    getAscentData () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/profile/transfer-ascent`, accessToken)
        .then((res) => {
          if (res) this.ascendData = res.data
        })
    },
    updateAscentData (data, name) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      //   .then((res) => {
      //     if (res.data.code === 201) {
      //       this.getAscentData()
      //       this.getDescendData()
      //       this.getDescenttData()
      //     }
      //   })
      return putRequest(`${url}/transfer/profile/transfer-${name}`, data, accessToken)
    },
    getDescenttData () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/profile/transfer-ascent`, accessToken)
        .then((res) => {
          if (res) this.descentData = res.data
        })
    },
    getRequestList (path) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/applications/${path}`, accessToken)
        .then((res) => {
          if (path === 'settlement') this.settlementRoom = res.data
          else this[path] = res.data
        })
    },
    recoveryPass (data) {
      return postRequest(url + '/api/update-password', data)
        .then((el) => el)
        .catch(err => err)
    },
    checkEmpCodeStore (data) {
      return postRequest(url + '/api/check/empcode', data)
        .then((el) => el)
        .catch(err => err)
    },
    checkPassportStore (data) {
      return postRequest(url + '/api/check/sin', data)
        .then((el) => el)
        .catch(err => err)
    },
    registerContractUser (data) {
      return postRequest(url + '/api/register', data)
        .then((el) => el)
        .catch(err => err)
    },
    getBookingStats (date) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      if (date) {
        getRequest(`${url}/statistics/bookings?date=${date}`, accessToken).then(res => {
          if (res) {
            this.bookings = res.data
          }
        })
      }
    },
    getRoomReport (date, camp, block) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/statistics/rooms?date=${date}&camp=${camp}&block=${block}`, accessToken).then(res => {
        if (res) {
          this.rooms = res.data
        }
      })
    },
    getStatistics (path) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/statistics/${path}`, accessToken).then(res => {
        if (res) this[path] = res.data
      })
    },
    getLocation () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-location`, accessToken).then(res => {
        if (res) this.locationRef = res.data
      })
    },
    getSchedule () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-schedule`, accessToken).then(res => {
        if (res) this.scheduleRef = res.data
      })
    },
    getRoomCapacity () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/get-room/capacity`, accessToken).then(res => {
        if (res) this.roomCapacity = res.data
      })
    },
    async getEmployees () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      await getRequest(`${url}/utility/get-employees`, accessToken).then(res => {
        if (res) this.employeesRef = res.data
      })
    },
    async getCostCenters () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      await getRequest(`${url}/utility/get-cost-center`, accessToken).then(res => {
        if (res) this.costCenterRef = res.data
      })
    },
    getDepartments () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-departments`, accessToken).then(res => {
        if (res) this.departmentsRef = res.data
      })
    },
    getJobTitles () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-job-titles`, accessToken).then(res => {
        if (res) this.jobTitlesRef = res.data
      })
    },
    getStatusList () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/get-booking-status`, accessToken).then(res => {
        if (res) this.statusListRef = res.data
      })
    },
    getRoomsList (dateIn, dateOut, block) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/get-room/by-date?date-in=${dateIn}&date-out=${dateOut}&block-id=${block}`, accessToken).then(res => {
        if (res) {
          this.roomsList = res.data
        }
      })
    },
    getRoomsListFilter (blockName, room, empCode, empType, status, camp, dateIn) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/get-all-rooms/filter/?block-name=${blockName}&room-num=${room}&emp-code=${empCode}&emp-type=${empType}&status=${status}&location-id=${camp}&date-in=${dateIn}`, accessToken).then(res => {
        if (res) {
          this.bookingList = res.data
        }
      })
    },
    getVisitors () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-visitor-types`, accessToken).then(res => {
        if (res) this.visitorsRef = res.data
      })
    },
    getBlocks (loc) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-block?location=${loc}`, accessToken).then(res => {
        if (res) {
          this.blockRef = res.data
        }
      })
    },
    getGender () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-gender`, accessToken).then(res => {
        if (res) {
          this.genderRef = res.data
        }
      })
    },
    getBedType () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/get-bed-types`, accessToken).then(res => {
        if (res) {
          this.bedTypeRef = res.data
        }
      })
    },
    getApplicationType () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/my-application-type`, accessToken).then(res => {
        if (res) {
          this.applicationRef = res.data
        }
      })
    },
    getApplicationTypeVahta () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/utility/application-type`, accessToken).then(res => {
        if (res) {
          this.applicationRefVahta = res.data
        }
      })
    },
    getBookingTheList (dateIn, dateOut, bed) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/from-booking-list?date-in=${dateIn}&date-out=${dateOut}&bed-id=${bed}`, accessToken).then(res => {
        return res
      })
    },
    getRoomCategory () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/get/room-category`, accessToken).then(res => {
        if (res) {
          this.roomCategory = res.data
        }
      })
    },
    getBlockParam (val) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/get-block/by-date?location-id=${val.locationId}&gender-id=${val.genderId}&date-in=${val.dateIn}&date-out=${val.dateOut}`, accessToken)
        .then(res => {
          if (res) {
            this.blockRef = res.data
          }
          return res
        })
    },
    getRoomByParams (val) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/get-room/by-date?block-id=${val.blockId}&date-in=${val.dateIn}&date-out=${val.dateOut}&gender-id=${val.genderId}&room-id=${val.roomId}`, accessToken)
        .then(res => {
          if (res) {
            this.roomByParams = res.data
          }
          return res
        })
    },
    getBedByParams (val) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/get-bed?room-id=${val.roomId}&date-in=${val.dateIn}&date-out=${val.dateOut}&bed-id=${val.bedId}`, accessToken).then(res => {
        if (res) {
          this.bedByParams = res.data
        }
        return res
      })
    },
    getBedQuantityParams (val) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/get-room/quantity?room-id=${val.roomId}&date-in=${val.dateIn}&date-out=${val.dateOut}`, accessToken).then(res => {
        if (res) {
          this.bedQuantityByParams = res.data
        }
        return res
      })
    },
    getTableData (path) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/statistics/applications/${path}?page=1`, accessToken).then(res => {
        if (res) {
          this[path].content = res?.data?.content
          this[path].pages = res?.data?.totalPages
        }
      })
    },
    async getEmpCodes () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      await getRequest(`${url}/booking/get-emp-codes`, accessToken).then(res => {
        if (res) {
          this.empCodes = res?.data
        }
      })
    },
    getEmployee (empCode) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/get-employee/` + empCode, accessToken).then(res => {
        if (res) {
          this.employee = res?.data
        }
        return res
      })
    },
    saveTransferRequest () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return postRequest(`${url}/transfer/save`, this.transferData, accessToken).then(res => {
        return res
      })
    },
    getLocations () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/get-location`, accessToken).then(res => {
        if (res) {
          this.locations = res?.data
        }
        return res
      })
    },
    checkinSt (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/statistics/applications/booking/check-in`, data, accessToken).then(res => {
        return res
      })
    },
    busApprove (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/bus/approve/${data}`, accessToken).then(res => {
        return res
      })
    },
    vahtaApprove (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/vahta/approve/${data}`, accessToken).then(res => {
        return res
      })
    },
    checkoutSt (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/statistics/applications/booking/check-out`, data, accessToken).then(res => {
        return res
      })
    },
    busReject (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/bus/reject/${data}`, accessToken).then(res => {
        return res
      })
    },
    busUndo (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/bus/undo/${data}`, accessToken).then(res => {
        return res
      })
    },
    checkinTrans (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/check-in`, data, accessToken).then(res => {
        return res
      })
    },
    vahtaReject (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/vahta/reject/${data}`, accessToken).then(res => {
        return res
      })
    },
    vahtaUndo (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/vahta/undo/${data}`, accessToken).then(res => {
        return res
      })
    },
    checkinCancelSt (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/statistics/applications/booking/check-in/cancel`, data, accessToken).then(res => {
        return res
      })
    },
    getRoomsConstuctorFilter (empCode, camp, sum, status, blockName, room, gender, category) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/room-designer/get/room?empCode=${empCode}&location-id=${camp}&room-capacity=${sum}&status=${status}&block-name=${blockName}&room-num=${room}&gender=${gender}&category=${category}`, accessToken).then(res => {
        if (res) {
          this.allRoomsForConstructor = res
        }
      })
    },
    getAllRoomsForConstructor (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/room-designer/get/room?location-id=${data.location}&block-name=${data.blockName}&room-num=${data.roomNum}&page=${data.page}&size=${data.size}`, accessToken).then(res => {
        if (res) {
          this.allRoomsForConstructor = res
        }
        return res
      })
    },
    getRoomDetails (id) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/room-designer/get/room-details/${id}`, accessToken).then(res => {
        if (res) {
          this.roomsDetails = res
        }
        return res
      })
    },
    filterFirstList (page, dateIn, dateOut, visitor, department, jobTitle, onSchedule, empCode) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/statistics/applications/settlement?page=${page}&date-in=${dateIn}&date-out=${dateOut}&visitor-type-id=${visitor}&department-id=${department}&job-title-id=${jobTitle}&on-schedule=${onSchedule}&empCode=${empCode}`, accessToken).then(res => {
        if (res) {
          this.settlement.content = res?.data?.content
          this.settlement.pages = res?.data?.totalPages
        }
      })
    },
    filterSecondList (page, checkIn, visitor, department, dateIn, dateOut, empCode) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/statistics/applications/booking?page=${page}&check-in=${checkIn}&visitor-type-id=${visitor}&department-id=${department}&date-in=${dateIn}&transit-status=&date-out=${dateOut}&empCode=${empCode}`, accessToken).then(res => {
        if (res) {
          this.booking.content = res?.data?.content
          this.booking.pages = res?.data?.totalPages
        }
      })
    },
    getConflictsData (empCode, dateIn, dateOut, empType, page) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/booking/get-conflict-booking?emp-code=${empCode}&dateIn=${dateIn}&dateOut=${dateOut}&emp-type=${empType}&page=${page}`, accessToken).then(res => {
        if (res) {
          this.conflicts.content = res?.data?.content
          this.conflicts.pages = res?.data?.totalPages
        }
      })
    },
    getBookingForChange (id) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/set-booking/${id}`, accessToken).then(res => {
        return res
      })
    },
    saveBooking1 () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return postRequest(`${url}/booking/save`, this.saveBooking, accessToken)
        .then((el) => {
          return el
        })
        .catch(err => err)
    },
    putBooking1 (id) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/booking/edit-booking/${id}`, this.putBooking, accessToken)
        .then((el) => {
          return el
        })
        .catch(err => err)
    },
    cancelBooking1 (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return deleteRequest(`${url}/statistics/applications/settlement/reject`, data, accessToken)
        .then((res) => res)
    },
    cancelManualBooking (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/booking/manual-booking-cancel`, data, accessToken)
        .then(res => {
          return res
        })
    },
    saveConstructorChanges (data, idRoom) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(
        `${url}/room-designer/edit/room/${idRoom}`,
        data,
        accessToken
      )
        .then((el) => el)
        .catch(err => err)
    },
    addVisitorToBed (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return postRequest(`${url}/room-designer/visitors`, data, accessToken).then(res => res)
    },
    deleteVisitorsFromBed (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return deleteRequest(`${url}/room-designer/visitors`, data, accessToken)
        .then(res => res)
        .catch(error => {
          console.log(error)
        })
    },
    addBed2Room (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return postRequest(`${url}/utility/bed`, data, accessToken)
    },
    deleteBedsFromRoom (ids) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return deleteRequest(`${url}/utility/bed/${ids}`, accessToken)
    },
    getStockBeds () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/utility/get-stock-beds`, accessToken)
        .then(res => res)
    },
    getRequestsListByParam (type, page) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/transfer/${type}?page=${page}&dateCreated=${this.requestsFilterData.createdDate}&plannedDate=${this.requestsFilterData.dateIn}&applicationType=${this.requestsFilterData.requestType}`, accessToken)
        .then(res => {
          if (res) {
            this.requestsData = res.data
          }
        })
    },
    createGuestRequest (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return postRequest(`${url}/utility/create-guest`, data, accessToken)
    },
    cancelMyRequests (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/applications/cancel`, data, accessToken)
    },
    approveRequestsFun (data) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return putRequest(`${url}/transfer/approve/transfer-status`, data, accessToken)
    },
    getDetailInfoForVacationDialog (bedId) {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      return getRequest(`${url}/booking/vacation-detail-info/` + bedId, accessToken)
        .then(res => {
          return res
        })
    },
    getPermanentResidents () {
      this.getRefreshToken()
      const accessToken = {
        Authorization: localStorage.getItem('token')
      }
      getRequest(`${url}/room-designer/get/permanent-resident?emp-code=${this.permanentResidentFilterData.empCode}&location-id=${this.permanentResidentFilterData.locationId}&block-name=${this.permanentResidentFilterData.blockId}&room-num=${this.permanentResidentFilterData.roomId}&gender=${this.permanentResidentFilterData.gender}&is-exist-permanent=${this.permanentResidentFilterData.isExistPermanent}&page=${this.permanentResidentFilterData.page}&size=${this.permanentResidentFilterData.size}`, accessToken).then(res => {
        if (res) {
          this.permanentResidentList = res.data
        }
      })
    }
  }
})
