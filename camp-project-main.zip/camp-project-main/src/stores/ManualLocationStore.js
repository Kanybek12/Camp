import { defineStore } from 'pinia'
import { getReq, putReq } from 'stores/http-request'

export const manualLocationStore = defineStore('manualLocationStore', {
  state: () => ({
    locationList: [],
    locationFilterData: {
      page: 1,
      size: 10,
      empCode: '',
      fullName: '',
      currentLocation: ''
    }
  }),
  getters: {
  },
  actions: {
    getLocationInfo () {
      getReq(`/manual/getManualLocation?emp-code=${this.locationFilterData.empCode}&page=${this.locationFilterData.page}&size=${this.locationFilterData.size}`).then(res => {
        if (res) {
          this.locationList = res.data
        }
      })
    },
    updateLocationInfo (data) {
      return putReq('/manual/updateLocationInfo', data).then(res => {
        return res
      })
    }
  }
})
