import axios from 'axios'
import authHeader from '../services/auth-header'

const API = process.env.API_URL

function getReq (url) {
  return axios.get(API + url, { headers: authHeader() })
    .then((el) => el)
    .catch(err => err)
}
function putReq (url, data) {
  return axios.put(API + url, data, { headers: authHeader() })
    .then((el) => el)
    .catch(err => err)
}

function getRequest (url, headers) {
  return axios.get(url, { headers })
    .then((el) => el)
    .catch(err => err)
}

function postRequest (url, data, headers) {
  return axios.post(url, data, { headers })
    .then((el) => el)
    .catch(err => err)
}

function deleteRequest (url, data, headers) {
  return axios.delete(url, {
    headers,
    data
  }).then((el) => el)
    .catch(err => err)
}

function putRequest (url, data, headers) {
  return axios.put(url, data, { headers })
    .then((el) => el)
    .catch(err => err)
}

export {
  getRequest,
  postRequest,
  deleteRequest,
  putRequest,
  getReq,
  putReq
}
