
const routes = [
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', component: () => import('pages/IndexPage.vue') },
      {
        path: '/room-booking',
        component: () => import('pages/RoomBooking.vue'),
        params: true
      },
      { path: '/reports', component: () => import('pages/ReportsPage.vue') },
      { path: '/booking-list', component: () => import('pages/BookingListPage.vue') },
      { path: '/room-constructor', component: () => import('pages/RoomConstructor.vue') },
      { path: '/guard-point', component: () => import('pages/GuardPointPage.vue') },
      { path: '/transport-request', component: () => import('pages/CreateTransportRequestPage.vue') },
      { path: '/my-account', component: () => import('pages/MyAccountPage.vue') },
      { path: '/transfer', component: () => import('pages/DriverIndexPage') },
      { path: '/archive-page', component: () => import('pages/ArchivePage') },
      { path: '/archive-page-transfer', component: () => import('pages/ArchivePageTransfer') },
      { path: '/request-list', component: () => import('pages/RequestListPage.vue') },
      { path: '/approve-requests', component: () => import('pages/ApproveRequests.vue') },
      { path: '/manual-location', component: () => import('pages/ManualLocationPage.vue') }
    ]
  },
  { path: '/login', component: () => import('pages/Authorization.vue') },
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue')
  }
]

export default routes
