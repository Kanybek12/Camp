<template>
  <q-list padding bordered
    class="shadow-2 rounded-borders list ip__diagram-form">
    <div class="ip__diagram-form__block">
      <div id="chart" class="color-grey">
        {{'Данные отображены на  ' + getDate}}
        <div class="box">
          <div class="pie">
            <ul class="legend">
              <li class="li-title">
                <div class="li-title-occup-circle"/>Занятые места: {{diagramData.totalOccupiedBeds}}
              </li>
              <li class="li-sub">
                <div class="li-sub-male-occup"/>мужские: {{diagramData?.occupiedBeds?.male}}
              </li>
              <li class="li-sub">
                <div class="li-sub-female-occup"/>женские: {{diagramData?.occupiedBeds?.female}}
              </li>
              <li class="li-title">
                <div class="li-title-avail-circle"/>Свободные места: {{diagramData.totalAvailableBeds}}
              </li>
              <li class="li-sub">
                <div class="li-sub-male-avail"/>мужские: {{diagramData?.availableBeds?.male}}
              </li>
              <li class="li-sub">
                <div class="li-sub-female-avail"/>женские: {{diagramData?.availableBeds?.female}}
              </li>
            </ul>
            <div :style="`background: conic-gradient(#4caf50 ${availablePercent}%, #f44336 0%);border-radius: 50%;width: 100%;height: 100%;`">
              <q-tooltip anchor="center middle" self="bottom middle"
                         style="background-color: #EFF3FB; padding: 8px">
                <div class="text-red ip__diagram-form__block__txt">
                  Занято: {{diagramData.totalOccupiedBeds}} ({{occupiedPercent}}%)
                </div>
                <div class="text-green ip__diagram-form__block__txt">
                  Свободно: {{diagramData.totalAvailableBeds}} ({{availablePercent}}%)
                </div>
              </q-tooltip>
            </div>
          </div>
        </div>
      </div>
    </div>
  </q-list>
</template>

<script>

export default {
  name: 'DiagramReportForm',
  props: {
    diagramData: {
      type: Array
    }
  },
  computed: {
    getDate () {
      return new Date().toISOString().slice(0, 10)
    },
    availablePercent () {
      const available = this.diagramData.totalAvailableBeds
      const occupied = this.diagramData.totalOccupiedBeds
      const total = Number(available) + Number(occupied)
      const minPercent = total / 100
      return Number(available / minPercent).toFixed(1)
    },
    occupiedPercent () {
      const available = this.diagramData.totalAvailableBeds
      const occupied = this.diagramData.totalOccupiedBeds
      const total = Number(available) + Number(occupied)
      const minPercent = total / 100
      return Number(occupied / minPercent).toFixed(1)
    }
  }
}
</script>
<style scoped lang="scss">
.box {
  padding: 10px;
  display: inline-block;
  border-radius: 10px;
  vertical-align: top;
}
.pie {
  width: 200px;
  height: 200px;
  position:relative;

}

.bg-fill {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  position:absolute;
  display:none;
  z-index: 1;
  clip-path: polygon(50% 0%, 50% 100%, 0% 100%, 0% 0%);
  transform: rotate(180deg);
}

.legend {
  position: absolute;
  margin-left: 15px;
  left: 100%;
  width: 200px;
  list-style: none;
  padding: 0;
}
.legend li {
  margin: 5px;
  display: flex;
  align-items: center;
  color: black;
}
.li-sub{
  margin-left: 15%!important;
}
.li-title{
  font-size: 15px;
  font-weight: 600;
  color: black;
  display: flex;
  align-items: center;
}
.li-title-occup-circle{
  width: 12px;
  height: 12px;
  background: #F84C26;
  margin-right: 5px;
  border-radius: 10px;
}
.li-title-avail-circle{
  width: 12px;
  height: 12px;
  background: rgba(76, 175, 80, 0.7);
  margin-right: 5px;
  border-radius: 10px;
}
.li-sub-male-occup {
  width: 6px;
  height: 6px;
  background: rgba(248, 76, 38, 0.65);
  margin-right: 3px;
  border-radius: 10px;
}
.li-sub-female-occup {
  width: 6px;
  height: 6px;
  background:rgba(248, 76, 38, 0.25);
  margin-right: 3px;
  border-radius: 10px;
}
.li-sub-male-avail {
  width: 6px;
  height: 6px;
  background: rgba(70, 233, 115, 0.50);
  margin-right: 5px;
  border-radius: 10px;
}
.li-sub-female-avail {
  width: 6px;
  height: 6px;
  background: rgba(70, 233, 115, 0.30);
  margin-right: 5px;
  border-radius: 10px;
}
</style>
