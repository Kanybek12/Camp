<template>
    <q-list padding bordered class="shadow-2 rounded-borders ip-rrf__list">
      <div class="ip-rrf__title">Отчет по комнатам</div>
      <div class="column ip-rrf__block">
        <div class="ip-rrf__filter">
          <q-select label="Лагерь" class="ip-rrf__filter__input" outlined dense
                    v-model="camp" :options="getLocation" @update:model-value="getBlockList"/>
          <q-input label="Дата" class="ip-rrf__filter__input" mask="date" outlined readonly dense v-model="date">
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy cover ref="qDateProxy" transition-show="scale" transition-hide="scale">
                <q-date v-model="date" minimal>
                  <div class="row items-center justify-end">
                    <q-btn label="Применить" color="primary" v-close-popup flat no-caps/>
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
        </div>
        <div class="ip-rrf__filter">
          <q-select label="Блок" class="ip-rrf__filter__input-second" outlined dense v-model="block"
                    :options="getBlock"/>
          <q-btn class="ip-rrf__filter__input-second ip-rrf__filter__btn" text-color="white"
                 flat dense no-caps @click="filterReport(date, camp, block)">
            <div class="ip-rrf__filter__btn__label">
              <q-icon name="filter_list"/>
              <div>Применить</div>
            </div>
            <q-tooltip>Применить фильтр</q-tooltip>
          </q-btn>
          <q-btn class="ip-rrf__filter__input-second ip-rrf__filter__btn" text-color="white" flat dense no-caps
                 @click="cancelFilter">
            <div class="ip-rrf__filter__btn__label">
              <q-icon name="filter_list_off"/>
              <div>Отменить</div>
            </div>
            <q-tooltip>Отменить фильтр</q-tooltip>
          </q-btn>
        </div>
      </div>
      <q-separator/>
      <q-table row-key="name" style="box-shadow: none" separator="cell" hide-bottom :rows="roomData" :columns="columns">
        <template v-slot:header="props">
          <q-tr :props="props">
            <q-th v-for="col in props.cols" :key="col.name" :props="props">
             <div class="tab-head">{{ col.label }}</div>
              <div v-if="col.name !== 'name'" class="ip-rrf__filter__icons">
                <q-icon name="boy" class="ip-rrf__filter__icons__male"/>
                <q-icon name="girl" class="ip-rrf__filter__icons__female"/>
              </div>
            </q-th>
          </q-tr>
        </template>
        <template v-slot:body="props">
          <q-tr :props="props">
            <q-td key="name" :props="props">{{ props.row.name }}</q-td>
            <q-td key="fully" :props="props">
              <div class="ip-rrf__filter__col-block">
                <span v-if="props.key === 'Свободные'">{{ props.row.fully.maleRooms }}</span>
                <span v-if="props.key === 'Свободные'">{{ props.row.fully.femaleRooms }}</span>
              </div>
              <div class="ip-rrf__filter__col-block">
                <span v-if="props.key === 'Занятые'">{{ props.row.fully.maleRooms }}</span>
                <span v-if="props.key === 'Занятые'">{{ props.row.fully.femaleRooms }}</span>
              </div>
              <div class="ip-rrf__filter__col-block">
                <span v-if="props.key === 'Забронированные'">{{ props.row.fully.maleRooms }}</span>
                <span v-if="props.key === 'Забронированные'">{{ props.row.fully.femaleRooms }}</span>
              </div>
            </q-td>
            <q-td key="partly" :props="props">
              <div class="ip-rrf__filter__col-block">
                <span v-if="props.key === 'Свободные'">{{ props.row.partly.maleRooms }}</span>
                <span v-if="props.key === 'Свободные'">{{ props.row.partly.femaleRooms }}</span>
              </div>
              <div class="ip-rrf__filter__col-block">
                <span v-if="props.key === 'Занятые'">{{ props.row.partly.maleRooms }}</span>
                <span v-if="props.key === 'Занятые'">{{ props.row.partly.femaleRooms }}</span>
              </div>
              <div class="ip-rrf__filter__col-block">
                <span v-if="props.key === 'Забронированные'">{{ props.row.partly.maleRooms }}</span>
                <span v-if="props.key === 'Забронированные'">{{ props.row.partly.femaleRooms }}</span>
              </div>
            </q-td>
          </q-tr>
        </template>
      </q-table>
    </q-list>
</template>

<script>
import { ref, computed } from 'vue'
import { mainStore } from 'stores/main-store'

const columns = [
  { name: 'name', label: 'Комнаты', align: 'left', field: row => row.name },
  { label: 'Полностью', align: 'center', field: 'fully', name: 'fully' },
  { label: 'Частично', field: 'partly', align: 'center', name: 'partly' }
]
export default {
  name: 'RoomReportForm',
  props: {
    roomData: {
      type: Array,
      default: () => []
    }
  },
  setup () {
    const progress1 = ref(0.3)
    const progress2 = ref(0.9)
    const store = mainStore()
    return {
      columns,
      store,
      progress1,
      progressLabel1: computed(() => (progress1.value * 100)),
      progress2,
      progressLabel2: computed(() => (progress2.value * 100)),
      date: ref(''),
      camp: ref(''),
      block: ref('')
    }
  },
  computed: {
    getLocation () {
      return this.store.modifiedLocationRef
    },
    getBlock () {
      return this.store.modifiedBlockRef
    }
  },
  methods: {
    getBlockList () {
      const data = {
        locationId: this.camp?.value,
        genderId: '',
        dateIn: '',
        dateOut: ''
      }
      this.store.getBlockParam(data).then((res) => {
        if (res.status === 200) {
          this.blockData = this.store.modifiedBlockRef
        } else {
          console.log('ERROR')
        }
      }).catch(error => {
        console.log(error)
      })
    },
    filterReport (date, camp, block) {
      if (date === '') {
        date = new Date().toISOString().substring(0, 10)
      } else {
        date = this.date.replaceAll('/', '-')
      }
      this.store.getRoomReport(
        date,
        this.camp?.value ?? '',
        block?.value ?? ''
      )
    },
    cancelFilter () {
      this.date = ''
      this.camp = ''
      this.block = ''
      this.store.getStatistics('rooms')
    }
  },
  async created () {
    await this.store.getLocation()
    await this.store.getBlocks(this.camp)
  }
}
</script>

<style scoped>
.q-table th, .q-table td {
  padding: 0 8px;
  background-color: inherit;
}
.q-table thead tr, .q-table tbody td {
  height: 40px;
}
</style>
