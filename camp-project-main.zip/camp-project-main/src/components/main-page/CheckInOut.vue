<template>
  <div class="checkinOut">
    <q-tabs v-model="tab" align="justify" narrow-indicator>
      <q-tab label="Заезд/Выезд" class="bg-grey-3 checkinOut__tab" name="checkout"/>
      <q-tab label="Заявки на заселение" class="bg-grey-3 checkinOut__tab" name="checkin"/>
      <q-tab label="Конфликты" class="bg-grey-3 checkinOut__tab" name="conflicts"/>
    </q-tabs>
    <q-tab-panels v-model="tab" animated>
      <q-tab-panel name="checkin">
        <div class="checkinOut__block">
          <p class="checkinOut__block__title">Фильтрация</p>
          <div class="checkinOut__block__filter">
            <div class="checkinOut__block__filter__tabs">
              <q-select label="Таб. №" class="checkinOut__block__filter__tabs__input" input-debounce="0"
                        outlined use-input hide-selected fill-input dense v-model="employeeCode"
                        :options="employeesData" @filter="filterFn" @input-value="setEmpCodeValue" @keyup.enter="filterList">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
                  </q-item>
                </template>
              </q-select>
              <q-select
                label="Выберите тип посетителя" class="checkinOut__block__filter__tabs__input" dense outlined
                v-model="selectGuestType" :options="[ { label: 'Штатный сотрудник рудника', value: 1 }, { label: 'Сотрудник КГК', value: 2 },
                { label: 'Контрактник', value: 3 }, { label: 'Гость', value: 4 } ]"/>
            </div>
            <div class="checkinOut__block__filter__tabs">
              <q-select label="Отдел" class="checkinOut__block__filter__tabs__input"
                        outlined use-input hide-selected fill-input dense v-model="departmentCode"
                        :options="departmentsData" @filter="filterDepartment" @input-value="setDepartmentValue">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
                  </q-item>
                </template>
              </q-select>
              <q-select label="Должность" class="checkinOut__block__filter__tabs__input"
                        outlined use-input hide-selected fill-input dense v-model="jobTitleCode"
                        :options="jobTitlesData" @filter="filterJobTitle" @input-value="setJobTitleValue">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
                  </q-item>
                </template>
              </q-select>
            </div>
            <div class="checkinOut__block__filter__tabs">
              <q-input placeholder="Планируемая дата заезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="dateIn">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="dateIn">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup flat label="Применить" color="primary"/>
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <q-input placeholder="Планируемая дата выезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="dateOut">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="dateOut">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup flat label="Применить" color="primary"/>
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="checkinOut__block__filter__btns">
              <q-btn label="Применить"
                     icon="filter_list"
                     class="checkinOut__block__filter__btns__btn"
                     text-color="white"
                     flat no-caps
                     @click="filterList()">
                <q-tooltip>Применить фильтр</q-tooltip>
              </q-btn>
              <q-btn label="Отменить"
                     icon="filter_list_off"
                     class="checkinOut__block__filter__btns__btn"
                     text-color="white"
                     flat no-caps
                     @click="cancelFilter('F')">
                <q-tooltip>Отменить фильтр</q-tooltip>
              </q-btn>
            </div>
          </div>
        </div>
        <q-table title="Заявки на заселение" ref="tableRef" tabindex="0" row-key="id" selection="multiple"
                 :rows="settlementData" :columns="columns1" :class="tableClass" :filter="filter"
                 v-model:selected="selected" v-model:pagination="paginationElements" no-data-label="Нет данных">
          <template v-slot:top-right>
            <div class="checkinOut__block__table-list">
              <q-btn label="Назначить" color="green-14" class="checkinOut__block__table-list__btn"
                     :disable="selected.length === 0" @click="goToBooking" no-caps>
                <q-tooltip>Назначить комнату</q-tooltip>
              </q-btn>
              <q-btn label="Не назначать" color="red-14" class="checkinOut__block__table-list__btn"
                     :disable="selected.length === 0" @click="cancelAppointment" no-caps>
                <q-tooltip>Не назначать комнату</q-tooltip>
              </q-btn>
              <q-btn label="Ручное бронирование" class="checkinOut__block__table-list__btn" color="primary"
                     no-caps outline @click="goToBooking1">
                <q-tooltip>Забронировать вручную</q-tooltip>
              </q-btn>
            </div>
          </template>
          <template v-slot:body-cell-jobTitle="props">
            <q-td :props="props">
              <div class="ip__checkin-checkout__col-txt">{{ props.row.jobTitle}}
                <q-tooltip>{{props.row.jobTitle}}</q-tooltip>
              </div>
            </q-td>
          </template>
          <template v-slot:bottom>
            <div class="checkinOut__block__table-list__pagination">
              <q-pagination v-model="currentSetElement" color="grey-10" active-color="grey-10"
                            active-text-color="white" :max="store.settlement?.pages" :max-pages="6"
                            direction-links boundary-links @click="filterList()"/>
            </div>
          </template>
        </q-table>
      </q-tab-panel>
      <q-tab-panel name="checkout">
        <div class="checkinOut__block">
          <p class="checkinOut__block__title">Фильтрация</p>
          <div class="checkinOut__block__filter">
            <div class="checkinOut__block__filter__btns">
              <q-btn label="Применить" icon="filter_list" class="checkinOut__block__filter__btns__btn"
                     text-color="white"
                     flat no-caps @click="filterInOut()">
                <q-tooltip>Применить фильтр</q-tooltip>
              </q-btn>
              <q-btn label="Отменить" icon="filter_list_off" class="checkinOut__block__filter__btns__btn"
                     text-color="white" flat no-caps @click="cancelFilter('S')">
                <q-tooltip>Отменить фильтр</q-tooltip>
              </q-btn>
            </div>
            <div class="checkinOut__block__filter__tabs">
              <q-select label="Таб. №" class="checkinOut__block__filter__tabs__input" input-debounce="0"
                        dense outlined use-input hide-selected fill-input v-model="employeeCode"
                        :options="employeesData" @filter="filterFn" @input-value="setEmpCodeValue" @keyup.enter="filterInOut">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
                  </q-item>
                </template>
              </q-select>
              <q-input placeholder="Планируемая дата заезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="dateIn">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="dateIn">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup flat label="Применить" color="primary"/>
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="checkinOut__block__filter__tabs">
              <q-select label="Отдел" class="checkinOut__block__filter__tabs__input"
                        outlined use-input hide-selected fill-input dense v-model="departmentCode"
                        :options="departmentsData" @filter="filterDepartment" @input-value="setDepartmentValue">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
                  </q-item>
                </template>
              </q-select>
              <q-input placeholder="Планируемая дата выезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="dateOut">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="dateOut">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup flat label="Применить" color="primary"/>
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="checkinOut__block__filter__tabs">
              <q-select label="Выберите тип посетителя" class="checkinOut__block__filter__tabs__input" dense outlined
                        v-model="selectGuestType" :options="[ { label: 'Штатный сотрудник рудника', value: 1 }, { label: 'Сотрудник КГК', value: 2 },
                { label: 'Контрактник', value: 3 }, { label: 'Гость', value: 4 } ]"/>
              <q-input placeholder="Фактическая дата заезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="checkIn">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="checkIn">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup label="Применить" color="primary" flat />
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
        </div>
        <q-table title="Заезд/Выезд" row-key="id" selection="multiple" ref="tableRef"
                 :filter="filter" :rows="bookingData" :columns="columns2"
                 v-model:selected="selectedSettlement" v-model:pagination="paginationBooking" no-data-label="Нет данных">
          <template v-slot:top-left>
            <div class="checkinOut__block__table-list">
              <q-btn label="Заезд" class="checkinOut__block__table-list__btn" color="green-14"
                     :disable="getDisGreen" @click="checkout('checkin')" no-caps>
                <q-tooltip>Установить дату заезда</q-tooltip>
              </q-btn>
              <q-btn label="Выезд" color="red-14" class="checkinOut__block__table-list__btn"
                     :disable="getDisRed" @click="checkout('checkout')" no-caps>
                <q-tooltip>Установить дату выезда</q-tooltip>
              </q-btn>
              <q-btn label="Отменить заезд" color="primary" class="checkinOut__block__table-list__btn"
                     :disable="getDisRed" @click="checkout('cancel')" no-caps outline>
                <q-tooltip>Отменить заезд</q-tooltip>
              </q-btn>
            </div>

              <q-btn dense color="secondary" label="Add Row" v-show="false" @click="show_dialog = true" no-caps></q-btn>
              <div class="q-pa-md q-gutter-sm">
                <q-dialog v-model="show_dialog" >
                  <q-card>
                    <q-card-section>
                      <div class="text-h6">Изменить фактическую дату заезда</div>
                    </q-card-section>
                    <q-card-section>
                      <div class="row q-col-gutter-x-xs" >
                        <q-input v-model="editedItem.empCode" label="Таб. №" :disable="true"></q-input>
                        <q-input v-model="editedItem.name" label="ФИО" :disable="true"></q-input>
                        <q-input v-model="editedItem.jobTitle" label="Должность" :disable="true"></q-input>
                        <q-input v-model="editedItem.department" label="Отдель/Организация" :disable="true"></q-input>
                        <q-input v-model="editedItem.dateIn" label="Планируемая дата заезда" :disable="true"></q-input>
                        <q-input v-model="editedItem.dateOut" label="Планируемая дата выезда" :disable="true"></q-input>
                        <q-input v-model="editedItem.visitorType" label="Тип" :disable="true"></q-input>
                        <q-input v-model="editedItem.onSchedule" label="График" :disable="true"></q-input>
                        <q-input v-model="editedItem.note" label="Примечание" :disable="true"></q-input>
                        <div class="col-12 text-center self-center">
                          <q-input filled v-model="date" mask="date"  label="Фактическая дата заезда" >
                            <template v-slot:append>
                              <q-icon name="event" class="cursor-pointer">
                                <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                                  <q-date v-model="date">
                                    <div class="row items-center justify-end">
                                      <q-btn v-close-popup label="Применить" color="primary" flat />
                                    </div>
                                  </q-date>
                                </q-popup-proxy>
                              </q-icon>
                            </template>
                          </q-input>
                        </div>
                      </div>
                    </q-card-section>
                    <q-card-actions align="right">
                      <q-btn label="Отмена" color="red" flat v-close-popup no-caps/>
                      <q-btn label="Сохранить" flatcolor="green" flat v-close-popup no-caps @click="updateCheckIn"/>
                    </q-card-actions>
                  </q-card>
                </q-dialog>
              </div>
          </template>
          <template v-slot:top-right>
            <span class="q-table__title">Заезд/Выезд</span>
          </template>
          <template v-slot:body-cell-dateOut="props">
            <q-td :props="props">
              <q-badge color="red" v-if="props.row.dateOut < getDate()" :label="props.value" ><q-icon name="warning" color="white" class="q-ml-xs" />
                <q-tooltip>Планируемая дата выезда истекла</q-tooltip>
              </q-badge>
              <q-badge color="grey" v-else :label="props.value" />
            </q-td>
          </template>
          <template v-slot:body-cell-jobTitle="props">
            <q-td :props="props">
              <div style="width: 200px; overflow: hidden; text-overflow: ellipsis;">{{ props.row.jobTitle}}
                <q-tooltip>{{props.row.jobTitle}}</q-tooltip>
              </div>
            </q-td>
          </template>
          <template v-slot:body-cell-actions="props">
            <q-td key="actions" :props="props">
              <q-btn dense round flat color="blue"   @click="editItem(props.row)"  icon="edit" ></q-btn>
            </q-td>
          </template>
          <template v-slot:bottom>
            <div class="checkinOut__block__table-list__pagination">
              <q-pagination v-model="currentBooking" color="grey-10" active-color="grey-10" active-text-color="white"
                            :max="store.booking?.pages" :max-pages="6" direction-links boundary-links @click="filterInOut"/>
            </div>
          </template>
        </q-table>
      </q-tab-panel>
      <q-tab-panel name="conflicts">
        <div class="checkinOut__block">
          <p class="checkinOut__block__title">Фильтрация</p>
          <div class="conflict__block__filter">
            <div class="conflict__block__filter__tabs">
              <q-select label="Таб. №" class="checkinOut__block__filter__tabs__input" input-debounce="0"
                        outlined use-input hide-selected fill-input dense v-model="employeeCode"
                        :options="employeesData" @filter="filterFn" @input-value="setEmpCodeValue" @keyup.enter="filterConflicts">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
                  </q-item>
                </template>
              </q-select>
              <q-select
                label="Выберите тип посетителя" class="checkinOut__block__filter__tabs__input" dense outlined
                v-model="selectGuestType" :options="[ { label: 'Штатный сотрудник рудника', value: 1 }, { label: 'Сотрудник КГК', value: 2 },
                { label: 'Контрактник', value: 3 }, { label: 'Гость', value: 4 } ]"/>
            </div>
            <div class="conflict__block__filter__tabs">
              <q-input placeholder="Планируемая дата заезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="dateIn">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="dateIn">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup flat label="Применить" color="primary"/>
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <q-input placeholder="Планируемая дата выезда" class="checkinOut__block__filter__tabs__input"
                       dense readonly outlined v-model="dateOut">
                <template v-slot:append>
                  <q-icon name="event" class="cursor-pointer">
                    <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                      <q-date v-model="dateOut">
                        <div class="row items-center justify-end">
                          <q-btn v-close-popup flat label="Применить" color="primary"/>
                        </div>
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="checkinOut__block__filter__btns">
              <q-btn label="Применить"
                     icon="filter_list"
                     class="checkinOut__block__filter__btns__btn"
                     text-color="white"
                     flat no-caps
                     @click="filterConflicts()">
                <q-tooltip>Применить фильтр</q-tooltip>
              </q-btn>
              <q-btn label="Отменить"
                     icon="filter_list_off"
                     class="checkinOut__block__filter__btns__btn"
                     text-color="white"
                     flat no-caps
                     @click="cancelFilter('C')">
                <q-tooltip>Отменить фильтр</q-tooltip>
              </q-btn>
            </div>
          </div>
        </div>
        <q-table title="Авто-бронь вне графика" ref="tableRef" tabindex="0" row-key="id" :separator="separator"
                 :rows="conflictsData" :columns="columns3" :class="tableClass" :filter="filter"
                 v-model:selected="selected" v-model:pagination="paginationElements" no-data-label="Нет данных">
          <template v-slot:bottom>
            <div class="checkinOut__block__table-list__pagination">
              <q-pagination v-model="currentConflicts" color="grey-10" active-color="grey-10"
                            active-text-color="white" :max="store.conflicts?.pages" :max-pages="6"
                            direction-links boundary-links @click="filterConflicts"/>
            </div>
          </template>
          <template v-slot:top-right>
            <span class="q-table__title">Ручная бронь, которая конфликтует с авто-бронью</span>
            <q-btn dense color="secondary" label="Delete" v-show="false" @click="show_conflict = true" no-caps></q-btn>
            <div class="q-pa-md q-gutter-sm">
              <q-dialog v-model="show_conflict" >
                <q-card>
                  <q-card-section>
                    <div class="text-h6">Вы действительно хотите отменить?</div>
                  </q-card-section>
                  <q-card-actions align="right">
                    <q-btn label="Отмена" color="red" flat v-close-popup no-caps/>
                    <q-btn label="Да" flatcolor="green" flat v-close-popup no-caps @click="updateConflict"/>
                  </q-card-actions>
                </q-card>
              </q-dialog>
            </div>
          </template>
          <template v-slot:body-cell-roomInfo="props">
            <q-td :props="props">
              <q-badge color="red" :label="props.value" >
              </q-badge>
            </q-td>
          </template>
          <template v-slot:body-cell-action="props">
            <q-td key="action" :props="props">
              <q-btn unelevated color="blue-12" label="Отменить"  @click="editConflict(props.row)"></q-btn>
            </q-td>
          </template>
        </q-table>
      </q-tab-panel>
    </q-tab-panels>
    <q-dialog v-model="confirm" persistent>
      <q-card>
        <q-card-section class="row items-center">
          <span class="q-ml-sm">Вы действительно хотите {{text}} ?</span>
        </q-card-section>
        <q-card-section class="row ctrp__gap-8">
          <q-input v-if="showInput" placeholder="Дата" class="checkinOut__block__filter__tabs__input" dense readonly outlined
                   v-model="dateCheckOut">
            <template v-slot:append>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                  <q-date v-model="dateCheckOut">
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup flat label="Close" color="primary"/>
                    </div>
                  </q-date>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn label="Отмена" color="red" flat v-close-popup no-caps/>
          <q-btn label="Да" flatcolor="green" v-close-popup no-caps @click="confirmed"/>
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { ref, computed } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'

const columns1 = [
  { name: 'empCode', required: true, label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'name', required: true, label: 'ФИО', align: 'left', field: 'name', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'jobTitle', align: 'left', label: 'Должность', field: 'jobTitle', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateIn', align: 'left', label: 'План. дата заезда', field: 'dateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateOut', align: 'left', label: 'План. дата выезда', field: 'dateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'visitorType', align: 'left', label: 'Тип', field: 'visitorType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'note', align: 'left', label: 'Примечание', field: 'note', headerStyle: 'font-size: 13px; font-weight:bold' }
]
const columns2 = [
  { name: 'empCode', required: true, label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'name', required: true, label: 'ФИО', align: 'left', field: 'name', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'jobTitle', align: 'left', label: 'Должность', field: 'jobTitle', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateIn', align: 'left', label: 'План. дата заезда', field: 'dateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateOut', align: 'left', label: 'План. дата выезда', field: 'dateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'checkIn', align: 'left', label: 'Факт. дата заезда', field: 'checkIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bedNumberInRoom', align: 'left', label: 'Кровать', field: 'bedNumberInRoom', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'visitorType', align: 'left', label: 'Тип', field: 'visitorType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'schedule', align: 'left', label: 'График', field: 'onSchedule', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'actions', align: 'left', label: 'Изменить', field: 'actions', headerStyle: 'font-size: 13px; font-weight:bold' }
]
const columns3 = [
  { name: 'confEmpCode', required: true, label: 'Таб. №', align: 'left', field: 'confEmpCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'confFullName', required: true, label: 'ФИО', align: 'left', field: 'confFullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'confDateIn', align: 'left', label: 'План. дата заезда', field: 'confDateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'confDateOut', align: 'left', label: 'План. дата выезда', field: 'confDateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'roomInfo', align: 'left', label: 'Кровать', field: 'roomInfo', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'empCode', required: true, label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', required: true, label: 'ФИО', align: 'left', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateIn', align: 'left', label: 'План. дата заезда', field: 'dateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateOut', align: 'left', label: 'План. дата выезда', field: 'dateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'action', align: 'left', label: 'Отменить ручную бронь', field: 'action', headerStyle: 'font-size: 13px; font-weight:bold' }
]

export default {
  name: 'CheckInOut',
  setup () {
    const selected = ref([])
    const selectedSettlement = ref([])
    const tableRef = ref(null)
    const navigationActive = ref(false)
    const pagination = ref({})
    const $q = useQuasar()
    return {
      isLoading: ref(true),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      store: mainStore(),
      tabMessage: ref('Данные отсутствуют'),
      confirm: ref(false),
      btnDisable: ref(false),
      text: ref(''),
      showInput: ref(true),
      currentSetElement: ref(1),
      currentBooking: ref(1),
      currentConflicts: ref(1),
      pagination,
      paginationElements: {
        descending: false,
        rowsPerPage: 10
      },
      paginationBooking: {
        descending: false,
        rowsPerPage: 10
      },
      separator: 'cell',
      selected,
      selectedSettlement,
      tableRef,
      columns1,
      columns2,
      columns3,
      // id: ref(''),
      // confId: ref(''),
      empType: ref(''),
      filter: ref(''),
      dateIn: ref(''),
      dateOut: ref(''),
      checkIn: ref(''),
      dateCheckOut: ref(''),
      employeeCode: ref(''),
      departmentCode: ref(''),
      visitorsData: ref(''),
      jobTitleCode: ref(''),
      isCheckinDisabled: ref(true),
      isCheckinCBDisabled: ref(false),
      isCheckOutDisabled: ref(true),
      isCheckOutCBDisabled: ref(false),
      isCancelCheckinDisabled: ref(true),
      navigationActive,
      employeesData: ref([]),
      departmentsData: ref([]),
      jobTitlesData: ref(''),
      pagesNumber: computed(() =>
        Math.ceil(this.tableData.length / pagination.value.rowsPerPage)),
      tab: ref('checkout'),
      tableClass: computed(() =>
        navigationActive.value === true ? 'shadow-8 no-outline' : null),
      selectStatusKPP: ref(null),
      selectGuestType: ref(''),
      selectSchedule: ref(''),
      isSettlement: ref(false),
      editedItem: {
        checkIn: ref(''),
        dateIn: ref(''),
        dateOut: ref(''),
        department: ref(''),
        empCode: ref(''),
        id: ref(''),
        jobTitle: ref(''),
        name: ref(''),
        note: ref(''),
        onSchedule: ref(''),
        transitStatus: ref(''),
        visitorType: ref('')
      },
      editedConflict: {
        id: ref(''),
        confId: ref('')
      },
      show_conflict: ref(false),
      date: ref(''),
      show_dialog: ref(false)
    }
  },
  computed: {
    bookingData () {
      return this.store.booking.content ?? []
    },
    settlementData () {
      return this.store.settlement.content ?? []
    },
    conflictsData () {
      return this.store.conflicts.content ?? []
    },
    scheduleData () {
      return this.store.modifiedSchedule
    },
    getDisGreen () {
      if (this.selectedSettlement.length === 0) return true
      else return this.selectedSettlement[0].checkIn !== null
    },
    getDisRed () {
      if (this.selectedSettlement.length === 0) return true
      else return this.selectedSettlement[0].checkIn === null
    }
  },
  watch: {
    selectedSettlement (val) {},
    bookingData (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    },
    settlementData (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    },
    tab (val) {
      if (val === 'checkout') {
        this.employeeCode = ''
        this.departmentCode = ''
        this.dateIn = ''
        this.dateOut = ''
        this.jobTitleCode = ''
        this.selectGuestType = ''
      }
      if (val === 'checkin') {
        this.employeeCode = ''
        this.departmentCode = ''
        this.dateIn = ''
        this.dateOut = ''
        this.jobTitleCode = ''
        this.selectGuestType = ''
      }
      if (val === 'conflicts') {
        this.employeeCode = ''
        this.dateIn = ''
        this.dateOut = ''
        this.empType = ''
      }
    }
  },
  methods: {
    editItem (item) {
      this.show_dialog = true
      this.editedItem = Object.assign({}, item)
      this.date = this.editedItem.checkIn
    },
    updateCheckIn () {
      const arr = []
      arr.push({
        id: this.editedItem.id,
        data: this.date.replaceAll('/', '-')
      })
      this.store.checkinSt({ id: arr })
        .then((el) => {
          if (String(el.data.code).startsWith('2')) {
            this.showNotif(el?.data?.message, 200)
            this.store.getStatistics('beds')
            this.store.getStatistics('rooms')
            this.store.getStatistics('bookings')
            this.store.getTableData('booking')
            this.arr = []
          } else {
            this.showNotif(el?.data?.message, 400)
          }
        }).catch(error => {
          console.log(error)
        })
    },
    editConflict (item) {
      this.show_conflict = true
      this.editedConflict = Object.assign({}, item)
    },
    updateConflict () {
      const data = {
        id: this.editedConflict.id,
        confId: this.editedConflict.confId
      }
      this.store.cancelManualBooking(data)
        .then((res) => {
          if (res.status === 200) {
            this.showNotif(res?.data?.message, 200)
            this.store.getConflictsData('', '', '', '', 1)
          } else {
            this.showNotif(res?.data?.message, 400)
          }
        }).catch(error => {
          console.log(error)
        })
    },
    getNow () {
      const today = new Date()
      let day = today.getDate()
      let month = today.getMonth() + 1
      if (month < 10) month = '0' + (today.getMonth() + 1)
      if (day < 10) day = '0' + (today.getDate())
      const year = today.getFullYear()
      return year + '/' + month + '/' + day
    },
    getDate () {
      return new Date().toISOString().slice(0, 10)
    },
    cancelAppointment () {
      const data = []
      this.selected.map(res => data.push(
        { id: res.id, note: '' }
      ))
      this.store.cancelBooking1(data)
        .then((el) => {
          if (el.status === 200) {
            this.showNotif(el?.data?.message, 200)
            this.store.getStatistics('beds')
            this.store.getStatistics('rooms')
            this.store.getStatistics('bookings')
            this.store.getTableData('settlement')
            this.selected = []
          } else {
            this.showNotif(el?.data?.message, 400)
            this.selected = []
          }
        }).catch(error => {
          console.log(error)
        })
    },
    filterFn (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.employeesData = this.store.modifiedEmployees
            .filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.employeesData = this.store.modifiedEmployees
      })
    },
    filterDepartment (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.departmentsData = this.departmentsData
            .filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.departmentsData = this.store.modifiedDepartments
      })
    },
    filterJobTitle (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.jobTitlesData = this.jobTitlesData
            .filter(v => v.label?.toLowerCase().indexOf(needle) > -1)
          : this.jobTitlesData = this.store.modifiedJobTitles
      })
    },
    setEmpCodeValue (val) {
      this.employeeCode = val
    },
    setDepartmentValue (val) {
      this.departmentCode = val
    },
    setJobTitleValue (val) {
      this.jobTitleCode = val
    },
    cancelFilter (id) {
      this.dateIn = ''
      this.dateOut = ''
      this.departmentCode = ''
      this.jobTitleCode = ''
      this.selectSchedule = ''
      this.employeeCode = ''
      this.selectGuestType = ''
      this.checkIn = ''
      if (id === 'S') {
        this.currentBooking = 1
        this.store.filterSecondList(this.currentBooking,
          '', '', '', '', '', '')
      } else if (id === 'F') {
        this.currentSetElement = 1
        this.store.filterFirstList(this.currentSetElement,
          '', '', '', '', '', '', '')
      } else if (id === 'C') {
        this.currentConflicts = 1
        this.store.getConflictsData('', '', '', '', 1)
      }
    },
    filterList () {
      this.store.filterFirstList(this.currentSetElement,
        this.dateIn?.replaceAll('/', '-') ?? '',
        this.dateOut?.replaceAll('/', '-') ?? '',
        this.selectGuestType?.value ?? '',
        this.departmentCode?.value ?? '',
        this.jobTitleCode?.value ?? '',
        this.selectSchedule?.value ?? '',
        this.employeeCode?.value ?? ''
      )
    },
    filterInOut () {
      this.store.filterSecondList(this.currentBooking,
        this.checkIn?.replaceAll('/', '-') ?? '',
        this.selectGuestType?.value ?? '',
        this.departmentCode?.value ?? '',
        this.dateIn?.replaceAll('/', '-') ?? '',
        this.dateOut?.replaceAll('/', '-') ?? '',
        this.employeeCode?.value ?? ''
      )
    },
    filterConflicts () {
      this.store.getConflictsData(this.employeeCode?.value ?? '',
        this.dateIn?.replaceAll('/', '-') ?? '',
        this.dateOut?.replaceAll('/', '-') ?? '',
        this.selectGuestType?.value ?? '',
        this.currentConflicts
      )
    },
    checkout (val) {
      if (val === 'checkin') {
        this.text = 'заселить'
        this.showInput = true
      }
      if (val === 'checkout') {
        this.text = 'выселить'
        this.showInput = true
      }
      if (val === 'cancel') {
        this.text = 'отменить'
        this.showInput = false
      }
      this.dateCheckOut = this.getNow()
      this.confirm = true
    },
    confirmed () {
      const arr = []
      this.selectedSettlement.map(el => {
        return arr.push({
          id: el.id,
          data: this.dateCheckOut.replaceAll('/', '-')
        })
      })
      if (this.text === 'заселить') {
        this.store.checkinSt({ id: arr })
          .then((el) => {
            if (String(el.data.code).startsWith('2')) {
              this.showNotif(el?.data?.message, 200)
              this.store.getStatistics('beds')
              this.store.getStatistics('rooms')
              this.store.getStatistics('bookings')
              this.store.filterSecondList(this.currentBooking = 1,
                this.checkIn = this.dateCheckOut.replaceAll('/', '-'),
                this.selectGuestType = '',
                this.departmentCode = '',
                this.dateIn = '',
                this.dateOut = '',
                this.employeeCode = ''
              )
              this.selectedSettlement = []
            } else {
              this.showNotif(el?.data?.message, 400)
            }
          }).catch(error => {
            console.log(error)
          })
      }
      if (this.text === 'выселить') {
        this.store.checkoutSt({ id: arr })
          .then((el) => {
            if (String(el.data.code).startsWith('2')) {
              this.showNotif(el?.data?.message, 200)
              this.store.getStatistics('beds')
              this.store.getStatistics('rooms')
              this.store.getStatistics('bookings')
              this.store.getTableData('booking')
              this.selectedSettlement = []
            } else {
              this.showNotif(el?.data?.message, 400)
            }
          })
      }
      if (this.text === 'отменить') {
        const arrData = []
        this.selectedSettlement.map(el => {
          return arrData.push(el.id)
        })
        this.store.checkinCancelSt({ id: arrData })
          .then((el) => {
            if (String(el.data.code).startsWith('2')) {
              this.showNotif(el?.data?.message, 200)
              this.store.getStatistics('beds')
              this.store.getStatistics('rooms')
              this.store.getStatistics('bookings')
              this.store.getTableData('booking')
              this.selectedSettlement = []
            } else {
              this.showNotif(el?.data?.message, 400)
              this.selectedSettlement = []
            }
          })
      }
    },
    goToBooking () {
      if (this.selected.length === 1) {
        localStorage.setItem('selectedData', JSON.stringify(this.selected[0]))
        localStorage.setItem('switchType', 'single')
        this.store.cardBooking.plannedDateIn = this.selected[0]?.dateIn
        this.store.cardBooking.plannedDateOut = this.selected[0]?.dateOut
        this.store.cardBooking.cardFIO = this.selected[0]?.name
        if (this.store.modifiedEmployees.find(el => el.value === this.selected[0]?.empCode)) {
          this.goToBooking1()
        } else {
          this.showNotif('Табельный номер не найден ' + this.selected[0]?.empCode, 500)
        }
      } else {
        for (let i = 0; i < this.selected.length; i++) {
          if (!this.store.modifiedEmployees.find(el => el.value === this.selected[i]?.empCode)) {
            this.showNotif('Табельный номер не найден ' + this.selected[i]?.empCode, 500)
            this.selected.splice(i, 1)
          }
        }
        localStorage.setItem('selectedData', JSON.stringify(this.selected))
        localStorage.setItem('switchType', 'multi')
        localStorage.setItem('selectType', 'multi')
        this.goToBooking1()
      }
    },
    goToBooking1 () {
      this.$router.push({
        path: '/room-booking'
      })
    }
  },
  created () {
    this.store.filterSecondList(this.currentBooking,
      this.checkIn?.replaceAll('/', '-') ?? '',
      this.selectGuestType?.value ?? '',
      this.departmentCode?.value ?? '',
      this.dateIn = this.getDate(),
      this.dateOut?.replaceAll('/', '-') ?? '',
      this.employeeCode?.value ?? ''
    )
    this.store.getTableData('settlement')
    this.employeesData = this.store.modifiedEmployees
    this.departmentsData = this.store.modifiedDepartments
    this.jobTitlesData = this.store.modifiedJobTitles
    this.visitorsData = this.store.modifiedVisitorsRef
    this.paginationElements.rowsPerPage = this.store.settlement?.content?.length
    this.paginationBooking.rowsPerPage = this.store.booking?.content?.length
    this.store.getConflictsData('', '', '', '', this.currentConflicts)
  }
}
</script>
