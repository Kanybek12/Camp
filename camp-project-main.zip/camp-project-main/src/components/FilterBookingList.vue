<template>
  <div class="gp-filter-form">
    <p class="gp-filter-form__title">Фильтрация</p>
    <div class="gp-filter-form__block">
      <div class="blp-filter-form__block">
        <q-select label="Выберите ФИО или Таб. Номер" class="blp-filter-form__block__input"
                  behavior="menu" input-debounce="0" outlined dense use-input hide-selected fill-input
                  v-model="empCode" :options="employee"
                  @filter="filterFnEmp" @input-value="setModelSelectEmp">
          <template v-slot:append>
            <q-icon v-if="empCode !== ''" @click.stop="empCode = ''" class="cursor-pointer" name="clear"/>
          </template>
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('noResult')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
        <q-select label="Выберите тип сотрудника" class="blp-filter-form__block__input"
                  dense outlined v-model="empType" :options="optionsEmpType"/>
      </div>
      <div class="blp-filter-form__block">
        <q-select label="Выберите Лагерь" class="blp-filter-form__block__input" dense outlined
                  v-model="camp" :options="getLocation" @update:model-value="getBlockData()">
          <template v-slot:no-option>
            <div>Нет данных</div>
          </template>
        </q-select>
        <q-input label="Дата заезда" class="blp-filter-form__block__input"
                 dense readonly outlined v-model="date">
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                <q-date v-model="date">
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup flat label="Применить" color="primary"/>
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
      <div class="blp-filter-form__block">
        <q-select label="Выберите Блок" class="blp-filter-form__block__input" dense outlined
                  v-model="block" :options="blockData.length === 0 ? getBlock : blockData"
                  @update:model-value="getRoomData()">
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
        <q-select label="Выберите статус" class="blp-filter-form__block__input" dense outlined
                  v-model="statusCode" :options="optionsStatus"/>
      </div>
      <div class="blp-filter-form__block">
        <q-select label="Выберите Комнату" class="blp-filter-form__block__input" dense outlined
                  v-model="room" :options="roomData.length === 0 ? getRooms : roomData">
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
        <div class="blp-filter-form__block__btn-block">
          <q-btn class="blp-filter-form__block__btn-block__btn" label="Применить"
                 push icon="filter_list" text-color="white" flat no-caps
                 @click="filterRecord">
            <q-tooltip>Применить фильтр</q-tooltip>
          </q-btn>
          <q-btn class="blp-filter-form__block__btn-block__btn" label="Отменить"
                 push flat no-caps icon="filter_list_off" text-color="white"
                 @click="clearInputFields">
            <q-tooltip>Отменить фильтр</q-tooltip>
          </q-btn>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'

export default {
  name: 'FilterBookingList',
  setup () {
    const store = mainStore()
    const $q = useQuasar()
    return {
      showNotif (mess) {
        $q.notify({
          message: mess,
          position: 'top',
          color: 'yellow-9'
        })
      },
      store,
      camp: ref(''),
      empCode: ref(''),
      block: ref(''),
      room: ref(''),
      employee: ref(''),
      empType: ref(''),
      statusCode: ref(''),
      blockData: ref(''),
      roomData: ref(null),
      date: ref('')
    }
  },
  methods: {
    getNow () {
      const today = new Date()
      let day = today.getDate()
      let month = today.getMonth() + 1
      if (month < 10) month = '0' + (today.getMonth() + 1)
      if (day < 10) day = '0' + (today.getDate())
      const year = today.getFullYear()
      return year + '/' + month + '/' + day
    },
    getBlockData () {
      const data = {
        dateIn: '',
        dateOut: '',
        genderId: '',
        locationId: this.camp.value ?? ''
      }
      this.store.getBlockParam(data)
        .then((result) => {
          if (result.status === 200) {
            this.blockData = this.store.modifiedBlockRef
          }
        })
    },
    getRoomData () {
      const data = {
        dateIn: '',
        dateOut: '',
        blockId: this.block?.value,
        genderId: '',
        roomId: ''
      }
      this.store.getRoomByParams(data)
        .then((result) => {
          if (result.status === 200) {
            if (result.data.length) {
              this.roomData = this.store.modifiedRoomByParam
            } else {
              this.showNotif('В данном блоке нет комнат, удовлетворяющих условию')
            }
          }
        })
    },
    filterRecord () {
      this.store.getRoomsListFilter(
        this.block?.label ?? '',
        this.room?.value ?? '',
        this.empCode?.value ?? '',
        this.empType?.value ?? '',
        this.statusCode?.value ?? '',
        this.camp?.value ?? '',
        this.date?.replaceAll('/', '-') ?? '')
    },
    clearInputFields () {
      this.store.getRoomByParams({
        dateIn: '',
        dateOut: '',
        blockId: '',
        genderId: '',
        roomId: ''
      })
      this.store.getBlockParam({
        dateIn: '',
        dateOut: '',
        genderId: '',
        locationId: ''
      })
      this.date = this.getNow()
      this.block = ''
      this.room = ''
      this.empCode = ''
      this.empType = ''
      this.statusCode = ''
      this.camp = ''
      this.employee = this.store.modifiedEmployees
      this.blockData = this.store.modifiedBlockRef
      this.roomData = this.store.modifiedRoomsList
      this.store.getRoomsListFilter('', '', '', '', '', '', '')
    },
    filterFnEmp (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.employee = this.store.modifiedEmployees.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.employee = this.store.modifiedEmployees
      })
    },
    setModelSelectEmp (val) {
      this.empCode = val
    }
  },
  computed: {
    getLocation () {
      return this.store.modifiedLocationRef
    },
    optionsEmpType () {
      return this.store.modifiedVisitorsRef
    },
    getBlock () {
      return this.store.modifiedBlockRef
    },
    getRooms () {
      return this.store.modifiedRoomsList
    },
    optionsStatus () {
      return this.store.modifiedStatusListRef
    }
  },
  created () {
    this.employee = this.store.modifiedEmployees
    this.blockData = this.store.modifiedBlockRef
    this.roomData = this.store.modifiedRoomsList
    this.date = this.getNow()
  }
}
</script>

<style lang="scss" scoped>
.filterForm{
  display: flex;
  background: #FFFFFF;
  flex-direction: column;
  width: 100%;
  height: 20%;
  justify-content: center;
  padding: 10px;
  margin-bottom: 16px;
  box-shadow: 0 1px 5px rgb(0 0 0 / 20%), 0 2px 2px rgb(0 0 0 / 14%), 0 3px 1px -2px rgb(0 0 0 / 12%);
}
.filterFields{
  width: 14%;
  padding: 10px;
}
.btnFilter{
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  gap: 8px;
}
.btnClear{
  background-color: $negative;
  border-radius: 5px;
}
.btnSearch{
  background-color: $secondary;
  border-radius: 5px;
}
</style>
