<template>
  <div class="filterForm">
    <div style="display: flex; flex-direction: column; width: 100%;">
      <p style="font-size: 40px;letter-spacing: 0.005em;font-weight: 400;">Список жителей</p>
    </div>
    <div style="display: flex; flex-direction: row; flex-wrap: wrap; align-items: center; width: 100%; gap: 8px">
      <q-select label="Таб. №" class="filterFields" input-debounce="0"
                outlined use-input hide-selected fill-input dense v-model="employeeCode"
                :options="employeesData" @filter="filterFn" @input-value="setEmpCodeValue">
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
          </q-item>
        </template>
      </q-select>
      <q-select label="Лагерь" class="filterFields" outlined dense v-model="camp" :options="getLocation"/>
      <q-select label="Блок" class="filterFields" outlined dense v-model="block" :options="getBlock" @update:model-value="getRoomData()"/>
      <q-select label="Комната" class="filterFields" outlined dense v-model="roomId" :options="getRooms"/>
      <q-select label="Пол" class="filterFields" outlined dense v-model="gender" :options="getGender"/>
      <q-select label="Постоянная комната" class="filterFields" outlined dense v-model="isExistPermanent" :options="options"/>
      <div class="btnFilter">
        <q-btn icon="filter_list" class="btnSearch" style="border-radius: 3px; height: 40px; width: 49%;"
               text-color="white" label="Применить" flat no-wrap no-caps @click="filterRecord">
          <q-tooltip>Применить фильтр</q-tooltip>
        </q-btn>
        <q-btn icon="filter_list_off" class="btnSearch" style="border-radius: 3px; height: 40px; width: 49%;"
               text-color="white" label="Отменить" flat no-wrap no-caps @click="clearInputFields">
          <q-tooltip>Отменить фильтр</q-tooltip>
        </q-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'

export default {
  name: 'FilterBookingList',
  setup () {
    return {
      store: mainStore(),
      employeeCode: ref(''),
      employeesData: ref([]),
      camp: ref(''),
      block: ref(''),
      gender: ref(''),
      roomId: ref(''),
      isExistPermanent: ref(''),
      options: [
        {
          value: true,
          label: 'Существует'
        },
        {
          value: false,
          label: 'Отсутсвует'
        }
      ]
    }
  },
  methods: {
    filterRecord () {
      this.store.permanentResidentFilterData.page = 1
      this.store.permanentResidentFilterData.empCode = this.employeeCode?.value ?? ''
      this.store.permanentResidentFilterData.locationId = this.camp?.value ?? ''
      this.store.permanentResidentFilterData.blockId = this.block?.label ?? ''
      this.store.permanentResidentFilterData.roomId = this.roomId?.label ?? ''
      this.store.permanentResidentFilterData.gender = this.gender?.value ?? ''
      this.store.permanentResidentFilterData.isExistPermanent = this.isExistPermanent?.value ?? ''
      this.store.getPermanentResidents()
    },
    filterFn (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.employeesData = this.store.modifiedEmployees
            .filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.employeesData = this.store.modifiedEmployees
      })
    },
    setEmpCodeValue (val) {
      this.employeeCode = val
    },
    getRoomData () {
      this.roomId = ''
      const data = {
        dateIn: '',
        dateOut: '',
        blockId: this.block?.value,
        genderId: '',
        roomId: ''
      }
      this.store.getRoomByParams(data)
        .then((result) => {
          if (result.status === 200) {
            if (result.data.length) {
              this.roomData = this.store.modifiedRoomByParam
            } else {
              this.showNotif('В данном блоке нет комнат, удовлетворяющих условию')
            }
          }
        })
    },
    clearInputFields () {
      this.employeeCode = ''
      this.camp = ''
      this.roomId = ''
      this.block = ''
      this.gender = ''
      this.isExistPermanent = ''
      this.store.permanentResidentFilterData.page = 1
      this.store.permanentResidentFilterData.empCode = ''
      this.store.permanentResidentFilterData.locationId = ''
      this.store.permanentResidentFilterData.blockId = ''
      this.store.permanentResidentFilterData.roomId = ''
      this.store.permanentResidentFilterData.gender = ''
      this.store.permanentResidentFilterData.isExistPermanent = ''
      this.store.getPermanentResidents()
    }
  },
  computed: {
    getGender () {
      return this.store.modifiedGenderRef
    },
    getLocation () {
      return this.store.modifiedLocationRef
    },
    getBlock () {
      return this.store.modifiedBlockRef
    },
    getRooms () {
      return this.store.modifiedRoomByParam
    }
  },
  created () {
    this.employeesData = this.store.modifiedEmployees
  }
}
</script>

<style lang="scss" scoped>
.filterForm{
  display: flex;
  flex-direction: column;
  background: #FFFFFF;
  width: 100%;
  height: 20%;
  padding: 10px;
  margin-bottom: 16px;
  box-shadow: 0 1px 5px rgb(0 0 0 / 20%), 0 2px 2px rgb(0 0 0 / 14%), 0 3px 1px -2px rgb(0 0 0 / 12%);
}
.filterFields{
  width: 28%;
}
.btnFilter{
  width: 24%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  gap: 8px;
}
.btnClear{
  background-color: #5F8BFF;
  border-radius: 5px;
}
.btnSearch{
  background-color: #5F8BFF;
  border-radius: 5px;
}
</style>
