<template>
  <div class="filterForm">
    <div style="display: flex; flex-direction: column; width: 100%;">
      <p style="font-size: 40px;letter-spacing: 0.005em;font-weight: 400;">Конструктор комнат</p>
    </div>
    <div style="display: flex; flex-direction: row; flex-wrap: wrap; align-items: center; width: 100%; gap: 8px">
      <q-select label="Таб. №" class="filterFields" input-debounce="0"
                outlined use-input hide-selected fill-input dense v-model="employeeCode"
                :options="employeesData" @filter="filterFn" @input-value="setEmpCodeValue">
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
          </q-item>
        </template>
      </q-select>
      <q-select label="Лагерь" class="filterFields" outlined dense v-model="camp" :options="getLocation"/>
      <q-select label="Блок" class="filterFields" outlined dense v-model="block" :options="getBlock" @update:model-value="getRoomData()"/>
      <q-select label="Комната" class="filterFields" outlined dense v-model="roomId" :options="getRooms"/>
      <q-select label="Количество мест" class="filterFields" outlined dense :options="getRoomCapacity" v-model="countPlace"/>
      <q-select label="Пол" class="filterFields" outlined dense v-model="gender" :options="getGender"/>
      <q-select label="Тип комнаты" class="filterFields" outlined dense v-model="roomType" :options="roomCategory"/>
      <q-select label="Статус комнаты" class="filterFields" outlined dense v-model="statusCode" :options="optionsStatus"/>
      <div class="btnFilter">
        <q-btn icon="filter_list" class="btnSearch" style="border-radius: 3px; height: 40px; width: 49%;"
               text-color="white" label="Применить" flat no-wrap no-caps @click="filterRecord">
          <q-tooltip>Применить фильтр</q-tooltip>
        </q-btn>
        <q-btn icon="filter_list_off" class="btnSearch" style="border-radius: 3px; height: 40px; width: 49%;"
               text-color="white" label="Отменить" flat no-wrap no-caps @click="clearInputFields">
          <q-tooltip>Отменить фильтр</q-tooltip>
        </q-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'

export default {
  name: 'FilterBookingList',
  setup () {
    const $q = useQuasar()
    return {
      showNotif (mess) {
        $q.notify({
          message: mess,
          position: 'top',
          color: 'yellow-9'
        })
      },
      store: mainStore(),
      employeeCode: ref(''),
      employeesData: ref([]),
      camp: ref(''),
      block: ref(''),
      gender: ref(''),
      countPlace: ref(''),
      statusCode: ref(''),
      roomId: ref(''),
      roomType: ref(''),
      optionsBlock: ref(null),
      roomRef: ref(null),
      bedQuantityData: ref(null),
      optionsStatus: [
        {
          value: 1,
          label: 'Занята'
        },
        {
          value: 2,
          label: 'Забронирована'
        },
        {
          value: 3,
          label: 'Свободна'
        }
      ]
    }
  },
  methods: {
    filterRecord () {
      this.store.getRoomsConstuctorFilter(
        this.checkItem(this.employeeCode?.value),
        this.checkItem(this.camp?.value),
        this.checkItem(this.countPlace?.value),
        this.checkItem(this.statusCode?.value),
        this.checkItem(this.block?.label),
        this.checkItem(this.roomId?.value),
        this.checkItem(this.gender?.value),
        this.checkItem(this.roomType?.value))
    },
    filterFn (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.employeesData = this.store.modifiedEmployees
            .filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.employeesData = this.store.modifiedEmployees
      })
    },
    setEmpCodeValue (val) {
      this.employeeCode = val
    },
    checkItem (item) {
      if (item) return item
      else return ''
    },
    getRoomData () {
      this.roomId = ''
      const data = {
        dateIn: '',
        dateOut: '',
        blockId: this.block?.value,
        genderId: '',
        roomId: ''
      }
      this.store.getRoomByParams(data)
        .then((result) => {
          if (result.status === 200) {
            if (result.data.length) {
              this.roomData = this.store.modifiedRoomByParam
            } else {
              this.showNotif('В данном блоке нет комнат, удовлетворяющих условию')
            }
          }
        })
    },
    clearInputFields () {
      this.employeeCode = ''
      this.camp = ''
      this.countPlace = ''
      this.statusCode = ''
      this.roomId = ''
      this.block = ''
      this.gender = ''
      this.roomType = ''
      this.store.getRoomsConstuctorFilter(
        this.checkItem(this.employeeCode?.value),
        this.checkItem(this.camp?.value),
        this.checkItem(this.countPlace?.value),
        this.checkItem(this.statusCode?.value),
        this.checkItem(this.block?.value),
        this.checkItem(this.roomId?.value),
        this.checkItem(this.gender?.value),
        this.checkItem(this.roomType?.value))
    }
  },
  computed: {
    getGender () {
      return this.store.modifiedGenderRef
    },
    getLocation () {
      return this.store.modifiedLocationRef
    },
    getBlock () {
      return this.store.modifiedBlockRef
    },
    getRooms () {
      // return this.store.modifiedRoomsList
      return this.store.modifiedRoomByParam
    },
    roomCategory () {
      return this.store.modifiedRoomCategory
    },
    getRoomCapacity () {
      return this.store.modifiedRoomCapacity
    }
  },
  created () {
    this.employeesData = this.store.modifiedEmployees
  }
}
</script>

<style lang="scss" scoped>
.filterForm{
  display: flex;
  flex-direction: column;
  background: #FFFFFF;
  width: 100%;
  height: 20%;
  padding: 10px;
  margin-bottom: 16px;
  box-shadow: 0 1px 5px rgb(0 0 0 / 20%), 0 2px 2px rgb(0 0 0 / 14%), 0 3px 1px -2px rgb(0 0 0 / 12%);
}
.filterFields{
  width: 24%;
}
.btnFilter{
  width: 24%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  gap: 8px;
}
.btnClear{
  background-color: #5F8BFF;
  border-radius: 5px;
}
.btnSearch{
  background-color: #5F8BFF;
  border-radius: 5px;
}
</style>
