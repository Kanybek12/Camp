<template>
  <div class="roomTapMenu">
    <q-tabs v-model="tab" align="justify" narrow-indicator>
      <q-tab label="Конструктор комнат" class="bg-grey-3 checkinOut__tab" name="construct"/>
      <q-tab label="Список жителей" class="bg-grey-3 checkinOut__tab" name="listOfRooms"/>
    </q-tabs>
    <q-tab-panels v-model="tab" animated>
      <q-tab-panel name="construct">
        <FilterRoomConstructor class="components"/>
        <ListRoomConstructor class="components"/>
      </q-tab-panel>
      <q-tab-panel name="listOfRooms">
        <div>
          <FilterPermanentResident class="components"/>
          <ListPermanentResident class="components"/>
        </div>
      </q-tab-panel>
    </q-tab-panels>
  </div>
</template>

<script>
import { ref } from 'vue'
import FilterRoomConstructor from 'components/room-constructor/FilterRoomConstructor'
import FilterPermanentResident from 'components/room-constructor/FilterPermanentResident'
import ListRoomConstructor from 'components/room-constructor/ListRoomConstructor'
import ListPermanentResident from 'components/room-constructor/ListPermanentResident'
export default {
  name: 'RoomTapMenu',
  components: {
    FilterRoomConstructor,
    FilterPermanentResident,
    ListRoomConstructor,
    ListPermanentResident
  },
  setup () {
    return {
      tab: ref('construct')
    }
  },
  computed: {
  }
}
</script>

<style scoped>

</style>
