<template>
  <q-table row-key="empCode" :rows="listOfPermanentResident" :columns="columns"
           v-model:pagination="pagination">
    <template v-slot:body-cell="props">
      <q-td :props="props">
        <q-badge color="red" v-if="props.row.room === null ">
              {{ props.value }}
          <q-icon name="warning" color="white" class="q-ml-xs" />
          <q-tooltip>Отсутсвует постоянная комната!</q-tooltip>
        </q-badge>
        <div v-else > {{ props.value }} </div>
      </q-td>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination v-model="currentPage.page" color="grey-10" active-color="grey-10" active-text-color="white"
                      :max="getPageSum" :max-pages="6" direction-links boundary-links @click="getPage(currentPage.page)"/>
      </div>
    </template>
  </q-table>
</template>

<script>

import { mainStore } from 'stores/main-store'

const columns = [
  { name: 'empCode', align: 'left', label: 'Таб. №', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', align: 'left', label: 'ФИО', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'room', align: 'left', label: '№ пост.комнаты', field: 'room', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'jobTitle', align: 'left', label: 'Должность', field: 'jobTitle', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' }
]

export default {
  name: 'ListPermanentResident',
  setup () {
    return {
      columns,
      pagination: {
        descending: false,
        rowsPerPage: 50
      },
      store: mainStore()
    }
  },
  computed: {
    listOfPermanentResident () {
      return this.store.permanentResidentList.content ?? []
    },
    currentPage () {
      return this.store.permanentResidentFilterData
    },
    getPageSum () {
      return this.store.permanentResidentList.totalPages ?? 1
    }
  },
  methods: {
    getPage (page) {
      this.store.permanentResidentFilterData.page = page
      this.store.getPermanentResidents()
    }
  },
  created () {
    this.store.getPermanentResidents()
  }
}
</script>
