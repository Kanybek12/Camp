<template>
<div class="list-constructor">
  <q-table row-key="id" virtual-scroll :rows="list" :columns="columns"
           v-model:selected="selected" :pagination="pagination">
    <template v-slot:body-cell-actions="props">
      <q-td class="action-btn btnGroup" :props="props">
        <q-btn label="Редактировать" class="btnAction" color="light-blue"
               fill push flat no-caps @click="viewDetail(props.row)">
          <q-tooltip>Редактировать комнату</q-tooltip>
        </q-btn>
      </q-td>
    </template>
    <template v-slot:no-data>
      <div v-if="!isLoading">Данные отсутствуют</div>
      <div v-else class="skeleton-loading">
        <q-skeleton square class="bed__skeleton" v-for="i in 5" :key="i"/>
      </div>
    </template>
  </q-table>
</div>
  <q-dialog v-model="dialog" persistent transition-show="scale" transition-hide="scale">
    <q-card v-if="!isSecondDialog && !isThirdDialog" class="list-constructor__dialog-card">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h5 text-black">Комната {{roomNumDetails.room}}</div>
        <q-space/>
        <q-btn icon="close" flat round dense @click="closeDialog"/>
      </q-card-section>
      <q-card-section>
        <div class="list-constructor__dialog-title">
          {{roomNumDetails.location}}, Блок {{roomNumDetails.block}},
          Количество мест: {{roomNumDetails.bedListDtos.length - idBed.length}}
        </div>
        <div>
          <div class="list-constructor__dialog-selects">
            <q-select label="Гендер" class="m-b-16 list-constructor__dialog-select"
                      outlined dense v-model="gender" :options="genderRef"/>
            <q-select label="Тип комнаты" class="m-b-16"
                      style="width: 50%" outlined dense v-model="roomType" :options="roomTypeRef"/>
          </div>
          <q-space />
          <div class="bed__title">Кровати</div>
          <div class="bed">
            <div class="bed__items" v-for="(el, ind) in roomNumDetails.bedListDtos" :key="ind">
              <q-card class="bed__item" :class="(isDeletedBed ? idBed.map((deletedBedId) =>
               el.bedId === deletedBedId.value ? 'deleted-bed' : '' ) : '')
                || (el.status === 'addedBed' ? 'added-bed' : '')">
                <q-card-section class="row no-wrap bed__visitors__f-block">
                  <span style="font-weight: 600; margin-right: 5px" class="text-grey-7">{{ el.bedId }}</span> {{el.bedTypeId.split('-')[1]}}
                  <q-icon v-if="el.visitors?.length < 1" name="add" size="20px" class="cursor-pointer bed__add-btn"
                          @click="showVisitorsDialog(el.bedId)">
                    <q-tooltip>Добавить постоянного жителя</q-tooltip>
                  </q-icon>
                </q-card-section>
                <q-separator v-if="el.visitors?.length"/>
                <q-card-section class="column ctrp__gap-4" v-if="el.visitors?.length">
                  <div class="text-grey-7 bed__visitors__s-block__txt">Постоянные жители</div>
                  <div class="row no-wrap ctrp__gap-8 bed__visitors__s-block__data"
                       v-for="(item, i) in el.visitors" :key="i">
                    <div class="bed__visitors__s-block__data__txt">{{getVisitor(item)}}</div>
                    <q-icon name="close" size="15px" class="cursor-pointer bed__add-btn"
                            @click="deleteVisitor(item, el.bedId)">
                      <q-tooltip>Удалить жителя</q-tooltip>
                    </q-icon>
                  </div>
                </q-card-section>
              </q-card>
            </div>
          </div>
              <div class="bed__btns">
                <q-btn label="Удалить кровать" class="bed__btn"
                       outline no-caps @click="openSecond"/>
                <q-btn label="Добавить кровать" outline no-caps
                       style="color: #1D4ED8" @click="openThird"/>
              </div>
        </div>
      </q-card-section>
      <q-card-section>
        <div class="bed__btns">
          <q-btn label="Сохранить свойства комнаты" class="bed__btn"
                 style="color: #1D4ED8" outline no-caps @click="saveChanges"/>
      <!--&lt;!&ndash;          <q-btn label="Очистить изменения"&ndash;&gt;-->
      <!--&lt;!&ndash;                 class="btn-clear" flat no-caps/>&ndash;&gt;-->
        </div>
      </q-card-section>
    </q-card>
    <q-card v-if="isSecondDialog" class="second-modal">
      <q-card-section><div class="text-h5 text-black">Удаление кровати</div></q-card-section>
      <q-card-section>
        <q-select label="Кровать" class="m-b-16" color="red" outlined dense use-chips multiple stack-label
                  v-model="idBed" :options="getBedsRef">
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
      </q-card-section>
      <q-card-section>
        <div class="second-modal__btns">
          <q-btn label="Отмена" class="btn-clear" flat no-caps @click="cancelDel"/>
          <q-btn label="Удалить" class="btn-save" color="#1D4ED8" no-caps @click="deleteBed"/>
        </div>
      </q-card-section>
    </q-card>
    <q-card v-if="isThirdDialog" class="second-modal">
      <q-card-section><div class="text-h5 text-black">Добавление кровати</div></q-card-section>
      <q-card-section>
        <q-select label="Тип кровати" class="m-b-16" outlined dense
                  v-model="bedType" :options="getBedTypes">
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
      </q-card-section>
      <q-card-section>
        <div class="second-modal__btns">
          <q-btn label="Отмена" class="btn-clear" flat no-caps @click="cancelAdd"/>
          <q-btn label="Добавить" class="btn-save" color="#1D4ED8" no-caps @click="addBed"/>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="visitorDialog">
    <q-card style="width: 400px; height: max-content">
      <q-card-section class="row items-center q-pb-none">
        <div style="font-size: 16px; font-weight: 600;">Добавление постоянного жителя</div>
        <q-space/>
        <q-btn icon="close" flat round dense v-close-popup/>
      </q-card-section>
      <q-card-section class="column ctrp__gap-8">
        <q-select label="Таб. №" input-debounce="0" class="m-b-16 list-constructor__dialog-select"
                  outlined use-input hide-selected fill-input dense
                  v-model="visitorCode" style="width: 100%" :options="visitorsData" @filter="visitorFilter">
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">
                {{('Нет данных')}}
              </q-item-section>
            </q-item>
          </template>
        </q-select>
        <q-checkbox v-model="isUpdateAutoBooking" label="Обновить комнаты в уже созданных автобронях"/>
        <div class="row" style="width: 100%; justify-content: flex-end">
          <q-btn text-color="white" flat style="background-color: #1D4ED8; align-self: flex-end" no-caps label="Добавить"
                 :disable="visitorCode" @click="addVisitor(visitorCode.value)"/>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="visitorResponseDialog">
    <q-card style="max-width: 1800px;width:1400px;height:400px">
      <q-card-section class="row items-center q-pb-none">
        <div style="font-size: 16px; font-weight: 600;" class="q-pa-md text-center">Конфликты</div>
        <q-space/>
        <q-btn icon="close" flat round dense v-close-popup/>
        <q-table title="Изменяемая бронь" ref="tableRef" tabindex="0" row-key="id"
                 :rows="conflictsData" :columns="columns1" :class="tableClass" no-data-label="Нет данных">
          <template v-slot:top-right>
            <span class="q-table__title">комната занята другой бронью</span>
          </template>
        </q-table>
      </q-card-section>
    </q-card>
  </q-dialog>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'
const columns = [
  { name: 'room', align: 'left', label: 'Номер комнаты', field: 'room', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'roomCapacity', align: 'left', label: 'Количество мест', field: 'roomCapacity', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'gender', align: 'left', label: 'Пол', field: 'gender', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'roomCategory', align: 'left', label: 'Тип Комнаты', field: 'roomCategory', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'statusText', align: 'left', label: 'Статус Комнаты', field: 'statusText', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'actions', align: 'left', field: row => row.action }
]
const columns1 = [
  { name: 'empCode', align: 'left', label: 'Таб.№', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', align: 'left', label: 'ФИО', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bedId', align: 'left', label: 'Комната', field: 'bedId', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateIn', align: 'left', label: 'Дата заезда', field: 'dateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateOut', align: 'left', label: 'Дата выезда', field: 'dateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'separator', divider: true, style: 'border-right: 2px solid grey;' },
  { name: 'bookedEmpCode', align: 'left', label: 'Таб.№', field: 'bookedEmpCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bookedFullName', align: 'left', label: 'ФИО', field: 'bookedFullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bookedBedId', align: 'left', label: 'Комната', field: 'bookedBedId', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bookedDateIn', align: 'left', label: 'Дата заезда', field: 'bookedDateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bookedDateOut', align: 'left', label: 'Дата выезда', field: 'bookedDateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'bookedStatus', align: 'left', label: 'Статус', field: 'bookedStatus', headerStyle: 'font-size: 13px; font-weight:bold' }
]

export default {
  name: 'ListRoomConstructor',
  setup () {
    const $q = useQuasar()
    return {
      columns,
      columns1,
      tableClass: 'q-table--separator',
      showNotify (mess, code) {
        $q.notify({
          message: mess,
          position: 'top',
          color: code === 200 ? 'green' : 'red'
        })
      },
      isLoading: ref(true),
      store: mainStore(),
      pagination: {
        rowsPerPage: 50
      },
      roomRow: ref(''),
      room: ref(''),
      roomNumDetails: ref(null),
      gender: ref(''),
      roomType: ref(''),
      bedId: ref(''),
      genderRef: ref(''),
      roomTypeRef: ref(''),
      visitorCode: ref(''),
      selected: ref(),
      dialog: ref(false),
      bedQuantityData: ref(null),
      roomCapacity: ref(null),
      roomId: ref(null),
      idBed: ref([]),
      bedType: ref(),
      isSecondDialog: ref(false),
      isThirdDialog: ref(false),
      isDeletedBed: ref(false),
      isAddedBed: ref(false),
      stockBeds: ref(),
      visitorDialog: ref(false),
      visitorResponseDialog: ref(false),
      visitorsData: ref(''),
      isUpdateAutoBooking: ref(false),
      conflictsData: []
    }
  },
  computed: {
    list () {
      return this.store.allRoomsForConstructor.data ?? []
    },
    getBedsRef () {
      const arr = []
      this.roomNumDetails?.bedListDtos?.map(el => (arr.push(
        {
          value: el.bedId,
          label: `ID:${el.bedId}, ${el.bedTypeId}`
        }
      )))
      return arr
    },
    getStockBedRef () {
      const arr = []
      if (this.stockBeds.length > 0) {
        this.stockBeds?.map(el => (arr.push(
          {
            value: el.bedId,
            label: `Тип:${el.bedType}, Имя:${el.roomName}`
          }
        )))
      }
      return arr
    },
    getBedTypes () {
      return this.store.modifiedBedTypesRef
    }
  },
  watch: {
    list (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    }
  },
  methods: {
    getBadType (val) {
      if (val === 1) return 'a'
      else if (val === 2) return 'b'
      else if (val === 3) return 'c'
      else return ''
    },
    cancelDel () {
      this.idBed = []
      this.isSecondDialog = false
    },
    cancelAdd () {
      this.isThirdDialog = false
    },
    closeDialog () {
      this.idBed = []
      this.dialog = false
    },
    saveChanges () {
      const bedsList = []
      const data = {
        gender: this.gender?.value,
        roomCapacity: 0, // capacity,
        roomCategory: this.roomType?.value,
        bedListDtos: bedsList
      }
      this.store.saveConstructorChanges(data, this.roomId)
        .then((el) => {
          if (el.status === 200) {
            const data = {
              location: '',
              blockName: '',
              roomNum: '',
              page: 1,
              size: 10
            }
            this.store.getAllRoomsForConstructor(data).then((res) => {
              if (res.status === 200) {
                this.idBed = []
                this.dialog = false
              }
            })
          }
        })
    },
    deleteBed () {
      const b = []
      this.idBed.map((bed) => {
        return b.push(bed.value)
      })
      this.store.deleteBedsFromRoom(b).then(res => {
        if (res.status === 200) {
          this.store.getRoomDetails(this.roomId).then(() => {
            if (res.data.code === 201) {
              this.showNotify(res.data.message, 200)
              this.roomNumDetails = this.store.roomsDetails?.data
              this.roomRow.roomCapacity = this.roomNumDetails.roomCapacity
            } else {
              this.showNotify(res.data.message, 400)
            }
          })
        } else {
          this.showNotif(res.data.message, res.data.status)
        }
      })

      this.idBed = []
      this.isDeletedBed = true
      this.isSecondDialog = false
    },
    addBed () {
      const data = {
        id: null,
        bedNumberInRoom: this.roomNumDetails?.bedListDtos?.length + 1,
        roomId: this.roomId,
        roomNum: this.roomNumDetails?.room,
        bedTypeId: this.bedType?.value,
        bedTypeTitle: this.bedType?.label,
        status: 'A',
        changedBy: null
      }

      this.store.addBed2Room(data).then(res => {
        if (res.status === 200) {
          this.store.getRoomDetails(this.roomId).then(() => {
            if (res.data.code === 201) {
              this.showNotify(res.data.message, 200)
              this.roomNumDetails = this.store.roomsDetails?.data
              this.roomRow.roomCapacity = this.roomNumDetails.roomCapacity
            } else {
              this.showNotify(res.data.message, 400)
            }
          })
        } else {
          this.showNotif(res.data.message, res.data.status)
        }
      })

      this.isAddedBed = true
      this.isThirdDialog = false
    },
    viewDetail (room) {
      this.roomRow = room
      this.genderRef = this.store.modifiedGenderRef
      this.roomTypeRef = this.store.modifiedRoomCategory
      this.roomId = room.roomId
      this.store.getRoomDetails(room.roomId)
        .then(() => {
          this.roomCapacity = this.store.roomsDetails?.data?.roomCapacity
          this.roomNumDetails = this.store.roomsDetails?.data
          this.gender = this.store.modifiedGenderRef.find(el => el.label === room?.gender) ?? ''
          this.roomType = this.store.modifiedRoomCategory.find(el => el.label === room?.roomCategory) ?? ''
          this.dialog = true
        })
        .catch((error) => {
          console.log(error)
        })
    },
    openSecond () {
      this.isSecondDialog = true
    },
    openThird () {
      this.bedType = this.getBedTypes[0]
      this.isThirdDialog = true
    },
    getBedQuantityData () {
      const data = {
        dateIn: '',
        dateOut: '',
        roomId: this.room?.value
      }
      this.store.getBedQuantityParams(data)
        .then((result) => {
          if (result.status === 200) {
            this.bedQuantityData = this.store.modifiedBedQuantityByParam
          }
        })
    },
    showVisitorsDialog (bedId) {
      this.bedId = bedId
      this.visitorsData = this.store.modifiedEmployees
      this.visitorDialog = true
    },
    addVisitor (item) {
      const data = {
        empCode: item,
        bedId: this.bedId,
        isUpdateAutoBooking: this.isUpdateAutoBooking
      }
      this.store.addVisitorToBed(data).then((res) => {
        if (res.data.code === 203) {
          this.showDialog(res.data.listResult)
          this.showNotify(res.data.message, 500)
        }
        this.store.getRoomDetails(this.roomId).then(() => {
          if (res.data.code === 201) {
            this.roomNumDetails = this.store.roomsDetails?.data
            this.visitorDialog = false
            this.showNotify(res.data.message, 200)
          } else {
            this.showNotify(res.data.message, 400)
          }
        })
      })
    },
    showDialog (list) {
      this.conflictsData = list
      this.visitorResponseDialog = true
    },
    visitorFilter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.visitorsData = this.visitorsData.filter(v => v.label?.toLowerCase().indexOf(needle) > -1)
          : this.visitorsData = this.store.modifiedEmployees
      })
    },
    getVisitor (item) {
      return this.store.modifiedEmployees.find(el => el.value === item).label ?? ''
    },
    deleteVisitor (item, bedId) {
      const data = {
        empCode: item,
        bedId
      }
      this.store.deleteVisitorsFromBed(data).then((res) => {
        this.store.getRoomDetails(this.roomId).then(() => {
          if (res.data.code === 201) {
            this.showNotify(res.data.message)
            this.roomNumDetails = this.store.roomsDetails?.data
          } else {
            this.showNotify(res.data.message)
          }
        })
      })
    }
  },
  created () {
    this.store.getStockBeds()
      .then((el) => {
        this.stockBeds = el?.data
      })
    const data = {
      location: '',
      blockName: '',
      roomNum: '',
      page: 1,
      size: 10
    }
    this.store.getAllRoomsForConstructor(data)
  }
}
</script>
