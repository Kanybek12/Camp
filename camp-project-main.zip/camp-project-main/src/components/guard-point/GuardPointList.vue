<template>
  <q-table ref="tableRef" tabindex="0" row-key="id" :rows="rows" :columns="columns1" v-model:pagination="pagination" no-data-label="Нет данных">
    <template v-slot:top>
      <div class="gp-filter-form__title gp-table__header">Персональные данные</div>
      <div class="gp-filter-form__title gp-table__header">КПП</div>
      <div class="gp-filter-form__title gp-table__header">Лагерь</div>
    </template>
    <template v-slot:header="props">
      <q-tr :props="props" class="gp-table__head">
        <q-th v-for="col in props.cols" :key="col.name" :props="props">
          <div class="gp-table__head__title" v-html="col.label"/>
        </q-th>
      </q-tr>
    </template>
    <template v-slot:body-cell-empCode="props">
      <q-td :props="props" class="gp-table__col">
        <div v-html="props.row.empCode"/>
      </q-td>
    </template>
    <template v-slot:body-cell-name="props">
      <q-td :props="props" class="gp-table__col">
        <div v-html="props.row.name"/>
      </q-td>
    </template>
    <template v-slot:body-cell-entranceDate="props">
      <q-td :props="props" class="gp-table__col">
        <div v-html="props.row.entranceDate"/>
      </q-td>
    </template>
    <template v-slot:body-cell-exitDate="props">
      <q-td :props="props" class="gp-table__col">
        <div v-html="props.row.exitDate"/>
      </q-td>
    </template>
    <template v-slot:body-cell-checkIn="props">
      <q-td :props="props" class="gp-table__col">
        <div v-html="props.row.checkIn"/>
      </q-td>
    </template>
    <template v-slot:body-cell-checkOut="props">
      <q-td :props="props" class="gp-table__col">
        <div v-html="props.row.checkOut"/>
      </q-td>
    </template>
    <template v-slot:bottom>
      <div class="gp-table__paginate">
        <q-pagination v-model="store.guardPointParams.page" color="grey-10" active-color="grey-10"
                      active-text-color="white" :max="getPages" :max-pages="6" direction-links boundary-links
                      @click="getPage(store.guardPointParams.page)"/>
      </div>
    </template>
  </q-table>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'

const columns1 = [
  { name: 'empCode', required: true, label: 'Табельный №', align: 'left', field: 'empCode' },
  { name: 'name', required: true, label: 'ФИО', align: 'left', field: 'name' },
  { name: 'entranceDate', align: 'center', label: 'Заезд', field: 'entranceDate' },
  { name: 'exitDate', align: 'center', label: 'Выезд', field: 'exitDate' },
  { name: 'checkIn', align: 'center', label: 'Заезд', field: 'checkIn' },
  { name: 'checkOut', align: 'center', label: 'Выезд', field: 'checkOut' }
]

export default {
  name: 'GuardPointList',
  props: {
    listData: {
      type: Array
    },
    pages: {
      type: Number
    }
  },
  setup () {
    return {
      isLoading: ref(true),
      store: mainStore(),
      pagination: {
        descending: false,
        rowsPerPage: 10
      },
      columns1,
      employeesData: ref([])
    }
  },
  computed: {
    rows () {
      return this.listData
    },
    settlementData () {
      return this.store.guardPointData ?? []
    },
    getCurrent () {
      return this.store.guardPointParams.page
    },
    getPages () {
      return this.store.guardPointData.totalPages
    }
  },
  methods: {
    getPage (page) {
      this.store.guardPointParams.page = page
      this.store.getGuardPoint(page,
        this.store.guardPointParams.dateIn,
        this.store.guardPointParams.dateOut,
        this.store.guardPointParams.dateInCamp,
        this.store.guardPointParams.dateOutCamp,
        this.store.guardPointParams.employeeCode)
    }
  },
  watch: {
    listData (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    }
  }
}
</script>
