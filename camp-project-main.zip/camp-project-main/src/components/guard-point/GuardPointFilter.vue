<template>
  <div class="gp-filter-form">
    <p class="gp-filter-form__title">Фильтрация</p>
    <div class="gp-filter-form__block">
      <q-select label="ФИО или Таб. №" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
                outlined dense use-input hide-selected fill-input
                v-model="employeeCode" :options="employeesData" @filter="filterFn" @input-value="setEmpCodeValue">
        <template v-slot:append>
          <q-icon v-if="employeeCode !== ''" class="cursor-pointer" name="clear" @click.stop="employeeCode = ''"/>
        </template>
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
          </q-item>
        </template>
      </q-select>
      <q-input label="Дата заезда в КПП" class="gp-filter-form__block__input" dense readonly outlined v-model="dateIn">
        <template v-slot:append>
          <q-icon name="event" class="cursor-pointer">
            <q-popup-proxy cover transition-show="scale" transition-hide="scale">
              <q-date v-model="dateIn">
                <div class="row items-center justify-end">
                  <q-btn v-close-popup flat label="Применить" color="primary" />
                </div>
              </q-date>
            </q-popup-proxy>
          </q-icon>
        </template>
      </q-input>
      <q-input label="Дата выезда из КПП" class="gp-filter-form__block__input" dense  readonly outlined
               v-model="dateOut">
        <template v-slot:append>
          <q-icon name="event" class="cursor-pointer">
            <q-popup-proxy cover transition-show="scale" transition-hide="scale">
              <q-date v-model="dateOut">
                <div class="row items-center justify-end">
                  <q-btn v-close-popup flat label="Применить" color="primary"/>
                </div>
              </q-date>
            </q-popup-proxy>
          </q-icon>
        </template>
      </q-input>
      <q-input label="Дата заезда в лагерь" class="gp-filter-form__block__input" dense readonly outlined
               v-model="dateInCamp">
        <template v-slot:append>
          <q-icon name="event" class="cursor-pointer">
            <q-popup-proxy cover transition-show="scale" transition-hide="scale">
              <q-date v-model="dateInCamp">
                <div class="row items-center justify-end">
                  <q-btn v-close-popup flat label="Применить" color="primary" />
                </div>
              </q-date>
            </q-popup-proxy>
          </q-icon>
        </template>
      </q-input>
      <q-input label="Дата выезда из лагеря" class="gp-filter-form__block__input" dense readonly outlined
               v-model="dateOutCamp">
        <template v-slot:append>
          <q-icon name="event" class="cursor-pointer">
            <q-popup-proxy cover transition-show="scale" transition-hide="scale">
              <q-date v-model="dateOutCamp">
                <div class="row items-center justify-end">
                  <q-btn v-close-popup flat label="Применить" color="primary"/>
                </div>
              </q-date>
            </q-popup-proxy>
          </q-icon>
        </template>
      </q-input>
      <div class="gp-filter-form__block__input gp-filter-form__block__btn-block">
        <q-btn icon="filter_list" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Применить"
               flat no-caps @click="filterData">
          <q-tooltip>Применить фильтр</q-tooltip>
        </q-btn>
        <q-btn icon="filter_list_off" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Отменить"
               flat no-caps @click="cancelFilter">
          <q-tooltip>Отменить фильтр</q-tooltip>
        </q-btn>
      </div>
    </div>
  </div>
</template>

<script>

import { ref } from 'vue'
import { mainStore } from 'stores/main-store'

export default {
  name: 'GuardPointFilter',
  setup () {
    return {
      store: mainStore(),
      employeeCode: ref(''),
      dateIn: ref(''),
      dateOut: ref(''),
      dateInCamp: ref(''),
      dateOutCamp: ref(''),
      employeesData: ref('')
    }
  },
  created () {
    this.employeesData = this.store.modifiedEmployees
  },
  methods: {
    filterFn (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.employeesData = this.store.modifiedEmployees.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.employeesData = this.store.modifiedEmployees
      })
    },
    cancelFilter () {
      this.dateIn = ''
      this.dateOut = ''
      this.dateInCamp = ''
      this.dateOutCamp = ''
      this.employeeCode = ''
      this.filterData()
    },
    setEmpCodeValue (val) {
      this.employeeCode = val
    },
    filterData () {
      this.store.guardPointParams.dateIn = this.dateIn?.replaceAll('/', '-') ?? ''
      this.store.guardPointParams.dateOut = this.dateOut?.replaceAll('/', '-') ?? ''
      this.store.guardPointParams.dateInCamp = this.dateInCamp.replaceAll('/', '-') ?? ''
      this.store.guardPointParams.dateOutCamp = this.dateOutCamp.replaceAll('/', '-') ?? ''
      this.store.guardPointParams.employeeCode = this.employeeCode?.value ?? ''
      this.store.guardPointParams.page = 1
      this.store.getGuardPoint('1',
        this.dateIn.replaceAll('/', '-') ?? '',
        this.dateOut.replaceAll('/', '-') ?? '',
        this.dateInCamp.replaceAll('/', '-') ?? '',
        this.dateOutCamp.replaceAll('/', '-') ?? '',
        this.employeeCode?.value ?? '')
    }
  }
}
</script>
