<template>
  <q-header elevated class="header">
    <q-tabs v-if="$q.platform.is.desktop" align="justify" class="flex indexPage__mainTab" v-model="tab" inline-label>
      <img alt  src="../assets/logo_new.png" class="header__bannerLogo" @click="reloadPage" style="width: 65px; height: 65px"/>
      <q-route-tab label="Главная страница" to="/" no-caps name="main" class="header__bannerTabs" v-if="coordinator"/>
      <q-route-tab label="Бронирование комнаты" to="/room-booking" no-caps name="bookingRoom" class="header__bannerTabs"
                   v-if="coordinator"/>
      <q-route-tab label="Список броней" no-caps to="/booking-list" class="header__bannerTabs" v-if="coordinator"/>
      <q-route-tab label="Конструктор комнаты" no-caps to="/room-constructor" name="constructorRoom"
                   class="header__bannerTabs" v-if="coordinator"/>
      <q-route-tab label="Отчеты" no-caps to="/reports" name="reports" class="header__bannerTabs" v-if="coordinator"/>
      <q-route-tab label="Guard Point" no-caps to="/guard-point" class="header__bannerTabs"
                   v-if="coordinator || shiftBus"/>
      <q-route-tab label="Заявки на утверждение" to="/approve-requests" no-caps class="header__bannerTabs"
                   v-if="approver"/>
      <q-route-tab label="Заявки на транспортировку" name="transport" to="/transfer" no-caps class="header__bannerTabs"
                   v-if="bus"/>
      <q-route-tab label="Мои заявки" name="my-request" to="/request-list" no-caps class="header__bannerTabs"
                   v-if="creator"/>
      <q-route-tab
        name="archive"
        to="/archive-page"
        no-caps
        class="header__bannerTabs"
        label="Архив"
        v-if="coordinator"
      />
      <q-route-tab
        name="archive"
        to="/archive-page-transfer"
        no-caps
        class="header__bannerTabs"
        label="Архив заявок"
        v-if="bus || shiftBus"
      />
      <q-route-tab name="manual" to="/manual-location" no-caps class="header__bannerTabs" label="Пункты отправки" v-if="bus || shiftBus"/>
      <q-tab label="Выйти" class="header__bannerTabs" no-caps @click="logout" flat/>
    </q-tabs>
  </q-header>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'

export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Header',
  setup () {
    return {
      store: mainStore(),
      tab: ref('my-request'),
      name: localStorage.getItem('emp'),
      role: ref(''),
      roleNew: ref(),
      creator: ref(false),
      approver: ref(false),
      bus: ref(false),
      shiftBus: ref(false),
      coordinator: ref(false)
    }
  },
  methods: {
    logout () {
      localStorage.clear()
      this.$router.push('/login')
    },
    goMyAccount () {
      this.$router.push('/my-account')
    }
  },
  created () {
    this.roleNew = localStorage.getItem('camp_role').split(',')
    this.roleNew.forEach((el) => {
      if (el === 'creator') this.creator = true
      if (el === 'coordinator') this.coordinator = true
      if (el === 'approver') this.approver = true
      if (el === 'bus-dispatcher' || el === 'shift-bus-dispatcher') this.bus = true
      if (el === 'shift-bus-dispatcher') this.shiftBus = true
    })
    this.store.getGender()
    this.store.getBedType()
    this.store.getRoomCategory()
    this.store.getEmpCodes()
    this.store.getSchedule()
    this.store.getDepartments()
    this.store.getJobTitles()
    this.store.getVisitors()
    this.store.getEmployees()
    this.store.getApplicationType()
    this.store.getLocations()
    this.store.getCostCenters()
  }
}
</script>
