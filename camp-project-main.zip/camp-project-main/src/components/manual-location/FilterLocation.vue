<template>
  <p class="checkinOut__block__title">Таб.номер и ФИО</p>
  <div class="gp-filter-form__block">
    <q-select label="Выберите" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
              outlined dense use-input hide-selected fill-input
              v-model="empCode" :options="empData" @filter="empFilter">
      <template v-slot:append>
        <q-icon v-if="empCode !== ''" class="cursor-pointer" name="clear" @click.stop="empCode = ''"/>
      </template>
      <template v-slot:no-option>
        <q-item>
          <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
        </q-item>
      </template>
    </q-select>
    <div class="gp-filter-form__block__input gp-filter-form__block__btn-block">
      <q-btn icon="filter_list" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Применить"
             flat no-caps @click="filterOn">
        <q-tooltip>Применить фильтр</q-tooltip>
      </q-btn>
      <q-btn icon="filter_list_off" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Отменить"
             flat no-caps @click="filterOff">
        <q-tooltip>Отменить фильтр</q-tooltip>
      </q-btn>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { manualLocationStore } from 'stores/ManualLocationStore'
import { mainStore } from 'stores/main-store'

export default {
  name: 'FilterLocation',
  setup () {
    return {
      store: manualLocationStore(),
      storeMain: mainStore(),
      empCode: ref(''),
      empData: ref('')
    }
  },
  created () {
    this.empData = this.storeMain.modifiedEmployees
  },
  methods: {
    empFilter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.empData = this.storeMain.modifiedEmployees.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.empData = this.storeMain.modifiedEmployees
      })
    },
    filterOn () {
      this.store.locationFilterData.page = 1
      this.store.locationFilterData.empCode = this.empCode.value ?? ''
      this.store.getLocationInfo()
    },
    filterOff () {
      this.empCode = ''
      this.filterOn()
    }
  }
}
</script>
