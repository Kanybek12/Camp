<template>
  <q-dialog v-model="show_dialog" >
    <q-card>
      <q-card-section>
        <div class="text-h6">Укажите новое место отправки</div>
      </q-card-section>
      <q-card-section>
          <div class="row__dialog">
            <div class="col-12">
              <q-input v-model="editedItem.empCode" label="Таб. №" :disable="true"></q-input>
            </div>
            <div class="col-12">
              <q-input v-model="editedItem.fullName" label="ФИО" :disable="true"></q-input>
            </div>
            <div class="col-12">
              <q-select label="Локация"
                        outlined dense v-model="location" :options="locationRef"/>
            </div>
            <div class="col-12">
              <q-checkbox v-model="isUpdateAutoBooking" label="Обновить место отправки в уже созданных автобронях"/>
            </div>
          </div>
          <br>
      </q-card-section>
      <q-card-actions align="right">
        <q-btn label="Отмена" color="red" flat v-close-popup no-caps/>
        <q-btn label="Сохранить" flatcolor="green" flat v-close-popup no-caps @click="updateCheckIn"/>
      </q-card-actions>
    </q-card>
  </q-dialog>
  <q-table row-key="empCode" :rows="rows" :columns="columns" :filter="filter" v-model:pagination="pagination">
    <template v-slot:body-cell-actions="props">
      <q-td key="actions" :props="props">
        <q-btn dense round flat color="blue"   @click="editItem(props.row)"  icon="edit" ></q-btn>
      </q-td>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination v-model="currentPage.page" color="grey-10" active-color="grey-10" active-text-color="white"
                      :max="pageSum" :max-pages="6" direction-links boundary-links @click="getPage(currentPage.page)"/>
      </div>
    </template>
  </q-table>
</template>

<script>

import { manualLocationStore } from 'stores/ManualLocationStore'
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'
import { useQuasar } from 'quasar'
const columns = [
  { name: 'empCode', align: 'left', label: 'Таб. №', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', align: 'left', label: 'ФИО', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'currentLocation', align: 'left', label: 'Текущее место отправки', field: 'currentLocation', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'actions', align: 'left', label: 'Изменить', field: 'actions', headerStyle: 'font-size: 13px; font-weight:bold' }
]
export default {
  name: 'TableManualLocation',
  setup () {
    const $q = useQuasar()
    const filter = ref('')
    return {
      store: manualLocationStore(),
      storeMain: mainStore(),
      columns,
      filter,
      pagination: {
        descending: false,
        rowsPerPage: 10
      },
      editedItem: {
        empCode: ref(''),
        fullName: ref(''),
        currentLocation: ref('')
      },
      show_dialog: ref(false),
      location: ref(''),
      locationRef: ref([]),
      isUpdateAutoBooking: ref(false),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      }
    }
  },
  props: {
    list: {
      type: Array
    },
    pageSum: {
      type: Number
    }
  },
  computed: {
    rows () {
      return this.list
    },
    currentPage () {
      return this.store.locationFilterData
    }
  },
  methods: {
    editItem (item) {
      this.show_dialog = true
      this.editedItem = Object.assign({}, item)
      this.locationRef = this.storeMain.modifiedLocations
      this.location = this.storeMain.modifiedLocations.find(el => el.label === this.editedItem.currentLocation) ?? ''
    },
    updateCheckIn () {
      if (!(this.location.value)) {
        this.showNotif('Пажалуйста выберите место положение!', 200)
      } else {
        this.store.updateLocationInfo({
          empCode: this.editedItem.empCode,
          locationId: this.location.value,
          isUpdateAutoBooking: this.isUpdateAutoBooking
        }).then((el) => {
          if (String(el.data.code).startsWith('2')) {
            this.showNotif(el?.data?.message, 200)
            this.store.getLocationInfo()
          } else {
            this.showNotif(el?.data?.message, 400)
          }
        }).catch(error => {
          console.log(error)
        })
      }
    },
    getPage (page) {
      this.store.locationFilterData.page = page
      this.store.getLocationInfo()
    }
  }
}
</script>

<style lang="sass" scoped>
.row__dialog > div
  padding : 10px 15px
  background : rgba(195, 173, 227, 0.15)
  border : 1px solid rgba(214, 206, 227, 0.2)
  margin-top : 1rem
</style>
