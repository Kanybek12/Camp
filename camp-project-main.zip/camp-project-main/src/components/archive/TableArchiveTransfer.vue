<template>
  <q-table title="Архив заявок на подъем/спуск" row-key="id"
           :rows="rows" :columns="columns"
           v-model:pagination="pagination" no-data-label="Данные отсутствуют">
    <template v-slot:header="props">
      <q-tr :props="props" class="gp-table__head">
        <q-th v-for="col in props.cols" :key="col.name" :props="props">
          <div v-html="col.label"/>
        </q-th>
      </q-tr>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination v-model="currentPage.page" color="grey-10" active-color="grey-10" active-text-color="white"
                      :max="pageSum" :max-pages="6" direction-links boundary-links @click="getPage(currentPage.page)"/>
      </div>
    </template>
  </q-table>
</template>

<script>

import { mainStore } from 'stores/main-store'

const columns = [
  { name: 'empCode', label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', label: 'ФИО', align: 'left', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'visitorType', align: 'left', label: 'Тип', field: 'visitorType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'transferDate', align: 'left', label: 'Планируемая дата поездки', field: 'transferDate', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'locationFrom', align: 'left', label: 'Откуда', field: 'locationFrom', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'locationTo', align: 'left', label: 'Куда', field: 'locationTo', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'applicationType', align: 'left', label: 'Вид поездки', field: 'applicationType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'note', align: 'left', label: 'Примечание', field: 'note', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'creator', align: 'left', label: 'Кем создано', field: 'creator', headerStyle: 'font-size: 13px; font-weight:bold' }
]

export default {
  name: 'TableArchiveTransfer',
  setup () {
    return {
      store: mainStore(),
      columns,
      pagination: {
        descending: false,
        rowsPerPage: 10
      }
    }
  },
  props: {
    list: {
      type: Array
    },
    pageSum: {
      type: Number
    }
  },
  computed: {
    rows () {
      return this.list
    },
    currentPage () {
      return this.store.archiveFilterTransferData
    }
  },
  methods: {
    getPage (page) {
      this.store.archiveFilterTransferData.page = page
      this.store.getArchiveTransferData()
    }
  }
}
</script>
