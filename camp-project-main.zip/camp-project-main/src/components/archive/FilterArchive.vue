<template>
  <p class="checkinOut__block__title">Фильтрация</p>
  <div class="gp-filter-form__block">
    <q-select label="ФИО или Таб. №" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
              outlined dense use-input hide-selected fill-input
              v-model="empCode" :options="empData" @filter="empFilter" @input-value="setEmpCodeValue">
      <template v-slot:append>
        <q-icon v-if="empCode !== ''" class="cursor-pointer" name="clear" @click.stop="empCode = ''"/>
      </template>
      <template v-slot:no-option>
        <q-item>
          <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
        </q-item>
      </template>
    </q-select>
    <q-input label="Планируемая дата заезда"
             class="gp-filter-form__block__input"
             dense readonly outlined
             v-model="dateIn">
      <template v-slot:append>
        <q-icon name="event"
                class="cursor-pointer">
          <q-popup-proxy cover
                         transition-show="scale"
                         transition-hide="scale">
            <q-date v-model="dateIn">
              <div class="row items-center justify-end">
                <q-btn v-close-popup flat
                       label="Применить"
                       color="primary" />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
    <q-input label="Планируемая дата выезда"
             class="gp-filter-form__block__input"
             dense readonly outlined
             v-model="dateOut">
      <template v-slot:append>
        <q-icon name="event"
                class="cursor-pointer">
          <q-popup-proxy cover
                         transition-show="scale"
                         transition-hide="scale">
            <q-date v-model="dateOut">
              <div class="row items-center justify-end">
                <q-btn v-close-popup flat
                       label="Применить"
                       color="primary" />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
    <q-input label="Фактическая дата заезда"
             class="gp-filter-form__block__input"
             dense readonly outlined
             v-model="checkIn">
      <template v-slot:append>
        <q-icon name="event"
                class="cursor-pointer">
          <q-popup-proxy cover
                         transition-show="scale"
                         transition-hide="scale">
            <q-date v-model="checkIn">
              <div class="row items-center justify-end">
                <q-btn v-close-popup flat
                       label="Применить"
                       color="primary" />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
    <q-input label="Фактическая дата выезда"
             class="gp-filter-form__block__input"
             dense readonly outlined
             v-model="checkOut">
      <template v-slot:append>
        <q-icon name="event"
                class="cursor-pointer">
          <q-popup-proxy cover
                         transition-show="scale"
                         transition-hide="scale">
            <q-date v-model="checkOut">
              <div class="row items-center justify-end">
                <q-btn v-close-popup flat
                       label="Применить"
                       color="primary" />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
    <div class="gp-filter-form__block__input gp-filter-form__block__btn-block">
      <q-btn icon="filter_list" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Применить"
             flat no-caps @click="filterOn">
        <q-tooltip>Применить фильтр</q-tooltip>
      </q-btn>
      <q-btn icon="filter_list_off" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Отменить"
             flat no-caps @click="filterOff">
        <q-tooltip>Отменить фильтр</q-tooltip>
      </q-btn>
    </div>
  </div>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'

export default {
  name: 'FilterArchive',
  setup () {
    return {
      store: mainStore(),
      empCode: ref(''),
      dateIn: ref(''),
      dateOut: ref(''),
      checkIn: ref(''),
      checkOut: ref(''),
      empData: ref('')
    }
  },
  created () {
    this.empData = this.store.modifiedEmployees
  },
  methods: {
    empFilter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.empData = this.store.modifiedEmployees.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.empData = this.store.modifiedEmployees
      })
    },
    filterOn () {
      this.store.archiveFilterData.page = 1
      this.store.archiveFilterData.empCode = this.empCode.value ?? ''
      this.store.archiveFilterData.dateIn = this.dateIn.replaceAll('/', '-') ?? ''
      this.store.archiveFilterData.dateOut = this.dateOut.replaceAll('/', '-') ?? ''
      this.store.archiveFilterData.checkIn = this.checkIn.replaceAll('/', '-') ?? ''
      this.store.archiveFilterData.checkOut = this.checkOut.replaceAll('/', '-') ?? ''
      this.store.getArchiveData()
    },
    filterOff () {
      this.empCode = ''
      this.dateIn = ''
      this.dateOut = ''
      this.checkIn = ''
      this.checkOut = ''
      this.filterOn()
    }
  }
}
</script>
