<template>
  <q-table title="Архив заявок на заселение" row-key="transferId"
           :rows="rows" :columns="columns" :filter="filter"
           v-model:pagination="pagination" no-data-label="Данные отсутствуют">
    <template v-slot:header="props">
      <q-tr :props="props" class="gp-table__head">
        <q-th v-for="col in props.cols" :key="col.name" :props="props">
          <div v-html="col.label"/>
        </q-th>
      </q-tr>
    </template>
    <template v-slot:body-cell-jobTitle="props">
      <q-td :props="props">
        <div style="width: 200px; overflow: hidden; text-overflow: ellipsis;">{{ props.row.jobTitle}}
          <q-tooltip>{{props.row.jobTitle}}</q-tooltip>
        </div>
      </q-td>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination v-model="currentPage.page" color="grey-10" active-color="grey-10" active-text-color="white"
                      :max="pageSum" :max-pages="6" direction-links boundary-links @click="getPage(currentPage.page)"/>
      </div>
    </template>
    <template v-slot:top-right>
    <q-btn dense color="secondary" label="Add Row" v-show="false" @click="show_dialog = true" no-caps></q-btn>
    <div class="q-pa-md q-gutter-sm">
      <q-dialog v-model="show_dialog" >
        <q-card>
          <q-card-section>
            <div class="text-h6">Изменить фактическую дату выезда</div>
          </q-card-section>
          <q-card-section>
            <div class="row q-col-gutter-x-xs">
              <q-input v-model="editedItem.empCode" label="Таб. №" :disable="true"></q-input>
              <q-input v-model="editedItem.name" label="ФИО" :disable="true"></q-input>
              <q-input v-model="editedItem.jobTitle" label="Должность" :disable="true"></q-input>
              <q-input v-model="editedItem.department" label="Отдель/Организация" :disable="true"></q-input>
              <q-input v-model="editedItem.dateIn" label="Планируемая дата заезда" :disable="true"></q-input>
              <q-input v-model="editedItem.dateOut" label="Планируемая дата выезда" :disable="true"></q-input>
              <q-input v-model="editedItem.visitorType" label="Тип" :disable="true"></q-input>
              <q-input v-model="editedItem.status" label="Статус" :disable="true"></q-input>
              <q-input v-model="editedItem.checkIn" label="Фактическая дата заезда" :disable="true"></q-input>
              <div class="col-12 text-center self-center">
                <q-input filled v-model="checkOut" mask="date"  label="Фактическая дата выезда" :disable="myDisable()">
                  <template v-slot:append>
                    <q-icon name="event" class="cursor-pointer">
                      <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                        <q-date v-model="checkOut">
                          <div class="row items-center justify-end">
                            <q-btn v-close-popup label="Применить" color="primary" flat />
                          </div>
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
          </q-card-section>
          <q-card-actions align="right">
            <q-btn label="Отмена" color="red" flat v-close-popup no-caps/>
            <q-btn label="Сохранить" flatcolor="green" flat v-close-popup no-caps @click="updateCheckOut()"/>
          </q-card-actions>
          </q-card>
      </q-dialog>
    </div>
    </template>
    <template v-slot:body-cell-actions="props">
      <q-td key="actions" :props="props">
        <q-btn dense round flat color="blue"   @click="editItem(props.row)"  icon="edit" ></q-btn>
      </q-td>
    </template>
  </q-table>
</template>

<script>

import { mainStore } from 'stores/main-store'
import { ref } from 'vue'
import { useQuasar } from 'quasar'

const columns = [
  { name: 'empCode', align: 'left', label: 'Таб. №', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'name', align: 'left', label: 'ФИО', field: 'name', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'jobTitle', align: 'left', label: 'Должность', field: 'jobTitle', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateIn', align: 'left', label: 'План. дата заезда', field: 'dateIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateOut', align: 'left', label: 'План. дата выезда', field: 'dateOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'checkIn', align: 'left', label: 'Факт. дата заезда', field: 'checkIn', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'checkOut', align: 'left', label: 'Факт. дата выезда', field: 'checkOut', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'visitorType', align: 'left', label: 'Тип', field: 'visitorType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'creator', align: 'left', label: 'Кем создано', field: 'creator', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'actions', align: 'left', label: 'Изменить', field: 'actions', headerStyle: 'font-size: 13px; font-weight:bold' }
]

export default {
  name: 'TableArchive',
  setup () {
    const filter = ref('')
    const $q = useQuasar()
    return {
      store: mainStore(),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      columns,
      filter,
      pagination: {
        descending: false,
        rowsPerPage: 10
      },
      isSettlement: ref(false),
      editedItem: {
        checkIn: ref(''),
        checkOut: ref(''),
        dateIn: ref(''),
        dateOut: ref(''),
        department: ref(''),
        empCode: ref(''),
        id: ref(''),
        jobTitle: ref(''),
        name: ref(''),
        status: ref(''),
        visitorType: ref('')
      },
      date: ref(''),
      checkOut: ref(''),
      show_dialog: ref(false)
    }
  },
  props: {
    list: {
      type: Array
    },
    pageSum: {
      type: Number
    }
  },
  computed: {
    rows () {
      return this.list
    },
    currentPage () {
      return this.store.archiveFilterData
    }
  },
  methods: {
    getPage (page) {
      this.store.archiveFilterData.page = page
      this.store.getArchiveData()
    },
    editItem (item) {
      this.show_dialog = true
      this.editedItem = Object.assign({}, item)
      this.date = this.editedItem.checkIn
      this.checkOut = this.editedItem.checkOut
    },
    updateCheckIn () {
      const arr = []
      arr.push({
        id: this.editedItem.id,
        data: this.date.replaceAll('/', '-')
      })
      this.store.checkinSt({ id: arr })
        .then((el) => {
          if (String(el.data.code).startsWith('2')) {
            this.showNotif(el?.data?.message, 200)
            this.store.getStatistics('beds')
            this.store.getStatistics('rooms')
            this.store.getStatistics('bookings')
            this.store.getArchiveData()
            this.arr = []
          } else {
            this.showNotif(el?.data?.message, 400)
          }
        })
        .catch(error => {
          console.log(error)
        })
    },
    updateCheckOut () {
      const arr = []
      arr.push({
        id: this.editedItem.id,
        data: this.checkOut.replaceAll('/', '-')
      })
      this.store.checkoutSt({ id: arr })
        .then((el) => {
          if (String(el.data.code).startsWith('2')) {
            this.showNotif(el?.data?.message, 200)
            this.store.getStatistics('beds')
            this.store.getStatistics('rooms')
            this.store.getStatistics('bookings')
            this.store.getArchiveData()
            this.arr = []
          } else {
            this.showNotif(el?.data?.message, 400)
          }
        })
        .catch(error => {
          console.log(error)
        })
    },
    myDisable () {
      if (this.editedItem.checkIn === null) {
        return true
      } else {
        return false
      }
    }
  }
}
</script>
