<template>
  <div class="gp-filter-form">
    <q-table title="Список броней"
             row-key="name"
             class="wrap"
             style="width: 100%"
             grid hide-header
             :card-container-class="cardContainerClass"
             :rows="rows"
             dense
             :pagination="initialPagination"
             :columns="columns" auto>
      <template v-slot:item="props">
        <div style="width: 20%; min-width: 330px; display: flex; flex-direction: column; padding: 4px">
          <div class="list">
            <div class="roomLabel">
              Комната {{ props.row.room }}
            </div>
            <div class="roomWrapper">
              <div class="Rooms"
                   v-for="i in props.row.bedList"
                   :key="i">
                <div class="Rooms__block">
                  <div class="Rooms__bed" >{{i.bedNum}}</div>
                  <div class="RoomsField"
                       v-if="i.status === 3"
                       style="background-color: #46E973; font-size: 16px; cursor: pointer; color:#121212"
                       @click="showGreenDialog(props.row.room, i.bedNum, i.dateIn, i.dateOut)">
                    Свободно
                  </div>
                  <div class="RoomsField no-wrap"
                       v-else-if="i.status === 2"
                       style="overflow: hidden; text-overflow: ellipsis;background-color: #F2C037; cursor: pointer; color: #121212"
                       @click="showDialog(props.row.room, i.bedNum, i.empCode, i.dateIn, i.dateOut, i.bookingId, i.department)"
                  >{{i.empCode}}</div>
                  <div class="RoomsField no-wrap"
                       v-else-if="i.status === 4"
                       style="overflow: hidden; text-overflow: ellipsis;background-color: #46E973; cursor: pointer;"
                       @click="showVacationDialog(props.row.room, i.bedNum)">
                    {{i.empCode}}
                  </div>
                  <div class="RoomsField no-wrap"
                       v-else-if="i.status === 5"
                       style="overflow: hidden; text-overflow: ellipsis;background-color: #46E973; cursor: pointer;color: #c10015">
                    {{i.empCode}}
                  </div>
                  <div class="RoomsField"
                       style="cursor: pointer; overflow: hidden; text-overflow: ellipsis; color:#121212"
                       v-else @click="showRedDialog(props.row.room, i.bedNum, i.empCode, i.dateIn, i.dateOut, i.bookingId, i.department)">
                    {{i.empCode}}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
      <template v-slot:no-data>
        <div v-if="!isLoading">Данные отсутствуют</div>
        <div v-else style="width: 20%; min-width: 330px; display: flex; flex-direction: column; padding: 4px">
          <div class="list" style="gap: 12px">
            <div class="roomLabel">
              Комната
            </div>
            <div class="roomLabel" v-for="i in 4"
                 :key="i">
              <div style="display: flex; flex-direction: row; justify-content: space-between; width: 100%">
                <q-skeleton square style="width: 13%; border-radius: 3px"/>
                <q-skeleton square style="width: 83%; border-radius: 3px"/>
              </div>
            </div>
          </div>
        </div>
      </template>
    </q-table>
  </div>
  <q-dialog v-model="greenDialog">
    <q-card style="display: flex; flex-direction: column; padding: 8px; width: 600px; height: max-content">
      <q-card-section class="column">
        <div class="row" style="font-style: normal;font-weight: 600;font-size: 20px;line-height: 20px; padding-bottom: 12px; justify-content: space-between; align-items: center">
          <div>Кровать {{selectRoom}}-{{selectBed}}</div>
          <q-btn icon="clear" flat @click="greenDialog = false" style="width: 20px"/>
        </div>
        <div class="row" style="justify-content: space-between;">
          <div style="width: 40%; height: max-content">Статус:</div>
          <div style="width: 56%; color: green; height: max-content; font-weight: bold">Свободна</div>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Постоянный житель:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">Имя Фамилия</div>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Период проживания:</div>
          <div style="width: 56%; height: max-content; font-weight: bold; display: flex; flex-direction: row; flex-wrap: nowrap; align-items: center; justify-content: space-between; gap: 4px">
            <q-input placeholder="Дата заезда"
                     class="blp-filter-form__block__input" style="width: 48%"
                     dense readonly outlined
                     v-model="dateIn">
              <template v-slot:append>
                <q-icon name="event"
                        class="cursor-pointer">
                  <q-popup-proxy cover
                                 transition-show="scale"
                                 transition-hide="scale">
                    <q-date v-model="dateIn" :options="optionsFn">
                      <div class="row items-center justify-end">
                        <q-btn v-close-popup flat
                               label="Close"
                               color="primary"/>
                      </div>
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>-
            <q-input placeholder="Дата выезда"
                     class="blp-filter-form__block__input" style="width: 48%"
                     dense readonly outlined
                     v-model="dateOut">
              <template v-slot:append>
                <q-icon name="event"
                        class="cursor-pointer">
                  <q-popup-proxy cover
                                 transition-show="scale"
                                 transition-hide="scale">
                    <q-date v-model="dateOut" :options="optionsFn">
                      <div class="row items-center justify-end">
                        <q-btn v-close-popup flat
                               label="Close"
                               color="primary"/>
                      </div>
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
        </div>
<!--        <div class="row" style="justify-content: space-between;">-->
<!--          <div style="width: 40%; height: max-content;">Занятые даты:</div>-->
<!--          <div style="width: 56%; height: max-content;">-->
<!--            <div v-for="i in 5" :key="i">{{i}}</div>-->
<!--          </div>-->
<!--        </div>-->
        <div class="row" style="justify-content: flex-end; padding-top: 8px">
          <q-btn label="Создать бронь"
                 style="color: white; background: #1D4ED8;"
                 flat no-caps
                 :disable="!dateIn || !dateOut"
                 @click="goToBooking1"/>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="yellowDialog" >
    <q-card style="display: flex; flex-direction: column; padding: 8px; width: 600px; height: max-content">
      <q-card-section v-show="!cancelModel" class="column">
        <div class="row" style="font-style: normal;font-weight: 600;font-size: 20px;line-height: 20px; padding-bottom: 4px; justify-content: space-between; align-items: center">
          <div>Кровать {{selectRoom}}-{{selectBed}}</div>
          <q-btn icon="clear" flat @click="yellowDialog = false" style="width: 20px"/>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Статус:</div>
          <div style="width: 56%; color: #F2C037; height: max-content; font-weight: bold">Забронирована</div>
        </div>
      </q-card-section>
      <q-card-section v-show="!cancelModel" class="column">
        <div class="row" style="justify-content: space-between; align-items: center;">
          <div style="width: 40%; height: max-content">Посетитель:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">{{selectEmp}}</div>
        </div>
<!--        <div class="row" style="justify-content: space-between; align-items: center;">-->
<!--          <div style="width: 40%; height: max-content">Тип посетителя:</div>-->
<!--          <div style="width: 56%; height: max-content; font-weight: bold">{{}}</div>-->
<!--        </div>-->
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Период брони:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">{{dateIn.replaceAll('-', '/')}} - {{dateOut.replaceAll('-', '/')}}</div>
        </div>
      </q-card-section>
      <q-card-section v-show="!cancelModel" class="column">
        <div class="row" style="justify-content: flex-end; gap: 8px">
          <q-btn outline no-caps style="color: #1D4ED8;" label="Изменить бронь" @click="goToBooking()"/>
          <q-btn flat no-caps style="color: white; background: #1D4ED8;" label="Отменить бронь" @click="cancelModel=true"/>
        </div>
      </q-card-section>
      <q-card-section  class="column" v-show="cancelModel" style="height: max-content; gap: 12px">
        <div style="font-style: normal; font-weight: 600; font-size: 20px; line-height: 20px; text-align: center">Укажите причину отмены брони</div>
        <q-input v-model="reason" class="blp-filter-form__block__input" dense outlined/>
        <div class="row" style="justify-content: flex-end; padding-top: 8px; gap: 8px">
          <q-btn outline no-caps style="color: #1D4ED8;" label="Отмена" @click="cancelModel = false"/>
          <q-btn flat no-caps style="color: white; background: #1D4ED8;" label="Подтвердить" @click="deleteItem"/>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="vacationDialog" >
    <q-card style="display: flex; flex-direction: column; padding: 8px; width: 600px; height: max-content">
      <q-card-section v-show="!cancelModel" class="column">
        <div class="row" style="font-style: normal;font-weight: 600;font-size: 20px;line-height: 20px; padding-bottom: 4px; justify-content: space-between; align-items: center">
          <div>Кровать {{selectRoom}}-{{selectBed}}</div>
          <q-btn icon="clear" flat @click="vacationDialog = false" style="width: 20px"/>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Статус:</div>
          <div style="width: 56%; color: #80c5f3; height: max-content; font-weight: bold">В отпуске</div>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center;">
          <div style="width: 40%; height: max-content">Постоянный житель:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">{{selectEmp}}</div>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Период отпуска:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">{{dateIn.replaceAll('-', '/')}} - {{dateOut.replaceAll('-', '/')}}</div>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="redDialog" >
    <q-card style="display: flex; flex-direction: column; padding: 8px; width: 600px; height: max-content">
      <q-card-section v-show="!cancelRedModel" class="column">
        <div class="row" style="font-style: normal;font-weight: 600;font-size: 20px;line-height: 20px; padding-bottom: 4px; justify-content: space-between; align-items: center">
          <div>Кровать {{selectRoom}}-{{selectBed}}</div>
          <q-btn icon="clear" flat @click="redDialog = false" style="width: 20px"/>
        </div>
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Статус:</div>
          <div style="width: 56%; color: darkred; height: max-content; font-weight: bold">Занято</div>
        </div>
      </q-card-section>
      <q-card-section v-show="!cancelRedModel" class="column">
        <div class="row" style="justify-content: space-between; align-items: center;">
          <div style="width: 40%; height: max-content">Посетитель:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">{{selectEmp}}</div>
        </div>
<!--        <div class="row" style="justify-content: space-between; align-items: center;">-->
<!--          <div style="width: 40%; height: max-content">Тип посетителя:</div>-->
<!--          <div style="width: 56%; height: max-content; font-weight: bold">Сотрудник КГК</div>-->
<!--        </div>-->
        <div class="row" style="justify-content: space-between; align-items: center">
          <div style="width: 40%; height: max-content">Период брони:</div>
          <div style="width: 56%; height: max-content; font-weight: bold">{{dateIn.replaceAll('-', '/')}} - {{dateOut.replaceAll('-', '/')}}</div>
        </div>
      </q-card-section>
      <q-card-section v-show="!cancelRedModel" class="column">
        <div class="row" style="justify-content: flex-end; gap: 8px">
          <q-btn flat no-caps style="color: white; background: #1D4ED8;" label="Продлить бронь" @click="cancelRedModel=true"/>
        </div>
      </q-card-section>
      <q-card-section  class="column" v-show="cancelRedModel" style="height: max-content; gap: 12px">
        <div style="font-style: normal; font-weight: 600; font-size: 20px; line-height: 20px; text-align: center">Продление брони</div>
        <q-input placeholder="Планируемая дата выезда"
                 class="blp-filter-form__block__input"
                 dense readonly outlined
                 v-model="dateOut">
          <template v-slot:append>
            <q-icon name="event"
                    class="cursor-pointer">
              <q-popup-proxy cover
                             transition-show="scale"
                             transition-hide="scale">
                <q-date v-model="dateOut" :options="optionsFn">
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup flat
                           label="Close"
                           color="primary"/>
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
        <div class="row" style="justify-content: flex-end; padding-top: 8px; gap: 8px">
          <q-btn outline no-caps style="color: #1D4ED8;" label="Отмена" @click="cancelRedModel = false"/>
          <q-btn flat no-caps style="color: white; background: #1D4ED8;" label="Сохранить" @click="saveDate"/>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
</template>

<script>

import { computed, ref, watch } from 'vue'
import { useQuasar } from 'quasar'
import { mainStore } from 'stores/main-store'

export default {
  name: 'BookedRooms',
  props: {
    bookingData: {
      type: Array,
      default: () => []
    },
    list: {
      type: Function,
      default: () => {}
    }
  },
  setup () {
    const $q = useQuasar()

    function getItemsPerPage () {
      if ($q.screen.lt.sm) {
        return 4
      }
      if ($q.screen.lt.md) {
        return 8
      }
      return 12
    }
    const filter = ref('')
    const pagination = ref({
      page: 1,
      rowsPerPage: getItemsPerPage()
    })

    watch(() => $q.screen.name, () => {
      pagination.value.rowsPerPage = getItemsPerPage()
    })
    return {
      isLoading: ref(true),
      initialPagination: {
        descending: false,
        rowsPerPage: 50
      },
      optionsFn (date) {
        const today = new Date()
        let day = today.getDate()
        let month = today.getMonth() + 1
        if (month < 10) month = '0' + (today.getMonth() + 1)
        if (day < 10) day = '0' + (today.getDate())
        const year = today.getFullYear()
        return date >= year + '/' + month + '/' + day
      },
      comment: ref(''),
      bedStatus: ref(''),
      dateFrom: ref(''),
      dateTo: ref(''),
      dateIn: ref(''),
      dateOut: ref(''),
      date: ref(''),
      roomId: ref(''),
      emp: ref(''),
      reason: ref(''),
      selectRoom: ref(''),
      selectBed: ref(''),
      selectEmp: ref(''),
      bookingId: ref(''),
      selectDepartment: ref(''),
      yellowDialog: ref(false),
      redDialog: ref(false),
      cancelModel: ref(false),
      cancelRedModel: ref(false),
      greenDialog: ref(false),
      vacationDialog: ref(false),
      store: mainStore(),
      filter,
      pagination,
      cardContainerClass: computed(() => {
        return $q.screen.gt.xs
          ? 'grid-masonry grid-masonry--' + ($q.screen.gt.sm ? '3' : '2')
          : null
      }),
      rowsPerPageOptions: computed(() => {
        return $q.screen.gt.xs
          ? $q.screen.gt.sm ? [4, 8, 12] : [4, 8]
          : [4]
      })
    }
  },
  computed: {
    rows () {
      return this.list
    },
    columns: [
      { name: 'room', label: 'Name', field: row => row.room }
    ]
  },
  watch: {
    list (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    }
  },
  methods: {
    deleteItem () {
      const data = [
        {
          id: this.bookingId,
          note: this.reason
        }
      ]
      this.store.cancelBooking1(data).then((res) => {
        if (res) {
          this.store.getRoomsListFilter('', '', '', '', '', '', '')
          this.yellowDialog = false
          this.cancelModel = false
          if (res.data.code === 202) {
            // window.location.reload()
            // this.$router.push({
            //   path: '/booking-list'
            // })
          } else {
            console.log(res.data.message)
          }
        }
      })
    },
    showGreenDialog (room, bed, dateIn, dateOut) {
      this.selectRoom = room
      this.selectBed = bed
      this.dateIn = dateIn
      this.dateOut = dateOut
      this.greenDialog = true
    },
    showDialog (room, bed, empCode, dateIn, dateOut, id, department) {
      this.selectRoom = room
      this.selectBed = bed
      this.selectEmp = empCode
      this.dateIn = dateIn
      this.dateOut = dateOut
      this.bookingId = id
      this.selectDepartment = department
      this.yellowDialog = true
    },
    showRedDialog (room, bed, empCode, dateIn, dateOut, id, department) {
      this.selectRoom = room
      this.selectBed = bed
      this.selectEmp = empCode
      this.dateIn = dateIn
      this.dateOut = dateOut
      this.bookingId = id
      this.selectDepartment = department
      this.redDialog = true
    },
    showVacationDialog (room, bed) {
      this.store.getDetailInfoForVacationDialog(bed)
        .then((res) => {
          if (res.status === 200) {
            this.selectEmp = res.data.empInfo
            this.dateIn = res.data.dateIn
            this.dateOut = res.data.dateOut
          } else {
            this.selectEmp = ''
            this.dateIn = ''
            this.dateOut = ''
          }
        }).catch(error => {
          console.log(error)
        })
      this.selectRoom = room
      this.selectBed = bed
      this.vacationDialog = true
    },
    saveDate () {
      this.store.getBookingForChange(this.bookingId).then((res) => {
        if (res) {
          this.store.putBooking.empCode = res.data.empCode
          this.store.putBooking.firstName = res.data.firstName
          this.store.putBooking.lastName = res.data.lastName
          this.store.putBooking.gender = res.data.gender
          this.store.putBooking.department = res.data.department
          this.store.putBooking.jobTitle = res.data.jobTitle
          this.store.putBooking.dateIn = res.data.dateIn
          this.store.putBooking.dateOut = this.dateOut.replaceAll('/', '-')
          this.store.putBooking.location = res.data.location
          this.store.putBooking.block = res.data.block
          this.store.putBooking.room = res.data.room
          this.store.putBooking.bedId = res.data.bedId
          this.store.putBooking.roomGender = res.data.roomGender
          this.store.putBooking.category = res.data.category
          this.store.putBooking.status = res.data.status
          this.store.putBooking1(this.bookingId).then((res) => {
            if (res.status === 200) this.redDialog = false
            window.location.reload()
          })
        }
      })
    },
    goToBooking () {
      localStorage.setItem('bookingId', this.bookingId)
      this.store.getBookingForChange(this.bookingId).then((res) => {
        localStorage.setItem('selectedData', JSON.stringify(res.data))
        localStorage.setItem('switchType', 'single')
        this.store.cardBooking.plannedDateIn = this.dateIn
        this.store.cardBooking.plannedDateOut = this.dateOut
        this.store.cardBooking.cardFIO = this.selectEmp
        this.$router.push({
          path: '/room-booking'
        })
      })
    },
    goToBooking1 () {
      this.store.cardBooking.plannedDateIn = this.dateIn.replaceAll('/', '-')
      this.store.cardBooking.plannedDateOut = this.dateOut.replaceAll('/', '-')
      this.store.cardBooking.bed = this.selectBed
      localStorage.setItem('switchType', 'booking')
      this.$router.push({
        path: '/room-booking'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.list{
  display: flex;
  flex-direction: column;
  padding: 10px;
  width: 100%;
  //max-width: 366px;
  height: 250px;
  background: #FFFFFF;
  border: 0.5px solid #B1B2C6;
  border-radius: 6px;
}
.roomLabel{
  font-size: 22px;
  text-align: center;
  font-weight: bold;
  color: $border;
}
.roomWrapper{
  display: flex;
  flex-direction: column;
  overflow: auto;
}
.Rooms{
  display: flex;
  flex-direction: column;
  //padding: 10px 0;
  width: 100%;
  height: 100%;
  &__block {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 5px;
    border-radius: 5px;
    gap: 8px;
    &-last {
      width: 70%;
    }
  }
  &__bed{
    border-width: 1.75px;
    border-color: $border;
    border-style: dashed;
    border-radius: 3px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    font-weight: bold;
    color: rgba(0, 0, 0, 0.6);
    background-color: $bg-color;
    width: 40px;
    height: 40px;
  }
}
.RoomsField{
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  padding: 0 10px;
  color: $border;
  border-radius: 3px;
  font-weight: bold;
  width: 85%;
  height: 40px;
  font-size: 16px;
  border-width: 1.75px;
  border-style: dashed;
  border-color: $border;
  background-color: $bg-color;
}
.RoomsField:active {
  transform: scale(0.98);
  display: flex;
  box-shadow: 3px 2px 22px 1px rgba(0, 0, 0, 0.24);
}
.dialogField{
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.fieldGroup{
  display: flex;
  flex-direction: column;
}
.Field{
  display: flex;
  flex-direction: column;
  //width: 50%;
}
.dialogRoomField{
  width: 100%;
  height: 40px;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  border-radius: 6px;
  font-weight: bold;
  font-size: 12px;
  border-width: 1.75px;
  border-style: dashed;
  border-color: #9FA2B4;
  padding: 10px;
}
.popup{
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
}
.popupWarning{
  display: flex;
  width: 100%;
  flex-direction: row;
  justify-content: space-between;
  padding-bottom: 10px;
}
.myCard{
  display: flex;
  justify-content: space-between;
}
.btn_confirm{
  display: inline-flex;
  background-color: $secondary;
  width: 100%;
  border-radius: 10px;
}
.btn_cancel{
  background-color: $cancel;
  width: 100%;
  border-radius: 10px;
}

</style>
