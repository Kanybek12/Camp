<template>
  <div class="booking-info">
    <div class="booking-selects">
      <div class="booking-selects__first-col">
        <q-select label="Пол" class="select m-b-16" outlined dense
                  v-model="genderSelect"
                  :options="genderData"
                  @update:model-value="resetModel()
          resetModel('camp')
          resetModel('block');
          resetModel('room');
          resetModel('bed');
          resetModel('sum');
          resetModel('armorType')"/>
        <q-select label="Лагерь" class="select m-b-16"
                  outlined dense
                  v-model="camp"
                  :options="locationData"
                  @update:model-value="
                  resetModel('block');
                  resetModel('room');
                  resetModel('bed');
                  resetModel('sum');
                  getBlockData()"/>
        <q-select label="Блок"
                  class="select m-b-16"
                  outlined dense
                  v-model="block"
                  :disable="camp === null"
                  :options="blockData"
                  @update:model-value="
                  resetModel('room');
                  resetModel('sum');
                  resetModel('bed');
                  getRoomData();"/>
        <q-select label="Комната"
                  class="select m-b-16"
                  outlined dense
                  v-model="room"
                  :disable="block === null"
                  :options="roomData"
                  @update:model-value="
                  resetModel('sum');
                  resetModel('bed');
                  getBedData();
                  getBedQuantityData();"/>
      </div>
      <div class="booking-selects__second-col">
        <q-select label="Количество мест" class="select m-b-16" outlined dense disable
                  v-model="sum" :options="bedQuantityData"/>
        <q-select label="№ кровати" class="select m-b-16" outlined dense
                  v-model="bed" :disable="room === null" :options="bedData"/>
        <q-select label="Тип комнаты" v-if="false" class="select m-b-16" outlined dense
                  v-model="roomType" :options="roomCategory"/>
        <q-select label="Вид брони" class="select" outlined dense v-model="armorType" :options="armorData"/>
        <div class="q-pa-md-book">
        <div class="q-pa-md-none" style="align-items: center; justify-content: space-between">
          <q-checkbox v-model="store.settle" label="Бронировать с заездом"/>
        </div>
        </div>
      </div>
    </div>
    <div class="booking-card-wrapper">
      <q-card-section class="booking-card">
        <div class="booking-card__title">Кровать {{store.cardBooking.title}}</div>
        <div class="booking-card__info-title booking-card__info-block">Забронирован на
          <div class="booking-card__info-person-name" style="width: 200px; overflow: hidden; text-overflow: ellipsis;">
            {{store.cardBooking.cardFIO}}
          </div>
        </div>
        <div class="booking-card__dates">
          <div class="booking-card__dates__text">
            Дата c
            <q-input readonly dense outlined :label="store.cardBooking.plannedDateIn">
              <template v-slot:append>
                <q-icon name="event">
                </q-icon>
              </template>
            </q-input>
          </div>
          <div class="booking-card__dates__text">
            Дата по
            <q-input readonly dense outlined :label="store.cardBooking.plannedDateOut">
              <template v-slot:append>
                <q-icon name="event">
                </q-icon>
              </template>
            </q-input>
          </div>
        </div>
      </q-card-section>
    </div>
  </div>
</template>

<script>
import { computed, ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'

export default {
  name: 'BookingInformation',
  setup () {
    const $q = useQuasar()
    const myStore = mainStore()
    const genderSelect = computed({
      get: () => myStore.gender,
      set (value) { myStore.gender = value }
    })
    const camp = computed({
      get: () => myStore.camp,
      set (value) { myStore.camp = value }
    })
    const block = computed({
      get: () => myStore.block,
      set (value) { myStore.block = value }
    })
    const room = computed({
      get: () => myStore.room,
      set (value) { myStore.room = value }
    })
    const bed = computed({
      get: () => myStore.bed,
      set (value) { myStore.bed = value }
    })
    return {
      store: mainStore(),
      showNotif (mess) {
        $q.notify({
          message: mess,
          position: 'top',
          color: 'yellow-9'
        })
      },
      camp,
      block,
      room,
      bed,
      genderSelect,
      sum: ref(null),
      roomType: ref(null),
      armorType: ref({
        value: 1,
        label: 'Временные'
      }),
      dateOut: ref(''),
      dateIn: ref(''),
      blockData: ref(null),
      roomData: ref(null),
      bedData: ref(null),
      bedQuantityData: ref(null),
      title: ref('')
    }
  },
  props: {
    date1: {
      type: String,
      default: ''
    }
  },
  watch: {
    selectedMultiData (val) {
      this.store.isMulti = true
      const selectType = localStorage.getItem('switchType')
      if (selectType === 'multi') {
        const id = val[0].id
        this.store.getBookingForChange(id).then((res) => {
          this.store.cardBooking.cardFIO = res.data.firstName + ' ' + res.data.lastName
          this.store.cardBooking.plannedDateIn = res.data.dateIn
          this.store.cardBooking.plannedDateOut = res.data.dateOut
          this.genderSelect = this.genderData.find((el) => el.value === res.data.roomGender)
          this.camp = this.locationData.find((el) => el.value === res.data.location)
          this.roomType = this.roomCategory.find((el) => el.value === res.data.category)
          this.block = this.store.modifiedBlockRef.find((el) => el.value === res.data.block)
          const data = {
            dateIn: res.data.dateIn,
            dateOut: res.data.dateOut,
            blockId: res.data.block,
            genderId: res.data.gender,
            roomId: res.data.room
          }
          this.store.getRoomByParams(data)
            .then((result) => {
              if (result.status === 200) {
                this.room = this.store.modifiedRoomByParam.find((el) => el.value === res.data.room)
              }
            })
          const bed = {
            dateIn: this.dateIn,
            dateOut: res.data.dateOut,
            roomId: res.data.room,
            bedId: res.data.bedId
          }
          this.store.getBedByParams(bed)
            .then((result) => {
              if (result.status === 200) {
                this.bed = this.store.modifiedBedByParam.find((el) => el.value === res.data.bedId)
              }
            })
          this.store.getBedQuantityParams(bed)
            .then((result) => {
              if (result.status === 200) {
                this.sum = this.store.modifiedBedByParam.find((el) => el.value === res.data.roomCapacity)
                this.store.saveBooking.bedId = this.bed?.value
              }
            })
        })
      }
    },
    camp (val) {
      this.store.putBooking.location = val?.value
      if (val) this.getBlockData()
    },
    block (val) {
      this.store.cardBooking.title = ''
      this.store.putBooking.block = val?.value
      if (val) {
        this.getRoomData()
        this.store.cardBooking.title = val.label + '-'
      } else this.store.cardBooking.title = ''
    },
    room (val) {
      this.store.putBooking.room = val?.value
      if (val) {
        this.getBedData()
        this.getBedQuantityData()
        const title = this.store.cardBooking.title.split('-')[0]
        this.store.cardBooking.title = title + '-' + val.label
      }
    },
    genderSelect (val) {
      this.store.saveBooking.genderId = val?.value
      this.store.putBooking.roomGender = val?.value
      this.store.putBooking.gender = val?.value
    },
    bed (val) {
      this.store.saveBooking.bedId = val?.value
      this.store.putBooking.bedId = val?.value
      const title = this.store.cardBooking.title.split('-')[0] + '-' + this.store.cardBooking.title.split('-')[1]
      if (val) this.store.cardBooking.title = title + '-' + val.label
    },
    roomType (val) {
      this.store.putBooking.category = val?.value
    }
  },
  computed: {
    locationData () {
      return this.store.modifiedLocationRef
    },
    genderData () {
      return this.store.modifiedGenderRefForParam
    },
    roomCategory () {
      return this.store.modifiedRoomCategory
    },
    selectedMultiData () {
      return this.store.selectedMulti
    },
    armorData () {
      return [
        {
          value: 1,
          label: 'Временные'
        },
        {
          value: 2,
          label: 'Постоянные'
        }
      ]
    }
  },
  methods: {
    getNow () {
      const today = new Date()
      let day = today.getDate()
      let month = today.getMonth() + 1
      if (month < 10) month = '0' + (today.getMonth() + 1)
      if (day < 10) day = '0' + (today.getDate())
      const year = today.getFullYear()
      return year + '-' + month + '-' + day
    },
    getDateOut () {
      const today = new Date()
      let day = today.getDate()
      let month
      if (today.getMonth() === 11) month = 1
      else if (today.getMonth() === 12) month = 2
      else month = today.getMonth() + 2
      if (month < 10) month = '0' + (today.getMonth() + 2)
      if (day < 10) day = '0' + (today.getDate())
      const year = today.getFullYear()
      return year + '-' + month + '-' + day
    },
    resetModel (val) {
      switch (val) {
        case 'camp': this.camp = null
          break
        case 'block': this.block = null
          break
        case 'room': this.room = null
          break
        case 'sum': this.sum = null
          break
        case 'bed': this.bed = null
          break
        case 'armorType': this.armorType = null
          break
        default:
          this.room = null
          this.sum = null
          this.bed = null
          break
      }
    },
    getBlockData () {
      const data = {
        locationId: this.camp?.value,
        genderId: this.genderSelect?.value,
        dateIn: this.store.cardBooking.plannedDateIn,
        dateOut: this.store.cardBooking.plannedDateOut
      }
      this.store.getBlockParam(data)
        .then((result) => {
          if (result.status === 200) {
            this.blockData = this.store.modifiedBlockRef
          }
        })
    },
    getRoomData () {
      const data = {
        dateIn: this.store.cardBooking.plannedDateIn,
        dateOut: this.store.cardBooking.plannedDateOut,
        blockId: this.block?.value,
        genderId: this.genderSelect?.value,
        roomId: ''
      }
      this.store.getRoomByParams(data)
        .then((result) => {
          if (result.status === 200) {
            if (result.data.length) {
              this.roomData = this.store.modifiedRoomByParam
            } else {
              this.showNotif('В данном блоке нет комнат, удовлетворяющих условию')
            }
          }
        })
    },
    getBedData () {
      const data = {
        dateIn: this.store.cardBooking.plannedDateIn,
        dateOut: this.store.cardBooking.plannedDateOut,
        roomId: this.room?.value,
        bedId: ''
      }
      this.store.getBedByParams(data)
        .then((result) => {
          if (result.status === 200) {
            this.bedData = this.store.modifiedBedByParam
          }
        })
    },
    getBedQuantityData () {
      const data = {
        dateIn: this.store.cardBooking.plannedDateIn,
        dateOut: this.store.cardBooking.plannedDateOut,
        roomId: this.room?.value
      }
      this.store.getBedQuantityParams(data)
        .then((result) => {
          if (result.status === 200) {
            this.bedQuantityData = this.store.modifiedBedQuantityByParam
            this.sum = result.data.name
          }
        })
    }
  },
  created () {
    this.store.getLocation()
    this.store.getGender()
    const data = {
      locationId: '',
      genderId: '',
      dateIn: this.store.cardBooking.plannedDateIn,
      dateOut: this.store.cardBooking.plannedDateOut
    }
    this.store.getBlockParam(data)
    const data2 = {
      dateIn: this.store.cardBooking.plannedDateIn,
      dateOut: this.store.cardBooking.plannedDateOut,
      blockId: '',
      genderId: '',
      roomId: ''
    }
    this.store.getRoomByParams(data2)
    const data3 = {
      dateIn: this.store.cardBooking.plannedDateIn,
      dateOut: this.store.cardBooking.plannedDateOut,
      roomId: '',
      bedId: ''
    }
    this.store.getBedByParams(data3)
    this.store.getRoomCategory()
    this.dateIn = this.getNow()
    this.dateOut = this.getDateOut()
    const selectType = localStorage.getItem('switchType')
    if (selectType === 'single') {
      let id
      if (JSON.parse(localStorage.getItem('selectedData'))?.id) {
        id = JSON.parse(localStorage.getItem('selectedData'))?.id
      } else id = localStorage.getItem('bookingId')
      this.store.getBookingForChange(id).then((res) => {
        this.store.cardBooking.cardFIO = res.data.firstName + ' ' + res.data.lastName
        this.store.cardBooking.plannedDateIn = res.data.dateIn
        this.store.cardBooking.plannedDateOut = res.data.dateOut
        this.genderSelect = this.genderData.find((el) => el.value === res.data.gender)
        this.camp = this.locationData.find((el) => el.value === res.data.location)
        this.roomType = this.roomCategory.find((el) => el.value === res.data.category)
        this.block = this.store.modifiedBlockRef.find((el) => el.value === res.data.block)
        const data = {
          dateIn: res.data.dateIn,
          dateOut: res.data.dateOut,
          blockId: res.data.block,
          genderId: res.data.gender,
          roomId: res.data.room
        }
        this.store.getRoomByParams(data)
          .then((result) => {
            if (result.status === 200) {
              this.room = this.store.modifiedRoomByParam.find((el) => el.value === res.data.room)
            }
          })
        const bed = {
          dateIn: res.data.dateIn,
          dateOut: res.data.dateOut,
          roomId: res.data.room,
          bedId: res.data.bedId
        }
        this.store.getBedByParams(bed)
          .then((result) => {
            if (result.status === 200) {
              this.bed = this.store.modifiedBedByParam.find((el) => el.value === res.data.bedId)
            }
          })
        this.store.getBedQuantityParams(bed)
          .then((result) => {
            if (result.status === 200) {
              this.sum = this.store.modifiedBedByParam.find((el) => el.label === res.data.roomCapacity) ?? res.data.roomCapacity
              if (this.bed !== null) this.store.saveBooking.bedId = this.bed?.value
            }
          })
      })
    }
    if (selectType === 'booking') {
      this.store.getBookingTheList(
        this.store.cardBooking.plannedDateIn,
        this.store.cardBooking.plannedDateOut,
        this.store.cardBooking.bed)
        .then((res) => {
          this.genderSelect = this.genderData.find((el) => el.value === res.data.gender)
          this.camp = this.locationData.find((el) => el.value === res.data.campId)
          this.block = this.store.modifiedBlockRef.find((el) => el.value === res.data.block)
          const data = {
            dateIn: this.store.cardBooking.plannedDateIn,
            dateOut: this.store.cardBooking.plannedDateOut,
            blockId: res.data.block,
            genderId: res.data.gender,
            roomId: res.data.roomId
          }
          this.store.getRoomByParams(data)
            .then((result) => {
              if (result.status === 200) {
                this.room = this.store.modifiedRoomByParam.find((el) => el.value === res.data.roomId)
              }
            })
          const bed = {
            dateIn: this.store.cardBooking.plannedDateIn,
            dateOut: this.store.cardBooking.plannedDateOut,
            roomId: res.data.roomId,
            bedId: res.data.bedId
          }
          this.store.getBedByParams(bed)
            .then((result) => {
              if (result.status === 200) {
                this.bed = this.store.modifiedBedByParam.find((el) => el.value === Number(res.data.bedId))
              }
            })
          this.roomType = this.roomCategory.find((el) => el.value === Number(res.data.roomCategory))
          this.store.getBedQuantityParams(bed)
            .then((result) => {
              if (result.status === 200) {
                this.sum = res.data.roomCapacity
              }
            })
        })
    }
  }
}
</script>
