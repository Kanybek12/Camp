<template>
  <q-table title="Список посетителей" row-key="id" selection="single"
           grid hide-header hide-bottom v-model:selected="selected"
           :rows="multiBookingData" :pagination="initialPagination" :columns="columns">
      <template v-slot:item="props">
        <div class="q-pa-xs col-sm-12 col-md-5 col-lg-3 grid-style-transition"
             :style="props.selected ? 'transform: scale(0.95);' : ''">
          <q-card :class="props.selected ? 'bg-green-2' : ''" style="width: 100%">
            <q-card-section>
              <q-checkbox dense v-model="props.selected" :label="props.row.name" />
            </q-card-section>
            <q-separator />
            <q-list dense>
              <q-item v-for="col in props.cols" :key="col.name">
                <q-item-section style="width: 30%">
                  <q-item-label caption>{{ col.label }}</q-item-label>
                </q-item-section>
                <q-item-section side style="width: 60%">
                  <q-item-label style="width: 100%; max-lines: 1;overflow: hidden; position: relative; -webkit-line-clamp: 1; display: -webkit-box; -webkit-box-orient: vertical;">
                    {{ col.value ?? '-' }}
                    <q-tooltip style="font-size: 14px">{{col.value ?? '-'}}</q-tooltip>
                  </q-item-label>
                </q-item-section>
              </q-item>
            </q-list>
          </q-card>
        </div>
      </template>
    </q-table>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
const columns = [
  {
    name: 'empCode',
    label: 'Табельный №',
    align: 'left',
    field: 'empCode'
  },
  { name: 'name', align: 'center', label: 'ФИО', field: 'name' },
  { name: 'gender', align: 'center', label: 'Гендер', field: 'gender' },
  { name: 'jobTitle', label: 'Должность', field: 'jobTitle' },
  { name: 'department', label: 'Отдел/Организация', field: 'department' },
  { name: 'dateIn', label: 'Планируемая дата заезда', field: 'dateIn' },
  { name: 'dateOut', label: 'Планируемая дата выезда', field: 'dateOut' },
  { name: 'schedule', label: 'График', field: 'schedule' },
  { name: 'visitorType', label: 'Тип', field: 'visitorType' }
]

export default {
  name: 'MultiplyRoomBooking',
  setup () {
    return {
      store: mainStore(),
      initialPagination: {
        descending: false,
        rowsPerPage: 4
      },
      filter: ref(''),
      selected: ref([]),
      columns
    }
  },
  watch: {
    selected (val) {
      this.store.selectedMulti = val
      this.store.putBooking.empCode = val[0].empCode
      this.store.putBooking.firstName = val[0].name
      this.store.putBooking.lastName = val[0].name
      this.store.putBooking.department = val[0].department
      this.store.putBooking.dateIn = val[0].dateIn
      this.store.putBooking.dateOut = val[0].dateOut
      this.store.putBooking.dateOut = val[0].dateOut
      this.store.putBooking.jobTitle = val[0].jobTitle
    }
  },
  created () {
    this.store.getEmpCodes()
    if (localStorage.getItem('switchType') === 'multi') {
      this.store.selDataMulti = JSON.parse(localStorage.getItem('selectedData'))
    }
  },
  computed: {
    multiBookingData () {
      return this.store.selDataMulti
    }
  }
}
</script>

<style scoped lang="sass">
.q-table__grid-content
  overflow-x: scroll
  flex-wrap: nowrap!important
.grid-style-transition
  transition: transform .28s, background-color .28s
</style>
