<template>
  <div class="single-booking">
    <q-form>
    <div class="single-booking__title">Информация о посетителе</div>
    <div class="row ctrp__gap-8" style="align-items: center; justify-content: space-between">
      <q-checkbox v-model="guest" label="Гость" :disable="guestType"/>
    </div>
    <div class="single-booking__row">
      <div class="single-booking__input-wrapper" v-show="!guest">
        <span class="single-booking__input-label">Табельный номер</span>
        <q-select class="m-b-10" behavior="menu" input-debounce="0" outlined dense
                  use-input hide-selected fill-input v-model="empCode" :options="empCodeData"
                  @filter="filterFnEmp" @input-value="setModelSelectEmp" @update:model-value="getDataByEmpCode()">
          <template v-slot:append>
            <q-icon v-if="empCode !== ''" class="cursor-pointer" name="clear" @click.stop="empCode = ''"/>
          </template>
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('noResult')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
      </div>
      <div class="single-booking__input-wrapper" v-show="guest">
        <span class="single-booking__input-label">ИНН</span>
        <q-input class="m-b-10" outlined dense v-model="passport"/>
      </div>
      <div class="single-booking__input-wrapper">
          <span class="single-booking__input-label">Фамилия</span>
        <q-input class="m-b-10" outlined dense :disable="!guest" v-model="lastName"/>
      </div>
      <div class="single-booking__input-wrapper">
          <span class="single-booking__input-label">Имя</span>
        <q-input class="m-b-10" outlined dense :disable="!guest" v-model="firstName"/>
      </div>
      <div class="single-booking__input-wrapper">
          <span class="single-booking__input-label">Должность</span>
        <q-input class="m-b-10" outlined dense :disable="!guest" v-model="jobTitle"/>
      </div>
    </div>
    <div class="single-booking__row">
      <div class="single-booking__input-wrapper">
        <span class="single-booking__input-label">Отдел/Организация</span>
        <q-input class="m-b-10" outlined dense :disable="!guest" v-model="department" :rules="inputRules"/>
      </div>
      <div class="single-booking__input-wrapper">
        <span class="single-booking__input-label">Центр затрат</span>
        <q-select class="m-b-10" behavior="menu" input-debounce="0" outlined dense
                  use-input hide-selected fill-input v-model="payAccount" :options="costCenterData" :disable="employeeType === 1 || employeeType === 2"
                  @filter="filterCostCenter">
          <template>
            <q-icon v-if="payAccount !== ''" class="cursor-pointer" name="clear" @click.stop="payAccount = ''"/>
          </template>
          <template v-slot:no-option>
            <q-item>
              <q-item-section class="text-grey">{{('noResult')}}</q-item-section>
            </q-item>
          </template>
        </q-select>
      </div>
      <div class="single-booking__input-wrapper">
        <span class="single-booking__input-label">Пол</span>
        <q-select class="m-b-10" outlined dense v-model="gender" :disable="!guest" :options="genderData"/>
      </div>
      <div class="single-booking__input-wrapper">
        <span class="single-booking__input-label">Планируемая дата заезда</span>
        <q-input readonly dense outlined v-model="this.store.cardBooking.plannedDateIn">
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                <q-date v-model="plannedDateIn" mask="YYYY-MM-DD"
                        @update:model-value="setDate(plannedDateIn, 'plannedDateIn')">
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Применить" color="primary" flat />
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
      <div class="single-booking__input-wrapper">
        <span class="single-booking__input-label">Планируемая дата выезда</span>
        <q-input readonly dense outlined v-model="this.store.cardBooking.plannedDateOut">
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                <q-date v-model="plannedDateOut" mask="YYYY-MM-DD"
                        @update:model-value="setDate(plannedDateOut, 'plannedDateOut')">
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Применить" color="primary" flat />
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
        </div>
      </div>
    </q-form>
  </div>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'

export default {
  name: 'SingleRoomBooking',
  setup () {
    return {
      store: mainStore(),
      empCode: ref(''),
      passport: ref(null),
      firstName: ref(null),
      lastName: ref(null),
      department: ref(null),
      gender: ref(null),
      jobTitle: ref(null),
      empCodeData: ref(''),
      plannedDateIn: ref(null),
      plannedDateOut: ref(null),
      guest: ref(false),
      guestType: ref(false),
      payAccount: ref(null),
      employeeType: ref(null),
      costCenterData: ref('')
    }
  },
  methods: {
    setDate (date, name) {
      if (name === 'plannedDateIn') this.store.cardBooking.plannedDateIn = date
      if (name === 'plannedDateOut') this.store.cardBooking.plannedDateOut = date
    },
    getDataByEmpCode (empCode) {
      if (empCode != null) {
        this.empCode = empCode
        this.store.getEmployee(this.empCode)
          .then(res => {
            this.store.cardBooking.cardFIO = res.data.firstName + ' ' + res.data.lastName
            this.firstName = res.data.firstName
            this.lastName = res.data.lastName
            this.department = res.data.department
            this.gender = this.store.modifiedGenderRef.find(el => el.value === res.data.gender)
            this.passport = ''
            this.jobTitle = res.data.jobTitle
            this.payAccount = res.data.payAccount
            this.employeeType = res.data.employeeTypeId
          })
      } else {
        this.store.getEmployee(this.empCode?.value ?? '')
          .then(res => {
            this.store.cardBooking.cardFIO = res.data.firstName + ' ' + res.data.lastName
            this.firstName = res.data.firstName
            this.lastName = res.data.lastName
            this.department = res.data.department
            this.gender = this.store.modifiedGenderRef.find(el => el.value === res.data.gender)
            this.passport = ''
            this.jobTitle = res.data.jobTitle
            this.payAccount = res.data.payAccount
            this.employeeType = res.data.employeeTypeId
            this.store.gender = this.store.modifiedGenderRef.find(el => el.value === res.data.genderId)
            this.store.camp = this.store.modifiedLocationRef.find(el => el.value === res.data.campId)
            this.store.block = this.store.modifiedBlockRef.find((el) => el.value === res.data.blockId)
            this.store.room = this.store.modifiedRoomByParam.find((el) => el.value === res.data.roomId)
            this.store.bed = this.store.modifiedBedByParam.find((el) => el.value === res.data.bedId)
          })
      }
    },
    filterFnEmp (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.empCodeData = this.store.modifiedEmployees.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.empCodeData = this.store.modifiedEmployees
      })
    },
    setModelSelectEmp (val) {
      this.empCode = val
    },
    filterCostCenter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.costCenterData = this.store.modifiedCostCenters.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.costCenterData = this.store.modifiedCostCenters
      })
    }
  },
  watch: {
    guest (val) {
      this.passport = ''
      this.empCode = ''
      this.firstName = ''
      this.lastName = ''
      this.jobTitle = ''
      this.department = ''
      this.payAccount = ''
    },
    passport (val) {
      this.store.saveBooking.passport = val
      this.store.putBooking.passport = val
    },
    empCode (val) {
      this.store.saveBooking.empCode = this.empCode?.value ?? ''
      this.store.putBooking.empCode = val
    },
    firstName (val) {
      this.store.saveBooking.firstName = val
      this.store.putBooking.firstName = val
    },
    lastName (val) {
      this.store.saveBooking.lastName = val
      this.store.putBooking.lastName = val
    },
    department (val) {
      this.store.saveBooking.department = val
      this.store.putBooking.department = val
    },
    plannedDateIn (val) {
      this.store.saveBooking.dateIn = val
      this.store.putBooking.dateIn = val
    },
    plannedDateOut (val) {
      this.store.saveBooking.dateOut = val
      this.store.putBooking.dateOut = val
    },
    jobTitle (val) {
      this.store.saveBooking.jobTitle = val
      this.store.putBooking.jobTitle = val
    },
    payAccount (val) {
      this.store.saveBooking.payAccount = val.value
    }
  },
  async created () {
    this.costCenterData = this.store.modifiedCostCenters
    this.empCodeData = this.store.modifiedEmployees
    if (localStorage.getItem('switchType') === 'single') {
      this.guestType = true
      const singleData = localStorage.getItem('selectedData')
      const singleDataObj = JSON.parse(singleData)
      this.empCode = this.store.modifiedEmployees.find((el) => el === singleDataObj.empCode + '' || singleDataObj.name + '')
      this.plannedDateIn = singleDataObj?.dateIn
      this.plannedDateOut = singleDataObj?.dateOut
      this.getDataByEmpCode(singleDataObj.empCode)
    }
    if (localStorage.getItem('switchType') === 'booking1') {
      this.guestType = true
      const singleData = localStorage.getItem('selectedData')
      const singleDataObj = JSON.parse(singleData)
      this.empCode = this.empCodeData.find((el) => el === singleDataObj.empCode)
      this.plannedDateIn = singleDataObj?.dateIn
      this.plannedDateOut = singleDataObj?.dateOut
      this.getDataByEmpCode(singleDataObj.empCode)
    }
    if (localStorage.getItem('switchType') === 'booking') {
      this.plannedDateIn = this.store.cardBooking.plannedDateIn
      this.plannedDateOut = this.store.cardBooking.plannedDateOut
    }
  },
  computed: {
    genderData () {
      return this.store.modifiedGenderRefForParam
    },
    inputRules () {
      return [
        (val) => (!this.guest || (val && val.length > 0)) || 'Обязательно заполните поле'
      ]
    }
  }
}
</script>
