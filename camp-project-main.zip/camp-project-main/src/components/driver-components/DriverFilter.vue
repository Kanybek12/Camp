<template>
  <div class="checkinOut__block">
    <p class="checkinOut__block__title">Фильтрация</p>
    <div class="gp-filter-form__block">
      <q-select label="Таб. №" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
                outlined dense use-input hide-selected fill-input v-model="empCode"
                :options="empData" @filter="empFilter">
        <template v-slot:append>
          <q-icon v-if="empCode !== ''" class="cursor-pointer" name="clear" @click.stop="empCode = ''"/>
        </template>
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
          </q-item>
        </template>
      </q-select>
      <q-select label="Вид поездки" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
                outlined dense use-input hide-selected fill-input
                v-model="appType" :options="appTypeData" @filter="appTypeFilter">
        <template v-slot:append>
          <q-icon v-if="appType !== ''" class="cursor-pointer" name="clear" @click.stop="appType = ''"/>
        </template>
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
          </q-item>
        </template>
      </q-select>
      <q-input label="Дата поездки" class="gp-filter-form__block__input" dense readonly outlined v-model="date">
        <template v-slot:append>
          <q-icon name="event" class="cursor-pointer">
            <q-popup-proxy cover transition-show="scale" transition-hide="scale">
              <q-date v-model="date">
                <div class="row items-center justify-end">
                  <q-btn v-close-popup flat label="Применить" color="primary" />
                </div>
              </q-date>
            </q-popup-proxy>
          </q-icon>
        </template>
      </q-input>
      <q-select label="Тип" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
                outlined dense use-input hide-selected fill-input v-model="guestType"
                :options="guestTypeData" @filter="guestTypeFilter">
        <template v-slot:append>
          <q-icon v-if="guestType !== ''" class="cursor-pointer" name="clear" @click.stop="guestType = ''"/>
        </template>
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">{{('Нет данных')}}</q-item-section>
          </q-item>
        </template>
      </q-select>
      <q-select label="Статус" class="gp-filter-form__block__input" behavior="menu" input-debounce="0"
                outlined dense use-input hide-selected fill-input v-model="status" :options="statusData">
        <template v-slot:append>
          <q-icon v-if="status !== ''" class="cursor-pointer" name="clear" @click.stop="status = ''"/>
        </template>
        <template v-slot:no-option>
          <q-item>
            <q-item-section class="text-grey">
              {{('noResult')}}
            </q-item-section>
          </q-item>
        </template>
      </q-select>
      <div class="gp-filter-form__block__input gp-filter-form__block__btn-block">
        <q-btn icon="filter_list" class="gp-filter-form__block__btn-block__btn" text-color="white" label="Применить"
               flat no-caps @click="filterOn">
          <q-tooltip>Применить фильтр</q-tooltip>
        </q-btn>
        <q-btn icon="filter_list_off" class="gp-filter-form__block__btn-block__btn" text-color="white"
               label="Отменить" flat no-caps @click="filterOff">
          <q-tooltip>Отменить фильтр</q-tooltip>
        </q-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'

export default {
  name: 'DriverFilter',
  created () {
    this.empData = this.store.modifiedEmployees
    this.guestTypeData = this.store.modifiedVisitorsRef
    this.appTypeData = this.store.modifiedApplicationRefVahta
    this.statusData = [
      {
        value: 1,
        label: 'Новая'
      },
      {
        value: 2,
        label: 'Ожидает утверждения'
      },
      {
        value: 3,
        label: 'Утверждена'
      }
    ]
  },
  setup () {
    return {
      store: mainStore(),
      empCode: ref(''),
      guestType: ref(''),
      date: ref(''),
      appType: ref(''),
      status: ref(''),
      statusData: ref(''),
      empData: ref(''),
      guestTypeData: ref(''),
      appTypeData: ref('')
    }
  },
  props: {
    role: {
      type: String
    },
    tab: {
      type: String
    }
  },
  methods: {
    empFilter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.empData = this.store.modifiedEmployees.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.empData = this.store.modifiedEmployees
      })
    },
    appTypeFilter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.appTypeData = this.appTypeData.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.appTypeData = this.store.modifiedApplicationRefVahta
      })
    },
    guestTypeFilter (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.guestTypeData = this.guestTypeData.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.guestTypeData = this.store.modifiedVisitorsRef
      })
    },
    filterOn () {
      this.store.transferDataFilter.page = 1
      this.store.transferDataFilter.empCode = this.empCode.value ?? ''
      this.store.transferDataFilter.visitorType = this.guestType.value ?? ''
      this.store.transferDataFilter.appType = this.appType.value ?? ''
      this.store.transferDataFilter.date = this.date.replaceAll('/', '-') ?? ''
      if (this.tab === 'transferReq') {
        if (this.role === 'bus-dispatcher') {
          this.store.busRequest()
        }
        if (this.role === 'shift-bus-dispatcher') {
          this.store.vahtaRequest()
        }
      } else if (this.tab === 'allReq') {
        if (this.role === 'bus-dispatcher') {
          this.store.allBusRequests()
        }
        if (this.role === 'shift-bus-dispatcher') {
          this.store.allVahtaRequest()
        }
      }
      this.clearFilterForm()
    },
    filterOff () {
      this.clearFilterForm()
      this.filterOn()
    },
    clearFilterForm () {
      this.empCode = ''
      this.guestType = ''
      this.appType = ''
      this.date = ''
    }
  }
}
</script>
