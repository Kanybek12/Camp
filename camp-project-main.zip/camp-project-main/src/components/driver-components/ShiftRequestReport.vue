<template>
  <q-list padding bordered class="shadow-2 rounded-borders ip-rrf__list"
          style="min-width: 500px; height:300px;padding: 0 10px">
    <div class="ip-rrf__title" style="font-weight: 600; margin: 12px 0">{{title}}</div>
    <div class="ip-erf__block">
      <q-input label="Выберите дату" style="width: 60%" class="ip-erf__block__input"
               clearable readonly outlined dense mask="date" v-model="date">
        <template v-slot:append>
          <q-icon name="event" class="cursor-pointer">
            <q-popup-proxy ref="qDateProxy" cover transition-show="scale" transition-hide="scale">
              <q-date v-model="date">
                <div class="row items-center justify-end">
                  <q-btn v-close-popup flat label="Применить" color="primary"/>
                </div>
              </q-date>
            </q-popup-proxy>
          </q-icon>
        </template>
      </q-input>
      <q-btn flat dense no-caps class="ip-rrf__filter__input-second ip-rrf__filter__btn" text-color="white"
             @click="setModelSelectDate">
        <div class="ip-rrf__filter__btn__label">
          <q-icon name="filter_list"/>
          <div>Применить</div>
        </div>
        <q-tooltip>Применить фильтр</q-tooltip>
      </q-btn>
      <q-btn flat dense no-caps class="ip-rrf__filter__input-second ip-rrf__filter__btn" text-color="white"
             @click="cancelFilter">
        <div class="ip-rrf__filter__btn__label">
          <q-icon name="filter_list_off"/>
          <div>Отменить</div>
        </div>
        <q-tooltip>Отменить фильтр</q-tooltip>
      </q-btn>
    </div>
    <q-separator/>
    <q-table row-key="name" separator="cell" style="box-shadow: none;" hide-bottom :columns="columns" :rows="data">
      <template v-slot:header="props">
        <q-tr :props="props">
          <q-th v-for="col in props.cols" :key="col.name" :props="props">
            <div class="tab-head">{{ col.label }}</div>
          </q-th>
        </q-tr>
      </template>
      <template v-slot:body="props">
        <q-tr :props="props">
          <q-td key="name" :props="props">{{ props.row.name }}</q-td>
          <q-td key="transferUp" :props="props"><span style="font-size: 16px">{{ props.row.transferUp }}</span></q-td>
          <q-td key="transferUp" :props="props"><span style=" font-size: 16px">{{ props.row.transferDown }}</span></q-td>
        </q-tr>
      </template>
    </q-table>
  </q-list>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'

const columns = [
  { name: 'name', label: 'Тип посетителя', align: 'left', field: row => row.name },
  { label: 'Подьем', align: 'center', field: 'transferUp', name: 'transferUp' },
  { label: 'Спуск', field: 'transferDown', align: 'center', name: 'transferDown' }
]
export default {
  name: 'ShiftRequestReport',
  props: {
    data: {
      type: Array,
      default: () => []
    },
    title: {
      type: String,
      default: 'Заявки'
    }
  },
  setup () {
    return {
      columns,
      store: mainStore(),
      date: ref('')
    }
  },
  methods: {
    setModelSelectDate () {
      // const val = this.date.replaceAll('/', '-')
      // this.store.getBookingStats(val)
      this.store.vahtaStatistic(this.date.replaceAll('/', '-'))
      // await this.store.vahtaStatusStatistic('')
    },
    cancelFilter () {
      this.date = ''
      // this.store.getStatistics('bookings')
      this.store.vahtaStatistic('')
    }
  }
}
</script>

<style scoped>
.q-table th, .q-table td {
  padding: 0 8px;
  background-color: inherit;
}
.q-table thead tr, .q-table tbody td {
  height: 40px;
}
</style>
