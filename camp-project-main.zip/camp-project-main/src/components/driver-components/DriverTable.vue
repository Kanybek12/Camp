<template>
  <q-table :title="title" :rows="rows" :columns="title === 'Заявки на транспортировку'?columnsOld : columns"
           ref="tableRef" tabindex="0" row-key="transferId"
           :selection="'multiple'"
           v-model:selected="selectedItems" v-model:pagination="pagination">
    <template v-slot:top-right>
      <div class="checkinOut__block__table-list" v-if="title === 'Заявки на транспортировку'">
        <q-btn label="Одобрить" :disable="selectedItems.length < 1" color="green"
               class="checkinOut__block__table-list__btn" no-caps @click="checkout('approve')">
          <q-tooltip>Одобрить заявку</q-tooltip>
        </q-btn>
        <q-btn label="Отклонить" :disable="selectedItems.length < 1"
               color="red" class="checkinOut__block__table-list__btn" no-caps @click="checkout('cancel')">
          <q-tooltip>Отклонить заявку</q-tooltip>
        </q-btn>
      </div>
      <div class="checkinOut__block__table-list" v-else>
        <q-btn label="Отменить" :disable="selectedItems.length < 1"
               color="red" class="checkinOut__block__table-list__btn" no-caps @click="checkout('undo')"/>
        <q-btn icon="file_upload" flat round @click="exportExcel()">
          <q-tooltip>Выгрузить в Excel</q-tooltip>
        </q-btn>
      </div>

      <div class="q-pa-md q-gutter-sm">
        <q-dialog v-model="show_dialog" >
          <q-card>
            <q-card-section>
              <div class="text-h6">Изменить параметры заявки</div>
            </q-card-section>
            <q-card-section>
              <div class="list-constructor__dialog-selects">
                <q-select label="Локация" class="m-b-16 list-constructor__dialog-select"
                          outlined dense v-model="location" :options="locationRef"/>
              </div>
              <q-space/>
              <div class="row q-col-gutter-x-xs" >
                <div class="col-12 text-center self-center">
                  <q-input filled v-model="date" mask="date" label="Планируемая дата поездки" >
                    <template v-slot:append>
                      <q-icon name="event" class="cursor-pointer">
                        <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                          <q-date v-model="date">
                            <div class="row items-center justify-end">
                              <q-btn v-close-popup label="Применить" color="primary" flat />
                            </div>
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </div>
              </div>
            </q-card-section>
            <q-card-actions align="right">
              <q-btn label="Отмена" color="red" flat v-close-popup no-caps/>
              <q-btn label="Сохранить" flatcolor="green" flat v-close-popup no-caps @click="updateTrans"/>
            </q-card-actions>
          </q-card>
        </q-dialog>
      </div>
    </template>
    <template v-slot:no-data>
      <div v-if="!isLoading">Данные отсутствуют</div>
      <div v-else><q-skeleton square/></div>
    </template>
    <template v-slot:body-cell="props">
      <q-td :props="props" :class="(props.row.applicationType === 'Подъём') ? 'bg-blue-grey-1' : 'bg-blue-1'">
        {{props.value}}
      </q-td>
    </template>
    <template v-slot:body-cell-actions="props" v-if="title === 'Список пассажиров'">
      <q-td :class="(props.row.applicationType === 'Подъём') ? 'bg-blue-grey-1' : 'bg-blue-1'" key="actions" :props="props">
        <q-btn dense round flat color="blue" @click="editItem(props.row)" icon="edit"></q-btn>
      </q-td>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination v-model="currentPage" color="grey-10" active-color="grey-10" active-text-color="white"
                      :max="getPages" :max-pages="6" direction-links boundary-links @click="getPage"/>
      </div>
    </template>
  </q-table>
  <q-dialog v-model="confirm" persistent>
    <q-card>
      <q-card-section class="row items-center">
        <span class="q-ml-sm">Вы действительно хотите {{text}} ?</span>
      </q-card-section>
      <q-card-actions align="right">
        <q-btn label="Отмена"
               color="red"
               flat v-close-popup no-caps/>
        <q-btn label="Да"
               flatcolor="green"
               v-close-popup no-caps
               @click="confirmed"/>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'
import { useQuasar } from 'quasar'

const columns = [
  { name: 'empCode', label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', label: 'ФИО', align: 'left', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'visitorType', align: 'left', label: 'Тип', field: 'visitorType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'transferDate', align: 'left', label: 'Планируемая дата поездки', field: 'transferDate', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'locationFrom', align: 'left', label: 'Откуда', field: 'locationFrom', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'locationTo', align: 'left', label: 'Куда', field: 'locationTo', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'applicationType', align: 'left', label: 'Вид поездки', field: 'applicationType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'note', align: 'left', label: 'Примечание', field: 'note', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'creator', align: 'left', label: 'Кем создано', field: 'creator', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'actions', align: 'left', label: 'Изменить', field: 'actions', headerStyle: 'font-size: 13px; font-weight:bold' }
]

const columnsOld = [
  { name: 'empCode', label: 'Таб. №', align: 'left', field: 'empCode', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'fullName', label: 'ФИО', align: 'left', field: 'fullName', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'visitorType', align: 'left', label: 'Тип', field: 'visitorType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'department', align: 'left', label: 'Отдел/Организация', field: 'department', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'transferDate', align: 'left', label: 'Планируемая дата поездки', field: 'transferDate', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'locationFrom', align: 'left', label: 'Откуда', field: 'locationFrom', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'locationTo', align: 'left', label: 'Куда', field: 'locationTo', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'applicationType', align: 'left', label: 'Вид поездки', field: 'applicationType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'note', align: 'left', label: 'Примечание', field: 'note', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'creator', align: 'left', label: 'Кем создано', field: 'creator', headerStyle: 'font-size: 13px; font-weight:bold' }
]

export default {
  name: 'DriverTable',
  created () {
    this.currentPage = 1
    this.store.transferDataFilter.empCode = ''
    this.store.transferDataFilter.visitorType = ''
    this.store.transferDataFilter.appType = ''
    this.store.transferDataFilter.date = ''
    this.getPage()
    this.store.getLocations()
  },
  setup () {
    const $q = useQuasar()
    return {
      isLoading: ref(true),
      store: mainStore(),
      columns,
      columnsOld,
      pagination: {
        descending: false,
        rowsPerPage: 10
      },
      currentPage: ref(1),
      confirm: ref(false),
      selectedItems: ref([]),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      editedItem: {
        dateIn: ref(''),
        locationFrom: ref('')
      },
      date: ref(''),
      show_dialog: ref(false),
      location: ref(''),
      locationRef: ref([])
    }
  },
  props: {
    title: {
      type: String,
      default: 'Заявки на транспортировку'
    },
    list: {
      type: Array
    },
    pages: {
      type: Number
    },
    role: {
      type: String
    }
  },
  computed: {
    rows () {
      return this.list
    },
    getPages () {
      return this.pages
    }
  },
  methods: {
    editItem (item) {
      this.show_dialog = true
      this.editedItem = Object.assign({}, item)
      this.date = this.editedItem.transferDate
      if (this.role === 'bus-dispatcher') {
        this.locationRef = this.store.modifiedLocationsBusDispatcher
        this.location = this.store.modifiedLocationsBusDispatcher.find(el => el.label === this.editedItem.locationFrom) ?? ''
      } else if (this.role === 'shift-bus-dispatcher') {
        this.locationRef = this.store.modifiedLocationsShiftBusDispatcher
        this.location = this.store.modifiedLocationsShiftBusDispatcher.find(el => el.label === this.editedItem.locationFrom) ?? ''
      } else {
        this.locationRef = this.store.modifiedLocations
        this.location = this.store.modifiedLocations.find(el => el.label === this.editedItem.locationFrom) ?? ''
      }
    },
    updateTrans () {
      this.store.checkinTrans({
        transferId: this.editedItem.transferId,
        transferDate: this.date.replaceAll('/', '-'),
        locationId: this.location.value
      })
        .then((el) => {
          if (String(el.data.code).startsWith('2')) {
            this.showNotif(el?.data?.message, 200)
            this.arr = []
          } else {
            this.showNotif(el?.data?.message, 400)
          }
          this.store.transferDataFilter.page = this.currentPage
          if (this.role === 'bus-dispatcher') {
            this.store.busRequest()
            this.store.allBusRequests()
          }
          if (this.role === 'shift-bus-dispatcher') {
            this.store.vahtaRequest()
            this.store.allVahtaRequest()
          }
        }).catch(error => {
          console.log(error)
        })
    },
    getPage () {
      this.store.transferDataFilter.page = this.currentPage
      if (this.role === 'bus-dispatcher') {
        this.store.busRequest()
        this.store.allBusRequests()
      }
      if (this.role === 'shift-bus-dispatcher') {
        this.store.vahtaRequest()
        this.store.allVahtaRequest()
      }
    },
    exportExcel () {
      if (this.role === 'bus-dispatcher') {
        this.store.downloadExcelFile(
          'bus',
          this.store.transferDataFilter.empCode,
          this.store.transferDataFilter.visitorType,
          this.store.transferDataFilter.appType,
          this.store.transferDataFilter.date
        )
      } else if (this.role === 'shift-bus-dispatcher') {
        this.store.downloadExcelFile(
          'vahta',
          this.store.transferDataFilter.empCode,
          this.store.transferDataFilter.visitorType,
          this.store.transferDataFilter.appType,
          this.store.transferDataFilter.date
        )
      }
    },
    checkout (val) {
      if (val === 'approve') {
        this.text = 'одобрить'
      }
      if (val === 'cancel') {
        this.text = 'отклонить'
      }
      if (val === 'undo') {
        this.text = 'отменить'
      }
      this.confirm = true
    },
    confirmed () {
      const arr = []
      this.selectedItems.map(el => {
        return arr.push(el.transferId)
      })
      if (this.text === 'одобрить') {
        arr.forEach(res => {
          if (this.role === 'bus-dispatcher') {
            this.store.busApprove(res)
              .then((el) => {
                if (String(el.data.code).startsWith('2')) {
                  this.showNotif(el?.data?.message, 200)
                  this.selectedItems = []
                  this.store.busRequest()
                } else {
                  this.showNotif(el?.data?.message, 400)
                }
              })
          } else if (this.role === 'shift-bus-dispatcher') {
            this.store.vahtaApprove(res)
              .then((el) => {
                if (String(el.data.code).startsWith('2')) {
                  this.showNotif(el?.data?.message, 200)
                  this.selectedItems = []
                  this.store.vahtaRequest()
                } else {
                  this.showNotif(el?.data?.message, 400)
                }
              })
          }
        })
      }
      if (this.text === 'отклонить') {
        arr.forEach(res => {
          if (this.role === 'bus-dispatcher') {
            this.store.busReject(res)
              .then((el) => {
                if (String(el.data.code).startsWith('2')) {
                  this.showNotif(el?.data?.message, 200)
                  this.selectedVahta = []
                  this.store.busRequest()
                } else {
                  this.showNotif(el?.data?.message, 400)
                }
              })
          } else if (this.role === 'shift-bus-dispatcher') {
            this.store.vahtaReject(res)
              .then((el) => {
                if (String(el.data.code).startsWith('2')) {
                  this.showNotif(el?.data?.message, 200)
                  this.selectedVahta = []
                  this.store.vahtaRequest()
                } else {
                  this.showNotif(el?.data?.message, 400)
                }
              })
          }
        })
      }
      if (this.text === 'отменить') {
        arr.forEach(res => {
          if (this.role === 'bus-dispatcher') {
            this.store.busUndo(res)
              .then((el) => {
                if (String(el.data.code).startsWith('2')) {
                  this.showNotif(el?.data?.message, 200)
                  this.selectedItems = []
                  this.store.allBusRequests()
                } else {
                  this.showNotif(el?.data?.message, 400)
                  this.selectedItems = []
                  this.store.allBusRequests()
                }
              })
          } else if (this.role === 'shift-bus-dispatcher') {
            this.store.vahtaUndo(res)
              .then((el) => {
                if (String(el.data.code).startsWith('2')) {
                  this.showNotif(el?.data?.message, 200)
                  this.selectedItems = []
                  this.store.allVahtaRequest()
                } else {
                  this.showNotif(el?.data?.message, 400)
                  this.selectedItems = []
                  this.store.allVahtaRequest()
                }
              })
          }
        })
      }
    }
  },
  watch: {
    list (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    }
  }
}
</script>
