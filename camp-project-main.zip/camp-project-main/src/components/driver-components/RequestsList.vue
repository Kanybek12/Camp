<template>
  <div class="checkinOut" style="width: 100%">
    <q-tabs v-model="tab" align="justify" narrow-indicator>
      <q-tab label="Заявки на транспортировку" class="bg-grey-3 checkinOut__tab" name="transferReq"/>
      <q-tab label="Список пассажиров" class="bg-grey-3 checkinOut__tab" name="allReq"/>
    </q-tabs>
    <q-tab-panels v-model="tab" animated>
      <q-tab-panel name="transferReq">
        <driver-filter :tab="tab" :role="role"/>
        <driver-table :title="`Заявки на транспортировку`" :pages="pages" :list="listData" :role="role"/>
      </q-tab-panel>
      <q-tab-panel name="allReq">
        <driver-filter :tab="tab" :role="role"/>
        <driver-table :title="`Список пассажиров`" :pages="pages" :list="listData" :role="role"/>
      </q-tab-panel>
    </q-tab-panels>
  </div>
</template>

<script>
import { ref } from 'vue'
import DriverTable from 'components/driver-components/DriverTable'
import { mainStore } from 'stores/main-store'
import DriverFilter from 'components/driver-components/DriverFilter'

export default {
  name: 'RequestsList',
  components: { DriverFilter, DriverTable },
  setup () {
    return {
      store: mainStore(),
      tab: ref('transferReq')
    }
  },
  props: {
    role: {
      type: String
    }
  },
  computed: {
    listData () {
      if (this.tab === 'transferReq') {
        if (this.role === 'bus-dispatcher') return this.store.busReq.content ?? []
        else if (this.role === 'shift-bus-dispatcher') return this.store.vahtaReq.content ?? []
        else return []
      } else {
        if (this.role === 'bus-dispatcher') return this.store.allBusReq.content ?? []
        else if (this.role === 'shift-bus-dispatcher') return this.store.allVahtaReq.content ?? []
        else return []
      }
    },
    pages () {
      if (this.tab === 'transferReq') {
        if (this.role === 'bus-dispatcher') return this.store.busReq.totalPages ?? 1
        else if (this.role === 'shift-bus-dispatcher') return this.store.vahtaReq.totalPages ?? 1
        else return 1
      } else {
        if (this.role === 'bus-dispatcher') return this.store.allBusReq.totalPages ?? 1
        else if (this.role === 'shift-bus-dispatcher') return this.store.allVahtaReq.totalPages ?? 1
        else return 1
      }
    }
  }
}
</script>
