<template>
  <q-card class="ctrp__card">
    <q-card-section class="ctrp__card-title" v-html="`Создание заявки на транспортировку`"/>
    <q-card-section class="column ctrp__card-radio-block">
      <q-radio label="Для себя" color="secondary" val="self" v-model="val"/>
      <q-radio label="Для другого человека" color="secondary" val="another" v-model="val"/>
    </q-card-section>
    <q-separator/>
    <q-card-section class="row ctrp__card-btn">
      <q-btn label="Продолжить" class="ctrp__card-btn-element" flat no-caps :disable="!val" @click="getNexStep"/>
    </q-card-section>
  </q-card>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'

export default {
  name: 'FirstStepCard',
  setup () {
    return {
      store: mainStore(),
      val: ref(false),
      camp: ref(false)
    }
  },
  methods: {
    getNexStep () {
      if (this.val === 'self') this.store.transferData.myApplication = true
      else if (this.val === 'another') this.store.transferData.myApplication = false
      this.$emit('nextStep')
    }
  }
}
</script>
