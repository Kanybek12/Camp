<template>
  <div class="row ctrp__gap-8">
    <div class="row ctrp__gap-8 no-wrap">
      <div class="column ctrp__cards ctrp__gap-8">
        <q-card class="ctrp__cards">
          <q-card-section class="ctrp__cards-element-head" v-html="`Персональные данные`"/>
          <q-separator/>
          <q-card-section class="row ctrp__gap-8 ctrp__cards-element ctrp__cards-element-person-data">
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Тип посетителя`"/>
              <q-select behavior="menu"
                        input-debounce="0"
                        outlined dense
                        use-input hide-selected fill-input
                        v-model="visitorType"
                        :options="visitorsData"/>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Табельный номер`"/>
              <q-select behavior="menu"
                        input-debounce="0"
                        outlined dense
                        use-input hide-selected fill-input
                        v-model="empCode"
                        :options="empCodeData"
                        @filter="filterFnEmp"
                        @input-value="setModelSelectEmp"
                        @update:model-value="getDataByEmpCode()">
                <template v-slot:no-option>
                  <q-item>
                    <q-item-section class="text-grey">
                      {{('noResult')}}
                    </q-item-section>
                  </q-item>
                </template>
              </q-select>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Фамилия`"/>
              <q-input outlined dense
                       v-model="empLastName"/>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Имя`"/>
              <q-input outlined dense
                       v-model="empFirstName"/>
            </div>
            <div class="row ctrp__gap-8 ctrp__cards-element-person-data-element ctrp__cards-element-person-data-element-row">
              <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                <div class="ctrp__cards-element-person-data-element-text" v-html="`Дата рождения`"/>
                <q-input dense readonly outlined
                         v-model="date">
                  <template v-slot:append>
                    <q-icon name="event" class="cursor-pointer">
                      <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                        <q-date minimal v-model="date">
                          <div class="row items-center justify-end">
                            <q-btn v-close-popup label="Close" color="primary" flat />
                          </div>
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
              <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                <div class="ctrp__cards-element-person-data-element-text" v-html="`Пол`"/>
                <q-select class="ctrp__cards-element"
                          behavior="menu"
                          input-debounce="0"
                          outlined dense
                          use-input hide-selected fill-input
                          v-model="empGender"
                          :options="optionGender"/>
              </div>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`ИНН`"/>
              <q-input outlined dense
                       v-model="empPassport"/>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Должность`"/>
              <q-select behavior="menu"
                        input-debounce="0"
                        outlined dense
                        use-input hide-selected fill-input
                        v-model="empJobTitle"
                        :options="optionJobTitle"
                        @filter="filterJobTitle"
                        @input-value="setJobTitleValue">
                <q-tooltip v-if="empJobTitle" style="font-size: 14px">{{empJobTitle}}</q-tooltip>
              </q-select>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Отдел`"/>
              <q-select class="ctrp__cards-element"
                        behavior="menu"
                        input-debounce="0"
                        outlined dense
                        use-input hide-selected fill-input
                        v-model="empDepartment"
                        :options="optionDepartment"
                        @filter="filterDepartment"
                        @input-value="setDepartmentValue">
                <q-tooltip v-if="empDepartment" style="font-size: 14px">{{empDepartment}}</q-tooltip>
              </q-select>
            </div>
            <div class="column ctrp__gap-4" style="width: 100%">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Примечание`"/>
              <q-input outlined dense
                       v-model="note"/>
            </div>
          </q-card-section>
        </q-card>
        <q-card class="ctrp__cards" v-if="camp">
          <q-card-section class="ctrp__cards-element-head" v-html="`Принимающая сторона`"/>
          <q-separator/>
          <q-card-section class="row ctrp__gap-8">
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`ФИО принимающего`"/>
              <q-select input-debounce="0" dense outlined use-input hide-selected fill-input
                        v-model="name" :options="optionName" @filter="filterFn"
                        @input-value="setEmpCodeValue" @update:model-value="getDataByEmpIn">
                <q-tooltip v-if="name" style="font-size: 14px">{{name}}</q-tooltip>
              </q-select>
            </div>
            <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
              <div class="ctrp__cards-element-person-data-element-text" v-html="`Отдел`"/>
              <q-select input-debounce="0" dense outlined use-input hide-selected fill-input
                        v-model="department" :options="optionDepartment">
                <q-tooltip v-if="department" style="font-size: 14px">{{department}}</q-tooltip>
              </q-select>
            </div>
          </q-card-section>
        </q-card>
      </div>
      <div class="row ctrp__gap-8">
        <q-card class="ctrp__cards">
          <q-input placeholder="Дата подъема" class="ctrp__cards-data" dense readonly outlined
                   v-model="dateInUp" v-if="valUp">
            <template v-slot:append>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                  <q-date minimal v-model="dateInUp">
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Close" color="primary" flat />
                    </div>
                  </q-date>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
          <q-card-section class="ctrp__cards-element-head">
            <q-checkbox color="secondary" size="xs" label="Подъем" v-model="valUp"/>
          </q-card-section>
          <q-separator/>
          <q-card-section class="column ctrp__gap-8 ctrp__cards-element">
            <div class="column ctrp__gap-8">
              <q-card class="ctrp__cards-element">
                <q-checkbox label="Автобус" color="secondary" v-model="busUp" :disable="!dateInUp">
                  <q-tooltip v-if="!dateInUp" style="font-size: 16px">Укажите дату подъема</q-tooltip>
                </q-checkbox>
                <q-slide-transition>
                  <div v-show="busUp">
                    <q-card-section class="row ctrp__gap-8">
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                        <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                                  outlined dense use-input hide-selected fill-input
                                  v-model="busUpFrom" :options="optionTransport"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                        <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                                  outlined dense use-input hide-selected fill-input
                                  v-model="busUpTo" :options="optionTransport"/>
                      </div>
                    </q-card-section>
                  </div>
                </q-slide-transition>
              </q-card>
              <q-card class="ctrp__cards-element">
                <q-checkbox label="Вахтовый автобус" color="secondary" v-model="shiftWorkUp" :disable="!dateInUp">
                  <q-tooltip v-if="!dateInUp" style="font-size: 16px">Укажите дату подъема</q-tooltip>
                </q-checkbox>
                <q-slide-transition>
                  <div v-show="shiftWorkUp">
                    <q-card-section class="row ctrp__gap-8">
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                        <q-input class="ctrp__cards-element" outlined dense disable v-model="shiftWorkUpFrom"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                        <q-input class="ctrp__cards-element" outlined dense disable v-model="shiftWorkUpTo"/>
                      </div>
                    </q-card-section>
                  </div>
                </q-slide-transition>
              </q-card>
              <q-card class="ctrp__cards-element">
                <q-checkbox label="Другое" color="secondary" v-model="carUp" :disable="!dateInUp">
                  <q-tooltip v-if="!dateInUp" style="font-size: 16px">Укажите дату подъема</q-tooltip>
                </q-checkbox>
                <q-slide-transition>
                  <div v-show="carUp">
                    <q-card-section class="column ctrp__gap-4">
                      <q-radio label="Личный автомобиль" color="secondary" val="1" v-model="carTypeUp"/>
                      <q-radio label="Служебный автомобиль" color="secondary" val="2" v-model="carTypeUp"/>
                    </q-card-section>
                    <q-separator/>
                    <q-card-section class="row ctrp__gap-8">
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                        <q-select class="ctrp__cards-element" outlined dense use-input v-model="carUpFrom"
                                  :options="optionTransport"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                        <q-select class="ctrp__cards-element" outlined dense use-input v-model="carUpTo"
                                  :options="optionTransport"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Номер машины:`"/>
                        <q-input class="ctrp__cards-element" outlined dense v-model="carNumberUp"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Марка машины:`"/>
                        <q-input class="ctrp__cards-element" outlined dense v-model="carModelUp"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Водитель:`"/>
                        <q-input class="ctrp__cards-element" outlined dense v-model="carDriverUp"/>
                      </div>
                    </q-card-section>
                  </div>
                </q-slide-transition>
              </q-card>
            </div>
          </q-card-section>
        </q-card>
        <q-card class="ctrp__cards">
          <q-input placeholder="Дата спуска" class="ctrp__cards-data" dense readonly outlined
                   v-model="dateInDown" v-if="valDown">
            <template v-slot:append>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                  <q-date minimal v-model="dateInDown">
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Close" color="primary" flat />
                    </div>
                  </q-date>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
          <q-card-section class="ctrp__cards-element-head">
            <q-checkbox color="secondary" size="xs" label="Спуск" v-model="valDown"/>
          </q-card-section>
          <q-separator/>
          <q-card-section class="column ctrp__gap-8 ctrp__cards-element">
            <div class="column ctrp__gap-8">
              <q-card class="ctrp__cards-element">
                <q-checkbox label="Вахтовка" color="secondary" v-model="shiftWorkDown" :disable="!dateInDown">
                  <q-tooltip v-if="!dateInUp" style="font-size: 16px">Укажите дату спуска</q-tooltip>
                </q-checkbox>
                <q-slide-transition>
                  <div v-show="shiftWorkDown">
                    <q-card-section class="row ctrp__gap-8">
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                        <q-input class="ctrp__cards-element" outlined dense disable v-model="shiftWorkUpTo"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                        <q-input class="ctrp__cards-element" outlined dense disable v-model="shiftWorkUpFrom"/>
                      </div>
                    </q-card-section>
                  </div>
                </q-slide-transition>
              </q-card>
              <q-card class="ctrp__cards-element">
                <q-checkbox label="Автобус" color="secondary" v-model="busDown" :disable="!dateInDown">
                  <q-tooltip v-if="!dateInUp" style="font-size: 16px">Укажите дату спуска</q-tooltip>
                </q-checkbox>
                <q-slide-transition>
                  <div v-show="busDown">
                    <q-card-section class="row ctrp__gap-8">
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                        <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                                  outlined dense use-input hide-selected fill-input
                                  v-model="busFromDown" :options="optionTransport"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                        <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                                  outlined dense use-input hide-selected fill-input
                                  v-model="busToDown" :options="optionTransport"/>
                      </div>
                    </q-card-section>
                  </div>
                </q-slide-transition>
              </q-card>
              <q-card class="ctrp__cards-element">
                <q-checkbox label="Другое" color="secondary" v-model="carDown" :disable="!dateInDown">
                  <q-tooltip v-if="!dateInUp" style="font-size: 16px">Укажите дату спуска</q-tooltip>
                </q-checkbox>
                <q-slide-transition>
                  <div v-show="carDown">
                    <q-card-section class="column ctrp__gap-4">
                      <q-radio label="Личный автомобиль" color="secondary" val="1" v-model="carTypeDown"/>
                      <q-radio label="Служебный автомобиль" color="secondary" val="2" v-model="carTypeDown"/>
                    </q-card-section>
                    <q-separator/>
                    <q-card-section class="row ctrp__gap-8">
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                        <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                                  outlined dense use-input hide-selected fill-input
                                  v-model="carDownFrom" :options="optionTransport"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                        <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                                  outlined dense use-input hide-selected fill-input
                                  v-model="carDownTo" :options="optionTransport"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Номер машины:`"/>
                        <q-input class="ctrp__cards-element" outlined dense v-model="carNumberDown"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Марка машины:`"/>
                        <q-input class="ctrp__cards-element" outlined dense v-model="carModelDown"/>
                      </div>
                      <div class="column ctrp__gap-4 ctrp__cards-element">
                        <div class="ctrp__cards-element-person-data-element-text" v-html="`Водитель:`"/>
                        <q-input class="ctrp__cards-element" outlined dense v-model="carDriverDown"/>
                      </div>
                    </q-card-section>
                  </div>
                </q-slide-transition>
              </q-card>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </div>
  <q-separator class="ctrp__separator"/>
  <div class="row ctrp__panel">
          <q-checkbox label="Требуется размещение в лагере" v-model="camp" color="secondary"/>
    <q-checkbox v-model="agree" color="secondary" label="Согласен с условиями подъема/спуска на рудник"/>
    <q-btn label="Отмена" class="ctrp__panel__btn-cancel" outline no-caps @click="getPreviousStep"/>
    <q-btn label="Сохранить заявку" class="ctrp__panel__btn-ok" flat no-caps :disable="nextValid" @click="nextStep"/>
  </div>
<!--  <UpDownForm :val="`up`"/>-->
<!--  <UpDownForm :val="`down`"/>-->
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'

export default {
  name: 'SecondStepCard',
  setup () {
    const $q = useQuasar()
    return {
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      store: mainStore(),
      shiftWorkUp: ref(false),
      shiftWorkDown: ref(false),
      carUp: ref(false),
      carDown: ref(false),
      busUp: ref(false),
      busDown: ref(false),
      valUp: ref(false),
      valDown: ref(false),
      agree: ref(false),
      camp: ref(false),
      visitorType: ref(''),
      name: ref(''),
      empCode: ref(''),
      empLastName: ref(''),
      empFirstName: ref(''),
      date: ref(''),
      dateInUp: ref(''),
      dateInDown: ref(''),
      empGender: ref(''),
      empPassport: ref(''),
      empJobTitle: ref(''),
      note: ref(''),
      empDepartment: ref(''),
      carNumberUp: ref(''),
      carNumberDown: ref(''),
      carModelUp: ref(''),
      carModelDown: ref(''),
      carDriverUp: ref(''),
      carDriverDown: ref(''),
      carUpFrom: ref(''),
      carDownFrom: ref(''),
      carTypeUp: ref(''),
      carTypeDown: ref(''),
      carUpTo: ref(''),
      carDownTo: ref(''),
      department: ref(''),
      busUpTo: ref(''),
      busUpFrom: ref(''),
      optionTransport: ref(''),
      optionGender: ref(''),
      shiftWorkUpFrom: ref('Волна'),
      shiftWorkUpTo: ref('Рудник'),
      busFromDown: ref(''),
      busToDown: ref(''),
      optionJobTitle: ref(''),
      optionDepartment: ref(''),
      optionName: ref(''),
      empCodeData: ref(''),
      visitorsData: ref('')
    }
  },
  created () {
    this.store.transferData.length = 0
    this.empCodeData = this.store.modifiedEmpCodes
    this.visitorsData = this.store.modifiedVisitorsRef
    this.optionJobTitle = this.store.modifiedJobTitles
    this.optionDepartment = this.store.modifiedDepartments
    this.optionName = this.store.modifiedEmployees
    this.optionTransport = this.store.modifiedLocations
    this.optionGender = this.store.modifiedGenderRefForParam
    if (this.store.transferData.myApplication === true) {
      this.empCode = this.store.personData?.empCode
      this.empFirstName = this.store.personData?.firstName
      this.empLastName = this.store.personData?.lastName
      this.visitorType = this.store.modifiedVisitorsRef.find((el) => el.value === this.store.personData?.employeeTypeId)
      this.empDepartment = this.store.modifiedDepartments.find((el) => el.value === this.store.personData?.departmentId)
      this.empJobTitle = this.store.modifiedJobTitles.find((el) => el.value === this.store.personData?.jobTitleId)
      this.empGender = this.store.modifiedGenderRefForParam.find((el) => el.value === this.store.personData?.genderId)
      this.date = this.store.personData?.dateBirth
      this.empPassport = this.store.personData?.sin
      //
      this.busUpTo = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.busTo) ?? ''
      this.busUpFrom = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.busFrom) ?? ''
      this.carTypeUp = this.store.ascendData?.carTypeId + ''
      this.carUpTo = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.carTo) ?? ''
      this.carUpFrom = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.carFrom) ?? ''
      this.carNumberUp = this.store.ascendData?.carNumber ?? ''
      this.carModelUp = this.store.ascendData?.carModel ?? ''
      this.carDriverUp = this.store.ascendData?.driver ?? ''
      //
      this.busToDown = this.store.modifiedLocations.find((el) => el.value === this.store.descendData?.busTo) ?? ''
      this.busFromDown = this.store.modifiedLocations.find((el) => el.value === this.store.descendData?.busFrom) ?? ''
      this.carTypeDown = this.store.descendData?.carTypeId + ''
      this.carDownTo = this.store.modifiedLocations.find((el) => el.value === this.store.descendData?.carTo) ?? ''
      this.carDownFrom = this.store.modifiedLocations.find((el) => el.value === this.store.descendData?.carFrom) ?? ''
      this.carNumberDown = this.store.descendData?.carNumber ?? ''
      this.carModelDown = this.store.descendData?.carModel ?? ''
      this.carDriverDown = this.store.descendData?.driver ?? ''
    }
  },
  computed: {
    nextValid () {
      return this.visitorType &&
        this.empFirstName &&
        this.empLastName &&
        this.date &&
        this.empGender &&
        this.empPassport &&
        !this.agree
    }
  },
  watch: {
    valUp (val) {
      if (val === false) {
        this.dateInUp = ''
        this.busUp = false
        this.shiftWorkUp = false
        this.carUp = false
      }
    },
    valDown (val) {
      if (val === false) {
        this.dateInDown = ''
        this.busDown = false
        this.shiftWorkDown = false
        this.carDown = false
      }
    },
    visitorType (val) {
      console.log(val)
    }
  },
  methods: {
    nextStep () {
      if (this.visitorType.value === 4) {
        const data = {
          changedBy: this.store.personData?.firstName + ' ' + this.store.personData?.lastName,
          firstName: this.empFirstName,
          lastName: this.empLastName,
          pin: this.empPassport,
          note: null,
          dateBirth: this.date.replaceAll('/', '-'),
          genderId: this.empGender.value
        }
        this.store.createGuestRequest(data).then(res => {
          if (res.status === 200) {
            this.empCode = res.data
            this.getNexStep()
          } else {
            this.showNotif(res.data.message, res.data.status)
          }
        })
      } else {
        this.getNexStep()
      }
    },
    getNexStep () {
      this.store.transferData.visitorTypeId = this.visitorType?.value ?? ''
      this.store.transferData.empCode = this.empCode ?? ''
      this.store.transferData.firstName = this.empFirstName ?? ''
      this.store.transferData.lastName = this.empLastName ?? ''
      this.store.transferData.dateBirth = this.date?.replaceAll('/', '-') ?? ''
      this.store.transferData.genderId = this.empGender?.value ?? ''
      this.store.transferData.pin = this.empPassport ?? ''
      this.store.transferData.department = this.empDepartment ?? ''
      this.store.transferData.jobTitle = this.empJobTitle ?? ''
      this.store.transferData.receivingSide = this.department?.label ?? ''
      this.store.transferData.receivingPerson = this.name?.value ?? ''
      this.store.transferData.campLiveNeed = this.camp
      if (this.valUp) {
        this.store.transferData.transferDateFrom = this.dateInUp?.replaceAll('/', '-') ?? ''
        this.store.transferData.busTransferUp = this.busUp
        this.store.transferData.busTransferUpDto.fromLocationId = this.busUpFrom?.value ?? ''
        this.store.transferData.busTransferUpDto.toLocationId = this.busUpTo?.value ?? ''
        this.store.transferData.vahtaTransferUp = this.shiftWorkUp
        if (this.shiftWorkUp) {
          this.store.transferData.vahtaTransferUpDto.toLocationId =
            this.store.modifiedLocations.find((el) => el.label === this.shiftWorkUpTo)?.value ?? ''
          this.store.transferData.vahtaTransferUpDto.fromLocationId =
            this.store.modifiedLocations.find((el) => el.label === this.shiftWorkUpFrom)?.value ?? ''
        }
        this.store.transferData.carTransfer = this.carUp
        this.store.transferData.carTransferDto.fromLocationId = this.carUpFrom.value ?? ''
        this.store.transferData.carTransferDto.toLocationId = this.carUpTo?.value ?? ''
        this.store.transferData.carTransferDto.carModel = this.carModelUp
        this.store.transferData.carTransferDto.carNumber = this.carNumberUp ?? ''
        this.store.transferData.carTransferDto.driverName = this.carDriverUp ?? ''
        this.store.transferData.carTransferDto.carTypeId = Number(this.carTypeUp)
      }
      if (this.valDown) {
        this.store.transferData.transferDateTo = this.dateInDown?.replaceAll('/', '-') ?? ''
        this.store.transferData.busTransferDown = this.busDown
        this.store.transferData.busTransferDownDto.fromLocationId = this.busFromDown?.value ?? ''
        this.store.transferData.busTransferDownDto.toLocationId = this.busToDown?.value ?? ''
        this.store.transferData.vahtaTransferDown = this.shiftWorkDown
        if (this.shiftWorkDown) {
          this.store.transferData.vahtaTransferDownDto.toLocationId =
            this.store.modifiedLocations.find((el) => el.label === this.shiftWorkUpFrom)?.value ?? ''
          this.store.transferData.vahtaTransferDownDto.fromLocationId =
            this.store.modifiedLocations.find((el) => el.label === this.shiftWorkUpTo)?.value ?? ''
        }
        this.store.transferData.carTransferDown = this.carDown
        this.store.transferData.carTransferDownDto.fromLocationId = this.carDownFrom?.value ?? ''
        this.store.transferData.carTransferDownDto.toLocationId = this.carDownTo.value ?? ''
        this.store.transferData.carTransferDownDto.carModel = this.carModelDown ?? ''
        this.store.transferData.carTransferDownDto.carNumber = this.carNumberDown ?? ''
        this.store.transferData.carTransferDownDto.driverName = this.carDriverDown ?? ''
        this.store.transferData.carTransferDownDto.carTypeId = Number(this.carTypeDown) ?? ''
      }
      this.store.transferData.agreement = this.agree
      this.store.saveTransferRequest().then((res) => {
        if (res.data.code) {
          this.showNotif(res.data.message, 500)
        } else {
          this.$emit('nextStep')
        }
      })
    },
    getPreviousStep () {
      this.$emit('previousStep')
    },
    getDataByEmpCode () {
      this.store.getEmployee(this.empCode)
        .then(res => {
          this.empFirstName = res.data?.firstName
          this.empLastName = res.data?.lastName
          this.empGender = this.optionGender.find((el) => el.value === res.data?.gender)
          this.empJobTitle = this.optionJobTitle.find((el) => el.value === res.data?.jobTitleId)
          this.empDepartment = this.store.modifiedDepartments.find((el) => el.value === res.data?.departmentId)
          this.empPassport = res.data?.pin
          this.date = res.data?.dateBirth
        })
    },
    getDataByEmpIn () {
      this.store.getEmployee(this.name.value ?? '')
        .then(res => {
          this.department = this.store.modifiedDepartments.find((el) => el.value === res.data?.departmentId)
        })
    },
    filterFnEmp (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val ? this.empCodeData = this.empCodeData.filter(v => v.toLowerCase().indexOf(needle) > -1)
          : this.empCodeData = this.store.modifiedEmpCodes
      })
    },
    filterJobTitle (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.optionJobTitle = this.optionJobTitle.filter(v => v.label?.toLowerCase().indexOf(needle) > -1)
          : this.optionJobTitle = this.store.modifiedJobTitles
      })
    },
    filterDepartment (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.optionDepartment = this.optionDepartment.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.optionDepartment = this.store.modifiedDepartments
      })
    },
    filterFn (val, update) {
      update(() => {
        const needle = val.toLowerCase()
        val
          ? this.optionName = this.optionName.filter(v => v.label.toLowerCase().indexOf(needle) > -1)
          : this.optionName = this.store.modifiedEmployees
      })
    },
    setEmpCodeValue (val) {
      this.name = val
    },
    setModelSelectEmp (val) {
      this.empCode = val
    },
    setJobTitleValue (val) {
      this.empJobTitle = val
    },
    setDepartmentValue (val) {
      this.empDepartment = val
    }
  }
}
</script>
