<template>
  <q-card class="ctrp__cards">
    <q-input placeholder="Дата" class="ctrp__cards-data" dense readonly outlined v-model="date" v-if="mainCheck">
      <template v-slot:append>
        <q-icon name="event" class="cursor-pointer">
          <q-popup-proxy cover transition-show="scale" transition-hide="scale">
            <q-date minimal v-model="date">
              <div class="row items-center justify-end">
                <q-btn v-close-popup label="Close" color="primary" flat />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
    <q-card-section class="ctrp__cards-element-head">
      <q-checkbox color="secondary" size="xs" :label="getTitle" v-model="mainCheck"/>
    </q-card-section>
    <q-separator/>
    <q-card-section class="column ctrp__gap-8 ctrp__cards-element">
      <div class="column ctrp__gap-8">
        <q-card class="ctrp__cards-element">
          <q-checkbox label="Автобус" color="secondary" v-model="bus" :disable="!date">
            <q-tooltip v-if="!date" style="font-size: 16px">Укажите дату</q-tooltip>
          </q-checkbox>
          <q-slide-transition>
            <div v-show="bus">
              <q-card-section class="row ctrp__gap-8">
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                  <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                            outlined dense use-input hide-selected fill-input
                            v-model="busFrom" :options="getLocations"/>
                </div>
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                  <q-select class="ctrp__cards-element" behavior="menu" input-debounce="0"
                            outlined dense use-input hide-selected fill-input
                            v-model="busTo" :options="getLocations"/>
                </div>
              </q-card-section>
            </div>
          </q-slide-transition>
        </q-card>
        <q-card class="ctrp__cards-element">
          <q-checkbox label="Вахтовый автобус" color="secondary" v-model="shiftWork" :disable="!date">
            <q-tooltip v-if="!date" style="font-size: 16px">Укажите дату</q-tooltip>
          </q-checkbox>
          <q-slide-transition>
            <div v-show="shiftWork">
              <q-card-section class="row ctrp__gap-8">
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                  <q-input class="ctrp__cards-element" outlined dense disable v-model="shiftWorkFrom"/>
                </div>
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                  <q-input class="ctrp__cards-element" outlined dense disable v-model="shiftWorkTo"/>
                </div>
              </q-card-section>
            </div>
          </q-slide-transition>
        </q-card>
        <q-card class="ctrp__cards-element">
          <q-checkbox label="Другое" color="secondary" v-model="car" :disable="!date">
            <q-tooltip v-if="!date" style="font-size: 16px">Укажите дату</q-tooltip>
          </q-checkbox>
          <q-slide-transition>
            <div v-show="car">
              <q-card-section class="column ctrp__gap-4">
                <q-radio label="Личный автомобиль" color="secondary" val="1" v-model="carType"/>
                <q-radio label="Служебный автомобиль" color="secondary" val="2" v-model="carType"/>
              </q-card-section>
              <q-separator/>
              <q-card-section class="row ctrp__gap-8">
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Откуда:`"/>
                  <q-select class="ctrp__cards-element" outlined dense use-input
                            v-model="carFrom" :options="getLocations"/>
                </div>
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Куда:`"/>
                  <q-select class="ctrp__cards-element" outlined dense use-input
                            v-model="carTo" :options="getLocations"/>
                </div>
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Номер машины:`"/>
                  <q-input class="ctrp__cards-element" outlined dense v-model="carNumber"/>
                </div>
                <div class="column ctrp__gap-4 ctrp__cards-element-person-data-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Марка машины:`"/>
                  <q-input class="ctrp__cards-element" outlined dense v-model="carModel"/>
                </div>
                <div class="column ctrp__gap-4 ctrp__cards-element">
                  <div class="ctrp__cards-element-person-data-element-text" v-html="`Водитель:`"/>
                  <q-input class="ctrp__cards-element" outlined dense v-model="carDriver"/>
                </div>
              </q-card-section>
            </div>
          </q-slide-transition>
        </q-card>
      </div>
    </q-card-section>
  </q-card>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'

export default {
  name: 'UpDownForm',
  setup () {
    return {
      store: mainStore(),
      mainCheck: ref(false),
      date: ref(''),
      bus: ref(false),
      busTo: ref(''),
      busFrom: ref(''),
      shiftWork: ref(false),
      shiftWorkFrom: ref(''),
      shiftWorkTo: ref(''),
      car: ref(false),
      carType: ref(),
      carFrom: ref(''),
      carTo: ref(''),
      carNumber: ref(''),
      carModel: ref(''),
      carDriver: ref('')
    }
  },
  props: {
    val: {
      type: String,
      default: ''
    }
  },
  computed: {
    getTitle () {
      return this.val === 'up' ? 'Подъем' : 'Спуск'
    },
    getLocations () {
      return this.store.modifiedLocations
    }
  },
  created () {
    this.store.transferData.length = 0
    if (this.val === 'up') {
      this.shiftWorkFrom = 'Волна'
      this.shiftWorkTo = 'Рудник'
      if (this.store.transferData.myApplication) {
        this.getStoreData(this.store?.ascendData)
      }
    } else if (this.val === 'down') {
      this.shiftWorkFrom = 'Рудник'
      this.shiftWorkTo = 'Волна'
      if (this.store.transferData.myApplication) {
        this.getStoreData(this.store?.descendData)
      }
    }
  },
  watch: {
    date (val) {
      switch (this.val) {
        case 'up': this.store.transferData.transferDateFrom = val?.replaceAll('/', '-') ?? ''
          break
        case 'down': this.store.transferData.transferDateTo = val?.replaceAll('/', '-') ?? ''
      }
    },
    bus (val) {
      switch (this.val) {
        case 'up': this.store.transferData.busTransferUp = val
          break
        case 'down': this.store.transferData.busTransferDown = val
          break
      }
    }
  },
  methods: {
    getStoreData (arr) {
      this.busTo = this.store.modifiedLocations.find((el) => el.value === arr?.busTo) ?? '' // this.store.ascendData
      this.busFrom = this.store.modifiedLocations.find((el) => el.value === arr?.busFrom) ?? ''
      this.carType = arr?.carTypeId + ''
      this.carTo = this.store.modifiedLocations.find((el) => el.value === arr?.carTo)
      this.carFrom = this.store.modifiedLocations.find((el) => el.value === arr?.carFrom)
      this.carNumber = arr?.carNumber ?? ''
      this.carModel = arr?.carModel ?? ''
      this.carDriver = arr?.driver
    }
  }
}
</script>
