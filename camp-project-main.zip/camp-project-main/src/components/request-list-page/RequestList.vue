<template>
  <q-table v-if="tab === 'my-applications'"
           :rows="getRequestsList" :columns="columns"
           v-model:pagination="pagination" v-model:selected="selected"
           row-key="id" selection="multiple">
    <template v-slot:top-right>
      <div class="checkinOut__block__table-list">
        <q-btn label="Отменить" color="red" class="checkinOut__block__table-list__btn"
               :disable="selected.length === 0" @click="cancelRequests" no-caps>
          <q-tooltip>Отменить заявку</q-tooltip>
        </q-btn>
      </div>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination color="grey-10" active-color="grey-10" active-text-color="white"
                      v-model="current"
                      :max="store.requestsData?.totalPages" :max-pages="6"
                      direction-links boundary-links @click="getNext"/>
      </div>
    </template>
    <template v-slot:no-data>
      <div v-if="!isLoading">Данные отсутствуют</div>
      <div v-else><q-skeleton square/></div>
    </template>
  </q-table>
  <q-table v-if="tab === 'applications-for-others'"
           :rows="getRequestsList" :columns="columnsCamp"
           v-model:selected="selected" v-model:pagination="pagination" row-key="id" selection="multiple">
    <template v-slot:top-right>
      <div class="checkinOut__block__table-list">
        <q-btn label="Отменить" color="red" class="checkinOut__block__table-list__btn"
               :disable="selected.length === 0" @click="cancelRequests" no-caps>
          <q-tooltip>Отменить заявку</q-tooltip>
        </q-btn>
      </div>
    </template>
    <template v-slot:body-cell-employee="props">
      <q-td :props="props">{{props.row.employee.name}}<br>
        <span style="font-size: 11px">{{props.row.employee.visitorType}}</span>
      </q-td>
    </template>
    <template v-slot:bottom>
      <div class="checkinOut__block__table-list__pagination">
        <q-pagination v-model="current" color="grey-10" active-color="grey-10" active-text-color="white"
                      :max="store.requestsData?.totalPages" :max-pages="6"
                      direction-links boundary-links @click="getNext"/>
      </div>
    </template>
    <template v-slot:no-data>
      <div v-if="!isLoading">Данные отсутствуют</div>
      <div v-else><q-skeleton square/></div>
    </template>
  </q-table>
</template>

<script>
import { mainStore } from 'stores/main-store'
import { ref } from 'vue'
import { useQuasar } from 'quasar'

const columns = [
  { name: 'id', align: 'left', label: '№', field: 'id', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateCreated', align: 'left', label: 'Дата заявки', field: 'dateCreated', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'applicationType', required: true, label: 'Тип заявки', align: 'left', field: 'applicationType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'plannedDate', align: 'left', label: 'Планируемая дата', field: 'plannedDate', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'info', align: 'left', label: 'Информация', field: 'info', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' }
]

const columnsCamp = [
  { name: 'id', align: 'left', label: '№', field: 'id', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'dateCreated', align: 'left', label: 'Дата заявки', field: 'dateCreated', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'employee', align: 'left', label: 'Информация о посетителе', field: 'employee', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'applicationType', required: true, label: 'Тип заявки', align: 'left', field: 'applicationType', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'plannedDate', align: 'left', label: 'Планируемая дата', field: 'plannedDate', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'info', align: 'left', label: 'Информация', field: 'info', headerStyle: 'font-size: 13px; font-weight:bold' },
  { name: 'status', align: 'left', label: 'Статус', field: 'status', headerStyle: 'font-size: 13px; font-weight:bold' }
  // { name: 'actions', align: 'center', label: 'Действие', field: 'actions' }
]

export default {
  name: 'RequestList',
  setup () {
    const selected = ref([])
    const selectedSettlement = ref([])
    const $q = useQuasar()
    return {
      isLoading: ref(true),
      store: mainStore(),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      columns,
      columnsCamp,
      pagination: {
        descending: false,
        rowsPerPage: 10
      },
      selected,
      selectedSettlement,
      requestType: ref(''),
      locationFrom: ref(''),
      locationTo: ref(''),
      carModel: ref(''),
      carNumber: ref(''),
      transport: ref(''),
      editCard: ref(false),
      bus: ref(false),
      vahta: ref(false),
      companyCar: ref(false),
      personCar: ref(false),
      current: ref(1)
    }
  },
  props: {
    tab: {
      type: String,
      default: ''
    }
  },
  computed: {
    getRequestsList () {
      return this.store.requestsData.content ?? []
    },
    getLocationRef () {
      return this.store.modifiedLocations ?? []
    },
    getTitle () {
      if (this.requestType === 'Подъем') return 'up'
      else return 'down'
    }
  },
  watch: {
    getRequestsList (val) {
      val.length === 0 ? this.isLoading = false : this.isLoading = true
    },
    tab (val) {
      this.current = 1
      this.selected.length = 0
    },
    transport (val) {
      this.bus = false
      this.vahta = false
      this.companyCar = false
      this.personCar = false
      switch (val) {
        case 'bus':
          this.bus = true
          break
        case 'vahta':
          this.vahta = true
          break
        case 'companyCar':
          this.companyCar = true
          break
        case 'personCar':
          this.personCar = true
          break
      }
    }
  },
  methods: {
    editRequest (request) {
      this.requestType = request
      this.editCard = true
    },
    saveRequest () {
      const data = {
        fromLocationId: this.locationFrom?.value ?? '',
        toLocationId: this.locationTo?.value ?? '',
        busTransferDown: this.bus,
        vahtaTransferDown: this.vahta,
        personalCarTransferDown: this.personCar,
        companyCarTransferDown: this.companyCar,
        carModel: this.carModel ?? '',
        carNumber: this.carNumber ?? ''
      }
      console.log(data)
    },
    getNext () {
      if (this.tab === 'my-applications') this.store.getRequestsListByParam('my-applications', this.current)
      else if (this.tab === 'applications-for-others') this.store.getRequestsListByParam('applications-for-others', this.current)
    },
    cancelRequests () {
      const data = []
      this.selected.map(res => data.push({
        id: res.id,
        applicationType: res.applicationType
      }))
      this.store.cancelMyRequests(data).then(res => {
        if (res.status === 200) {
          if (res.data.code === 200) {
            this.store.getRequestsListByParam(this.tab, this.current)
            this.showNotif(res.data.message, res.data.code)
          } else this.showNotif(res.data.message, res.data.code)
        }
      })
      this.selected.length = 0
    }
  }
}
</script>
