<template>
  <div class="row ctrp__gap-8 rlp__main__form">
    <q-card class="column no-wrap max_x_max rlp__main__form-card">
      <q-card-section class="row no-wrap ctrp__gap-8">
        <q-input placeholder="Дата создания" class="checkinOut__block__filter__tabs__input"
                 dense readonly outlined v-model="createdDate">
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                <q-date v-model="createdDate" minimal>
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup flat no-caps label="Применить"
                           style="background-color: #5F8BFF" text-color="white"/>
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
        <q-input placeholder="Планируемая дата" class="checkinOut__block__filter__tabs__input"
                 dense readonly outlined v-model="dateIn">
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                <q-date v-model="dateIn" minimal>
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup flat no-caps label="Применить"
                           style="background-color: #5F8BFF" text-color="white"/>
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
        <q-select label="Тип заявки" class="checkinOut__block__filter__tabs__input" dense outlined
                  v-model="requestType" :options="requestsOptions"/>
        <q-btn label="Применить" class="rlp__main__form-card-flat-btn" text-color="white"
               flat no-caps @click="filterOn">
          <q-tooltip>Применить фильтр</q-tooltip>
        </q-btn>
        <q-btn label="Отменить" class="rlp__main__form-card-flat-btn" text-color="white"
               flat no-caps @click="filterOff">
          <q-tooltip>Отменить фильтр</q-tooltip>
        </q-btn>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'

export default {
  name: 'MyRequestsFilter',
  setup () {
    return {
      store: mainStore(),
      createdDate: ref(''),
      dateIn: ref(''),
      requestType: ref('')
    }
  },
  props: {
    tabMain: {
      type: String
    }
  },
  computed: {
    requestsOptions () {
      return this.store.modifiedApplicationRef
    }
  },
  watch: {
    tabMain (val) {
      this.clearData()
    }
  },
  methods: {
    filterOn () {
      this.store.requestsFilterData.createdDate = this.createdDate?.replaceAll('/', '-') ?? ''
      this.store.requestsFilterData.dateIn = this.dateIn?.replaceAll('/', '-') ?? ''
      this.store.requestsFilterData.requestType = this.requestType?.value ?? ''
      this.chooseTab()
    },
    filterOff () {
      this.clearData()
      this.chooseTab()
    },
    clearData () {
      this.createdDate = ''
      this.dateIn = ''
      this.requestType = ''
      this.store.requestsFilterData.createdDate = ''
      this.store.requestsFilterData.dateIn = ''
      this.store.requestsFilterData.requestType = ''
    },
    chooseTab () {
      if (this.tabMain === 'my-applications') this.store.getRequestsListByParam('my-applications', 1)
      else if (this.tabMain === 'applications-for-others') this.store.getRequestsListByParam('applications-for-others', 1)
    }
  }
}
</script>
