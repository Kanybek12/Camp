<template>
  <q-card class="ctrp__cards-element-climb-data">
    <q-card-section class="ctrp__cards-element-head" v-html="getTitle"/>
    <q-separator/>
    <q-card-section class="column ctrp__gap-8">
      <q-checkbox label="Автобус" class="ctrp__cards-element-climb-data__title" color="secondary"
                  v-model="bus" @update:model-value="clearBus"/>
      <div class="row ctrp__gap-8 no-wrap ctrp__cards-element-climb-data__card">
        <q-select label="Пункт отправки" class="ctrp__cards-element-climb-data__card__element" behavior="menu"
                  input-debounce="0" outlined dense use-input hide-selected fill-input
                  v-model="busFrom" :options="optionTransport"/>
        <q-icon name="keyboard_double_arrow_right" size="22px"/>
        <q-select label="Пункт назначения" class="ctrp__cards-element-climb-data__card__element" behavior="menu"
                  input-debounce="0" outlined dense use-input hide-selected fill-input
                  v-model="busTo" :options="optionTransport"/>
      </div>
    </q-card-section>
    <q-separator/>
    <q-card-section class="column ctrp__gap-8">
      <q-checkbox label="Вахтовка" class="ctrp__cards-element-climb-data__title" color="secondary" v-model="vahta"/>
      <div class="row ctrp__gap-8 no-wrap ctrp__cards-element-climb-data__card">
        <q-input label="Пункт отправки" style="width: 50%" outlined dense disable v-model="shiftCarFrom"/>
        <q-icon name="keyboard_double_arrow_right" size="22px"/>
        <q-input label="Пункт назначения" style="width: 50%" outlined dense disable v-model="shiftCarTo"/>
      </div>
    </q-card-section>
    <q-separator/>
    <q-card-section class="column ctrp__gap-8">
      <q-checkbox label="Другое" class="ctrp__cards-element-climb-data__title" color="secondary"
                  v-model="car" @update:model-value="clearCar"/>
      <div class="row ctrp__gap-8">
        <q-radio label="Личный автомобиль" color="secondary" val="1" v-model="carTypeUp"/>
        <q-radio label="Служебный автомобиль" color="secondary" val="2" v-model="carTypeUp"/>
      </div>
      <div class="row ctrp__gap-8 no-wrap ctrp__cards-element-climb-data__card">
        <q-select label="Пункт отправки" class="ctrp__cards-element-climb-data__card__element" behavior="menu"
                  input-debounce="0" outlined dense use-input hide-selected fill-input
                  v-model="carFrom" :options="optionTransport"/>
        <q-icon name="keyboard_double_arrow_right" size="22px"/>
        <q-select label="Пункт назначения" class="ctrp__cards-element-climb-data__card__element" behavior="menu"
                  input-debounce="0" outlined dense use-input hide-selected fill-input
                  v-model="carTo" :options="optionTransport"/>
      </div>
      <div class="row ctrp__cards-element-climb-data__card">
        <div v-html="`Номер автомобиля`" class="ctrp__cards-element-climb-data__card__text"/>
        <q-input dense outlined class="ctrp__cards-element-climb-data__card__label" v-model="carNumber"/>
      </div>
      <div class="row ctrp__cards-element-climb-data__card">
        <div v-html="`Марка автомобиля`" class="ctrp__cards-element-climb-data__card__text"/>
        <q-input dense outlined class="ctrp__cards-element-climb-data__card__label" v-model="carModel"/>
      </div>
      <div class="row ctrp__cards-element-climb-data__card">
        <div v-html="`Водитель`" class="ctrp__cards-element-climb-data__card__text"/>
        <q-input dense outlined class="ctrp__cards-element-climb-data__card__label" v-model="carDriver"/>
      </div>
    </q-card-section>
    <q-separator/>
    <q-card-section class="row ctrp__gap-8 no-wrap" style="justify-content: space-between">
      <q-btn style="width: 50%" no-caps outline class="ctrp__panel__btn-cancel" label="Очистить" @click="clear"/>
      <q-btn style="width: 50%" no-caps flat class="ctrp__panel__btn-ok" label="Сохранить" @click="save"/>
    </q-card-section>
  </q-card>
</template>

<script>
import { ref } from 'vue'
import { mainStore } from 'stores/main-store'
import { useQuasar } from 'quasar'

export default {
  name: 'ClimbComponent',
  setup () {
    const $q = useQuasar()
    return {
      store: mainStore(),
      showNotif (mess, code) {
        $q.notify({
          message: mess,
          position: 'center',
          color: code === 200 ? 'green' : 'red'
        })
      },
      title: ref(''),
      bus: ref(false),
      vahta: ref(false),
      car: ref(false),
      busFrom: ref(''),
      busTo: ref(''),
      shiftCarFrom: ref('Волна'),
      shiftCarTo: ref('Рудник'),
      carFrom: ref(''),
      carTo: ref(''),
      carTypeUp: ref(),
      carNumber: ref(''),
      carModel: ref(''),
      carDriver: ref(''),
      optionTransport: ref('')
    }
  },
  props: {
    val: {
      type: String,
      default: ''
    }
  },
  computed: {
    getTitle () {
      return this.val === 'up' ? 'Подъем' : 'Спуск'
    }
  },
  mounted () {
    if (this.val === 'up') {
      this.bus = this.store.ascendData?.busTransfer
      this.vahta = this.store.ascendData?.vahtaTransfer
      this.car = this.store.ascendData?.carTransfer
      this.busFrom = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.busFrom)
      this.busTo = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.busTo)
      this.carFrom = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.carFrom)
      this.carTo = this.store.modifiedLocations.find((el) => el.value === this.store.ascendData?.carTo)
      this.carNumber = this.store.ascendData?.carNumber
      this.carModel = this.store.ascendData?.carModel
      this.carTypeUp = this.store.ascendData?.carTypeId + ''
      this.carDriver = this.store.ascendData?.driver
    } else if (this.val === 'down') {
      this.bus = this.store.descendData?.busTransfer
      this.vahta = this.store.descendData?.vahtaTransfer
      this.car = this.store.descendData?.carTransfer
      this.busFrom = this.store.modifiedLocations.find((el) => el.value === this.store.descendData?.busFrom)
      this.busTo = this.store.modifiedLocations.find((el) => el.value === this.store.descendData?.busTo)
      this.carFrom = this.store.modifiedLocations.find((el) => el.value === this.store.descentData?.carFrom)
      this.carTo = this.store.modifiedLocations.find((el) => el.value === this.store.descentData?.carTo)
      this.carNumber = this.store.descentData?.carNumber
      this.carModel = this.store.descentData?.carModel
      this.carTypeUp = this.store.descentData?.carTypeId + ''
      this.carDriver = this.store.descentData?.driver
    }
  },
  methods: {
    clearBus (val) {
      if (val === false) {
        this.busTo = ''
        this.busFrom = ''
      }
    },
    clearCar (val) {
      if (val === false) {
        this.carTo = ''
        this.carFrom = ''
        this.carDriver = ''
        this.carModel = ''
        this.carNumber = ''
        this.carTypeUp = null
      }
    },
    clear () {
      this.busFrom = ''
      this.busTo = ''
      this.carFrom = ''
      this.carTo = ''
      this.carNumber = ''
      this.carModel = ''
      this.carDriver = ''
      this.bus = false
      this.car = false
      this.vahta = false
      this.carTypeUp = null
    },
    save () {
      const data = {
        empCode: this.store.personData?.empCode,
        busTransfer: this.bus,
        busFrom: this.busFrom?.value,
        busTo: this.busTo?.value,
        vahtaTransfer: this.vahta,
        vahtaFrom: this.store.modifiedLocations.find((el) => el.label === 'Волна')?.value,
        vahtaTo: this.store.modifiedLocations.find((el) => el.label === 'Рудник')?.value,
        carTransfer: this.car,
        carFrom: this.carFrom?.value,
        carTo: this.carTo?.value,
        carNumber: this.carNumber ?? '',
        carModel: this.carModel ?? '',
        driver: this.carDriver ?? '',
        carTypeId: this.carTypeUp ?? null
      }
      this.store.updateAscentData(data, this.val === 'up' ? 'ascent' : 'descent').then(res => {
        if (res.status === 200) {
          if (res.data.code === 201) {
            this.showNotif(res.data.message, 200)
          } else {
            this.showNotif(res.data.message, res.data.code)
          }
        }
      })
    }
  },
  created () {
    this.optionTransport = this.store.modifiedLocations
  }
}
</script>
