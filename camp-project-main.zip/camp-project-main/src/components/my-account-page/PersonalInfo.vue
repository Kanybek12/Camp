<template>
  <q-card style="width: 1000px; height: max-content">
    <q-card-section class="ctrp__cards-element-head" v-html="`Личная информация`"/>
    <q-separator/>
    <q-card-section class="column ctrp__gap-8">
      <div class="row no-wrap ctrp__gap-8">
        <div class="column ctrp__gap-4" style="width: 25%">
          <div v-html="`Табельный номер`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="empCode"/>
        </div>
        <div class="column ctrp__gap-4" style="width: 25%">
          <div v-html="`Фамилия`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="empLastName"/>
        </div>
        <div class="column ctrp__gap-4" style="width: 25%">
          <div v-html="`Имя`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="empFirstName"/>
        </div>
        <div class="column ctrp__gap-4" style="width: 25%">
          <div v-html="`Тип сотрудника`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="empType"/>
        </div>
      </div>
      <div class="row no-wrap ctrp__gap-8">
        <div class="column ctrp__gap-4" style="width: 100%">
          <div v-html="`Должность`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="empJobTitle"/>
        </div>
        <div class="column ctrp__gap-4" style="width: 100%">
          <div v-html="`Отдел`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="empDepartment"/>
        </div>
        <div class="column ctrp__gap-4" style="width: 100%">
          <div v-html="`Вид пройденного медосмотра:`" style="width: 100%"/>
          <q-input disable dense outlined style="width: 100%" v-model="medicalExamination"/>
        </div>
      </div>
    </q-card-section>
  </q-card>
</template>

<script>
import { mainStore } from 'stores/main-store'
export default {
  name: 'PersonalInfo',
  props: {
    personInfo: {
      type: Array
    }
  },
  data () {
    return {
      store: mainStore(),
      empCode: '',
      empLastName: '',
      empFirstName: '',
      empDepartment: '',
      empJobTitle: '',
      medicalExamination: '',
      empType: ''
    }
  },
  mounted () {
    this.empCode = this.store.personData?.empCode ?? ''
    this.empLastName = this.store.personData?.lastName ?? ''
    this.empFirstName = this.store.personData?.firstName ?? ''
    this.empType = this.store.modifiedVisitorsRef?.find((el) => el.value === this.store.personData?.employeeTypeId)?.label ?? ''
    this.empDepartment = this.store.modifiedDepartments?.find((el) => el.value === this.store.personData?.departmentId)?.label ?? ''
    this.empJobTitle = this.store.modifiedJobTitles?.find((el) => el.value === this.store.personData?.jobTitleId)?.label ?? ''
    this.medicalExamination = this.store.personData?.medicalExamination ?? ''
  }
}
</script>
