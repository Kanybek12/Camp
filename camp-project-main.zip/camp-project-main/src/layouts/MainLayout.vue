<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container>
      <div style="width: 100%;">
        <Header v-if="!loginRoute" />
      </div>
<!--      <router-view v-slot="{ Component }">-->
<!--        <transition>-->
<!--          <keep-alive>-->
<!--            <component :is="Component" />-->
<!--          </keep-alive>-->
<!--        </transition>-->
<!--      </router-view>-->
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { defineComponent } from 'vue'
import Header from 'components/Header'

export default defineComponent({
  name: 'MainLayout',
  components: {
    Header
  },
  computed: {
    loginRoute () {
      return this.$route.path === '/login'
    }
  }
})
</script>
