<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container>
      <div style="width: 100%;">
        <Header v-if="!loginRoute" />
      </div>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { defineComponent } from 'vue'
import Header from 'components/Header'
import { mainStore } from 'stores/main-store'

export default defineComponent({
  name: 'UserLayout',
  components: {
    Header
  },
  setup () {
    return {
      store: mainStore()
    }
  },
  computed: {
    loginRoute () {
      return this.$route.path === '/login'
    }
  },
  async created () {
    await this.store.getApplicationType()
    // await this.store.getLocations()
    await this.store.getPersonData()
    await this.store.getAscentData()
    await this.store.getDescendData()
    // await this.store.getDescenttData()
    await this.store.getGender()
    await this.store.getRoomCategory()
    await this.store.getEmpCodes()
    await this.store.getSchedule()
    await this.store.getDepartments()
    await this.store.getJobTitles()
    await this.store.getVisitors()
    await this.store.getEmployees()
  }
})
</script>
