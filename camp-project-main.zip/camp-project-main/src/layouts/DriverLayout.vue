<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container>
      <div style="width: 100%;">
        <Header v-if="!loginRoute" />
      </div>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import Header from 'components/Header'
export default {
  name: 'DriverLayout',
  components: {
    Header
  }
}
</script>

<style scoped>

</style>
